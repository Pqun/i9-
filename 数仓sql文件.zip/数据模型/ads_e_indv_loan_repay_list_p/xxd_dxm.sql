---------------------------------------------------------------------------------------------------------------
--脚本名称：贷款还款流水表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive gdata层gdata.ads_e_indv_loan_repay_list_p
--作    者：张礼娟
--开发日期：2021-03-26
--直属经理：程宏明
--来源表  ：odata.sym_mb_acct 账户基本信息表
--来源表  ：odata.sllv_mb_receipt_detail	回收明细表
--来源表  ：odata.sllv_mb_invoice	回收表
--来源表  ：odata.sllv_mb_receipt	单据表
--目标表  ：gdata.ads_e_indv_loan_repay_list_p
--修改历史：
--          1.张礼娟   2021-03-26    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table gdata.ads_e_indv_loan_repay_list_p partition(data_date='${DATA_DATE}',prod_code='110114')
select
     t1.repay_ref_nbr                       as receipt_no --回收号
    ,t1.repay_ref_nbr                       as invoice_no --通知单号
    ,t1.loan_no                             as bill_no --借据号
    ,t1.loan_no                             as acct_no --账号
    ,t1.loan_no                             as cont_no --合同号
    ,t3.cust_id_core                        as cust_id --客户号
    ,t3.currency                            as ccy --币种
    ,row_number() over (partition by loan_no order by biz_date asc )    as term_no --当前期数
    ,'PRI'                                  as amt_type --金额类型
    ,0                                      as mature_amt --应还款金额(本金)
    ,null                                   as mature_date --应还款日期
    ,t1.principal_amt                       as receipt_amt --回收金额
    ,from_unixtime(unix_timestamp(substr(t1.repay_date,1,8),'yyyymmdd'),'yyyy-mm-dd')  as receipt_date --回收日期    
    ,case when t1.repay_type in ('11','12') then 'NS1'
          when t1.repay_type in ('13') then 'ER1'
          when t1.repay_type in ('14') then 'PF1'
         else t1.repay_type end             as early_repay_flag  --提前还款标志
    ,'12'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from odata.slur_dxm_repay_file t1	 
left join odata.ols_loan_cont_info t3
on t1.loan_no = t3.bill_no 
and t3.data_date='${DATA_DATE}' 
and trim(t3.cont_status) in ('105', '106', '107', '108', '109', '110') 
and t3.bddw_end_date='9999-99-99' 
and t3.prd_code ='10091001001'
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and substr(from_unixtime(unix_timestamp(t1.biz_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
and t1.principal_amt >0
union all
select
     t1.repay_ref_nbr                       as receipt_no --回收号
    ,t1.repay_ref_nbr                       as invoice_no --通知单号
    ,t1.loan_no                             as bill_no --借据号
    ,t1.loan_no                             as acct_no --账号
    ,t1.loan_no                             as cont_no --合同号
    ,t3.cust_id_core                        as cust_id --客户号
    ,t3.currency                            as ccy --币种
    ,row_number() over (partition by loan_no order by biz_date asc )    as term_no --当前期数
    ,'INT'                                  as amt_type --金额类型
    ,0                                      as mature_amt --应还款金额(利息)
    ,null                                   as mature_date --应还款日期 
    ,t1.interest_amt                        as receipt_amt --回收金额
    ,from_unixtime(unix_timestamp(substr(t1.repay_date,1,8),'yyyymmdd'),'yyyy-mm-dd')  as receipt_date --回收日期  
    ,case when t1.repay_type in ('11','12') then 'NS1'
          when t1.repay_type in ('13') then 'ER1'
          when t1.repay_type in ('14') then 'PF1'
         else t1.repay_type end             as early_repay_flag  --提前还款标志
    ,'12'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from odata.slur_dxm_repay_file  t1
left join odata.ols_loan_cont_info t3
on t1.loan_no = t3.bill_no 
and t3.data_date='${DATA_DATE}' 
and trim(t3.cont_status) in ('105', '106', '107', '108', '109', '110') 
and t3.bddw_end_date='9999-99-99' 
and t3.prd_code ='10091001001'
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and substr(from_unixtime(unix_timestamp(t1.biz_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
and t1.interest_amt >0
union all 
select
     t1.repay_ref_nbr                       as receipt_no --回收号
    ,t1.repay_ref_nbr                       as invoice_no --通知单号
    ,t1.loan_no                             as bill_no --借据号
    ,t1.loan_no                             as acct_no --账号
    ,t1.loan_no                             as cont_no --合同号
    ,t3.cust_id_core                        as cust_id --客户号
    ,t3.currency                            as ccy --币种
    ,row_number() over (partition by loan_no order by biz_date asc )    as term_no --当前期数
    ,'ODP'                                  as amt_type --金额类型
    ,0                                      as mature_amt --应还款金额(罚息)
    ,null                                   as mature_date --应还款日期
    ,t1.penalty_amt                         as receipt_amt --回收金额
    ,from_unixtime(unix_timestamp(substr(t1.repay_date,1,8),'yyyymmdd'),'yyyy-mm-dd')  as receipt_date --回收日期  
    ,case when t1.repay_type in ('11','12') then 'NS1'
          when t1.repay_type in ('13') then 'ER1'
          when t1.repay_type in ('14') then 'PF1'
         else t1.repay_type end             as early_repay_flag  --提前还款标志
    ,'12'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from odata.slur_dxm_repay_file t1
left join odata.ols_loan_cont_info t3
on t1.loan_no = t3.bill_no 
and t3.data_date='${DATA_DATE}' 
and trim(t3.cont_status) in ('105', '106', '107', '108', '109', '110') 
and t3.bddw_end_date='9999-99-99' 
and t3.prd_code ='10091001001'
where  t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and substr(from_unixtime(unix_timestamp(t1.biz_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
and t1.penalty_amt >0
union all 
select
     t1.repay_ref_nbr                       as receipt_no --回收号
    ,t1.repay_ref_nbr                       as invoice_no --通知单号
    ,t1.loan_no                             as bill_no --借据号
    ,t1.loan_no                             as acct_no --账号
    ,t1.loan_no                             as cont_no --合同号
    ,t3.cust_id_core                        as cust_id --客户号
    ,t3.currency                            as ccy --币种
    ,row_number() over (partition by loan_no order by biz_date asc )    as term_no --当前期数
    ,'FEE'                                  as amt_type --金额类型
    ,0                                      as mature_amt --应还款金额(担保费)
    ,null                                   as mature_date --应还款日期
    ,t1.guar_amt                            as receipt_amt --回收金额
    ,from_unixtime(unix_timestamp(substr(t1.repay_date,1,8),'yyyymmdd'),'yyyy-mm-dd')  as receipt_date --回收日期  
    ,case when t1.repay_type in ('11','12') then 'NS1'
          when t1.repay_type in ('13') then 'ER1'
          when t1.repay_type in ('14') then 'PF1'
         else t1.repay_type end             as early_repay_flag  --提前还款标志
    ,'12'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from odata.slur_dxm_repay_file t1
left join odata.ols_loan_cont_info t3
on t1.loan_no = t3.bill_no 
and t3.data_date='${DATA_DATE}' 
and trim(t3.cont_status) in ('105', '106', '107', '108', '109', '110') 
and t3.bddw_end_date='9999-99-99' 
and t3.prd_code ='10091001001'
where  t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and substr(from_unixtime(unix_timestamp(t1.biz_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
and t1.guar_amt >0