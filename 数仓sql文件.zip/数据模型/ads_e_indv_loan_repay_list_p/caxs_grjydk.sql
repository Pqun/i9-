---------------------------------------------------------------------------------------------------------------
--脚本名称：贷款还款流水表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive gdata层gdata.ads_e_indv_loan_repay_list_p
--作    者：张礼娟
--开发日期：2021-03-26
--直属经理：程宏明
--来源表  ：odata.sym_mb_acct 账户基本信息表
--来源表  ：odata.sllv_mb_receipt_detail	回收明细表
--来源表  ：odata.sllv_mb_invoice	回收表
--来源表  ：odata.sllv_mb_receipt	单据表
--目标表  ：gdata.ads_e_indv_loan_repay_list_p
--修改历史：
--          1.张礼娟   2021-03-26    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table gdata.ads_e_indv_loan_repay_list_p partition(data_date='${DATA_DATE}',prod_code='110118')
select
     t1.receipt_no                          as receipt_no --回收号
    ,t1.invoice_tran_no                     as invoice_no --通知单号
    ,t2.cmisloan_no                         as bill_no --借据号
    ,t2.base_acct_no                        as acct_no --账号
    ,t18.contract_no                        as cont_no --合同号
    ,t2.client_no                           as cust_id --客户号
    ,t2.ccy                                 as ccy --币种
    ,t1.stage_no                            as term_no --当前期数
    ,t1.amt_type                            as amt_type --金额类型
    ,t3.billed_amt *0.99                    as mature_amt --应还款金额
    ,substr(t3.due_date,1,10)               as mature_date --应还款日期
    ,t1.rec_amt-t1.partner_rec_amt          as receipt_amt --回收金额
    ,substr(t4.receipt_date,1,10)           as receipt_date --回收日期
    ,case when t4.receipt_type in ('NS') then 'NS1'                                         
         when t4.receipt_type in ('PO') then 'PF1'       
         else t4.receipt_type 
         end                                as early_repay_flag  --提前还款标志
    ,'01'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from  odata.sllv_nl_receipt_detail t1
inner join odata.sllv_nl_acct t2    
on t1.internal_key = t2.internal_key 
and t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99'
and t2.prod_type='110118'
left join odata.sllv_nl_acct_schedule_detail t3 
on t1.internal_key=t3.internal_key  
and t3.data_date='${DATA_DATE}' 
and t3.bddw_end_date='9999-99-99'
and t1.stage_no=t3.stage_no 
and t1.amt_type=t3.amt_type 
left join odata.sllv_nl_receipt t4 
on t1.receipt_no=t4.receipt_no            
and t4.data_date='${DATA_DATE}' 
and t4.bddw_end_date='9999-99-99'
left join odata.order_main_loan_order t14
on trim(t2.cmisloan_no)=trim(t14.receipt_no) 
and t14.data_date='${DATA_DATE}' 
and t14.bddw_end_date='9999-99-99'
left join odata.order_contract_sign t18 
on trim(t14.loan_id)=trim(t18.loan_id) 
and t18.data_date='${DATA_DATE}' 
and t18.bddw_end_date='9999-99-99' 
and t18.signer_type=1 
and t18.contract_type=2
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and from_unixtime(unix_timestamp(substr(t4.RECEIPT_DATE,1,10),'yyyy-MM-dd'),'yyyy-MM-dd')<='${DATA_DATE}'
union all
select
     t1.seq_no                              as receipt_no --回收号
    ,t1.batch_no                            as invoice_no --通知单号
    ,t1.cmisloan_no                         as bill_no --借据号
    ,t2.base_acct_no                        as acct_no --账号
    ,t18.contract_no                        as cont_no --合同号
    ,t2.client_no                           as cust_id --客户号
    ,t2.ccy                                 as ccy --币种
    ,row_number() over (partition by t1.cmisloan_no order by t1.apply_date asc )  as term_no --当前期数
    ,'PRI'                                  as amt_type --金额类型
    ,t1.pri_amt                             as mature_amt --应还款金额
    ,t1.apply_date                          as mature_date --应还款日期
    ,t1.pri_amt                             as receipt_amt --回收金额
    ,t1.apply_date                          as receipt_date --回收日期
    ,'NS1'                           as early_repay_flag  --提前还款标志
    ,'12'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from  odata.slur_nl_credit_assign_detail t1
inner join odata.sllv_nl_acct t2    
on t1.cmisloan_no = t2.cmisloan_no 
and t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99' 
and t2.prod_type='110118'
left join odata.order_main_loan_order t14
on trim(t2.cmisloan_no)=trim(t14.receipt_no) 
and t14.data_date='${DATA_DATE}' 
and t14.bddw_end_date='9999-99-99'
left join odata.order_contract_sign t18 
on trim(t14.loan_id)=trim(t18.loan_id) 
and t18.data_date='${DATA_DATE}' 
and t18.bddw_end_date='9999-99-99' 
and t18.signer_type=1 
and t18.contract_type=2
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99'
and substr(from_unixtime(unix_timestamp(t1.apply_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
and t1.status='S'
union all
select
     t1.seq_no                              as receipt_no --回收号
    ,t1.batch_no                            as invoice_no --通知单号
    ,t1.cmisloan_no                         as bill_no --借据号
    ,t2.base_acct_no                        as acct_no --账号
    ,t18.contract_no                        as cont_no --合同号
    ,t2.client_no                           as cust_id --客户号
    ,t2.ccy                                 as ccy --币种
    ,row_number() over (partition by t1.cmisloan_no order by t1.apply_date asc )  as term_no --当前期数
    ,'INT'                                  as amt_type --金额类型
    ,t1.int_amt                             as mature_amt --应还款金额
    ,t1.apply_date                          as mature_date --应还款日期
    ,t1.int_amt                             as receipt_amt --回收金额
    ,t1.apply_date                          as receipt_date --回收日期
    ,'NS1'                           as early_repay_flag  --提前还款标志
    ,'12'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from  odata.slur_nl_credit_assign_detail t1
inner join odata.sllv_nl_acct t2    
on t1.cmisloan_no = t2.cmisloan_no 
and t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99' 
and t2.prod_type='110118'
left join odata.order_main_loan_order t14
on trim(t2.cmisloan_no)=trim(t14.receipt_no) 
and t14.data_date='${DATA_DATE}' 
and t14.bddw_end_date='9999-99-99'
left join odata.order_contract_sign t18 
on trim(t14.loan_id)=trim(t18.loan_id) 
and t18.data_date='${DATA_DATE}' 
and t18.bddw_end_date='9999-99-99' 
and t18.signer_type=1 
and t18.contract_type=2
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99'
and substr(from_unixtime(unix_timestamp(t1.apply_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
and t1.status='S'
union all
select
     t1.seq_no                              as receipt_no --回收号
    ,t1.batch_no                            as invoice_no --通知单号
    ,t1.cmisloan_no                         as bill_no --借据号
    ,t2.base_acct_no                        as acct_no --账号
    ,t18.contract_no                        as cont_no --合同号
    ,t2.client_no                           as cust_id --客户号
    ,t2.ccy                                 as ccy --币种
    ,row_number() over (partition by t1.cmisloan_no order by t1.apply_date asc )  as term_no --当前期数
    ,'ODP'                                  as amt_type --金额类型
    ,t1.odp_amt                             as mature_amt --应还款金额
    ,t1.apply_date                          as mature_date --应还款日期
    ,t1.odp_amt                             as receipt_amt --回收金额
    ,t1.apply_date                          as receipt_date --回收日期
    ,'NS1'                           as early_repay_flag  --提前还款标志
    ,'12'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from  odata.slur_nl_credit_assign_detail t1
inner join odata.sllv_nl_acct t2    
on t1.cmisloan_no = t2.cmisloan_no 
and t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99' 
and t2.prod_type='110118'
left join odata.order_main_loan_order t14
on trim(t2.cmisloan_no)=trim(t14.receipt_no) 
and t14.data_date='${DATA_DATE}' 
and t14.bddw_end_date='9999-99-99'
left join odata.order_contract_sign t18 
on trim(t14.loan_id)=trim(t18.loan_id) 
and t18.data_date='${DATA_DATE}' 
and t18.bddw_end_date='9999-99-99' 
and t18.signer_type=1 
and t18.contract_type=2
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99'
and substr(from_unixtime(unix_timestamp(t1.apply_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
and t1.status='S'
union all
select
     t1.seq_no                              as receipt_no --回收号
    ,t1.batch_no                            as invoice_no --通知单号
    ,t1.cmisloan_no                         as bill_no --借据号
    ,t2.base_acct_no                        as acct_no --账号
    ,t18.contract_no                        as cont_no --合同号
    ,t2.client_no                           as cust_id --客户号
    ,t2.ccy                                 as ccy --币种
    ,row_number() over (partition by t1.cmisloan_no order by t1.apply_date asc )  as term_no --当前期数
    ,'FEE'                                  as amt_type --金额类型
    ,t1.fee_amt                             as mature_amt --应还款金额
    ,t1.apply_date                          as mature_date --应还款日期
    ,t1.fee_amt                             as receipt_amt --回收金额
    ,t1.apply_date                          as receipt_date --回收日期
    ,'NS1'                           as early_repay_flag  --提前还款标志
    ,'12'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from  odata.slur_nl_credit_assign_detail t1
inner join odata.sllv_nl_acct t2    
on t1.cmisloan_no = t2.cmisloan_no 
and t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99' 
and t2.prod_type='110118'
left join odata.order_main_loan_order t14
on trim(t2.cmisloan_no)=trim(t14.receipt_no) 
and t14.data_date='${DATA_DATE}' 
and t14.bddw_end_date='9999-99-99'
left join odata.order_contract_sign t18 
on trim(t14.loan_id)=trim(t18.loan_id) 
and t18.data_date='${DATA_DATE}' 
and t18.bddw_end_date='9999-99-99' 
and t18.signer_type=1 
and t18.contract_type=2
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99'
and substr(from_unixtime(unix_timestamp(t1.apply_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
and t1.status='S'