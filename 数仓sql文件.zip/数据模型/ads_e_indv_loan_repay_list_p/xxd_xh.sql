---------------------------------------------------------------------------------------------------------------
--脚本名称：贷款还款流水表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive gdata层gdata.ads_e_indv_loan_repay_list_p
--作    者：张礼娟
--开发日期：2021-03-26
--直属经理：程宏明
--来源表  ：odata.sym_mb_acct 账户基本信息表
--来源表  ：odata.sllv_mb_receipt_detail	回收明细表
--来源表  ：odata.sllv_mb_invoice	回收表
--来源表  ：odata.sllv_mb_receipt	单据表
--目标表  ：gdata.ads_e_indv_loan_repay_list_p
--修改历史：
--          1.张礼娟   2021-03-26    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table gdata.ads_e_indv_loan_repay_list_p partition(data_date='${DATA_DATE}',prod_code='110111')
select 
     t1.receipt_no                          as receipt_no --回收号
    ,t1.invoice_tran_no                     as invoice_no --通知单号
    ,t2.cmisloan_no                         as bill_no --借据号
    ,t2.base_acct_no                        as acct_no --账号
    ,t2.cmisloan_no                         as cont_no --合同号
    ,t2.client_no                           as cust_id --客户号
    ,t2.ccy                                 as ccy --币种
    ,t1.stage_no                            as term_no --当前期数
    ,t1.amt_type                            as amt_type --金额类型
    ,t3.billed_amt                          as mature_amt --应还款金额
    ,from_unixtime(unix_timestamp(t3.due_date,'yyyymmdd'),'yyyy-mm-dd')   as mature_date --应还款日期    
    ,t1.rec_amt                             as receipt_amt --回收金额
    ,substr(t1.receipt_date,1,10)           as receipt_date --回收日期
    ,t4.receipt_type                        as early_repay_flag  --提前还款标志
    ,'12'                                   as receipt_type --回收方式
    ,null                                   as fee_no --费用号
    ,'N'                                    as bad_treat_flag --是否不良贷款处置
    ,null                                   as treat_type --处置方式
    ,null                                   as remark1 --备用字段1
    ,null                                   as remark2 --备用字段2
    ,null                                   as remark3 --备用字段3
    ,null                                   as remark4 --备用字段4
    ,null                                   as remark5 --备用字段5
from  odata.sllv_mb_receipt_detail t1
inner join odata.sllv_mb_acct t2    
on t1.acct_internal_key = t2.internal_key 
and  t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99' 
and t2.prod_type='110111'
left join odata.sllv_mb_invoice t3 
on t1.invoice_tran_no=t3.invoice_tran_no  
and  t3.data_date='${DATA_DATE}' 
and t3.bddw_end_date='9999-99-99'
left join odata.sllv_mb_receipt t4 
on t1.receipt_no=t4.receipt_no            
and  t4.data_date='${DATA_DATE}' 
and t4.bddw_end_date='9999-99-99'
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and substr(t1.receipt_date,1,10)<='${DATA_DATE}'