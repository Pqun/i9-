insert overwrite table smart.yq_yuqinvoice partition(data_date='${DATA_DATE}',source_id='110104')
select 
nvl(t1.loan_no,'')                                                         --借据号
,nvl(t1.cont_no,'')                                                        --贷款编号
,nvl(t3.repay_term,'')                                                     --还款期次
,nvl(t3.no_repay_prin_amt+t3.no_repay_int+t3.no_repay_penalty_int,0)       --逾期总金额
,nvl(t3.no_repay_prin_amt,0)                                               --逾期本金  
,nvl(t3.no_repay_int,0)                                                    --逾期利息  
,nvl(t3.no_repay_penalty_int,0)                                            --逾期罚息
,nvl(regexp_replace(t3.prin_end_date,'-',''),'')                           --应还款日期
,0                                                                         --逾期担保费
,'110104'                                                                  --产品类型
from (select loan_no,cont_no,loan_status,input_time,row_number() over(partition by loan_no order by   last_update_time desc )nul 
from odata.ols_bat_jd_loan_jt_his t1                 
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
) t1
inner join odata.ols_loan_cont_info t2
on trim(t1.cont_no)=trim(t2.bill_no) 
and t2.data_date='${DATA_DATE}'     
and t2.bddw_end_date='9999-99-99' 
and t2.prd_code in ('10011001003') 
and t2.cont_status='107'
and substr(t2.input_time,1,10)<='${DATA_DATE}'
inner join (select loan_no,repay_term,no_repay_prin_amt,no_repay_int,no_repay_penalty_int,prin_end_date,curr_overdue_status,input_time,row_number()over(partition by loan_no,term_no order by last_update_time desc ) nul
from odata.ols_bat_jd_plan_jt_his                             
where data_date='${DATA_DATE}' 
and bddw_end_date='9999-99-99' 
) t3
on  trim(t1.loan_no)=trim(t3.loan_no)  
and t3.nul =1
and t3.curr_overdue_status='1'
and substr(t3.input_time,1,10)='${DATA_DATE}'
where substr(t1.input_time,1,10)<='${DATA_DATE}' and t1.loan_status=2
and t1.nul = 1