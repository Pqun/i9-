sh export_hive_table.sh -d ${DATA_DATE} -t smart.loan_info_detail -s 100000
