insert overwrite table smart.yq_yuqinvoice partition(data_date='${DATA_DATE}',source_id='110143')
select 
nvl(t1.loan_id,'')                                                                   --借据号
,nvl(t1.loan_id,'')                                                                  --贷款编号
,nvl(t2.period,'')                                                                   --还款期次
,nvl(t2.prin_amt+t2.int_amt+t2.odp_amt-t2.paid_prin_amt-t2.paid_int_amt-t2.paid_odp_amt,0) --逾期总金额
,nvl(t2.prin_amt-t2.paid_prin_amt,0)                                                 --逾期本金 
,nvl(t2.int_amt-t2.paid_int_amt,0)                                                   --逾期利息 
,nvl(t2.odp_amt-t2.paid_odp_amt,0)                                                   --逾期罚息
,nvl(t2.repay_date,'')                                                               --应还款日期
,nvl(t2.gurantee_fee_amt-t2.repay_gurantee_fee_amt,0)                                --逾期担保费
,'110143'                                                                            --核心产品编号
from odata.slur_acc_duebill_info t1      -- 借据信息表
left join 
(
 select *
 from odata.slur_acc_repay_plan     -- 还款计划 
 where data_date='${DATA_DATE}' 
 and bddw_end_date='9999-99-99' 
 and from_unixtime(unix_timestamp(channel_date,'yyyymmdd'),'yyyy-mm-dd')<='${DATA_DATE}'
)t2
on t1.loan_id=t2.loan_id 
and date_add(from_unixtime(unix_timestamp(t2.channel_date,'yyyyMMdd'),'yyyy-MM-dd'),4)<= '${DATA_DATE}'
and t2.status='3'  -- 逾期
where t1.data_date='${DATA_DATE}' 
	and t1.bddw_end_date='9999-99-99' 
	and t1.loan_status='3'         -- 逾期