insert overwrite table smart.yq_yuqinvoice partition(data_date='${DATA_DATE}',source_id='110114')
select 
nvl(t1.loan_no,'')                                                                   --借据号
,nvl(t1.loan_no,'')                                                                  --贷款编号
,nvl(t2.term,'')                                                            --还款期次
,nvl(t2.principal_due+t2.interest_due+t2.penalty_due,0)                              --逾期总金额
,nvl(t2.principal_due,0)                                                             --逾期本金 
,nvl(t2.interest_due,0)                                                              --逾期利息 
,nvl(t2.penalty_due,0)                                                               --逾期罚息
,nvl(t2.stmt_date,'')                                                                --应还款日期
,0                                                                                   --逾期担保费
,'110114'                                                                            --核心产品编号
from odata.slur_dxm_loan_file_clear t1 
left join 
(
 select *
 from odata.slur_dxm_repayplan_file_clear 
 where data_date='${DATA_DATE}' 
 and bddw_end_date='9999-99-99' 
 and substr(from_unixtime(unix_timestamp(biz_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
)t2
on t1.loan_no=t2.loan_no 
and date_add(from_unixtime(unix_timestamp(t2.stmt_date,'yyyyMMdd'),'yyyy-MM-dd'),4)<= '${DATA_DATE}'
and t2.status='N' 
where t1.data_date='${DATA_DATE}' 
	and t1.bddw_end_date='9999-99-99' 
	and t1.loan_status='107'