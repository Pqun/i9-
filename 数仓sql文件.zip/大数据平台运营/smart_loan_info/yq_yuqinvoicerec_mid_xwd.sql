insert overwrite table smart.yq_yuqinvoicerec_mid partition(data_date='${DATA_DATE}',source_id='110143')
select 
nvl(t1.loan_id,'')                                                                   --借据号
,nvl(t1.loan_id,'')                                                                  --贷款编号
,nvl(t3.period,'')                                                                   --还款期次
,nvl(max(t1.repay_date),'')                                                          --还款日期
,nvl(sum(t1.repay_amt),0)                                                            --还款金额
,nvl(sum(t1.repay_prin_amt),0)                                                       --已还本金
,nvl(sum(t1.repay_int_amt),0)                                                        --已还利息
,nvl(sum(t1.repay_odp_amt),0)                                                        --已还罚息
,nvl(sum(t1.repay_gua_amt),0)                                                        --已还担保费
,nvl(concat(max(t1.repay_date),' ','22:00:00'),'')                                   --还款时间(无时分秒字段取值)
from odata.slur_acc_repay_detail t1  -- 还款明细
inner join 
(
 select *
 from odata.slur_acc_repay_plan      -- 还款计划 
 where data_date='${DATA_DATE}' 
 and bddw_end_date='9999-99-99' 
 and substr(from_unixtime(unix_timestamp(channel_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
 and status='2'  -- 正常结清
)t3
on t1.loan_id=t3.loan_id  
and t1.period=t3.period
where  t1.data_date='${DATA_DATE}' 
     and t1.bddw_end_date='9999-99-99' 
	 and t1.repay_type='2'  -- 逾期还款
     and substr(from_unixtime(unix_timestamp(t1.channel_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
--	 and substr(t1.update_date,1,10)='${DATA_DATE}'       -- 取锡望贷增量还款数据
	 group by t1.loan_id,t3.period