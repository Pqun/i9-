---------------------------------------------------------------------------------------------------------------
--脚本名称：张家港联合贷出催中间表.sql
--功能描述：生成每日结果数据并插入hive smart.yq_yuqinvoicerec_mid
--作    者：邓权
--开发日期：2022-10-31
--直属经理：方杰
--来源表  ：dwd.slur_bdul_repayplan_file_clear    百度张家港还款计划表
--来源表  ：dwd.slur_bdul_repay_item_file         百度张家港还款明细表
--目标表  ：smart.yq_yuqinvoicerec_mid
--修改历史：
--          1.邓权     2022-11-02    新建
--------------------------------------------------------------------------------------------------------------
insert overwrite table smart.yq_yuqinvoicerec_mid partition (data_date = '${DATA_DATE}',source_id = '110142')
select 
nvl(t1.loan_id,'')                                                                   --借据号
,nvl(t1.loan_id,'')                                                                  --贷款编号
,nvl(t1.term_no,'')                                                                  --还款期次
,nvl(max(from_unixtime(unix_timestamp(substr(t1.tran_date,1,10),'yyyy-MM-dd'),'yyyyMMdd')),'')                                                           --还款日期
,nvl(sum(t1.prin_amt/100)+sum(t1.int_amt/100)+sum(t1.pnlt_int_amt/100),0)            --还款金额
,nvl(sum(t1.prin_amt/100),0)                                                         --已还本金
,nvl(sum(t1.int_amt/100),0)                                                          --已还利息
,nvl(sum(t1.pnlt_int_amt/100),0)                                                     --已还罚息
,0                                                                                   --已还担保费
,nvl(concat(max(from_unixtime(unix_timestamp(substr(t1.tran_date,1,10),'yyyy-MM-dd'),'yyyyMMdd')),' ','22:00:00'),'')                                    --还款时间(无时分秒字段取值)
from odata.slur_bdul_repay_item_file t1 
inner join 
(
 select *
 from odata.slur_bdul_repayplan_file_clear 
 where data_date='${DATA_DATE}' 
 and bddw_end_date='9999-99-99' 
 and loan_mode = '03'    --对客
 and term_status ='5'   --已结清
 and substr(from_unixtime(unix_timestamp(cur_date,'yyyyMMdd'),'yyyy-MM-dd'),1,10)<='${DATA_DATE}'
)t3
on t1.loan_id=t3.loan_id  
and t1.term_no=t3.term_no
where  t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and t1.loan_mode = '03'   --对客
and substr(from_unixtime(unix_timestamp(t1.cur_date,'yyyyMMdd'),'yyyy-MM-dd'),1,10)<='${DATA_DATE}'
group by t1.loan_id,t1.term_no