insert overwrite table smart.yq_yuqinvoicerec partition(data_date='${DATA_DATE}',source_id='110126')
select 
 t1.lending_no
,t1.dkbh
,t1.hqqs
,t1.receipt_date
,t1.receipt_amt
,t1.receipt_pri
,t1.receipt_int
,t1.receipt_pay
,t1.receipt_pre
,t1.receipt_time
from smart.yq_yuqinvoicerec_mid t1 
left join smart.yq_yuqinvoicerec_mid t2
on t1.lending_no = t2.lending_no
and t1.hqqs = t2.hqqs
and t2.data_date=date_sub('${DATA_DATE}',1)
and t2.source_id='110126'
where t1.data_date='${DATA_DATE}'
and t1.source_id='110126'
and t2.lending_no is null
and t2.hqqs is null