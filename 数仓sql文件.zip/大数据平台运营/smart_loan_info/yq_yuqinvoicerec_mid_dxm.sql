insert overwrite table smart.yq_yuqinvoicerec_mid partition(data_date='${DATA_DATE}',source_id='110114')
select 
nvl(t1.loan_no,'')                                                                   --借据号
,nvl(t1.loan_no,'')                                                                  --贷款编号
,nvl(t3.term,'')                                                                  --还款期次
,nvl(max(t1.repay_date),'')                                                          --还款日期
,nvl(sum(t1.principal_amt)+sum(t1.interest_amt)+sum(t1.penalty_amt),0)               --还款金额
,nvl(sum(t1.principal_amt),0)                                                        --已还本金
,nvl(sum(t1.interest_amt),0)                                                         --已还利息
,nvl(sum(t1.penalty_amt),0)                                                          --已还罚息
,0                                                                                   --已还担保费
,nvl(concat(max(t1.repay_date),' ','22:00:00'),'')                                   --还款时间(无时分秒字段取值)
from odata.slur_dxm_repay_file t1 
inner join 
(
 select *
 from odata.slur_dxm_repayplan_file_clear 
 where data_date='${DATA_DATE}' 
 and bddw_end_date='9999-99-99' 
 and substr(from_unixtime(unix_timestamp(biz_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
 and status='Y'
)t3
on t1.loan_no=t3.loan_no  
and t1.term_no=t3.term
where  t1.data_date='${DATA_DATE}' 
     and t1.bddw_end_date='9999-99-99' 
	 and t1.repay_type='11'
     and substr(from_unixtime(unix_timestamp(t1.biz_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
--	 and t1.tran_date=regexp_replace('${DATA_DATE}','-','')      -- 取度小满增量还款数据
	 group by t1.loan_no,t3.term