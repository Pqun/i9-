insert overwrite table smart.yq_yuqinvoicerec_mid partition(data_date='${DATA_DATE}',source_id='110126')
select 
nvl(t1.loan_id,'')                                                                                                          --借据号
,nvl(t1.loan_id,'')                                                                                                         --贷款编号
,nvl(t1.term_no,'')                                                                                                         --还款期次
,nvl(max(t1.xm_tran_date),'')                                                                                               --还款日期
--,case when t2.loan_status='6' then t1.xm_tran_date else '' end                                                            --还款日期
,nvl(sum(t1.prin_amt/100)+sum(t1.int_amt/100)+sum(t1.int_today/100)+sum(t1.pnlt_int_amt/100),0)                             --还款金额
,nvl(sum(t1.prin_amt/100),0)                                                                                                --已还本金
,nvl(sum(t1.int_amt/100)+sum(t1.int_today/100),0)                                                                           --已还利息
,nvl(sum(t1.pnlt_int_amt/100),0)                                                                                            --已还罚息
,0                                                                                                                          --已还担保费
,from_unixtime(unix_timestamp(concat(max(t1.xm_tran_date),max(t1.xm_tran_time)),'yyyyMMddHHmmss'),'yyyyMMdd HH:mm:ss')      --还款时间
from
odata.slur_xm_repay_item_file t1
inner join
(
 select *
 from odata.slur_xm_term_status_file_clear       
 where data_date='${DATA_DATE}' 
 and bddw_end_date='9999-99-99' 
 and term_status='5'
)t2
on t1.loan_id=t2.loan_id  
and t1.term_no=t2.term_no 
where t1.data_date='${DATA_DATE}'
 and t1.bddw_end_date='9999-99-99' 
 and t1.event='11'
and substr(from_unixtime(unix_timestamp(t1.xm_tran_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
--and substr(t1.tran_date,1,10)='${DATA_DATE}'                      -- 取小米增量还款数据
group by t1.loan_id,t1.term_no