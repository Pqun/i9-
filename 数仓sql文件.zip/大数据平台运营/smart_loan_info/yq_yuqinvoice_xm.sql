insert overwrite table smart.yq_yuqinvoice partition(data_date='${DATA_DATE}',source_id='110126')
select 
nvl(t1.loan_id,'')                                                                                     --借据号
,nvl(t1.loan_id,'')                                                                                    --贷款编号
,nvl(t2.term_no,'')                                                                                    --还款期次
,nvl(t2.prin_total/100+t2.int_total/100+t2.pnlt_int_total/100+t2.int_pnlt_total/100,0)                 --逾期总金额
,nvl(t2.prin_total/100,0)                                                                              --逾期本金
,nvl(t2.int_total/100,0)                                                                               --逾期利息
,nvl(t2.pnlt_int_total/100+t2.int_pnlt_total/100,0)                                                    --逾期罚息
,nvl(t2.end_date,'')                                                                                   --应还款日期
,0                                                                                                     --逾期担保费
,'110126'                                                                                              --核心产品编号
from odata.slur_xm_loan_file_clear t1
left join 
(
 select *   
 from odata.slur_xm_term_status_file_clear 
 where data_date='${DATA_DATE}' 
 and bddw_end_date='9999-99-99' 
 and substr(from_unixtime(unix_timestamp(cur_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'
 and term_status='2'
)t2
on t1.loan_id=t2.loan_id  
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and t1.loan_form=2 