---------------------------------------------------------------------------------------------------------------
--脚本名称：张家港联合贷入催表.sql
--功能描述：生成每日结果数据并插入hive smart.yq_yuqinvoice
--作    者：邓权
--开发日期：2022-10-31
--直属经理：方杰
--来源表  ：dwd.slur_bdul_repayplan_file_clear  百度张家港还款计划表
--目标表  ：smart.yq_yuqinvoice             
--修改历史：
--          1.邓权     2022-11-02    新建
--------------------------------------------------------------------------------------------------------------
insert overwrite table smart.yq_yuqinvoice partition (data_date = '${DATA_DATE}',source_id = '110142')
select 
nvl(loan_id,'')                                                                      --借据号
,nvl(loan_id,'')                                                                     --贷款编号
,nvl(term_no,'')                                                                     --还款期次
,nvl((prin_total-prin_repay)/100,0)+nvl((int_total-int_repay)/100,0)+nvl((pnlt_int_total-pnlt_int_repay)/100,0)   --逾期总金额
,nvl((prin_total-prin_repay)/100,0)                                                  --逾期本金 
,nvl((int_total-int_repay)/100,0)                                                    --逾期利息 
,nvl((pnlt_int_total-pnlt_int_repay)/100,0)                                          --逾期罚息
,nvl(end_date,'')                                                                    --应还款日期
--,nvl((service_total-service_repay)/100,0)                                          --逾期担保费
,0                                                                                   --逾期担保费
,'110142'                                                                            --核心产品编号
from odata.slur_bdul_repayplan_file_clear 
where data_date='${DATA_DATE}' 
and bddw_end_date='9999-99-99' 
and loan_mode = '03'      --对客
and term_status ='2'      --逾期
and substr(from_unixtime(unix_timestamp(cur_date,'yyyyMMdd'),'yyyy-MM-dd'),1,10)<='${DATA_DATE}'
and date_add(from_unixtime(unix_timestamp(end_date,'yyyyMMdd'),'yyyy-MM-dd'),4)<= '${DATA_DATE}'    --宽限期为三天