insert overwrite table smart.yq_yuqinvoicerec_mid partition(data_date='${DATA_DATE}',source_id='110104')
select 
nvl(t1.loan_no,'')                                                                      --借据号 
,nvl(t1.cont_no,'')                                                                     --贷款编号
,nvl(t1.repay_num,'')                                                                   --还款期次
,regexp_replace(max(t1.retu_date),'-','')                                               --还款日期
--,case when t2.loan_status='3' then regexp_replace(t1.retu_date,'-','')  else '' end   --还款日期
,nvl(sum(t1.real_amt)+sum(t1.teal_rate)+sum(t1.real_penalty_amt),0)                     --还款金额
,nvl(sum(t1.real_amt),0)                                                                --已还本金
,nvl(sum(t1.teal_rate),0)                                                               --已还利息
,nvl(sum(t1.real_penalty_amt),0)                                                        --已还罚息
,0                                                                                      --已还担保费
,nvl(concat(regexp_replace(max(t1.retu_date),'-',''),' ','22:00:00'),'')                --还款时间
from odata.ols_bat_jd_flow_jt_his t1
inner join 
(
     select loan_no,repay_term,curr_overdue_status,input_time,row_number()  over(partition by loan_no,repay_term order by last_update_time desc) nul 
     from odata.ols_bat_jd_plan_jt_his
     where data_date='${DATA_DATE}'
     and bddw_end_date='9999-99-99' 
) t2
on trim(t1.loan_no)=trim(t2.loan_no) 
and t1.repay_num = t2.repay_term 
and t2.nul = 1
and t2.curr_overdue_status = '0'  -- 非逾期
and substr(t2.input_time,1,10)<='${DATA_DATE}' 
where t1.data_date='${DATA_DATE}' and t1.bddw_end_date='9999-99-99'
  and t1.busi_date<=regexp_replace(date_add('${DATA_DATE}',-1),'-','')
--  and t1.last_update_date='${DATA_DATE}'         -- 取京东金条增量还款数据
  and t1.repay_type='03'
  group by t1.loan_no,t1.cont_no,t1.repay_num