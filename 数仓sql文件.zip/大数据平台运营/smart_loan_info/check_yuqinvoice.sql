select "贷后催收推数-逾期借据状态与网贷系统不符" as `校验描述`,count(1) as `条数` from smart.yq_yuqinvoice t1
left join odata.ols_loan_cont_info t2 
on t1.lending_no = t2.bill_no
and t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99' 
where t1.data_date='${DATA_DATE}' 
and t2.cont_status <> '107'
union all 
select "贷后催收推数-部分逾期借据未推送" as `校验描述`,count(1) as `条数` from  odata.ols_loan_cont_info t1 
left join (
	select lending_no
	from smart.yq_yuqinvoice
	where data_date='${DATA_DATE}' 
	group by lending_no
	) t2 
on t1.bill_no = t2.lending_no
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99'
and t1.cont_status = '107'    -- 逾期
and t2.lending_no is null
and t1.prd_code in ('10011001003','10111001001','10091001001','10091004004') -- 京东 小米 度小满 张家港
union all 
select "贷后催收推数-借据状态恢复正常但未推送逾期还款记录" as `校验描述`,count(1) as `条数`  from smart.yq_yuqinvoice t1
left join smart.yq_yuqinvoicerec t2 
on t1.lending_no = t2.lending_no 
and t1.hqqs = t2.hqqs
and t2.data_date='${DATA_DATE}' 
left join smart.yq_yuqinvoice t3 
on t1.lending_no = t3.lending_no 
and t1.hqqs = t3.hqqs
and t3.data_date='${DATA_DATE}' 
where t1.data_date=date_add('${DATA_DATE}',-1) 
and t3.lending_no is null
and t2.lending_no is null