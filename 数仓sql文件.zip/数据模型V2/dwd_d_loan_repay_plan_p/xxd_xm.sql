---------------------------------------------------------------------------------------------------------------
--脚本名称：贷款还款计划表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive表 dwd.dwd_d_loan_repay_plan_p
--作    者：张礼娟
--开发日期：2020-12-28
--直属经理：程宏明
--来源表  ：odata.slur_xm_term_status_file_clear 小米日初期次信息表
--来源表  ：odata.ols_loan_cont_info             支用合同信息表
--来源表  ：odata.slur_xm_loan_file_clear        小米日初借据信息表
--修改历史：
--          1.张礼娟   2020-12-28    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_loan_repay_plan_p partition(data_date='${DATA_DATE}',prod_code='110126')
select /*+ REPARTITION(1) */ 
    null                     as acct_no       --账号
    ,t1.loan_id              as bill_no       --借据号
    ,t3.total_terms          as term_total    --总期数
    ,t1.term_no              as repay_num     --还款期数
    ,t2.currency             as ccy           --币种
    ,t1.prin_total/100       as pri_amt       --应还本金
    ,t1.int_total_plan/100   as int_amt       --应还利息
    ,from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd') as repay_date    --应还日期
    ,null                    as remark1       --备用字段1
    ,null                    as remark2       --备用字段2
    ,null                    as remark3       --备用字段3
    ,null                    as remark4       --备用字段4
    ,null                    as remark5       --备用字段5    
from  odata.slur_xm_term_status_file_clear  t1
left join odata.ols_loan_cont_info t2
on t1.loan_id = t2.bill_no 
and t2.data_date='${DATA_DATE}' 
--and trim(t2.cont_status) in ('105','107') 
and t2.bddw_end_date='9999-99-99' 
and t2.prd_code ='10111001001'
left join odata.slur_xm_loan_file_clear t3
on t1.loan_id = t3.loan_id
and t3.data_date='${DATA_DATE}' 
--and trim(t2.cont_status) in ('105','107') 
and t3.bddw_end_date='9999-99-99' 
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and substr(from_unixtime(unix_timestamp(t1.cur_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'