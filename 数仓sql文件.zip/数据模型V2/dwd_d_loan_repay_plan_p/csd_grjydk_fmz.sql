---------------------------------------------------------------------------------------------------------------
--脚本名称：贷款还款计划表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive表 dwd.dwd_d_loan_repay_plan_p
--作    者：张礼娟
--开发日期：2020-12-28
--直属经理：程宏明
--修改历史：
--          1.张礼娟   2020-12-28    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_loan_repay_plan_p partition(data_date='${DATA_DATE}',prod_code='110120')
select /*+ REPARTITION(1) */ 
    t1.base_acct_no                  --账号
    ,t1.cmisloan_no                  --借据号
    ,t5.stage_no_max                 --总期数
    ,t2.stage_no                     --还款期数
    ,t1.ccy                          --币种
    ,t2.sched_amt_pri                --应还本金
    ,t2.sched_amt_int                --应还利息
    ,t2.end_date                     --应还日期
    ,''                                                 --备用字段1
    ,''                                                 --备用字段2
    ,''                                                 --备用字段3
    ,''                                                 --备用字段4
    ,''                                                 --备用字段5    
from odata.sllv_mb_acct t1 
left join
(
    select
        internal_key
        ,stage_no
        ,end_date
        ,sum(case when trim(amt_type)='PRI' then sched_amt else 0 end) as sched_amt_pri
        ,sum(case when trim(amt_type)='INT' then sched_amt else 0 end) as sched_amt_int
    from odata.sllv_mb_acct_schedule_detail
    where data_date='${DATA_DATE}' 
    and bddw_end_date='9999-99-99'
    group by internal_key,stage_no,end_date
)t2
on t1.internal_key=t2.internal_key
left join 
(
    select
        acct_internal_key
        ,max( cast(stage_no as int) ) as stage_no_max
    from  odata.sllv_mb_receipt_detail
    where data_date='${DATA_DATE}' 
    and bddw_end_date='9999-99-99'
    group by acct_internal_key
)t4
on t1.internal_key=t4.acct_internal_key
left join
(
    select 
        internal_key
        ,max( cast(stage_no as int) ) as stage_no_max
    from odata.sllv_mb_acct_schedule_detail
    where  data_date='${DATA_DATE}' 
    and bddw_end_date='9999-99-99'
    group by internal_key
) t5  
on t1.internal_key=t5.internal_key
where t1.data_date='${DATA_DATE}' 
and t1.bddw_end_date='9999-99-99' 
and from_unixtime(unix_timestamp(t1.acct_open_date,'yyyymmdd'),'yyyy-mm-dd')<='${DATA_DATE}' 
and t1.prod_type='110120' 
and t1.acct_status<>'C' 
and nvl(t2.stage_no,0)>nvl(t4.stage_no_max,0)