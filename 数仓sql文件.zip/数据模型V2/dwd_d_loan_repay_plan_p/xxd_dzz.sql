---------------------------------------------------------------------------------------------------------------
--脚本名称：贷款还款计划表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive表 dwd.dwd_d_loan_repay_plan_p
--作    者：张礼娟
--开发日期：2020-12-28
--直属经理：程宏明
--来源表  ：odata.slur_dzz_repayplan_file_clear 百度债转贷款还款计划表
--来源表  ：odata.ols_loan_cont_info            支用合同信息表
--来源表  ：odata.slur_dzz_loan_file_clear      百度债转借据文件表
--修改历史：
--          1.张礼娟   2020-12-28    新建
--          2.于国睿   2023-10-24     虚拟卡和债转停批，大于等于2023-09-21的日期写死
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_loan_repay_plan_p partition(data_date='${DATA_DATE}',prod_code='110128')
select /*+ REPARTITION(1) */ 
     null            as acct_no       --账号
    ,t1.loan_no      as bill_no       --借据号
    ,t3.loan_term    as term_total    --总期数
    ,t1.term         as repay_num     --还款期数
    ,t2.currency     as ccy           --币种
    ,t1.principal    as pri_amt       --应还本金
    ,t1.interest     as int_amt       --应还利息
    ,from_unixtime(unix_timestamp(t1.stmt_date,'yyyymmdd'),'yyyy-mm-dd')    as repay_date    --应还日期
    ,null            as remark1       --备用字段1
    ,null            as remark2       --备用字段2
    ,null            as remark3       --备用字段3
    ,null            as remark4       --备用字段4
    ,null            as remark5       --备用字段5   
from  odata.slur_dzz_repayplan_file_clear t1
left join odata.ols_loan_cont_info t2
on t1.loan_no = t2.bill_no 
and t2.data_date='${DATA_DATE}' 
--and trim(t2.cont_status) in ('105','106','107','108','109','110') 
and t2.bddw_end_date='9999-99-99' 
and t2.prd_code ='10091004002'
left join odata.slur_dzz_loan_file_clear t3
    on t3.data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批 
    and t3.bddw_end_date='9999-99-99'
and  t1.loan_no = t3.loan_no 
where --t1.status='N'
        t1.data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批 
and t1.bddw_end_date='9999-99-99' 
and substr(from_unixtime(unix_timestamp(t1.biz_date,'yyyymmdd'),'yyyy-mm-dd'),1,10)<='${DATA_DATE}'