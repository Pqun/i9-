---------------------------------------------------------------------------------------------------------------
--脚本名称：dws_loan_corp_loan_repay_sum_p.sql行内产品取数
--功能描述：生成每日结果数据并插入hive dws层dws.dws_loan_corp_loan_repay_sum_p
--作    者：华天顺
--开发日期：2022-07-19
--直属经理：方杰
--来源表  ：
--来源表  ：
--来源表  ：
--来源表  ：
--来源表  ：
--来源表  ：
--来源表  ：
--目标表  ：dws.dws_loan_corp_loan_repay_sum_p
--修改历史：
--          1.华天顺   2022-07-19    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table dws.dws_loan_corp_loan_repay_sum_p_tmp partition (data_date='${DATA_DATE}',prod_code)
select 
     nvl(t4.cmisloan_no,'')                                                              as bill_no                   --借据号
    ,nvl(t4.base_acct_no,'')                                                             as acct_no                   --账号
    ,t5.relativeserialno2                                                                as cont_no                   --合同号
    ,nvl(t4.client_no,'')                                                                as cust_id                   --客户号
    ,'${DATA_DATE}'                                                                      as biz_date                  --业务日期
    ,from_unixtime(unix_timestamp(t4.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')            as loan_start_date           --贷款起始日期
    ,from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')             as loan_end_date             --贷款结束日期
    ,nvl(from_unixtime(unix_timestamp(t4.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   as loan_clear_date           --贷款结清日
    ,'m'                                                                                 as loan_term_type            --贷款期限类型
    ,nvl(t4.term,t15.stage_no)                                                           as total_loan_terms          --贷款总期数
    ,nvl(t4.ccy,'')                                                                      as ccy                       --币种
    ,t1.stage_no                                                                         as term_no                   --期次
    ,t1.term_start_date                                                                  as term_start_date           --本期开始日期
    ,t1.term_end_date                                                                    as term_mature_date          --本期到期日期
    ,nvl(t2.grace_period_date,'')                                                        as term_grace_date           --本期宽限到期日
    ,''                                                                                  as grace_days                --宽限天数
    ,nvl(t2.receipt_date,'')                                                             as repay_date                --实际还款日
    ,nvl(t11.repay_cnt,'')                                                               as term_repay_cnt            --本期还款次数
    ,case when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date = t1.term_end_date then '01'
          when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date > t1.term_end_date and t2.receipt_date <= t2.grace_period_date then '02'
          when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date > t2.grace_period_date then '03'
          when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date < t1.term_end_date then '04'
          when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='N' then '07'
          when t2.internal_key is null and t4.acct_close_date is not null then '04'
          when t2.internal_key is null then '06'
          when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' < t1.term_end_date then '06'
          when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' >= t1.term_end_date  then '07'
          else '06' end                                                                  as term_repay_status         --还款状态
    ,t1.sched_amt_pri                                                                    as matured_prin              --本期应还本金
    ,nvl(t2.rec_amt_pri,0)                                                               as repaid_prin               --本期已还本金
    ,case when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' >= t1.term_end_date then t1.sched_amt_pri
          when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' < t1.term_end_date then 0
          when t2.internal_key is not null and t2.receipt_date is not null and t2.receipt_date > t1.term_end_date then t1.sched_amt_pri-nvl(t2.rec_amt_pri,0)
          when t2.internal_key is null then 0 --未关联上，期次还未开始，直接置0
          else 0  end                                                                    as overdue_prin              --本期逾期本金
    ,t1.sched_amt_int                                                                    as matured_int               --本期应还利息
    ,t2.rec_amt_int                                                                      as repaid_int                --本期已还利息
    ,case when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' >= t1.term_end_date then t1.sched_amt_int
          when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' < t1.term_end_date then 0
          when t2.internal_key is not null and t2.receipt_date is not null and t2.receipt_date > t1.term_end_date then t1.sched_amt_int-nvl(t2.rec_amt_int,0)
          when t2.internal_key is null then 0  --未关联上，期次还未开始，直接置0
          else 0  end                                                                    as overdue_int               --本期逾期利息
    ,nvl(t1.sched_amt_fee,0)                                                             as matured_fee               --本期应还担保费
    ,nvl(t2.rec_amt_fee,0)                                                               as repaid_fee                --本期已还担保费
    ,nvl(t3.billed_amt,0)                                                                as matured_pena              --本期应还罚息
    ,nvl(t3.billed_amt-t3.outstanding,0)                                                 as repaid_pena               --本期已还罚息
    ,case when t2.fully_settled ='Y' then t2.receipt_date
          when t4.acct_close_date is not null then from_unixtime(unix_timestamp(t4.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd')
          else '' end                                                                    as term_clear_date           --本期还清日期
    ,case when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled = 'Y' and t2.receipt_date = t1.term_end_date then 0
          when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled = 'Y' then if(datediff(t2.receipt_date,t1.term_end_date)<0,0,datediff(t2.receipt_date,t1.term_end_date))
          when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled = 'N' then if(datediff('${DATA_DATE}',t1.term_end_date)<0,0,datediff('${DATA_DATE}',t1.term_end_date)+1)
          when t2.internal_key is not null and t2.receipt_date is null then if(datediff('${DATA_DATE}',t1.term_end_date)<0,0,datediff('${DATA_DATE}',t1.term_end_date)+1)
          when t2.internal_key is null then 0  --未关联上，期次还未开始，直接置空值
      end                                                                                as overdue_days              --本期逾期天数
	 ,0                                                                                  as adv_repay_fee             --提前还款手续费
	 ,case when t4.accounting_status='FYJ' then nvl(t2.non_accru_bal,0) else 0 end       as non_accru_bal             --非应计本金
	 ,case when t4.accounting_status='FYJ' then nvl(t2.aoff_bal_int,0)+nvl(t3.outstanding,0) 
	       else 0 end                                                                    as aoff_bal_int              --表外利息
     ,nvl(t4.prod_type,'')                                                               as prod_code                 --产品号
from (
    select 
         a.internal_key
        ,a.stage_no              as stage_no                                                               --期次
        ,from_unixtime(unix_timestamp(min(a.start_date),'yyyyMMdd'),'yyyy-MM-dd')      as term_start_date  --期次开始日期
        ,from_unixtime(unix_timestamp(max(a.end_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_end_date    --期次到期日期
        ,sum(case when amt_type ='PRI' then a.sched_amt else 0 end) as sched_amt_pri                       --计划本金
        ,sum(case when amt_type ='INT' then a.sched_amt else 0 end) as sched_amt_int                       --计划利息
        ,sum(case when amt_type ='FEE' then a.sched_amt else 0 end) as sched_amt_fee                       --计划费用
        ,max(pri_outstanding) as pri_outstanding                                                           --剩余未到期本金
    from odata.sym_mb_acct_schedule_detail a
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    group by 
         a.internal_key
        ,a.stage_no
        ,a.start_date
        ,a.end_date
    ) t1 
                 --取回收的明细信息
left join (
    select 
         a.internal_key
        ,a.stage_no  --期次
        ,min(a.fully_settled)    as fully_settled --是否收回标识(min 取N)
        ,from_unixtime(unix_timestamp(min(c.start_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_start_date    --期次开始期日
        ,from_unixtime(unix_timestamp(max(a.grace_period_date),'yyyyMMdd'),'yyyy-MM-dd') as grace_period_date  --期次宽限日
        ,sum(case when a.amt_type = 'PRI' then b.rec_amt else 0 end) as rec_amt_pri                            --回收本金
        ,sum(case when a.amt_type = 'INT' then b.rec_amt else 0 end) as rec_amt_int                            --回收利息
        ,sum(case when a.amt_type = 'FEE' then b.rec_amt else 0 end) as rec_amt_fee                            --回收费用(担保费）
		,sum(case when a.amt_type = 'PRI' then a.outstanding else 0 end) as non_accru_bal                          --非应计本金
		,sum(case when a.amt_type = 'INT'  then a.outstanding else 0 end) as aoff_bal_int                          --非应计本金
        ,max(substr(b.receipt_date,1,10)) as receipt_date                                                      --回收日期
		,max(b.receipt_no)  as receipt_no
    from odata.sym_mb_invoice a
    left join odata.sym_mb_receipt_detail b
    on b.data_date = '${DATA_DATE}'
    and b.bddw_end_date = '9999-99-99'
    and a.invoice_tran_no = b.invoice_tran_no
    and a.internal_key = b.acct_internal_key
    and a.stage_no = b.stage_no
    and a.amt_type = b.amt_type
    left join odata.sym_mb_acct_schedule_detail c
    on c.data_date = '${DATA_DATE}'
    and c.bddw_end_date = '9999-99-99'
    and a.internal_key = c.internal_key
    and a.stage_no = c.stage_no
    and a.amt_type = c.amt_type
    where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and a.amt_type <> 'ODP'
    group by 
         a.internal_key
        ,a.stage_no
        ,c.start_date
    ) t2
on t1.internal_key = t2.internal_key
and t1.stage_no = t2.stage_no
and t1.term_start_date = t2.term_start_date
left join (
    select 
         internal_key
        ,stage_no
        ,sum(billed_amt)  as billed_amt  --可能会有多笔罚息，故按期次进行汇总
        ,sum(outstanding) as outstanding
    from odata.sym_mb_invoice  --取罚息(罚息在单据表生成，罚息的最后还款日与正常期次的还款日不一致，故在此处单独提取。还款计划明细表中没有罚息记录)
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    and amt_type = 'ODP'
    group by 
         internal_key
        ,stage_no
    ) t3
on t1.internal_key = t3.internal_key
and t1.stage_no = t3.stage_no
inner join odata.sym_mb_acct t4
on t4.data_date = '${DATA_DATE}'
and t4.bddw_end_date = '9999-99-99'
and from_unixtime(unix_timestamp(t4.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')<='${DATA_DATE}'
and t4.lead_acct_flag='N'
and t4.source_module ='CL'
and t1.internal_key = t4.internal_key
inner join odata.als_business_duebill t5
on t5.data_date = '${DATA_DATE}'
and t5.bddw_end_date = '9999-99-99'
and t4.cmisloan_no=t5.serialno
--获取每期还款次数
left join (
     select acct_internal_key
              ,stage_no
              ,count(*) as repay_cnt
              from (
          select 
               acct_internal_key
              ,stage_no
              ,substr(receipt_date,1,10)
          from odata.sym_mb_receipt_detail  --单笔还款分本金和利息多条数据，暂时按还款日期汇总
          where data_date = '${DATA_DATE}'
          and bddw_end_date = '9999-99-99'
          group by 
               acct_internal_key
              ,stage_no
              ,substr(receipt_date,1,10)) a
              group by 
               acct_internal_key
              ,stage_no) t11
on  t1.internal_key = t11.acct_internal_key
and t1.stage_no = t11.stage_no
--剔除发放冲正的借据
left join odata.sym_mb_drawdown t13
on t1.internal_key = t13.internal_key
and t13.data_date = '${DATA_DATE}'
and t13.bddw_end_date = '9999-99-99'
and t13.reversal = 'Y'  
left join (select 
         a.internal_key
        ,max(a.stage_no)              as stage_no                                                               --期次
    from odata.sym_mb_acct_schedule_detail a
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    group by 
         a.internal_key) t15
on t1.internal_key=t15.internal_key
where 
    t13.internal_key is null --剔除发放冲正的借据
	
union all

select 
     t3.serialno                                                                           as bill_no              --借据号
    ,t3.serialno                                                                           as acct_no              --账号
    ,t3.relativeserialno2                                                                  as cont_no              --合同号
    ,t3.customerid                                                                         as cust_id              --客户号
    ,'${DATA_DATE}'                                                                        as biz_date             --业务日期
    ,from_unixtime(unix_timestamp(t4.loan_date,'yyyyMMdd'),'yyyy-MM-dd')                   as loan_start_date      --贷款起始日期
    ,from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')               as loan_end_date        --贷款结束日期
    ,nvl(from_unixtime(unix_timestamp(t4.real_maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as loan_clear_date      --贷款结清日
    ,'m'                                                                                   as loan_term_type       --贷款期限类型
    ,t4.term                                                                               as total_loan_terms     --贷款总期数
    ,'CNY'                                                                                 as ccy                  --币种
    ,t1.term                                                                               as term_no              --期次
    ,from_unixtime(unix_timestamp(t1.inte_date,'yyyyMMdd'),'yyyy-MM-dd')                   as term_start_date      --本期开始日期
    ,from_unixtime(unix_timestamp(t1.due_date,'yyyyMMdd'),'yyyy-MM-dd')                    as term_mature_date     --本期到期日期
    ,from_unixtime(unix_timestamp(t1.grace_date,'yyyyMMdd'),'yyyy-MM-dd')                  as term_grace_date      --本期宽限到期日
    ,datediff(from_unixtime(unix_timestamp(t1.grace_date,'yyyyMMdd'),'yyyy-MM-dd'),from_unixtime(unix_timestamp(t1.due_date,'yyyyMMdd'),'yyyy-MM-dd')) as grace_days                         --宽限天数
    ,nvl(t5.receipt_date,'')                                                               as repay_date           --实际还款日
    ,nvl(t5.repay_cnt,'')                                                                  as term_repay_cnt       --本期还款次数
    ,case when plan_status='04' then '07'
 	      when plan_status='02' and t1.settle_date=t1.due_date then '01'
		  when plan_status='02' and t1.settle_date>t1.due_date and t1.settle_date<=t1.grace_date then '02'
		  when plan_status='02' and  t1.settle_date>t1.grace_date then '03'
		  when plan_status='02' and  t1.settle_date<t1.due_date then '04'
		  when plan_status='01' and replace('${DATA_DATE}','-','')>=t1.due_date then '07'
		  when plan_status='01' and replace('${DATA_DATE}','-','')<t1.due_date then '06'
	  end                                                                                  as term_repay_status    --还款状态
    ,t1.prin_amt                                                                           as matured_prin         --本期应还本金
    ,t1.paid_prin_amt                                                                      as repaid_prin          --本期已还本金
    ,case when plan_status='01' and replace('${DATA_DATE}','-','')>=t1.due_date then t1.prin_amt-t1.paid_prin_amt
	      else 0
	  end                                                                                  as overdue_prin         --本期逾期本金
    ,t1.int_amt                                                                            as matured_int          --本期应还利息
    ,t1.paid_int_amt                                                                       as repaid_int           --本期已还利息
    ,case when plan_status='01' and replace('${DATA_DATE}','-','')>=t1.due_date then t1.int_amt-t1.paid_int_amt
	      else 0
	  end                                                                                  as overdue_int          --本期逾期利息
    ,0                                                                                     as matured_fee          --本期应还担保费
    ,0                                                                                     as repaid_fee           --本期已还担保费
    ,t1.oint_amt                                                                           as matured_pena         --本期应还罚息
    ,t1.paid_oint_amt                                                                      as repaid_pena          --本期已还罚息
    ,from_unixtime(unix_timestamp(t1.settle_date,'yyyyMMdd'),'yyyy-MM-dd')                 as term_clear_date      --本期还清日期
    ,case when t1.plan_status='04' then datediff(t1.settle_date,t1.due_date)+1
  	      else if(datediff(t1.settle_date,t1.due_date)<0,0,datediff(t1.settle_date,t1.due_date))
	  end                                                                                  as overdue_days         --本期逾期天数
	,0                                                                                     as adv_repay_fee        --提前还款手续费
	,case when t4.loan_form='03' then t1.prin_amt-t1.paid_prin_amt else 0 end              as non_accru_bal        --非应计本金
	,case when t4.loan_form='03' then t1.int_amt-t1.paid_int_amt else 0 end                as aoff_bal_int         --表外利息
    ,'120108'                                                                              as prod_code            --产品号
from odata.slur_jcb_repay_plan_final t1
inner join odata.supacct_enterprise_loan_info t2
       on t2.data_date='${DATA_DATE}'
      and t2.bddw_end_date='9999-99-99'
	  and t1.loan_no = t2.partner_loan_no
	  and t2.reversal_flag = '00'
left join odata.slur_jcb_loan_info_final t4 
       on t4.data_date='${DATA_DATE}'
      and t4.bddw_end_date='9999-99-99'
	  and t1.loan_no=t4.loan_no
	  and loan_status<>'03'
left join (select  plan_no
                  ,count(1) as repay_cnt
				  ,min(from_unixtime(unix_timestamp(trans_date,'yyyyMMdd'),'yyyy-MM-dd')) as receipt_date
			 from odata.slur_jcb_repay_detail_split 
            where data_date='${DATA_DATE}'
			  and bddw_end_date='9999-99-99' 
		 group by plan_no) t5 
       on t1.plan_no = t5.plan_no
left join  odata.als_business_duebill t3
       on t3.data_date='${DATA_DATE}'
      and t3.bddw_end_date='9999-99-99'
	  and t2.iou_no = t3.serialno
where t1.data_date = '${DATA_DATE}'
and t1.bddw_end_date = '9999-99-99'
and t1.plan_status <> '03'
