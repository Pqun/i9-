with tmp as (
 select
   yjlx.bill_no as loan_id ,
   '',
   nvl(yjlx.receiv_int,0) as amt 
 from dwd.mid_xm_recv_int_scene_tran_new_used yjlx
 where yjlx.data_date = date_add('${DATA_DATE}',-1)
  
union all 

select 
 yjlx.bill_no as loan_id ,
 '',
 nvl(yjlx.receiv_int,0) as amt 
from dwd.mid_xm_recv_int_scene_tran_new_used yjlx
where yjlx.data_date = '${DATA_DATE}' 

union all

select
   dzz.loan_no as loan_id,
   '',
   -sum(dzz.comps_int+dzz.comps_prin_pnlt) as amt
from odata.slur_dzz_compensatory_detail dzz 
where dzz.data_date ='${DATA_DATE}'
  and dzz.comps_date = regexp_replace('${DATA_DATE}','-','')
  and dzz.prod_type ='110126'
  and dzz.comps_status = 'S'
  and not exists(select 1
                     from (select 1
                           from odata.slur_xm_term_status_file_clear a 
                           where a.data_date = '${DATA_DATE}'
                             and a.bddw_end_date = '9999-99-99'
                             and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                             and a.days_ovd > 89 
                             and a.term_status <> '5' 
                             and a.loan_id = dzz.loan_no
                             and not exists(select 1 
                                              from odata.slur_dzz_compensatory_detail dcd 
                                              where dcd.data_date = '${DATA_DATE}'
                                                and dcd.bddw_end_date = '9999-99-99'
                                                and dcd.loan_no = a.loan_id 
                                                and dcd.term_no = a.term_no 
                                                and dcd.comps_status = 'S'
                                                and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-',''))))
  group by dzz.loan_no
)

insert overwrite table dwd.mid_xm_recv_int_scene_tran_new_used partition(data_date='${DATA_DATE}')

select /*+ REPARTITION(1) */ 
 tmp.loan_id,
 '',
  sum(tmp.amt)
from tmp 
group by tmp.loan_id 