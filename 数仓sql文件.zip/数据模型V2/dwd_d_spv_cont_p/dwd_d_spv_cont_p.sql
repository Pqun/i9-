--2.dengquan.dwd_d_spv_cont_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：dwd_d_spv_cont_p.sql
--功能描述：
--作    者：于国睿
--开发日期：2022-08-19
--直属经理：方杰
--来源表  ：odata.tb_v_balance                      资产-余额
--来源表  ：odata.tb_vs_accentry2                   原始账务分录
--来源表  ：odata.tb_v_alterbalance                 资产-变动
--来源表  ：odata.tb_v_payment                      实际收付确认
--来源表  ：odata.tb_v_nstd_asset                   查询非标资产基本资料信息
--来源表  ：odata.tb_v_risk_asset_type_setting      债券资产类别定义表
--来源表  ：odata.gl_v_gl_subject                   总账科目表
--来源表  ：odata.tb_v_fund_asset                   货币基金基本资料
--目标表  ：dwd.dwd_d_spv_cont_p                    特定目的载体投资协议表
--修改历史：
--          1.于国睿   2022-08-19    新建
--          2.邓权     2022-12-13    新增字段起息日、发行日、目的载体名称、计息基础、票面利率、计息频率、付息频率、
--                                   利率类型、发行人名称、交易净价、交易全价、还款方式
--          3.邓权     2023-01-10    新增字段应收应付利息、应收应付利息科目、日计提利息
--          4.邓权     2023-02-09    新增字段结算金额、到期收益率、累计价差收益、累计摊销收益、累计利息收益、累计公允价值变动损益
--          5.邓权     2023-04-11    货币基金及非标资产认购日期逻辑调整
--          6.吴镇宇   2023-05-16    新增字段主资产编码、利率类型逻辑调整
--          7.高源     2023-09-06    净值型产品业务发生金额逻辑调整
--                                   非标资产科目逻辑调整
--			8.彭群	   2023-12-07	 新增最短开放周期、账户类型、经办人名称字段
--          9.高源     2023-12-14    新增最新动账日期、发行金额、发行价格
--			10.彭群    2024-04-11    对公允价值变动金额字段，应收利息进行逻辑特殊处理
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_spv_cont_p partition(data_date = '${DATA_DATE}')
--非标资产
select 
    /*+ REPARTITION(1) */ 
      nvl(trim(t1.nstd_asset_code),'')       as cont_no          --特定目的载体投资协议号
     ,nvl(t1.keepfolder_id,'')               as spv_id           --特定目的载体的唯一编码
     ,case when trim(t1.asset_key) = '107_16' then '01'    --银行非保本理财
           when trim(t1.asset_key) = '107_19' then '02'    --信托公司资管产品                
           when trim(t1.asset_key) = '107_18' then '03'    --证券公司及其子公司资管产品           
           when trim(t1.asset_key) = '107_22' then '04'    --基金管理公司及其子公司专户           
           when trim(t1.asset_key) = '107_23' then '05'    --期货公司及子公司资管产品            
           when trim(t1.asset_key) = '107_20' then '06'    --保险资管产品                  
           when trim(t1.asset_key) = '107_21' then '07'    --金融资产投资公司资管产品            
           when trim(t1.asset_key) in('107_14','107_24','107_25','107_26') then '08'  --公募基金(货币基金，债券基金)                
           when trim(t1.asset_key) = '107_17' then '09'    --私募机构私募基金
           else ''
       end                                   as spv_type                 --特定目的载体类型
     ,''                                     as issuer_unif_soc_crdt     --发行人社会统一信用代码
     ,''                                     as issuer_area_code         --发行人地区代码
     ,''                                     as spv_opera_mode           --特定目的载体的运行方式
     ,nvl(from_unixtime(unix_timestamp(trim(COALESCE(t11.value_date,t12.amount_value_date,t1.trade_date)),'yyyyMMdd'),'yyyy-MM-dd'),'')            
	                                         as start_date               --认购日期          --是交易日期还是 结算日期 quota_value_date
     ,nvl(from_unixtime(unix_timestamp(trim(t1.maturity_date),'yyyyMMdd'),'yyyy-MM-dd'),'')         
	                                         as maturity_date            --到期日期
     ,nvl(trim(t1.ccy),'')                   as ccy                      --币种
     ,nvl(t1.asset_rating,'')                as invest_prod_rating       --投资产品评级
     ,nvl(t1.holdfaceamount,0)               as biz_amt                  --业务发生金额（持有成本）
     ,nvl(trim(t1.accountingcode),'')        as subj_no                  --科目号
     ,case when nvl(trim(t1.accountingcode),'') = '10522101' then 0
           else nvl(t1.fairvaluealter,0) end 
                                             as fair_value_adj_amt       --公允价值变动金额     updatapengqun 20240403(对调账数据临时特殊处理)
     ,nvl(trim(t10.gl_code),'')              as fair_value_adj_subj      --公允价值变动科目号
     ,nvl(t1.interestadjust,0)               as int_adj                  --利息调整金额
     ,nvl(trim(t9.gl_code),'')               as int_adj_subj_no          --利息调整科目号
     ,nvl(from_unixtime(unix_timestamp(trim(t1.start_coupon_date),'yyyyMMdd'),'yyyy-MM-dd'),'')     
	                                         as accr_date                --起息日
     ,nvl(from_unixtime(unix_timestamp(trim(t1.issue_date),'yyyyMMdd'),'yyyy-MM-dd'),'')            
	                                         as issue_date               --发行日
     ,nvl(trim(t1.asset_name),'')            as spv_name                 --目的载体名称 
     ,case when trim(t1.day_count) = '0' then '2'
           when trim(t1.day_count) = '1' then '3'
           when trim(t1.day_count) = '2' then '6'
           when trim(t1.day_count) = '3' then '8'
           when trim(t1.day_count) = '4' then '9'
           when trim(t1.day_count) = '5' then '1'
           else '' end                       as int_basis                --计息基础
     ,nvl(case when t1.fixed_rate = 0 then 0
          else t1.fixed_rate end,0)          as spv_rate                 --票面利率
     ,nvl(trim(t1.coupon_freq),'')           as int_freq                 --计息频率          
     ,nvl(trim(t1.payment_freq),'')          as repay_freq               --付息频率
--     ,case when trim(t1.rate_type) in ('0','3') then 'RF01'
--           when trim(t1.rate_type) in ('1','2','4','5') then	'RF02' 
--           else '' end                       as rate_type              --利率类型
     ,nvl(trim(t1.rate_type),'')             as rate_type                --利率类型         update wuzhenyu 20230516
     ,nvl(t1.issuer,0)                       as issuer_name              --发行人名称
     ,nvl(t1.price,0)                        as clean_price              --交易净价
     ,nvl(t1.dirty_price,0)                  as dirty_price              --交易全价     
     ,case when trim(t1.payment_return_type) = '1' then '1'
       	   when trim(t1.payment_return_type) = '2' then '2'
           else trim(t1.payment_return_type) end as repay_mode           --还款方式
     ,nvl(t2.withdraw_int,0)                 as withdraw_int
     ,case when nvl(trim(t1.accountingcode),'') = '10522101' and t1.fairvaluealter <> 0 
           then nvl(t1.fairvaluealter,0) else nvl(t1.interestcost,0)
      end                                    as recv_int                 --应收利息  updatapengqun 20240403(对调账数据临时特殊处理) 
     ,nvl(concat('10601',substr(t1.accountingcode,4,3)) ,'')    
	                                         as recv_int_subj_no         --应收利息科目
     ,nvl(case when t11.asset_code is not null then t11.settle_amt else nvl(t12.value_amount,0) end,0) 
	                                         as settle_amt               --结算金额 
     ,nvl(t11.yield,0)                       as yield_mature             --到期收益率	 
     ,nvl(t1.total_diff_income,0)            as total_diff_income
     ,nvl(t1.total_amort_income,0)           as total_amort_income
     ,nvl(t1.total_int_income,0)             as total_int_income
     ,nvl(t1.total_fair_value_change,0)      as total_fair_value_change
	 ,nvl(t1.majorassetcode,'')              as asset_code               --主资产编码       update wuzhenyu 20230516
	 ,nvl(te.zdkfzq  ,'' )                   as open_cycle               --最短开放周期		--add 20231207  pengqun
	 ,coalesce(t11.keepfolder_shortname,t12.keepfolder_shortname,'')         
                           	                 as acct_type                --账户类型			--add 20231207  pengqun
	 ,nvl(te.jbr,'')                         as oper_emp_name            --经办人名称			--add 20231207  pengqun
     ,nvl(from_unixtime(unix_timestamp(string(t1.settledate),'yyyyMMdd'),'yyyy-MM-dd'),'')           
                                             as last_tran_date           --最近一次动账日期
     ,t1.number_issued                       as issue_amt          --发行金额
     ,t1.auction_price                       as issue_price        --发行价格  
 from 
          (select  t51.accountingcode
                   ,t51.settledate
                   ,t2.minorassetcode
                   ,t2.majorassetcode
                   ,t3.nstd_asset_code
                   ,t3.maturity_date
                   ,t4.asset_key
                   ,t3.ccy
                   ,t3.asset_rating
                   ,t3.payment_return_type
                   ,t3.start_coupon_date
                   ,t3.issue_date
                   ,t3.asset_name
                   ,t3.day_count
                   ,t3.fixed_rate
                   ,t3.coupon_freq
                   ,t3.payment_freq
                   ,t3.rate_type
                   ,t3.issuer
                   ,t3.number_issued
                   ,t3.auction_price
                   ,t2.keepfolder_id
                   ,nvl(t6.value_date,t6.trade_date) trade_date
				   ,sum(case when t2.assettype = '净值型产品'  then t2.cleanpricecost            
                             else t2.holdfaceamount   end)                          --2023-09-06余额逻辑调整          
							                   as holdfaceamount
				   ,sum(t2.holdposition)       as holdposition
                   ,sum(t5.fairvaluealter)     as fairvaluealter
                   ,sum(t5.interestadjust)     as interestadjust
                   ,sum(t6.price)              as price
                   ,sum(t6.dirty_price)        as dirty_price
                   ,sum(t5.interestcost)       as interestcost
                   ,sum(t5.diff_income)        as total_diff_income
                   ,sum(t5.amort_income)       as total_amort_income
                   ,sum(t5.int_income)         as total_int_income
                   ,sum(t5.fair_value_change)  as total_fair_value_change				   
            from (
			       select max(bls.balance_id)   as balance_id
                    from odata.tb_v_balance bls
                   where bls.data_date = '${DATA_DATE}'
                     and bls.bddw_end_date ='9999-99-99'
                     and bls.settledate <= regexp_replace('${DATA_DATE}','-','') --统计日期
                     and bls.aspclient_id = '2244' --请替换本行部门ID
                     and bls.assettype = '资产'
                   group by bls.aspclient_id,
                            bls.keepfolder_id,
                            bls.assettype,
                            bls.buztype,
                            bls.majorassetcode,
                            bls.minorassetcode
                   union all
                  select max(bls.balance_id)    as balance_id
                    from odata.tb_v_balance bls
                   where bls.data_date = '${DATA_DATE}'
                     and bls.bddw_end_date ='9999-99-99'
                     and bls.settledate <= regexp_replace('${DATA_DATE}','-','') --统计日期
                     and bls.aspclient_id = '2244' --请替换本行部门ID
                     and bls.assettype = '净值型产品'
                     and bls.balance_id_prev is not null
                   group by bls.aspclient_id,
                            bls.keepfolder_id,
                            bls.assettype,
                            bls.buztype,
                            bls.majorassetcode,
                 bls.minorassetcode) t1
            inner join odata.tb_v_balance t2
               on t2.data_date = '${DATA_DATE}'
              and t2.bddw_end_date ='9999-99-99'
              and t1.balance_id = t2.balance_id
            inner join odata.tb_v_nstd_asset t3
               on t3.data_date = '${DATA_DATE}'
              and t3.bddw_end_date ='9999-99-99'
              and t2.majorassetcode = t3.asset_code
            left join odata.tb_v_risk_asset_type_setting t4
               on t4.data_date = '${DATA_DATE}'
              and t4.bddw_end_date ='9999-99-99'
              and t3.asset_type = t4.asset_key
            left join(select aspclient_id,
                             keepfolder_id,
                             assettype,
                             majorassetcode,
                             minorassetcode,
                             cast(sum(interestcost)    as decimal(20,2)) as interestcost,      --利息成本
                             cast(sum(interestadjust)  as decimal(20,2)) as interestadjust ,   --利息调整
                             cast(sum(interestearning) as decimal(20,2)) as interestearning,   --利息收益
                             cast(sum(fairvaluealter)  as decimal(20,2)) as fairvaluealter,    --公允价值变动
                             cast(sum(case when baretradename in ('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
							             then priceearning 
									    else 0 end)    as decimal(20,2)) as diff_income,
                             cast(sum(case when baretradename in ('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
							             then amortizeearning 
										else 0 end)    as decimal(20,2)) as amort_income,
                             cast(sum(case when baretradename in ('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
							             then interestearning 
										else 0 end)    as decimal(20,2)) as int_income,
                             cast(sum(case when baretradename in ('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
							             then fairvalueincome 
										else 0 end)    as decimal(20,2)) as fair_value_change				  
                       from odata.tb_v_alterbalance
                      where data_date ='${DATA_DATE}'
                        and bddw_end_date ='9999-99-99'
                      group by aspclient_id,
                               keepfolder_id,
                               assettype,
                               majorassetcode,
                               minorassetcode) t5
              on t2.aspclient_id   = t5.aspclient_id
             and t2.keepfolder_id  = t5.keepfolder_id
             and t2.assettype      = t5.assettype
             and t2.majorassetcode = t5.majorassetcode
             and t2.minorassetcode = t5.minorassetcode
          inner join (select ac.accountingcode,
                            b21.majorassetcode,
                            b21.minorassetcode,
                            b21.buztype,
                            b21.keepfolder_id,
                            b21.aspclient_id,
                            b21.assettype,
                            b21.settledate,
                            row_number()over(partition by b21.majorassetcode,b21.minorassetcode order by ac.lastmodified  desc ) as rn   --2023-09-06科目号逻辑调整    
                       from odata.tb_v_alterbalance b21
                       left join odata.tb_vs_accentry2 ac
                         on b21.alterbalance_id = ac.bundlecode
                        and ac.debitcredit in ('D','C')
                        and ac.data_date = '${DATA_DATE}'
                        and ac.bddw_end_date ='9999-99-99'
                        and substr(ac.accountingcode,1,4) in ('1051','1050','1052')
                        and ac.accountingcode like '%01'
                      where b21.data_date = '${DATA_DATE}'
                        and b21.bddw_end_date = '9999-99-99'
                        and b21.settledate <= regexp_replace('${DATA_DATE}','-','')
                        and ac.accountingcode is not null
                        and ac.amount>0) t51                              --存在资产科目变更，取发生额大于零的最新科目
              on t51.majorassetcode = t2.majorassetcode
             and t51.minorassetcode = t2.minorassetcode
             and t51.buztype        = t2.buztype
             and t51.keepfolder_id  = t2.keepfolder_id
             and t51.aspclient_id   = t2.aspclient_id
             and t51.assettype      = t2.assettype
             and t51.rn=1
           left join odata.tb_vs_payment_wtrade_nstd_asset t6
             on t6.data_date ='${DATA_DATE}'
            and t6.bddw_end_date ='9999-99-99'
            and t6.asset_code = t3.asset_code
            and t6.status <> 'D'
        group by t51.accountingcode
                ,t51.settledate
                ,t2.minorassetcode
                ,t2.majorassetcode
                ,t3.nstd_asset_code
                ,t3.maturity_date
                ,t4.asset_key
                ,t3.ccy
                ,t3.asset_rating
                ,t3.start_coupon_date
                ,t3.issue_date
                ,t3.asset_name
                ,t3.day_count
                ,t3.fixed_rate
                ,t3.coupon_freq
                ,t3.payment_freq
                ,t3.rate_type
                ,t3.issuer
                ,t3.payment_return_type
                ,t3.number_issued
                ,t3.auction_price
                ,t2.keepfolder_id
                ,nvl(t6.value_date,t6.trade_date)) t1
 left join (select   bls.majorassetcode,bls.minorassetcode,
                     max(tva.amount)  as  withdraw_int
                   from odata.tb_v_balance bls
             left  join  odata.tb_vs_accentry2 tva                --取当日计提利息 
                     on bls.alterbalance_id = tva.bundlecode
                    and tva.data_date='${DATA_DATE}'
                    and tva.bddw_end_date='9999-99-99'
                    and tva.settledate= regexp_replace('${DATA_DATE}','-','')  --统计日期
                    and tva.accountingcode like '106%' 
                    and bls.baretradename='WITHDRAWALDEALS'                 
                  where bls.settledate <= regexp_replace('${DATA_DATE}','-','') --统计日期
                    and bls.aspclient_id = '2244' -- 请替换本行部门 ID
                    --and bls.majorassetcode <> bls.minorassetcode
                    and bls.data_date = '${DATA_DATE}'
                    and bls.bddw_end_date = '9999-99-99'
                  group by bls.minorassetcode,bls.majorassetcode
                    ) t2 
        on t1.majorassetcode = t2.majorassetcode 
       and t1.minorassetcode = t2.minorassetcode
 left join odata.gl_v_gl_subject t9
        on substr(t1.accountingcode,1,6)=substr(t9.gl_code,1,6)
       and substr(t9.gl_code_name,-4)='利息调整'
       and t9.data_date = '${DATA_DATE}'
       and t9.bddw_end_date = '9999-99-99'
 left join odata.gl_v_gl_subject t10
        on substr(t1.accountingcode,1,6)=substr(t10.gl_code,1,6)
       and substr(t10.gl_code_name,-6)='公允价值变动'
       and t10.data_date = '${DATA_DATE}'
       and t10.bddw_end_date = '9999-99-99'
 left join odata.tb_v_wtrade_nstd_asset t11 
        on t1.majorassetcode = t11.asset_code
       and t11.data_date = '${DATA_DATE}'
       and t11.bddw_end_date = '9999-99-99'
       and t1.keepfolder_id = t11.keepfolder_id
 left  join 
    ( select  
      value_amount,
      keepfolder_shortname,
      asset_code,
      keepfolder_id,
      amount_value_date, 
      quota_value_date,
      row_number()over(partition by asset_code order by quota_value_date  desc ) as rn   --2023-12-29科目号逻辑调整    
      from odata.tb_v_wtrade_nv_asset t12 
     where t12.data_date = '${DATA_DATE}'
       and t12.bddw_end_date = '9999-99-99'
       and t12.type = 'P') t12
   on t1.majorassetcode = t12.asset_code
      and t1.keepfolder_id = t12.keepfolder_id
      and rn=1
left  join  
         (select    te2.asset_code,
                    te2.field_value2  as  jbr,
                    te1.field_value2  as  zdkfzq
            from odata.tb_v_nstd_asset_extent2 te2    
            left join odata.tb_v_nstd_asset_extent2 te1
              on te2.asset_code = te1.asset_code
             and te1.data_date = '${DATA_DATE}'
             and te1.bddw_end_date = '9999-99-99'
             and te1.field_level = '最短开放周期(天)'
             and te1.field_value2 is not null 
           where te2.data_date = '${DATA_DATE}'
             and te2.bddw_end_date = '9999-99-99'
             and te2.field_level = '投资经办人'
	         and te2.field_value2 is not null 
            group by te2.asset_code,
                     te2.field_value2,
                     te1.field_value2
             ) te															--add 20231207  pengqun
       on t1.majorassetcode = te.asset_code	
 union all
--货币基金
  select 
      /*+ REPARTITION(1) */
        nvl(trim(t3.fund_asset_code),'')      as cont_id                 --特定目的载体投资协议号
       ,nvl(t2.keepfolder_id,'')              as spv_id                  --特定目的载体的唯一编码
       ,case when trim(t4.asset_key) = '107_16' then '01'                --银行非保本理财
             when trim(t4.asset_key) = '107_19' then '02'                --信托公司资管产品                
             when trim(t4.asset_key) = '107_18' then '03'                --证券公司及其子公司资管产品           
             when trim(t4.asset_key) = '107_22' then '04'                --基金管理公司及其子公司专户           
             when trim(t4.asset_key) = '107_23' then '05'                --期货公司及子公司资管产品            
             when trim(t4.asset_key) = '107_20' then '06'                --保险资管产品                  
             when trim(t4.asset_key) = '107_21' then '07'                --金融资产投资公司资管产品            
             --when trim(t4.asset_key) = '107_14' then '08'              --公募基金
             when trim(t4.asset_key) in('107_14','107_24','107_25') then '08'  --公募基金(货币基金，债券基金)                       
             when trim(t4.asset_key) = '107_17' then '09'                --私募机构私募基金
             else ''
         end                                  as spv_type                 --特定目的载体类型
       ,''                                    as issuer_unif_soc_crdt     --发行人社会统一信用代码
       ,''                                    as issuer_area_code         --发行人地区代码
       ,''                                    as spv_opera_mode           --特定目的载体的运行方式
       ,nvl(from_unixtime(unix_timestamp(trim(t11.value_date),'yyyyMMdd'),'yyyy-MM-dd'),'')  
  	                                          as start_date               --认购日期
       ,''                                    as maturity_date            --到期日期
       ,nvl(trim(t3.ccy),'')                  as ccy                      --币种
       ,''                                    as invest_prod_rating       --投资产品评级
       ,nvl(t2.holdposition,0)                as biz_amt                  --业务发生金额（持有成本）
       ,nvl(trim(t8.accountingcode),'')       as subj_no                  --科目号
       ,nvl(t5.interestcost,0)                as fair_value_adj_amt       --公允价值变动金额
       ,nvl(trim(t10.gl_code),'')             as fair_value_adj_subj      --公允价值变动科目号
       ,nvl(t5.interestadjust,0)              as int_adj                  --利息调整金额
       ,nvl(trim(t9.gl_code),'')              as int_adj_subj_no          --利息调整科目号
       ,nvl(from_unixtime(unix_timestamp(trim(t3.start_coupon_date),'yyyyMMdd'),'yyyy-MM-dd'),'')    
  	                                          as accr_date                --起息日
       ,nvl(from_unixtime(unix_timestamp(trim(t3.fund_date),'yyyyMMdd'),'yyyy-MM-dd'),'')    
                                              as issue_date               --发行日                  
       ,nvl(trim(t3.asset_name),'')           as spv_name                 --目的载体名称 
       ,''                                    as int_basis                --计息基础
       ,0                                     as spv_rate                 --票面利率
       ,''                                    as int_freq                 --计息频率          
       ,''                                    as repay_freq               --付息频率
       ,''                                    as rate_type                --利率类型
       ,nvl(trim(t3.issuer),'')               as issuer_name              --发行人名称
       ,0                                     as clean_price              --交易净价
       ,0                                     as dirty_price              --交易全价     
       ,''                                    as repay_mode               --还款方式          
       ,0                                     as withdraw_int
       ,0                                     as recv_int                 --应收利息
       ,''                                    as recv_int_subj_no         --应收利息科目
       ,nvl(t11.amount,0)                     as settle_amt
       ,0                                     as yield_mature
       ,nvl(t5.diff_income,0)                 as total_diff_income
       ,nvl(t5.amort_income,0)                as total_amort_income
       ,nvl(t5.fair_value_change,0)           as total_int_income
       ,nvl(t5.int_income,0)                  as total_fair_value_change
  	   ,nvl(trim(t2.majorassetcode),'')       as asset_code               --主资产编码          update wuzhenyu 20230516
	 ,nvl(te2.field_value2       ,'')         as open_cycle               --最短开放周期			--add 20231207  pengqun
	 ,nvl(t11.keepfolder_shortname ,'')       as acct_type                --账户类型				--add 20231207  pengqun
     ,nvl(split(t11.note,'>')[0] ,'')         as tran_emp_name            --交易员				--add 20231207  pengqun
     ,nvl(from_unixtime(unix_timestamp(string(t6.settledate),'yyyyMMdd'),'yyyy-MM-dd'),'')           
                                              as last_tran_date           --最近一次动账日期
     ,t3.unit_total                           as issue_amt                --发行金额
     ,''                                      as issue_price              --发行价格
   from (select max(bls.balance_id) as balance_id,
                min(bls.alterbalance_id) as alterbalance_id
           from odata.tb_v_balance bls
          where bls.data_date = '${DATA_DATE}'
            and bls.bddw_end_date ='9999-99-99'
            and bls.settledate <= regexp_replace('${DATA_DATE}','-','')  --统计日期
            and aspclient_id = '2244' --请替换本行部门ID
            and trim(bls.assettype) = '货币基金'
            --"华商现金增利货币B",业务类型发生变更，从净值型调整成了货币基金
            and balance_id not in (188425,188426)
          group by bls.aspclient_id,
                   bls.keepfolder_id,
                   bls.assettype,
                   bls.buztype,
                   bls.majorassetcode,
                   bls.minorassetcode) t1
  inner join odata.tb_v_balance t2
     on t2.data_date = '${DATA_DATE}'
    and t2.bddw_end_date ='9999-99-99'
    and t1.balance_id = t2.balance_id
  inner join odata.tb_v_fund_asset t3
     on t3.data_date = '${DATA_DATE}'
    and t3.bddw_end_date ='9999-99-99'
    and trim(t2.majorassetcode) = trim(t3.asset_code)
   left join odata.tb_v_risk_asset_type_setting t4
     on t4.data_date = '${DATA_DATE}'
    and t4.bddw_end_date ='9999-99-99'
    and trim(t3.asset_type) = trim(t4.asset_key)
   left join(select aspclient_id,
                    keepfolder_id,
                    assettype,
                    majorassetcode,
                    minorassetcode,
                    cast(sum(interestcost)    as decimal(20,2)) interestcost,      --利息成本
                    cast(sum(interestadjust)  as decimal(20,2)) interestadjust ,   --利息调整
                    cast(sum(interestearning) as decimal(20,2)) interestearning,   --利息收益
                    cast(sum(fairvaluealter)  as decimal(20,2)) fairvaluealter,    --公允价值变动
                    cast(sum(case when baretradename in ('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
					            then priceearning  else 0 end)   as decimal(20,2)) as diff_income,
                    cast(sum(case when baretradename in ('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
					            then amortizeearning else 0 end) as decimal(20,2)) as amort_income,
                    cast(sum(case when baretradename in ('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
					            then interestearning else 0 end) as decimal(20,2)) as int_income,
                    cast(sum(case when baretradename in ('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
					            then fairvalueincome else 0 end) as decimal(20,2)) as fair_value_change				  
               from odata.tb_v_alterbalance
              where data_date ='${DATA_DATE}'
                and bddw_end_date ='9999-99-99'
                and aspclient_id = '2244' --请替换本行部门ID
                and trim(assettype) = '货币基金'
              group by aspclient_id,
                       keepfolder_id,
                       assettype,
                       majorassetcode,
                       minorassetcode) t5
       on t2.aspclient_id  = t5.aspclient_id
      and t2.keepfolder_id = t5.keepfolder_id
      and trim(t2.assettype) = trim(t5.assettype)
      and trim(t2.majorassetcode) = trim(t5.majorassetcode)
      and trim(t2.minorassetcode) = trim(t5.minorassetcode)
   left join(select    aspclient_id,
                       keepfolder_id,
                       assettype,
                       majorassetcode,
                       minorassetcode,
                       max(settledate)  as  settledate         --最新日期
               from odata.tb_v_alterbalance
              where data_date ='${DATA_DATE}'
                and bddw_end_date ='9999-99-99'
                and aspclient_id  = '2244' --请替换本行部门ID
                and trim(assettype) = '货币基金'
                and holdposition<>0                            --余额变动
              group by aspclient_id,
                       keepfolder_id,
                       assettype,
                       majorassetcode,
                       minorassetcode) t6
       on t2.aspclient_id = t6.aspclient_id
      and t2.keepfolder_id= t6.keepfolder_id
      and trim(t2.assettype) = trim(t6.assettype)
      and trim(t2.majorassetcode) = trim(t6.majorassetcode)
      and trim(t2.minorassetcode) = trim(t6.minorassetcode)      
   left join odata.tb_vs_accentry2 t8
       on t8.data_date = '${DATA_DATE}'
      and t8.bddw_end_date ='9999-99-99'
      and t1.alterbalance_id = t8.bundlecode
      and t8.accountingcode like '105%01' 
   left join odata.gl_v_gl_subject t9
       on substr(t8.accountingcode,1,6)=substr(t9.gl_code,1,6)
      and substr(t9.gl_code_name,-4)='利息调整'
      and t9.data_date = '${DATA_DATE}'
      and t9.bddw_end_date = '9999-99-99'
   left join odata.gl_v_gl_subject t10
       on substr(t8.accountingcode,1,6)=substr(t10.gl_code,1,6)
      and substr(t10.gl_code_name,-6)='公允价值变动'
      and t10.data_date = '${DATA_DATE}'
      and t10.bddw_end_date = '9999-99-99'
 left join (select t.asset_code,t.keepfolder_id,keepfolder_shortname,note,t.amount,t.value_date from 
           (select asset_code,keepfolder_id,keepfolder_shortname,note,amount,value_date,row_number() over(partition by asset_code,keepfolder_id order by value_date) rn 
              from odata.tb_v_wtrade_mmf_asset 
             where data_date = '${DATA_DATE}'
               and bddw_end_date = '9999-99-99'
               and buy_or_sell = 'P') t
             where t.rn =1) t11
     on t2.majorassetcode = t11.asset_code 
    and t2.keepfolder_id = t11.keepfolder_id
left  join       
   (select    asset_code,field_value2
      from odata.tb_v_nstd_asset_extent2 te2    
     where te2.data_date = '${DATA_DATE}'
       and te2.bddw_end_date = '9999-99-99'
       and te2.field_level = '最短开放周期(天)'
       and te2.field_value2 is not null
     group by  asset_code,field_value2 ) te2
 on trim(t2.majorassetcode) = te2.asset_code