--2.yangqihao.dwd_e_corp_loan_repay_detail_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：对公贷款还款明细表.sql
--功能描述：生成每日结果数据并插入hive dwd层dwd_e_corp_loan_repay_detail_p分区表
--作    者：华天顺
--开发日期：2022-08-18
--直属经理：方杰
--来源表  ：odata.sym_mb_receipt 回收表 
--来源表  ：odata.sym_mb_receipt_detail 回收明细表
--来源表  ：odata.sym_mb_acct 账户基本信息表
--来源表  ：odata.slur_jcb_repay_detail 金城网贷还款明细表
--来源表  ：odata.slur_jcb_repay_detail_split 金城还款明细拆分表
--来源表  ：odata.slur_jcb_repay_plan_final 金城网贷还款计划表
--来源表  ：odata.supacct_enterprise_loan_info 贷款信息表
--目标表  ：dwd.dwd_e_corp_loan_repay_detail_p
--修改历史：
--          1.华天顺   2022-08-18    新建
--          2.杨琦浩   2023-05-24    新增回收方式字段
--          3.杨琦浩   2023-09-18    金城还款日期取数逻辑变更
--          4.姚威     2023-11-28    剔除个人经营贷及供应链信e融
--          5.吴镇宇   2023-12-07    新增记账日期,产品号
--          6.吴镇宇   2023-12-16    金城记账日期加一天，还款日期取消加一天
---------------------------------------------------------------------------------------------------------------

insert overwrite table dwd.dwd_e_corp_loan_repay_detail_p partition (data_date = '${DATA_DATE}')
--行内核心
         select /*+ REPARTITION(1) */
                 t1.receipt_no              as repay_seq_no       --还款流水号  
                ,t1.receipt_no              as receipt_no         --回收号
                ,t1.reference               as reference          --交易参考号
                ,t3.cmisloan_no             as bill_no            --借据号
                ,t1.ccy                     as ccy                --币种
                ,t2.stage_no                as term_no            --期次
                ,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd')             as repay_date         --还款日期
                ,'00:00:00'                 as repay_time         --还款时间
                ,case when t1.receipt_type in ('NS','ER') then concat(t1.receipt_type,'1')
                      else 'PF1'
                  end                       as repay_type         --还款方式
                ,t2.repaid_prin             as repaid_prin        --还款本金
                ,t2.repaid_int              as repaid_int         --还款利息
                ,t2.repaid_pena             as repaid_pena        --还款罚息
                ,t2.repaid_compo            as repaid_compo       --还款复利
                ,0                          as repaid_guar_fee    --还款担保费
                ,nvl(t1.receipt_gen_code,'') as recov_mode        --回收方式 M：人工 A：自动
                ,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd')             as accting_date         --记账日期
				,t3.prod_type               as prod_code          --产品号
          from  odata.sym_mb_receipt t1
     left join  (select 
                       receipt_no
                      ,stage_no
                      ,sum(case when amt_type = 'PRI' then rec_amt else 0 end ) as repaid_prin
                      ,sum(case when amt_type = 'INT' then rec_amt else 0 end ) as repaid_int
                      ,sum(case when amt_type = 'ODP' then rec_amt else 0 end ) as repaid_pena
                      ,sum(case when amt_type = 'ODI' then rec_amt else 0 end ) as repaid_compo
                
                  from odata.sym_mb_receipt_detail 
                 where  data_date = '${DATA_DATE}'
                   and  bddw_end_date = '9999-99-99'
              group by  receipt_no,stage_no
                   ) t2                               --拆分到期次粒度
            on  t1.receipt_no=t2.receipt_no
     left join  odata.sym_mb_acct t3                  --获取借据号
            on  t1.acct_internal_key = t3.internal_key
           and  t3.data_date = '${DATA_DATE}'
           and  t3.bddw_end_date = '9999-99-99'
         where  t1.data_date = '${DATA_DATE}'
           and  t1.bddw_end_date = '9999-99-99'
           and  t1.reversal <> 'Y'
		   and  t3.prod_type not in ('110101','110150')    --剔除个人经营贷柜面、供应链信e融
     union all
--金城
         select /*+ REPARTITION(1) */
                 t2.trans_seq_no              as repay_seq_no       --还款流水号  
                ,''                           as receipt_no         --回收号
                ,''                           as reference          --交易参考号
                ,t4.iou_no                    as bill_no            --借据号
                ,'CNY'                        as ccy                --币种
                ,t3.term                      as term_no            --期次
                ,from_unixtime(unix_timestamp(t2.trans_date,'yyyyMMdd'),'yyyy-MM-dd')             as repay_date         --还款日期
                ,'00:00:00'                   as repay_time         --还款时间
                ,case when t1.trans_type in ('1','3') then 'NS1' 
                      when t1.trans_type = '2' then 'ER1'  
                  end                         as repay_type         --还款方式  还款类型  1.正常/逾期还款 2.提前还款 3.续贷还款 4.冲还款
                ,t2.prin_amt                  as repaid_prin        --还款本金
                ,t2.int_amt                   as repaid_int         --还款利息
                ,t2.oint_amt                  as repaid_pena        --还款罚息
                ,0                            as repaid_compo       --还款复利
                ,0                            as repaid_guar_fee    --还款担保费
                ,''                           as recov_mode         --回收方式
                ,date_add(substr(t2.sl_tran_date,1,10),1) as accting_date       --记账日期
				,'120108'                     as prod_code          --产品号
          from  odata.slur_jcb_repay_detail_split t2 --拆分到期次粒度
     left join  odata.slur_jcb_repay_detail t1 
            on  t2.core_trans_seq_no = t1.core_trans_seq_no
           and  t1.data_date = '${DATA_DATE}'
           and  t1.bddw_end_date = '9999-99-99'
     left join  odata.slur_jcb_repay_plan_final t3 --获取还款期次
            on  t2.plan_no = t3.plan_no
           and  t3.data_date = '${DATA_DATE}'
           and  t3.bddw_end_date = '9999-99-99'
     left join  odata.supacct_enterprise_loan_info t4 --获取信贷借据号
            on  t2.loan_no = t4.partner_loan_no
           and  t4.data_date = '${DATA_DATE}'
           and  t4.bddw_end_date = '9999-99-99'
         where  t2.data_date = '${DATA_DATE}'
           and  t2.bddw_end_date = '9999-99-99'
union all
--行内核算
         select /*+ REPARTITION(1) */
                 t1.receipt_no              as repay_seq_no       --还款流水号  
                ,t1.receipt_no              as receipt_no         --回收号
                ,t1.reference               as reference          --交易参考号
                ,t3.cmisloan_no             as bill_no            --借据号
                ,t1.ccy                     as ccy                --币种
                ,t2.stage_no                as term_no            --期次
                ,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd')             as repay_date         --还款日期
                ,'00:00:00'                 as repay_time         --还款时间
                ,t1.receipt_type            as repay_type         --还款方式
                ,t2.repaid_prin             as repaid_prin        --还款本金
                ,t2.repaid_int              as repaid_int         --还款利息
                ,t2.repaid_pena             as repaid_pena        --还款罚息
                ,t2.repaid_compo            as repaid_compo       --还款复利
                ,0                          as repaid_guar_fee    --还款担保费
                ,nvl(t1.receipt_gen_code,'') as recov_mode        --回收方式 M：人工 A：自动
                ,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd')             as accting_date         --记账日期
				,t3.prod_type               as prod_code          --产品号
          from  odata.sllv_mb_receipt t1
     left join  (select 
                       receipt_no
                      ,stage_no
                      ,sum(case when amt_type = 'PRI' then rec_amt else 0 end ) as repaid_prin
                      ,sum(case when amt_type = 'INT' then rec_amt else 0 end ) as repaid_int
                      ,sum(case when amt_type = 'ODP' then rec_amt else 0 end ) as repaid_pena
                      ,sum(case when amt_type = 'ODI' then rec_amt else 0 end ) as repaid_compo
                  from odata.sllv_mb_receipt_detail 
                 where  data_date = '${DATA_DATE}'
                   and  bddw_end_date = '9999-99-99'
              group by  receipt_no,stage_no
                   ) t2                               --拆分到期次粒度
            on  t1.receipt_no=t2.receipt_no
     inner join  odata.sllv_mb_acct t3                  --获取借据号
            on  t1.acct_internal_key = t3.internal_key
           and  t3.data_date = '${DATA_DATE}'
           and  t3.bddw_end_date = '9999-99-99'
		   and  t3.prod_type like '120%'
         where  t1.data_date = '${DATA_DATE}'
           and  t1.bddw_end_date = '9999-99-99'
           and  t1.reversal <> 'Y'