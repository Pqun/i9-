--2.yangqihao.dwd_d_indv_loan_bill_p
-------------------------------------------------------------------
--脚本名称:dwd_d_indv_loan_bill_p
--功能描述:个人贷款借据表
--作    者:于国睿
--开发日期:2021-10-18
--直属经理:方杰
--目标表  :dwd.dwd_d_indv_loan_bill_p 
--来源表：odata.sym_mb_acct                   账户信息表
--来源表：odata.sym_cif_client                客户信息表
--来源表：odata.sym_mb_acct_balance           账户余额表
--来源表：odata.sym_cif_client_document       客户证件信息表
--来源表：odata.sym_cif_client_contact_tbl    客户联系信息表
--来源表：odata.sym_mb_acct_int_detail        利息明细表
--来源表：odata.sym_mb_acct_schedule_detail   账户计划明细表
--来源表：odata.plm_loan_info_detail          五级分类表
--来源表：odata.sym_mb_prod_define            产品科目表
--来源表：odata.sym_mb_invoice                单据表
--来源表：dwd.dwd_d_indv_credit_cont_p        个人授信合同表  
--来源表：adm.ods_code_mapping                源系统接口与ADM目标表参数对应表
--来源表：odata.sym_mb_agreement_loan         贷款签约表
--来源表：odata.supacct_enterprise_loan_info  贷款信息表
--来源表：odata.sym_mb_acct_int_detail        利息明细
--修改历史:
--         1、于国睿     2021-10-18     新建
--         2、高源       2022-06-07     新增应收未收利息、应收利息科目、利息调整、利息调整科目、利息拖欠日期、
--                                      来源系统、贷款投向行业、结清标识等字段,结清日期逻辑调整
--         3、高源       2022-06-22     新增入账时间字段逻辑
--         4、高源       2022-07-07     新增计息基础、客户所属行业、贷款业务细类、贷款用途明细分类字段逻辑
--         5、高源       2022-07-12     贷款合同号逻辑调整
--         6、高源       2022-08-10     借据起始日期、借据到期日、借据关闭日期逻辑调整，结清时间格式调整
--         7、高源       2022-10-09     新增机构号、贷款支用申请编号字段逻辑
--         8、高源       2022-10-26     合同号逻辑调整
--         9、高源       2022-11-03     还款方式、还款频率逻辑调整
--         10.华天顺     2022-11-18     应收利息取数逻辑调整
--         11.华天顺     2022-11-28     贷款担保方式，投向行业逻辑调整
--         12.华天顺      2022-12-02     新增核算状态字段
--         13.华天顺     2022-12-27     贷款合同号取数逻辑调整，逾期天数取数逻辑调整，新增逾期本金，利息和本金逾期日字段
--         14.华天顺     2023-01-12     担保方式取数逻辑调整  
--         15.华天顺     2023-01-28     应收利息取数逻辑调整,业务产品号取数逻辑调整
--         16.杨琦浩     2023-03-14     增加到期日字段
--         17.杨琦浩     2023-03-27     还款频率取数逻辑调整、担保方式新增卫城征信
--         18.杨琦浩     2023-04-12     担保方式新增药师帮、投向行业新增供应链产品、供应链五级分类调整取数逻辑
--         19.杨琦浩     2023-04-17     供应链产品贷款业务细类逻辑调整
--         20.杨琦浩     2023-05-17     新增项目ID字段
--         21.杨琦浩     2023-05-31     新增人上融融-新渠道
--         22.杨琦浩     2023-06-12     110150产品业务细类逻辑变更
--         23.杨琦浩     2023-06-19     支付方式取数逻辑调整
--         24.杨琦浩     2023-06-27     授信信息逻辑调整
--         24.高源       2023-08-10     个人经营贷支付方式逻辑调整
--         25.杨琦浩     2023-08-25     新增放款、还款账号信息字段
--         26.杨琦浩     2023-08-30     新增表内、表外欠息字段
--         27.杨琦浩     2023-08-31     修改计息方式取数逻辑
--         28.杨琦浩     2023-10-12     新增入账户名字段，调整入账、还款账号信息取数逻辑
--         29.杨琦浩     2023-10-25     表外欠息调整为非应计标志
-------------------------------------------------------------------
with 
t17 as 
(
    select 
         a.internal_key
        ,b.stage_no  --期次
        ,from_unixtime(unix_timestamp(max(c.start_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_start_date    --期次开始期日
    from odata.sym_mb_invoice a
   inner join (select a.internal_key
                     ,max(cast(a.stage_no as int)) as stage_no
                 from odata.sym_mb_invoice a
                where a.data_date = '${DATA_DATE}'
                  and a.bddw_end_date = '9999-99-99'
                  and a.amt_type = 'INT'
                group by a.internal_key) b
     on a.internal_key=b.internal_key
    and a.stage_no=b.stage_no
   left join odata.sym_mb_acct_schedule_detail c
     on c.data_date = '${DATA_DATE}'
    and c.bddw_end_date = '9999-99-99'
    and a.internal_key = c.internal_key
    and a.stage_no = c.stage_no
    and a.amt_type = c.amt_type
  where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and a.amt_type <> 'ODP'
    group by a.internal_key
            ,b.stage_no
),
t18 as 
(        select  internal_key
               ,min(case when amt_type='PRI'then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_pri
               ,min(case when amt_type='INT'then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_int
        from odata.sym_mb_invoice
          where outstanding>0   
            and data_date='${DATA_DATE}'
            and due_date < regexp_replace('${DATA_DATE}','-','')
            and bddw_end_date='9999-99-99'
        group by internal_key
),
t19 as  
(select internal_key
       ,min( from_unixtime(unix_timestamp(nvl(due_date,''),'yyyyMMdd'),'yyyy-MM-dd')) as due_date_pri
       ,sum(case when amt_type = 'PRI' then billed_amt else 0 end) as due_amount_pri
   from odata.sym_mb_invoice
  where outstanding > 0
    and amt_type = 'PRI'
    and data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
  group by internal_key
),
t20 as 
(select internal_key
       ,min( from_unixtime(unix_timestamp(nvl(due_date,''),'yyyyMMdd'),'yyyy-MM-dd')) as due_date_int
       ,sum(case when amt_type = 'INT' then billed_amt else 0 end) as due_amount_int
   from odata.sym_mb_invoice
  where outstanding > 0
    and amt_type = 'INT'
    and data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
  group by internal_key
)
insert overwrite table dwd.dwd_d_indv_loan_bill_p_tmp partition(data_date='${DATA_DATE}',prod_code)
select /*+ REPARTITION(1) */
       nvl(t1.cmisloan_no,'')                     as bill_no  --借据号
      ,case when t1.prod_type='110101' then '个人经营贷款' 
            when t1.prod_type='110150' then '信e融'
            else ''
        end                                       as prod_name  --产品名称
      ,nvl(t1.base_acct_no,'')                    as acct_no  --账号
      ,nvl(t1.acct_seq_no,'')                     as acct_seq_no  --账户序列号
      ,nvl(t41.project_id,'')                     as biz_prod_code  --业务产品号
      ,''                                         as sub_biz_prod_code  --业务子产品号
      ,'01'                                       as accting_cacl_mode --会计核算方式
      ,'10400201'                                 as subj_no  --科目号
      ,'个人经营贷款-成本'                        as subj_name  --科目名称
      ,nvl(t1.client_no,'')                       as cust_id  --客户号
      ,nvl(t2.client_short,'')                    as cust_name  --客户姓名
      ,nvl(t3.document_type,'')                   as cert_type  --证件类型
      ,nvl(t3.document_id,'')                     as cert_no  --证件号
      ,nvl(t4.contact_tel,'')                     as mobile_no  --客户手机号
      --,0                                          as credit_limit  --授信额度
      --,''                                         as credit_term  --授信期限
      --,''                                         as credit_start_date  --授信起始日期
      --,''                                         as credit_end_date  --授信到期日期
      --,''                                         as credit_cont_no  --授信合同编号
      ,nvl(t42.credit_limit,0)                    as credit_limit  --授信额度
      --,nvl(t42.credit_terms,'')                   as credit_term  --授信期限
      ,''                                         as credit_term  --授信期限
      ,nvl(substr(t42.credit_start_date,1,10),'') as credit_start_date  --授信起始日期
      ,nvl(substr(t42.credit_mature_date,1,10),'')as credit_end_date  --授信到期日期
      ,nvl(t42.credit_cont_no,'')                 as credit_cont_no  --授信合同编号
      ,nvl(t1.sched_mode ,'')                     as repay_mode  --还款方式
      ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as loan_grant_date  --贷款发放日期
      ,'00:00:00'                                 as loan_grant_time  --贷款发放时间
      --,nvl(t41.loan_contract_no,'')               as loan_cont_no  --贷款合同号
      ,case when t1.prod_type='110150' then nvl(t1.cmisloan_no,'')
            else nvl(t41.loan_contract_no,'')
       end                                        as loan_cont_no  --贷款合同号  --update yqh 20230926 110150产品贷款合同号取借据号
      ,' '                                        as fin_supp_mode  --贷款财政扶持方式
      --,case when t41.project_id='scp0012010020' then  'D'
      --      when t41.project_id='scp0019510027'    then  'C'
      --      when t41.project_id='scp0022510031' then  'C'
      --      when t41.project_id='scp0026510033' then  'D'
      --      else ''
      --end                                       as loan_guar_mode  --贷款担保方式
        ,case when t41.project_id='scp0012010020' then 'D'  --金润ETC
              when t41.project_id='scp0019510027' then 'C'  --大数金融
              when t41.project_id='scp0022510031' then 'C'  --人上融融
              when t41.project_id='scp0024510034' then 'C'  --卫城征信
              when t41.project_id='scp0026510033' then 'D'  --小雨点
              when t41.project_id='scp0013510043' then 'D'    --药师帮
              when t41.project_id='scp0022510049' then 'C'    --人上融融-新
              else ''
         end                                      as loan_guar_mode  --贷款担保方式
      ,'3'                                        as loan_purp  --贷款用途
      ,'TR05'                                     as pric_benc  --定价基准
      ,case when t1.acct_status<>'C' and t1.accounting_status<>'ZHC' then '107' 
            when t1.acct_status<>'C' and t1.accounting_status='ZHC' then '105'
            when t1.acct_status='C' then '106'     
        end                                       as loan_cont_status  --贷款合同状态
      ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as loan_start_date  --借据起始日期
      ,nvl(from_unixtime(unix_timestamp(t1.ori_maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as loan_mature_date  --借据到期日期
      ,nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')    as loan_close_data  --借据关闭日期
      ,nvl(t5.total_amount,0)                     as loan_amt  --放款金额
      ,nvl(t6.stage_no_max,0)                     as total_loan_terms  --放款总期数
      ,nvl(t17.stage_no,0)                        as curr_term_no  --当前期次
      ,'RF01'                                     as rate_type  --利率类型
      ,nvl(t7.real_rate,0)                        as real_rate  --实际利率
      ,''                                         as partner_id  --合作方编码
      ,''                                         as partner_name  --合作方名称
      ,''                                         as sub_channel_type  --贷款办理渠道
      ,''                                         as consume_scen_flag  --消费场景标签
      ,1.00                                       as invest_ratio  --出资比例
      ,'CNY'                                      as ccy  --币种
      ,nvl(t8.attr_value,0)                       as grace_days  --宽限天数
      ,case when nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')>'${DATA_DATE}'
            then ''
            else nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'') 
        end                                       as clear_date  --结清日期
      ,case when t18.internal_key is not null
            then least(nvl(t18.due_date_pri,''),nvl(t18.due_date_int,''))
            else '' 
        end    as overdue_start_date  --逾期起始日
      ,case when t18.internal_key is not null
            then greatest(nvl(datediff('${DATA_DATE}',t18.due_date_pri),0),nvl(datediff('${DATA_DATE}',t18.due_date_int),0))
            else 0  
        end                                           as overdue_days --逾期天数
      ,''                                         as defer_mature_date  --贷款展期到期日期
      ,case when t18.due_date_pri is not null and t18.due_date_int is null 
            then '01'
            when t18.due_date_pri is null and t18.due_date_int is not null 
            then '02'
            when t18.due_date_pri is not null and t18.due_date_int is not null 
            then '03'
            else '' 
        end                                           as overdue_type  --逾期类型
      ,case when t22.iou_no is not null then  --供应链
            case when t22.cust_five_loan_flag = '01' then 'FQ01' 
                 when t22.cust_five_loan_flag = '02' then 'FQ02' 
                 when t22.cust_five_loan_flag = '03' then 'FQ03' 
                 when t22.cust_five_loan_flag = '04' then 'FQ04' 
                 when t22.cust_five_loan_flag = '05' then 'FQ05' 
                 else '' end
      else 
           case when t9.manual_five_class is not null 
                  then nvl(t9.manual_five_class,'')
                when t9.manual_five_class is null and t1.five_category='1' 
                then 'FQ01' 
                when t9.manual_five_class is null and t1.five_category='2' 
                then 'FQ02'
                when t9.manual_five_class is null and t1.five_category='3' 
                then 'FQ03'
                when t9.manual_five_class is null and t1.five_category='4' 
                then 'FQ04'
                when t9.manual_five_class is null and t1.five_category='5' 
                then 'FQ05' 
                end 
       end                                      as five_risk_level  --贷款5级分类
      ,case when t1.prod_type='110101' then nvl(t32.settle_base_acct_no,'')
            when t41.project_id in ('scp0013510043','scp0012010020','scp0026510033') then nvl(t41.default_repay_account_no,'')
            else coalesce(t23.linked_base_acct_no,t23_1.linked_base_acct_no,t41.repay_account_no,t41.default_repay_account_no,'')
       end                                      as receive_acct_no   --贷款入账账号 
      ,case when t1.prod_type='110101' then nvl(t33.settle_base_acct_no,'')
            when t41.project_id in ('scp0013510043','scp0012010020','scp0026510033') then nvl(t41.default_repay_account_no,'')
            else coalesce(t23_2.linked_base_acct_no,t23_3.linked_base_acct_no,t41.repay_account_no,t41.default_repay_account_no,'')
       end                                      as repay_acct_no  --还款账号
      --,''                                         as payment_mode  --支付方式
      ,case when t1.prod_type='110101'  and ts.internal_key is null  then 1     --自主支付
            when t1.prod_type='110101'  and ts.internal_key is not null  then 2 --受托支付
            when t1.prod_type='110150' then
            case when t41.pay_type='01' then 1 --自主支付
                 when t41.pay_type in ('02','03') then 2 --受托支付
            else ''   end                                         
       else ''       end                          as payment_mode  --支付方式     --20230809updata
      ,'02'                                       as cash_tran_flag  --现转标志
      ,nvl(t16.cust_manager_name,'')              as credit_tlr_name  --信贷员姓名
      ,nvl(t16.cust_manager_id,'')                as credit_tlr_id  --信贷员员工号
      ,case t7.cycle_freq
            when 'M1' then 'B01'
            when 'M3' then 'B02'
            when 'M6' then 'B06'
            else 'B99'
        end                                       as int_mode  --计息方式
      --,case  when  t1.sched_mode ='3'  then '05'
      --       when  t1.sched_mode ='4'  then '06'
      --       else    ''   end                     as repay_freq --还款频率
      ,case when t1.sched_mode='1' then '01' --sched_mode='1'等额本息
            when t1.sched_mode='2' then '01' --sched_mode='2'等额本金
            when t1.sched_mode='3' then '05' --sched_mode='3'一次还本付息
            when t1.sched_mode='4' then '06' --sched_mode='4'按频率付息、一次还本
            when t1.sched_mode='5' then '07' --sched_mode='5'按频率付息、任意本金
       else '' end repay_freq --还款频率
      ,''                                         as pay_seq_no --支付流水号
      ,'2'                                        as loan_biz_class  --业务分类
      ,nvl(a.total_amount_prev,0)                 as bal        --贷款余额
      ,nvl(t51.int_accrued,0) + nvl(t51.int_adj,0) + nvl(t51.int_posted_ctd,0) + nvl(t21.outstanding,0) as receiv_int   -- 应收利息
      ,nvl(t71.gl_code_int_rec,'')                as  overdue_int_subj  -- 应收利息科目
      ,0                                          as  int_adj       -- 利息调整
      ,''                                         as  int_adj_subj  -- 利息调整科目
      ,nvl(t18.due_date_int,'')                   as  overdue_date_int  --利息逾期日期
      ,'SYM'                                      as  source_system  -- 来源系统   
      ,case when t41.project_id='scp0012010020' then 'G5430' 
            when t41.project_id='scp0019510027' then prise_info.industry_category_tiny_code
            when t41.project_id in ('scp0022510031','scp0022510049') then prise_info.industry_category_tiny_code
            when t41.project_id='scp0024510034' then nvl(prise_info.industry_category_tiny_code,'')  --卫城征信
                when t41.project_id='scp0026510033' then nvl(prise_info.industry_category_tiny_code,'')  --小雨点
                when t41.project_id='scp0013510043' then nvl(prise_info.industry_category_tiny_code,'')  --药师帮
        end                                       as  loan_indst_type  --贷款投向行业
      ,case when nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')>'${DATA_DATE}' then '0'
            when t1.acct_close_date is not null then '1' 
            else  '0'   end                       as fully_settled -- 0未结清 1结清 
      ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')            as accting_date   --记账日期
      ,case when t7.year_basis='360' and t7.month_basis='30' then  '1'
            when t7.year_basis='360' and t7.month_basis='ACT' then  '2'  
            else '7'  end                         as int_basis    --计息基础                                            as int_basis    --计息基础
      ,''                                         as cust_indust_type  --客户所属行业
      ,case when t1.prod_type='110101' then t10.t_code
               --when t1.prod_type='110150' then 'A19'
               --when t1.prod_type='110150' then nvl(t16.loan_type,'')
               --when t1.prod_type='110150' and '${DATA_DATE}' >= '2023-02-28' then nvl(t16.loan_type,'') --监管现逻辑
               --when t1.prod_type='110150' and '${DATA_DATE}' >= '2023-01-01' and '${DATA_DATE}' < '2023-02-28' then 'A17' --监管旧逻辑
               --when t1.prod_type='110150' and '${DATA_DATE}' < '2023-01-01' then 'A19' ----监管旧逻辑
               when t1.prod_type='110150' and prise_info.enterprise_type='210' then 'A18' --个体工商户贷款
               when t1.prod_type='110150' then nvl(t16.loan_type,'')
               else ''  end                       as loan_biz_detail  --贷款业务细类
      ,case when t1.prod_type='110150' then t16.loan_usage
            when t1.prod_type='110101' and t12.purpose ='100' then '资金周转'
            when t1.prod_type='110101' and t12.purpose ='101' then '投资需求'
            when t1.prod_type='110101' and t12.purpose ='102' then '扩大经营规模'
            when t1.prod_type='110101' and t12.purpose ='103' then '店面装修改造'
            when t1.prod_type='110101' and t12.purpose ='104' then '购房'
            when t1.prod_type='110101' and t12.purpose ='105' then '购车（自用型）'
            when t1.prod_type='110101' and t12.purpose ='106' then '购买车位'
            when t1.prod_type='110101' and t12.purpose ='107' then '房屋装修'
            when t1.prod_type='110101' and t12.purpose ='108' then '购买大额耐用消费品'
            when t1.prod_type='110101' and t12.purpose ='109' then '旅游'
            when t1.prod_type='110101' and t12.purpose ='110' then '出国留学'
            when t1.prod_type='110101' and t12.purpose ='111' then '教育'
            when t1.prod_type='110101' and t12.purpose ='112' then '婚嫁'
            when t1.prod_type='110101' and t12.purpose ='113' then '医疗保健'
            when t1.prod_type='110101' and t12.purpose ='114' then '购买大额人寿保险'
            when t1.prod_type='110101' and t12.purpose ='115' then '资产置换'
            when t1.prod_type='110101' and t12.purpose ='116' then '其他'
            when t1.prod_type='110101' and t12.purpose ='117' then '土地储备'
            when t1.prod_type='110101' and t12.purpose ='118' then '房地产开发'
            when t1.prod_type='110101' and t12.purpose ='119' then '个人住房'
            when t1.prod_type='110101' and t12.purpose ='120' then '商业用房'
            when t1.prod_type='110101' and t12.purpose ='121' then '基本建设'
            when t1.prod_type='110101' and t12.purpose ='122' then '技术改造'
            when t1.prod_type='110101' and t12.purpose ='123' then '基础设施'
            when t1.prod_type='110101' and t12.purpose ='124' then '个人日常消费'
            else '其他'  end                        as loan_purp_detail  --贷款用途明细分类
      ,nvl(t1.branch   ,'')                           as org_id            --机构号
      ,''                                             as loan_app_no       --贷款支用申请编号
      ,nvl(t1.accounting_status,'')                   as accting_status    --核算状态
      ,nvl(yq.pri_outstanding,0)                    as overdue_prin              --逾期本金
      ,nvl(yq.int_outstanding,0)                    as overdue_int               --逾期利息
      ,nvl(t18.due_date_pri,'')                     as pri_overdue_date          --本金逾期日
      ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as mature_date  --到期日
      ,nvl(t41.project_id,'') as project_id --项目ID
      ,case when t1.prod_type='110101' and t32.settle_base_acct_no is not null then nvl(case when length(t32.payee_bank_code)=12 then t32.payee_bank_code else '' end,'')
            when t1.prod_type<>'110101' and t23.linked_base_acct_no is not null then nvl(case when length(t24.bank_code)=12 then t24.bank_code else ''end,'')
            when t1.prod_type<>'110101' and t23_1.linked_base_acct_no is not null then nvl(case when length(t24_1.bank_code)=12 then t24_1.bank_code else '' end,'')
            when t1.prod_type<>'110101' and nvl(t41.repay_account_no,t41.default_repay_account_no) is not null then nvl(case when length(t41.payee_bank_code)=12 then t41.payee_bank_code else '' end,'')
            else ''
       end                                          as receive_bank_code --贷款入账账号所属行号
      ,case when t1.prod_type='110101' and t32.settle_base_acct_no is not null then nvl(t32.payee_bank_name,'')
            when t1.prod_type<>'110101' and t23.linked_base_acct_no is not null then nvl(t24.bank_name,'')
            when t1.prod_type<>'110101' and t23_1.linked_base_acct_no is not null then nvl(t24_1.bank_name,'')
            when t1.prod_type<>'110101' and nvl(t41.repay_account_no,t41.default_repay_account_no) is not null then nvl(t41.payee_bank_name,'')
            else ''
       end                                          as receive_bank_name --贷款入账账号所属行名
      ,case when t1.prod_type='110101' then '323302000012'
            when t1.prod_type<>'110101' and t23_2.linked_base_acct_no is not null then nvl(case when length(t24_2.bank_code)=12 then t24_2.bank_code else '' end,'')
            when t1.prod_type<>'110101' and t23_3.linked_base_acct_no is not null then nvl(case when length(t24_3.bank_code)=12 then t24_3.bank_code else '' end,'')
            when t1.prod_type<>'110101' and nvl(t41.repay_account_no,t41.default_repay_account_no) is not null then nvl(case when length(t41.payee_bank_code)=12 then t41.payee_bank_code else '' end,'')
            else ''
       end                                          as repay_bank_code --还款账号所属行号
      ,case when t1.prod_type='110101' then '无锡锡商银行股份有限公司'
            when t1.prod_type<>'110101' and t23_2.linked_base_acct_no is not null then nvl(t24_2.bank_name,'')
            when t1.prod_type<>'110101' and t23_3.linked_base_acct_no is not null then nvl(t24_3.bank_name,'')
            when t1.prod_type<>'110101' and nvl(t41.repay_account_no,t41.default_repay_account_no) is not null then nvl(t41.payee_bank_name,'')
            else ''
       end                                          as repay_bank_name --还款账号所属行名
      ,case when t1.accounting_status in ('FY','FYJ','WRN') then '1'
            else '0'
       end                                          as non_accru_flag --非应计标志
      --,case when t1.accounting_status in ('ZHC','YUQ') then nvl(yq.int_int_outstanding,0)
      --      else 0
      -- end                                          as in_bal_int --表内欠息
      ,0                                            as in_bal_int --表内欠息
      ,case when t1.prod_type='110101' then nvl(t32.settle_acct_name,'')
            when t1.prod_type<>'110101' and t23.linked_base_acct_no is not null then nvl(t23.linked_acct_name,'')
            when t1.prod_type<>'110101' and t23_1.linked_base_acct_no is not null then nvl(t23_1.linked_acct_name,'')
            when t1.prod_type<>'110101' and t41.repay_account_no is not null then nvl(t41.repay_account_name,'')
            when t1.prod_type<>'110101' and t41.default_repay_account_no is not null then nvl(t41.default_repay_account_name,'')
            else ''
       end                                          as receive_acct_name --入账户名
      ,nvl(t1.prod_type,'')                         as prod_code         --产品号
  from odata.sym_mb_acct t1
  left join odata.sym_cif_client t2
    on t1.client_no=t2.client_no
   and t2.data_date='${DATA_DATE}'
   and t2.bddw_end_date='9999-99-99'
  left join odata.sym_cif_client_document t3
    on t1.client_no = t3.client_no
   and t3.data_date = '${DATA_DATE}'
   and t3.bddw_end_date = '9999-99-99'
   and t3.pref_flag='Y' 
  left join odata.sym_cif_client_contact_tbl t4
    on t1.client_no = t4.client_no 
   and t4.pref_flag='Y'
   and t4.data_date='${DATA_DATE}'
   and t4.bddw_end_date='9999-99-99'
   left join odata.supacct_enterprise_loan_info t41
    on t1.cmisloan_no = t41.iou_no
   and t41.data_date='${DATA_DATE}'
   and t41.bddw_end_date='9999-99-99'
   left join dwd.dwd_d_indv_credit_cont_p t42
   on t42.credit_cont_no=t41.loan_contract_no
   and t42.data_date='${DATA_DATE}'
   left join odata.supwall_scp_personal_cust_info cust1   --贷款投向行业
  on  t41.cust_id=cust1.cust_id 
  and cust1.data_date='${DATA_DATE}'
  and cust1.bddw_end_date='9999-99-99'
left join odata.supwall_scp_personal_cust_enterprise_info prise_info
  on  prise_info.personal_cust_id=cust1.id
  and prise_info.data_date='${DATA_DATE}'
  and prise_info.bddw_end_date='9999-99-99'
  left join odata.suppimp_scp_project_info  t16  --金融项目表
       on t41.platform_id=t16.partner_platform_id
      and t16.data_date='${DATA_DATE}'
      and t16.bddw_end_date = '9999-99-99'
      and t41.project_id=t16.project_id
left join 
  ( select  internal_key  from 
      odata.sym_mb_acct_settle             --账户结算信息表
     where data_date = '${DATA_DATE}'
       and bddw_end_date = '9999-99-99'
       and event_type = 'DRW'
       and settle_acct_class = 'TPP'       --结算分类为受托支付
       and trusted_pay_no is not null      --受托支付编号不为空
     group by  internal_key ) ts
    on t1.internal_key = ts.internal_key
left join odata.sym_mb_acct_settle t32 
  on t1.internal_key=t32.internal_key
  and t32.event_type='DRW'
  and t32.settle_acct_class='TPP'
  and t32.data_date = '${DATA_DATE}'
  and t32.bddw_end_date = '9999-99-99'
  and t1.prod_type='110101'
left join odata.sym_mb_acct_settle t33
  on t1.parent_internal_key=t33.internal_key
 and t33.event_type='REC'
 and t33.data_date = '${DATA_DATE}'
 and t33.bddw_end_date = '9999-99-99'
 and t1.prod_type='110101'
  left join odata.sym_mb_acct_balance t5
    on t1.internal_key = t5.internal_key
   and t5.amt_type ='DDA'
   and t5.data_date = '${DATA_DATE}'
   and t5.bddw_end_date = '9999-99-99'
  left join odata.sym_mb_acct_balance a
    on t1.internal_key = a.internal_key
   and a.amt_type ='BAL'
   and a.data_date = '${DATA_DATE}'
   and a.bddw_end_date = '9999-99-99'
   left join odata.sym_gl_prod_accounting t71
       on t1.prod_type = t71.prod_type
      and t71.accounting_status = 'ZHC' 
      and t71.data_date = '${DATA_DATE}'
      and t71.bddw_end_date = '9999-99-99'
  --总期次
  left join( select internal_key,max( cast(stage_no as int) ) as stage_no_max
               from odata.sym_mb_acct_schedule_detail
              where data_date='${DATA_DATE}' and bddw_end_date='9999-99-99'
              group by internal_key) t6 
    on t1.internal_key=t6.internal_key
  left join odata.sym_mb_acct_int_detail t7
    on t1.internal_key = t7.internal_key
   and t7.int_class = 'INT'
   and t7.data_date='${DATA_DATE}'
   and t7.bddw_end_date='9999-99-99'
  left join (select internal_key,sum(int_accrued) int_accrued,sum(int_adj) int_adj,sum(int_posted_ctd) int_posted_ctd  from odata.sym_mb_acct_int_detail 
           where data_date = '${DATA_DATE}'
           and bddw_end_date='9999-99-99' 
           and int_class not like 'ODI%'
           group by internal_key) t51          
       on t1.internal_key = t51.internal_key 
  left join odata.sym_mb_prod_define t8
    on t1.prod_type = t8.prod_type 
   and t8.data_date='${DATA_DATE}'
   and t8.bddw_end_date='9999-99-99'
   and t8.assemble_id='GRACE_PERIOD'
  left join(select loan_id
                  ,prod_type
                  ,case when manual_five_class = '正常'  then  'FQ01'
                        when manual_five_class = '关注'  then  'FQ02'
                        when manual_five_class = '次级'  then  'FQ03'
                        when manual_five_class = '可疑'  then  'FQ04'
                        when manual_five_class = '损失'  then  'FQ05'
                    end as manual_five_class
              from odata.plm_loan_info_detail
             where data_date = '${DATA_DATE}'
               and bddw_end_date = '9999-99-99'
               and manual_term_validity_date >= '${DATA_DATE}') t9
    on t1.cmisloan_no = t9.loan_id
   and t1.prod_type = t9.prod_type
   left join adm.ods_code_mapping t10
   on t1.prod_type=t10.s_code
   and t10.convert_id='6'
   left join odata.sym_mb_agreement_loan t12
   on t1.parent_internal_key=t12.internal_key
   and t12.data_date='${DATA_DATE}'
   and t12.bddw_end_date='9999-99-99'
  left join t18
    on t1.internal_key=t18.internal_key
  left join t17 
    on t1.internal_key=t17.internal_key
  left join t19
    on t1.internal_key=t19.internal_key 
  left join t20
    on t1.internal_key=t20.internal_key
  left join (select 
                     internal_key
                    ,sum(outstanding) as outstanding
              from  odata.sym_mb_invoice 
             where  data_date='${DATA_DATE}'
               and  bddw_end_date='9999-99-99'
               and  amt_type <> 'PRI'
               and  amt_type not like 'ODI%'
               and  outstanding<>0
               and  fully_settled = 'N'
               and  due_date <= regexp_replace('${DATA_DATE}','-','')
          group by  internal_key
            ) t21
    on t1.internal_key=t21.internal_key
left join (
        select
              ce.internal_key
             ,sum(case when ce.amt_type ='PRI' then ce.outstanding when ce.amt_type in ('INT','ODP') then 0 end) as pri_outstanding  --逾期本金
             ,sum(case when ce.amt_type ='PRI' then 0 when ce.amt_type in ('INT','ODP') then ce.outstanding end) as int_outstanding  --逾期利息
             ,sum(case when ce.amt_type ='PRI' then 0 when ce.amt_type in ('INT','ODP','ODI') then ce.outstanding end) as int_int_outstanding  
        from odata.sym_mb_invoice  ce
        where ce.data_date='${DATA_DATE}' 
          and ce.bddw_end_date='9999-99-99'
          and ce.outstanding >0
          and ce.due_date < regexp_replace('${DATA_DATE}','-','')
        group by ce.internal_key
) yq 
on t1.internal_key = yq.internal_key 
--供应链5级分类
left join odata.supdsc_scp_dsc_loan_analysis t22
  on t1.cmisloan_no = t22.iou_no
  and t22.data_date='${DATA_DATE}' 
  and t22.bddw_end_date='9999-99-99'
left join odata.suporder_scp_payment_record t25
on t41.pay_order_no  = t25.payment_no 
and t25.data_date='${DATA_DATE}'
and t25.bddw_end_date='9999-99-99'
left join (
        select
                c.base_acct_no
               ,c.linked_base_acct_no
               ,a.linked_acct_name
               ,d.iou_no
               ,row_number() over(partition by a.base_acct_no,d.iou_no order by abs(unix_timestamp(nvl(f.time_stamp,concat(substr(a.tran_date,1,10),' 00:00:00')))-unix_timestamp(concat((regexp_replace(e.putoutdate,'/','-')),' 00:00:00')))) rn
        from odata.va_am_aa_maint_hist a 
        left join (
                   select base_acct_no 
                   from odata.va_va_loan_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   union all 
                   select base_acct_no 
                   from odata.va_va_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   ) b 
        on a.linked_base_acct_no=b.base_acct_no
        inner join (
                   select base_acct_no
                          ,linked_base_acct_no
                   from odata.va_am_rel_acct_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   --and linked_status='A'
                   group by base_acct_no
                   ,linked_base_acct_no
                   ) c  
        on a.base_acct_no=c.base_acct_no
        and a.linked_base_acct_no=c.linked_base_acct_no
        left join odata.va_cm_tran_comm f
        on a.main_seq_no=f.main_seq_no
        and f.data_date=if ('${DATA_DATE}' <'2023-10-11','2023-10-11','${DATA_DATE}') --20231011之前数据不全
        and f.bddw_end_date='9999-99-99'
        left join odata.supacct_enterprise_loan_info d 
        on a.base_acct_no=d.repay_account_no
        and d.data_date='${DATA_DATE}' 
        and d.bddw_end_date='9999-99-99'
        left join odata.als_business_duebill e
        on d.iou_no=e.serialno
        and e.data_date='${DATA_DATE}' 
        and e.bddw_end_date='9999-99-99'
        left join 
        (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
        ) i
        on c.linked_base_acct_no=i.base_acct_no
        and i.rn=1
        where a.data_date='${DATA_DATE}' 
        and a.bddw_end_date='9999-99-99'
        and b.base_acct_no is null
        and d.iou_no is not null 
        and length(i.bank_code)=12
    ) t23
        on t41.repay_account_no=t23.base_acct_no
        and t41.iou_no=t23.iou_no
        and t23.rn=1
     left join 
    (
        select
                c.base_acct_no
               ,c.linked_base_acct_no
               ,a.linked_acct_name
               ,row_number() over(partition by a.base_acct_no order by f.time_stamp desc) rn
        from odata.va_am_aa_maint_hist a 
        left join (
                   select base_acct_no 
                   from odata.va_va_loan_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   union all 
                   select base_acct_no 
                   from odata.va_va_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   ) b 
        on a.linked_base_acct_no=b.base_acct_no
        inner join (
                   select base_acct_no
                          ,linked_base_acct_no
                   from odata.va_am_rel_acct_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   --and linked_status='A'
                   group by base_acct_no
                   ,linked_base_acct_no
                   ) c  
        on a.base_acct_no=c.base_acct_no
        and a.linked_base_acct_no=c.linked_base_acct_no
        left join odata.va_cm_tran_comm f
        on a.main_seq_no=f.main_seq_no
        and f.data_date=if ('${DATA_DATE}' <'2023-10-11','2023-10-11','${DATA_DATE}') --20231011之前数据不全
        and f.bddw_end_date='9999-99-99'
        left join 
        (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
        ) i
        on c.linked_base_acct_no=i.base_acct_no
        and i.rn=1
        where a.data_date='${DATA_DATE}' 
        and a.bddw_end_date='9999-99-99'
        and b.base_acct_no is null
        and length(i.bank_code)=12
    ) t23_2
        on t41.repay_account_no=t23_2.base_acct_no
        and t23_2.rn=1
     left join 
     (
        select
                c.base_acct_no
               ,c.linked_base_acct_no
               ,a.linked_acct_name
               ,e.iou_no
               ,row_number() over(partition by a.base_acct_no,e.iou_no order by abs(unix_timestamp(nvl(g.time_stamp,concat(substr(a.tran_date,1,10),' 00:00:00')))-unix_timestamp(concat((regexp_replace(f.putoutdate,'/','-')),' 00:00:00')))) rn
        from odata.va_am_aa_maint_hist a 
        left join (
                   select base_acct_no 
                   from odata.va_va_loan_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   union all 
                   select base_acct_no 
                   from odata.va_va_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   ) b 
        on a.linked_base_acct_no=b.base_acct_no
        inner join (
                   select base_acct_no
                          ,linked_base_acct_no
                   from odata.va_am_rel_acct_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   --and linked_status='A'
                   group by base_acct_no
                   ,linked_base_acct_no
                   ) c  
        on a.base_acct_no=c.base_acct_no
        and a.linked_base_acct_no=c.linked_base_acct_no
        left join odata.va_cm_tran_comm g
        on a.main_seq_no=g.main_seq_no
        and g.data_date=if ('${DATA_DATE}' <'2023-10-11','2023-10-11','${DATA_DATE}') --20231011之前数据不全
        and g.bddw_end_date='9999-99-99'
        left join odata.suporder_scp_payment_record d 
        on a.base_acct_no=d.balance_payment_account_no
        and d.data_date='${DATA_DATE}' 
        and d.bddw_end_date='9999-99-99'
        left join odata.supacct_enterprise_loan_info e
        on e.pay_order_no  = d.payment_no 
        and e.data_date='${DATA_DATE}' 
        and e.bddw_end_date='9999-99-99'
        left join odata.als_business_duebill f
        on e.iou_no=f.serialno
        and f.data_date='${DATA_DATE}' 
        and f.bddw_end_date='9999-99-99'
        left join 
        (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
        ) i
        on c.linked_base_acct_no=i.base_acct_no
        and i.rn=1
        where a.data_date='${DATA_DATE}' 
        and a.bddw_end_date='9999-99-99'
        and b.base_acct_no is null
        and e.iou_no is not null
        and length(i.bank_code)=12
      ) t23_1
        on t25.balance_payment_account_no=t23_1.base_acct_no
        and t41.iou_no=t23_1.iou_no
        and t23_1.rn=1
    left join 
     (
        select
                c.base_acct_no
               ,c.linked_base_acct_no
               ,a.linked_acct_name
               ,row_number() over(partition by a.base_acct_no order by f.time_stamp desc) rn
        from odata.va_am_aa_maint_hist a 
        left join (
                   select base_acct_no 
                   from odata.va_va_loan_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   union all 
                   select base_acct_no 
                   from odata.va_va_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   ) b 
        on a.linked_base_acct_no=b.base_acct_no
        inner join (
                   select base_acct_no
                          ,linked_base_acct_no
                   from odata.va_am_rel_acct_acct
                   where data_date='${DATA_DATE}' 
                   and bddw_end_date='9999-99-99'
                   --and linked_status='A'
                   group by base_acct_no
                   ,linked_base_acct_no
                   ) c  
        on a.base_acct_no=c.base_acct_no
        and a.linked_base_acct_no=c.linked_base_acct_no
        left join odata.va_cm_tran_comm f
        on a.main_seq_no=f.main_seq_no
        and f.data_date=if ('${DATA_DATE}' <'2023-10-11','2023-10-11','${DATA_DATE}') --20231011之前数据不全
        and f.bddw_end_date='9999-99-99'
        left join 
        (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
        ) i
        on c.linked_base_acct_no=i.base_acct_no
        and i.rn=1
        where a.data_date='${DATA_DATE}' 
        and a.bddw_end_date='9999-99-99'
        and b.base_acct_no is null
        and length(i.bank_code)=12
      ) t23_3
        on t25.balance_payment_account_no=t23_3.base_acct_no
        and t23_3.rn=1
    left join 
    (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
    ) t24
        on t23.linked_base_acct_no=t24.base_acct_no
        and t24.rn=1
    left join 
    (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
    ) t24_1
        on t23_1.linked_base_acct_no=t24_1.base_acct_no
        and t24_1.rn=1
        left join 
    (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
    ) t24_2
        on t23_2.linked_base_acct_no=t24_2.base_acct_no
        and t24_2.rn=1
        left join 
    (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
    ) t24_3
        on t23_3.linked_base_acct_no=t24_3.base_acct_no
        and t24_3.rn=1
 where t1.data_date='${DATA_DATE}'
   and t1.bddw_end_date='9999-99-99'
   and t1.lead_acct_flag='N'
   and t1.prod_type in ('110101','110150')
   and (nvl(t1.acct_close_reason,'') not in ('发放冲正','贷款未发放复核关闭') or (nvl(t1.acct_close_reason,'') in ('发放冲正','贷款未发放复核关闭') and t1.acct_open_date<>t1.acct_close_date ))