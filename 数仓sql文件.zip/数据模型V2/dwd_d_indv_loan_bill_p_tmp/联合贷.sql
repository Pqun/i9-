--2.yangqihao.dwd_d_indv_loan_bill_p
-------------------------------------------------------------------
--脚本名称:dwd_d_indv_loan_bill_p
--功能描述:个人贷款借据信息表
--作    者:于国睿
--开发日期:2021-09-24
--直属经理:方杰
--目标表  :dwd.dwd_d_indv_loan_bill_p 
--来源表：odata.sllv_nl_acct_schedule_detail    线上贷款账户计划明细表
--来源表：odata.sllv_nl_receipt_detail          线上贷款回收明细表
--来源表：odata.sllv_nl_acct                    线上贷款账户基本信息表
--来源表：odata.sym_gl_prod_accounting          产品科目表
--来源表：odata.sym_cif_client                  客户信息表
--来源表：odata.sym_cif_client_document         客户证件信息表
--来源表：odata.sym_cif_client_contact_tbl      客户联系信息表
--来源表：odata.sllv_nl_acct_balance            线上贷款账户余额表
--来源表：odata.sllv_nl_acct_int_detail         线上贷款账户利息明细表
--来源表：odata.plm_loan_info_detail            贷款五级分类
--来源表：odata.order_contract_sign             合同签署表
--来源表：odata.order_main_loan_order           订单主表
--来源表：odata.sym_mb_prod_type                产品类型定义表
--来源表：odata.acct_loan_category              贷款五级分类
--来源表：odata.gl_v_gl_subject                 科目名称表
--来源表：dwd.dwd_d_indv_credit_cont_p          个人授信合同表
--来源表：gdata.dim_g_partner_mapping_p         合作方编码映射表
--来源表：odata.order_product_loan_info         产品贷款信息表
--来源表：odata.sllv_nl_partner_int_detail      合作方利息明细表  
--来源表：odata.sllv_nl_noschedule_invoice      线上贷款非计划单据表
--来源表：odata.order_job_info                  工作信息表 
--来源表：odata.slur_nl_credit_assign_detail    债转明细记录表
--修改历史:
--         1、于国睿     2021-09-24     新建
--         2、高源       2022-06-07     新增应收未收利息、应收利息科目、利息调整、利息调整科目、利息拖欠日期、
--                                      来源系统、贷款投向行业、结清标识等字段,结清日期逻辑调整
--         3、高源       2022-06-22     新增记账时间字段逻辑
--         4、高源       2022-07-07     新增计息基础、客户所属行业、贷款业务细类、贷款用途明细分类字段逻辑
--         5、高源       2022-07-14     修改借据关闭日期字段逻辑
--         6、高源       2022-08-10     借据起始日期、借据到期日、借据关闭日期逻辑调整，结清时间格式调整
--         7、高源       2022-10-09     新增机构号、贷款支用申请编号字段逻辑
--         8、高源       2022-10-19     洋钱罐联合贷还款方式逻辑调整
--         9、高源       2022-10-24     贷款合同状态冲正部分逻辑调整
--         10、高源      2022-11-03     还款方式、还款频率逻辑调整
--         11、华天顺    2022-12-02     新增核算状态字段
--         12、华天顺    2022-12-20     新增伊春联合贷
--         13.华天顺     2022-12-27     担保方式取数逻辑调整
--         14.华天顺     2023-01-03     逾期天数取数逻辑调整，新增逾期本金，利息和本金逾期日字段
--         15.华天顺     2023-02-01     新增张家港二期贷款产品
--         16.华天顺     2023-02-03     逾期本金，逾期利息逻辑调整
--         17.杨琦浩     2023-03-14     增加到期日字段
--         18.杨琦浩     2023-04-14     长安新生业务细类取数逻辑修改
--         19.杨琦浩     2023-05-17     新增项目ID字段
--         20.杨琦浩     2023-05-22     新增小赢张家港联合贷产品
--         21.杨琦浩     2023-06-27     授信信息逻辑调整
--         22.杨琦浩     2023-07-06     调整发放金额、贷款合同状态、逾期信息在借据债转后的取数逻辑
--         23.杨琦浩     2023-08-24     新增放款、还款账号信息字段
--         24.杨琦浩     2023-08-30     新增表内、表外欠息字段
--         25.杨琦浩     2023-08-31     修改计息方式取数逻辑
--         26.杨琦浩     2023-10-12     新增入账户名字段
--         27.杨琦浩     2023-10-25     表外欠息调整为非应计标志
-------------------------------------------------------------------
--联合贷
insert overwrite table dwd.dwd_d_indv_loan_bill_p_tmp partition(data_date='${DATA_DATE}',prod_code)
select /*+ REPARTITION(1) */
       nvl(t1.cmisloan_no,'')        as bill_no  --借据号
      ,nvl(t2.prod_desc,'')          as prod_name  --产品名称
      ,nvl(t1.base_acct_no,'')       as acct_no  --账号
      ,nvl(t1.acct_seq_no,'')        as acct_seq_no  --账户序列号
      ,nvl(t11.product_type,'')      as biz_prod_code  --业务产品号
      ,nvl(t11.sub_product_type,'')  as sub_biz_prod_code  --业务子产品号
      ,'01'                          as accting_cacl_mode  --会计核算方式
      ,nvl(t3.gl_code_a,'')          as subj_no  --科目号
      ,nvl(t9.gl_code_name,'')       as subj_name  --科目名称
      ,nvl(t1.client_no,'')          as cust_id  --客户号
      ,nvl(t4.ch_client_name,'')     as cust_name  --客户姓名
      ,nvl(t5.document_type,'')      as cert_type  --证件类型
      ,nvl(t5.document_id,'')        as cert_no  --证件号
      ,nvl(t6.contact_tel,'')        as mobile_no  --客户手机号
      --,nvl(t27.credit_limit,0)       as credit_limit  --授信额度
      --,nvl(t27.credit_terms,'')      as credit_term  --授信期限
      --,nvl(substr(t27.credit_start_date,1,10),'')     as credit_start_date  --授信起始日期
      --,nvl(substr(t27.credit_mature_date,1,10),'')    as credit_end_date  --授信到期日期
      --,nvl(t11.credit_order_id,'')   as credit_cont_no  --授信合同编号
      ,coalesce(t27.credit_limit,t31.credit_limit,0)         as credit_limit  --授信额度
      --,coalesce(t27.credit_terms,t31.credit_terms,'')      as credit_term  --授信期限
      ,''                                                    as credit_term  --授信期限
      ,coalesce(substr(t27.credit_start_date,1,10),substr(t31.credit_start_date,1,10),'')     as credit_start_date  --授信起始日期
      ,coalesce(substr(t27.credit_mature_date,1,10),substr(t31.credit_mature_date,1,10),'')    as credit_end_date  --授信到期日期
      ,coalesce(t27.credit_cont_no,t31.credit_cont_no,'') as credit_cont_no  --授信合同编号
      ,case when t1.prod_type in ('110135','110174','110169','110176') then nvl(t7.repay_type,'')   --网贷信用贷款
            when t1.prod_type in ('110118','110119','110127') then nvl(t12.repay_type,'')   --长安新生其他抵押贷款
        end                          as repay_mode  --还款方式   
      ,nvl(substr(t1.acct_open_date,1,10),'')  as loan_grant_date  --贷款发放日期
      ,'00:00:00'                    as loan_grant_time  --贷款发放时间
      ,case when t1.prod_type in ('110135','110174','110169','110176') then t1.cmisloan_no --网贷合同号就取借据号
            else nvl(t10.contract_no ,'')
        end                          as loan_cont_no  --贷款合同号
      ,''                            as fin_supp_mode  --贷款财政扶持方式
      ,case when t1.prod_type in ('110118','110119','110127') then 'D'  --网贷信用贷款
            when t1.prod_type in ('110135','110174','110169','110176') then 'C' --长安新生其他抵押贷款 --230522 新增小赢张家港联合贷
        end                          as loan_guar_mode  --贷款担保方式
      ,case when t3.gl_code_a = '10400101' then '2' 
            when t3.gl_code_a = '10400201' then '3'  
            else '' 
        end                          as loan_purp_desc  --贷款用途说明
      ,'TR05'                        as pric_benc  --定价基准
      ,case when t91.cmisloan_no is not null then '106'
            when t1.acct_close_reason='发放冲正'  then '111'
            when t1.acct_status<>'C' and t1.accounting_status<>'ZHC' then '107' 
            when t1.acct_status<>'C' and t1.accounting_status='ZHC' then '105'
            when t1.acct_status='C' then '106'
            when t11.status in(1,2,13,14) then '101'
            when t11.status in(4,5) then '103'
            when t11.status =11 then '104'
            when t11.status =12 then '102'
            when t11.status =15 then '111'
        end                          as loan_cont_status  --贷款合同状态
      ,nvl(substr(t1.acct_open_date,1,10),'')     as loan_start_date  --借据起始日期
      ,nvl(substr(t1.ori_maturity_date,1,10),'')  as loan_mature_date  --借据到期日期
      --,nvl(substr(t1.acct_close_date,1,10  ),'')  as loan_close_data  --借据关闭日期
      ,case when t91.cmisloan_no is not null then from_unixtime(unix_timestamp(t91.apply_date,'yyyyMMdd'),'yyyy-MM-dd')
            else nvl(substr(t1.acct_close_date,1,10  ),'') end as loan_close_data  --借据关闭日期
      --,nvl(t16.total_amount_dda-t16.total_amount_dda_partner,0)   as loan_amt  --放款金额
      ,case when t91.cmisloan_no is not null then nvl(round(nvl(t12.actual_loan_amount,0)*0.99,2),0)
            else nvl(t16.total_amount_dda-t16.total_amount_dda_partner,0) end as loan_amt  --放款金额
      ,nvl(t28.stage_no_max,0)       as total_loan_terms  --放款总期数
      ,nvl(t29.stage_no_max,0)       as curr_term_no  --当前期次
      ,'RF01'                        as rate_type  --利率类型
      ,nvl(t15.real_rate,0)          as real_rate  --实际利率
      ,nvl(t50.partner_id,'')        as partner_id  --合作方编码
      ,nvl(t50.partner_name,'')      as partner_name  --合作方名称
      ,''                            as sub_channel_type  --渠道类型
      ,case when t1.prod_type = '110119' then '1'
            when t1.prod_type in ('110135','110174','110169','110176') then '0'
            else '' 
        end                          as consume_scen_flag  --消费场景标签
      ,case when t1.prod_type in ('110135','110174','110169','110176') then t7.invest_ratio
            else 0.99 
        end                          as invest_ratio  --出资比例
      ,nvl(t1.ccy,'')                as ccy  --币种
      ,nvl(t26.attr_value,0)         as grace_days  --宽限天数
      ,case when coalesce(from_unixtime(unix_timestamp(t91.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),substr(t1.acct_close_date,1,10),'')>'${DATA_DATE}'
            then ''
            else coalesce(from_unixtime(unix_timestamp(t91.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),substr(t1.acct_close_date,1,10),'')
        end  as clear_date  --结清日期
      ,case when t91.cmisloan_no is not null then ''
            when t30.internal_key is not null
            then least(nvl(t30.due_date_pri,''),nvl(t30.due_date_int,''))
            else '' 
        end          as overdue_start_date  --逾期起始日
      ,case when t91.cmisloan_no is not null then 0
            when t30.internal_key is not null
            then greatest(nvl(datediff('${DATA_DATE}',t30.due_date_pri),0),nvl(datediff('${DATA_DATE}',t30.due_date_int),0))
            else 0  
        end                              as overdue_days --逾期天数
      ,''                            as defer_mature_date  --贷款展期到期日期
      ,case when t91.cmisloan_no is not null then ''
            when t30.due_date_pri is not null and t30.due_date_int is null 
            then '01'
            when t30.due_date_pri is null and t30.due_date_int is not null 
            then '02'
            when t30.due_date_pri is not null and t30.due_date_int is not null 
            then '03'
            else '' 
        end                              as overdue_type  --逾期类型
      ,case when t91.cmisloan_no is not null then 'FQ01'
            when t17.loan_id is not null 
            then nvl(t17.manual_five_class,'')
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.five_cate = '1' 
            then 'FQ01'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.five_cate = '2' 
            then 'FQ02'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.five_cate = '3' 
            then 'FQ03'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.five_cate = '4' 
            then 'FQ04'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.five_cate = '5' 
            then 'FQ05'
            when t1.prod_type not in ('110135','110174','110169','110176') and t17.loan_id is null 
            then nvl(t18.five_category,'')
        end                          as five_risk_level  --贷款5级分类
      --,nvl(t20.account_no,'')        as receive_acct_no   --贷款入账账号 
      ,case when t1.prod_type not in ('110135','110174','110169','110176') 
            then nvl(t20.account_no,'')
            else coalesce(t7.loan_card_no,t7.loan_acc,'') 
       end as receive_acct_no  --贷款入账账号 
      --,nvl(t19.account_no,'')        as repay_acct_no  --还款账号
      ,case when t1.prod_type not in ('110135','110174','110169','110176') 
            then coalesce(t19.account_no,t32.base_acct_no,'')
            else coalesce(t7.repay_card_no,t7.repay_acc,'')
       end as repay_acct_no  --还款账号
      ,case when t12.payment_mode=1 then '1'
            when t12.payment_mode=2 then '2'
            else '1' 
        end                          as payment_mode  --支付方式
      ,'02'                          as cash_tran_flag  --现转标志
      ,'顾凡'                        as credit_tlr_name  --信贷员姓名
      ,'xs0087'                      as credit_tlr_id  --信贷员员工号
      ,case t15.cycle_freq
            when 'M1' then 'B01'
            when 'M3' then 'B02'
            when 'M6' then 'B06'
            else 'B99'
        end                          as int_mode  --计息方式
      ,case t15.cycle_freq
            when 'M1' then '01'
            when 'M3' then '02'
            when 'M6' then '03'
            else '07'  
      end                                            as repay_freq  --还款频率
      ,''                                            as pay_seq_no  --支付流水号
      ,case when t1.prod_type in ('110135','110174','110169','110176') then '1' 
            when t1.prod_type in ('110118','110119','110127') then '2'   end                        as loan_biz_class  --业务分类
      ,t16.total_amount_bal-t16.total_amount_partner    as bal  --贷款余额
      ,nvl(case when t1.accounting_status in ('ZHC','YUQ') and t1.acct_status in ('A','P')
         then (nvl(smaid.int_accrued,0) - nvl(snpid.partner_int_accrued_sum,0)) + nvl(snpid.manager_int_adj_sum,0) + 
        (nvl(snasd.outstanding_sum,0) - nvl(snasd.partner_outstanding_sum,0)) else 0 end,0)         as recv_int  --应收未收利息
      ,nvl(t3.gl_code_int_rec,'')                    as recv_int_subj  --应收利息科目
      ,0                                             as int_adj  --利息调整
      ,''                                            as int_adj_subj  --利息调整科目
      --,nvl(t30.due_date_int,'')                   as overdue_date_int  --利息拖欠日期
      ,case when t91.cmisloan_no is not null then ''
            else nvl(t30.due_date_int,'') end        as overdue_date_int  --利息拖欠日期
      ,'SYM'                                         as source_system  --来源系统
      ,nvl(case when t12.loan_id is not null then substr(t12.loan_cast_industry_code,19,5) else '' end,'') as loan_indst_type  --贷款投向行业
      ,case when coalesce(from_unixtime(unix_timestamp(t91.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),substr(t1.acct_close_date,1,10),'')>'${DATA_DATE}'
            then '0'
            when t91.apply_date is not null then '1'
            when t1.acct_close_date is not null then '1'
            else '0'  end                            as fully_settled -- 结清标识  0未结清 1结清
      ,nvl(substr(t1.acct_open_date,1,10),'')        as accting_date   --记账日期
      ,case when t15.year_basis='360' and t15.month_basis='30' then  '1'
            when t15.year_basis='360' and t15.month_basis='ACT' then  '2'  
            else '7'   end                           as int_basis    --计息基础
      ,''                                            as cust_indust_type  --客户所属行业
      ,case when t1.prod_type in ('110135','110174','110169','110176') then 'A29'
            when t1.prod_type = '110119' and t12.loan_need_type ='2' then 'A29'
            when t1.prod_type in ('110118','110127') then 
              case when t12.loan_need_type=3 and tt20.work_kind='1' then 'A18'
                   when t12.loan_need_type=3 and tt20.work_kind='3' then 'A17'
                   when t12.loan_need_type=3 then 'A19' else '' end
            else ''  end                             as loan_biz_detail  --贷款业务细类
      ,case when t1.prod_type not in ('110135','110174','110169','110176') and t12.loan_need_type = '1' then '企业经营性贷款'
            when t1.prod_type not in ('110135','110174','110169','110176') and t12.loan_need_type = '2' then '个人消费贷款'
            when t1.prod_type not in ('110135','110174','110169','110176') and t12.loan_need_type = '3' then '个人经营性贷款'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '100' then '资金周转'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '101' then '投资需求'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '102' then '扩大经营规模'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '103' then '店面装修改造'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '104' then '购房'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '105' then '购车（自用型）'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '106' then '购买车位'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '107' then '房屋装修'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '108' then '购买大额耐用消费品'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '109' then '旅游'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '110' then '出国留学'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '111' then '教育'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '112' then '婚嫁'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '113' then '医疗保健'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '114' then '购买大额人寿保险'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '115' then '资产置换'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '116' then '其他'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '117' then '土地储备'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '118' then '房地产开发'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '119' then '个人住房'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '120' then '商业用房'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '121' then '基本建设'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '122' then '技术改造'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '123' then '基础设施'
            when t1.prod_type in ('110135','110174','110169','110176')  and t7.loan_purpose = '124' then '个人日常消费'
            else  '其他'   end                          as loan_purp_detail  --贷款用途明细分类
      ,nvl(t1.branch   ,'')                             as org_id            --机构号
      ,coalesce(t11.loan_id,t7.app_no,'')               as loan_app_no       --贷款支用申请编号
      ,nvl(t1.accounting_status,'')                     as accting_status    --核算状态
      --,nvl(yq.pri_outstanding,0)                                       as overdue_prin              --逾期本金
      ,case when t91.cmisloan_no is not null then 0
            else nvl(yq.pri_outstanding,0) end          as overdue_prin              --逾期本金
      --,nvl(yq.int_outstanding,0)+nvl(odp.odp_outstanding,0)                                       as overdue_int               --逾期利息
      ,case when t91.cmisloan_no is not null then 0
            else nvl(yq.int_outstanding,0)+nvl(odp.odp_outstanding,0)  end as overdue_int               --逾期利息
      --,nvl(t30.due_date_pri,'')                as pri_overdue_date          --本金逾期日
      ,case when t91.cmisloan_no is not null then ''
            else nvl(t30.due_date_pri,'') end           as pri_overdue_date          --本金逾期日
      ,nvl(substr(t1.maturity_date,1,10),'')            as mature_date  --到期日
      ,''                                                 as project_id --项目ID
      ,case when t1.prod_type not in ('110135','110174','110169','110176') and t20.account_no is not null
            then nvl(case when length(t20.bank_name_code)=12 then t20.bank_name_code else '' end,'')
            when t1.prod_type in ('110135','110174','110169','110176') and nvl(t7.loan_card_no,t7.loan_acc) is not null
            then nvl(case when length(t7.loan_acc_bank)=12 then t7.loan_acc_bank else '' end,'')
            else ''
       end                                              as receive_bank_code --贷款入账账号所属行号
      ,case when t1.prod_type not in ('110135','110174','110169','110176') and t20.account_no is not null
            then nvl(t20.bank_name,'')
            when t1.prod_type in ('110135','110174','110169','110176') and nvl(t7.loan_card_no,t7.loan_acc) is not null 
            then nvl(t7.loan_acc_bank_name,'')
            else ''
       end                                              as receive_bank_name --贷款入账账号所属行名
      ,case when t1.prod_type not in ('110135','110174','110169','110176') and t19.account_no is not null 
            then nvl(case when length(t19.settle_bank_code)=12 then t19.settle_bank_code else '' end,'')
            when t1.prod_type not in ('110135','110174','110169','110176') and t32.base_acct_no is not null
            then nvl(case when length(t32.bank_code)=12 then t32.bank_code else '' end,'')
            when t1.prod_type in ('110135','110174','110169','110176') and nvl(t7.loan_card_no,t7.loan_acc) is not null
            then nvl(case when length(t7.repay_acc_bank)=12 then t7.repay_acc_bank else '' end,'')
            else ''
       end                                              as repay_bank_code --还款账号所属行号
      ,case when t1.prod_type not in ('110135','110174','110169','110176') and t19.account_no is not null
            then nvl(t19.settle_bank_name,'')
            when t1.prod_type not in ('110135','110174','110169','110176') and t32.base_acct_no is not null
            then nvl(t32.bank_name,'')
            when t1.prod_type in ('110135','110174','110169','110176') and nvl(t7.loan_card_no,t7.loan_acc) is not null
            then nvl(t7.repay_acc_bank_name,'')
            else ''
       end                                              as repay_bank_name --还款账号所属行名
      ,case when t1.accounting_status in ('FY','FYJ','WRN') then '1'
            else '0' end                                as non_accru_flag --非应计标志
      --,case when t1.accounting_status in ('ZHC','YUQ') then nvl(yq.int_int_outstanding,0)+nvl(odp.odp_outstanding,0)-nvl(t33.par_odp_outstanding,0)
      --     else 0 end                                  as in_bal_int --表内欠息
      ,0                                                as in_bal_int --表内欠息
      ,case when t1.prod_type not in ('110135','110174','110169','110176') and t20.account_no is not null
            then nvl(t19.account_name,'')
            when t1.prod_type in ('110135','110174','110169','110176') and nvl(t7.loan_card_no,t7.loan_acc) is not null
            then nvl(t7.cust_name,'')
            else ''
       end                                              as receive_acct_name --入账户名
      ,t1.prod_type                                     as prod_code         --产品号
 from odata.sllv_nl_acct t1
 left join odata.sym_mb_prod_type t2
   on t1.prod_type=t2.prod_type
  and t2.data_date = '${DATA_DATE}'
  and t2.bddw_end_date = '9999-99-99'
 left join odata.order_main_loan_order t11
   on trim(t1.cmisloan_no) = trim(t11.receipt_no)
  and t11.data_date='${DATA_DATE}'
  and t11.bddw_end_date='9999-99-99'
 left join odata.sym_gl_prod_accounting t3  --通过科目号来取消费还是经营
   on t3.data_date='${DATA_DATE}'
  and t3.bddw_end_date='9999-99-99'
  and t1.prod_type = t3.prod_type
  and t3.accounting_status = 'ZHC'
  and t3.tran_category = 'ALL'
 left join odata.sym_cif_client t4
   on t1.client_no = t4.client_no
  and t4.data_date = '${DATA_DATE}'
  and t4.bddw_end_date = '9999-99-99'
 left join odata.sym_cif_client_document t5
   on t1.client_no = t5.client_no
  and t5.data_date = '${DATA_DATE}'
  and t5.bddw_end_date = '9999-99-99'
  and t5.pref_flag='Y' 
 left join odata.sym_cif_client_contact_tbl t6
   on t1.client_no = t6.client_no 
  and t6.pref_flag='Y'
  and t6.data_date='${DATA_DATE}'
  and t6.bddw_end_date='9999-99-99'
 left join odata.ols_loan_cont_info t7
   on t1.cmisloan_no=t7.bill_no
  and t7.prd_code = '10071001001'
  and t7.data_date='${DATA_DATE}'
  and t7.bddw_end_date='9999-99-99'
 left join odata.gl_v_gl_subject t9
   on t3.gl_code_a=t9.gl_code
  and t9.bddw_end_date = '9999-99-99'
  and t9.data_date = '${DATA_DATE}'
 left join odata.order_contract_sign t10
   on t11.loan_id=t10.loan_id
  and t10.data_date='${DATA_DATE}'
  and t10.bddw_end_date='9999-99-99'
  and t10.signer_type= '1'   --签署人为借款人
  and t10.contract_type= '2' --个人借款合同
  and t10.status='1'
 left join odata.order_product_loan_info t12
   on t11.loan_id = t12.loan_id
  and t12.data_date='${DATA_DATE}' 
  and t12.bddw_end_date='9999-99-99'
 left join odata.sllv_nl_acct_int_detail t15
   on t1.internal_key = t15.internal_key
  and t15.int_class = 'INT'
  and t15.data_date='${DATA_DATE}'
  and t15.bddw_end_date='9999-99-99'
 left join (select internal_key
                  ,sum(bal_prev)      as total_amount_bal
                  ,sum(dda_amt)  as total_amount_dda
                  ,sum(intp_amt) as total_amount_intp
                  ,sum(odpp_amt) as total_amount_odpp
                  ,sum(osl_amt)  as total_amount_osl
                  ,sum(prd_amt)  as total_amount_prd
                  ,sum(partner_bal_prev)  as total_amount_partner
                  ,sum(partner_dda_amt) as total_amount_dda_partner
              from odata.sllv_nl_acct_balance
             where data_date='${DATA_DATE}' 
               and bddw_end_date='9999-99-99'
             group by internal_key) t16
   on t1.internal_key=t16.internal_key
   left join (select internal_key,sum(int_accrued) int_accrued,sum(int_adj) int_adj from odata.sllv_nl_acct_int_detail 
           where data_date = '${DATA_DATE}'
           and bddw_end_date='9999-99-99' 
           and int_class in ('INT','ODP')
           group by internal_key) smaid
       on t1.internal_key = smaid.internal_key 
   left join (select internal_key,sum(partner_int_accrued) as partner_int_accrued_sum,sum(manager_int_adj) as manager_int_adj_sum from odata.sllv_nl_partner_int_detail 
           where int_class in ('INT','ODP') and data_date = '${DATA_DATE}' and bddw_end_date = '9999-99-99'
           group by internal_key) snpid 
        on t1.internal_key = snpid.internal_key 
  left join (select internal_key,sum(outstanding) as outstanding_sum,sum(partner_outstanding) as partner_outstanding_sum from odata.sllv_nl_acct_schedule_detail 
           where amt_type in ('INT','ODP') and data_date = '${DATA_DATE}' and bddw_end_date = '9999-99-99'
           group by internal_key) snasd 
       on t1.internal_key = snasd.internal_key 
 left join (select  loan_id
                   ,prod_type
                   ,case when manual_five_class = '正常'  then  'FQ01'
                         when manual_five_class = '关注'  then  'FQ02'
                         when manual_five_class = '次级'  then  'FQ03'
                         when manual_five_class = '可疑'  then  'FQ04'
                         when manual_five_class = '损失'  then  'FQ05'
                     end   as manual_five_class
              from odata.plm_loan_info_detail
             where data_date = '${DATA_DATE}'
               and bddw_end_date = '9999-99-99'
               and manual_term_validity_date >= '${DATA_DATE}')t17
       on t1.cmisloan_no = t17.loan_id
      and t1.prod_type = t17.prod_type
 left join odata.acct_loan_category t18
   on trim(t1.cmisloan_no) = trim(t18.loan_id)
  and t18.data_date = '${DATA_DATE}'
  and t18.bddw_end_date = '9999-99-99'
 left join odata.order_repay_account t19
   on trim(t11.loan_id)=trim(t19.loan_id) 
  and t19.data_date='${DATA_DATE}' 
  and t19.bddw_end_date='9999-99-99' 
  and t19.withhold_order=1
 left join odata.order_bank_account_info t20
   on trim(t11.loan_id)=trim(t20.loan_id) 
  and t20.data_date='${DATA_DATE}' 
  and t20.bddw_end_date='9999-99-99'
 left join odata.order_job_info tt20
    on trim(t11.loan_id)=tt20.loan_id
   and tt20.data_date='${DATA_DATE}' 
   and tt20.bddw_end_date='9999-99-99'
 left join odata.sso_upms_user t21
   on t11.xsbank_salesman=t21.user_id     
  and t21.data_date='${DATA_DATE}' 
  and t21.bddw_end_date='9999-99-99'
 left join odata.sym_mb_prod_define t26
   on t1.prod_type = t26.prod_type 
  and t26.data_date='${DATA_DATE}'
  and t26.bddw_end_date='9999-99-99'
  and t26.assemble_id='GRACE_PERIOD'
 left join dwd.dwd_d_indv_credit_cont_p t27
   on t27.credit_cont_no=t11.loan_id
  and t27.data_date='${DATA_DATE}'
 left join dwd.dwd_d_indv_credit_cont_p t31
   on t31.credit_cont_no=t7.crd_cont_no
  and t31.data_date='${DATA_DATE}'
 left join gdata.dim_g_partner_mapping_p t50
   on t1.partner_id=t50.order_partner_id
 left join(select internal_key,
                  max(cast(stage_no as int)) as stage_no_max
             from odata.sllv_nl_receipt_detail
            where data_date='${DATA_DATE}' 
              and bddw_end_date='9999-99-99'
            group by internal_key) t29  
   on t1.internal_key=t29.internal_key
 left join(select internal_key,
                  max(cast(stage_no as int)) as stage_no_max
             from odata.sllv_nl_acct_schedule_detail
            where data_date='${DATA_DATE}' 
              and bddw_end_date='9999-99-99'
            group by internal_key) t28  
   on t1.internal_key=t28.internal_key
 left join(        
         select  
                 internal_key
                ,min(case when amt_type='PRI'then substr(due_date,1,10) end) due_date_pri
                ,min(case when amt_type='INT'then substr(due_date,1,10) end) due_date_int
          from odata.sllv_nl_acct_schedule_detail
         where outstanding>0   
           and data_date='${DATA_DATE}' 
           and bddw_end_date='9999-99-99'
           and due_date is not null
           and substr(due_date,1,10) < '${DATA_DATE}'
      group by internal_key) t30
   on t1.internal_key=t30.internal_key
 left join odata.slur_nl_credit_assign_detail t91  --长安新生债转
       on t1.cmisloan_no = t91.cmisloan_no
      and t91.data_date = '${DATA_DATE}'
      and t91.bddw_end_date = '9999-99-99'
      and t91.status = 'S'
left join (
    select
             sum(case 
                     when ce.amt_type ='PRI' then ce.outstanding - nvl(ce.partner_outstanding,0)
                     when ce.amt_type in ('INT','ODP') then 0
                 end 
                 ) as pri_outstanding
            ,sum(case 
                     when ce.amt_type ='PRI' then 0
                     when ce.amt_type in ('INT','ODP') then ce.outstanding
                 end 
                ) as int_outstanding
            ,sum(case 
                     when ce.amt_type ='PRI' then 0
                     when ce.amt_type in ('INT') then nvl(ce.outstanding,0) - nvl(ce.partner_outstanding,0)
                 end 
                ) as int_int_outstanding,
         ce.internal_key
       from odata.sllv_nl_acct_schedule_detail ce    --非联合贷 小花  小赢  锡房 锡车 
       where ce.data_date='${DATA_DATE}' 
         and ce.bddw_end_date='9999-99-99'
         and substr(ce.due_date,1,10) < '${DATA_DATE}'
         and ce.outstanding >0
       group by ce.internal_key
) yq 
on t1.internal_key = yq.internal_key
left join 
        (select
              od.internal_key
             ,sum(nvl(od.int_accrued,0)+nvl(od.int_adj,0)) as odp_outstanding  --逾期罚息
        from odata.sllv_nl_od_int_detail  od
        where od.data_date='${DATA_DATE}' 
          and od.bddw_end_date='9999-99-99'
          and od.int_class='ODP'
        group by od.internal_key)odp
on t1.internal_key=odp.internal_key
left join (
            select 
                  document_id
                  ,document_type
                  ,base_acct_no
                  ,bank_code
                  ,bank_name
                  ,acct_name
                  ,row_number() over(partition by document_id order by tran_date desc) rn
            from odata.contract_um_agreement_comm
            where data_date = '${DATA_DATE}'
            and bddw_end_date = '9999-99-99'
            and agreement_status='A'
            ) t32 
       on t5.document_id=t32.document_id
       and t5.document_type=concat('1',t32.document_type)
       and t32.rn=1
left join (
          select internal_key
                 ,sum(nvl(int_accrued,0)+nvl(int_adj,0)) as par_odp_outstanding
          from odata.sllv_nl_partner_od_int_detail
          where data_date = '${DATA_DATE}'
            and bddw_end_date = '9999-99-99'
            and int_class in  ('ODP','ODI')
            group by internal_key
          ) t33 
on t1.internal_key=t33.internal_key
where t1.data_date = '${DATA_DATE}'
  and t1.bddw_end_date = '9999-99-99'
  and substr(t1.acct_open_date,1,10) <= '${DATA_DATE}'
  and t1.prod_type in ('110118','110119','110127','110135','110174','110169','110176')