--2.yangqihao.dwd_d_corp_loan_cont_p
--脚本名称：非同业对公贷款合同信息表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive dwd层dwd.dwd_d_corp_loan_cont_p
--作    者：杨琦浩
--开发日期：2022-07-08
--直属经理：方杰
--来源表  ：odata.sym_mb_acct 账户基本信息表
--来源表  ：odata.sym_cif_client_type 客户类型
--来源表  ：odata.als_business_duebill 业务借据(账户)信息表
--来源表  ：odata.als_business_contract 业务合同信息表
--来源表  ：odata.sym_mb_prod_type 产品类型定义表
--来源表  ：smart.js_201_dbwxx 担保物信息表
--来源表  ：adm.ods_code_mapping 源系统接口与ADM目标表参数对应表
--来源表  ：odata.slur_jcb_loan_info_final 金城网贷借据信息表
--来源表  ：odata.supacct_enterprise_loan_info 贷款信息表 
--来源表  ： odata.als_flow_task  流程任务表  

--目标表  ：dwd.dwd_d_corp_loan_cont_p
--修改历史：
--          1.杨琦浩   2022-07-08    新建
--          2.杨琦浩   2022-12-26    新增锡惠贷部分
--          3.杨琦浩   2023-02-06    新增客户经理工号字段
--          4.高源     2023-03-20    新增银承业务数据范围，业务分类字段逻辑调整为信贷业务品种
--                                   贷款合同数据范围变更，新增已生成贷款合同但未放款的合同号
--          5.高源     2023-03-23    授信号逻辑调整，取最新的授信合同号（包括失效授信）
--          6.高源     2023-07-17    新增展期合同数据范围，新增发生类型字段
--          7.于国睿   2023-09-05    新增担保方式,贷款用途逻辑
--          8.姚威     2023-11-21    新增审批人工号
--          9.姚威     2023-11-28    信贷取最早的授信审批人员
--          10.邓权    2023-12-18    新增项目编号
--          11.杨琦浩  2024-03-20    新增锡享贷产品
--          12.杨琦浩  2024-04-01    修改锡享贷产品贷款投向行业取数逻辑
--          13.姚威    2024-05-14    新增孚厘企业贷
--------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_corp_loan_cont_p partition(data_date = '${DATA_DATE}')
    select /*+ REPARTITION(1) */
           nvl(a.serialno,'')                           as cont_no              --合同号
          ,nvl(a.customerid,'')                         as cust_id              --客户号
          ,nvl(a.customername,'')                       as cust_name            --客户名称
          ,''                                           as prod_code            --产品编号
          ,''                                           as prod_name            --产品名称
          ,'CNY'                                        as ccy                  --币种
          ,nvl(a.businesssum,0)                         as cont_amt             --合同金额
          ,nvl(regexp_replace(a.putoutdate,'/','-'),'') as cont_start_date      --合同生效日期
          ,nvl(regexp_replace(a.maturity,'/','-'),'')   as cont_mature_date     --合同到期日期
          ,nvl(a.vouchtype,'')                          as guar_mode            --担保方式  update 20230905 yuguorui 新增逻辑
          ,nvl(a.purpose,'')                            as loan_purp            --贷款用途  update 20230908 yuguorui 新增逻辑
          ,''                                           as loan_area_code       --贷款投向地区
          ,nvl(a.direction,'')                          as loan_indust_type     --贷款投向行业
          ,nvl(g.relativeserialno,'')                   as credit_cont_no       --授信合同号
          ,nvl(regexp_replace(a.putoutdate,'/','-'),'') as approve_date         --批准日期
          ,nvl(a.status,'')                             as loan_cont_status     --贷款合同状态
          ,nvl(a.businesstype,'')                       as loan_biz_class       --业务分类 
          ,''                                           as loan_biz_detail      --贷款业务细类   
          ,coalesce(h.userid,a.operateuserid,'')        as cust_magr_id         --客户经理工号
		  ,nvl(a.occurtype,'')                          as occur_type           --发生类型        --2023-07-17新增字段
          ,nvl(q.userid , '')                           as approver             --审批人员工号
          ,nvl(i.project_id,'')                         as project_id           --项目ID
	  from odata.als_business_contract a --业务合同信息表
	  left join  (select p.userid , p.contractserialno from
         ( select  
                  t1.userid , t.contractserialno,row_number()over(partition by t.contractserialno order by t1.endtime desc) as rn --信贷取最早的授信审批人员     
                  from 
                   (select *,row_number()over(partition by contractserialno order by putoutdate,serialno) as row_num  
					from odata.als_business_putout 
					where data_date = '${DATA_DATE}' 
					and bddw_end_date = '9999-99-99' 
					)t 
				   inner join odata.als_flow_task t1        --流程任务表  
                        on  t1.data_date = '${DATA_DATE}' 
                        and  t1.bddw_end_date = '9999-99-99' 
                        and  t1.objecttype = 'PutOutApply'  --只选择放款申请类型
						and lower(t1.userid) <>'system'  --删除机器审核记录只保留人审
                        and t.serialno = t1.objectno
                       where t.row_num = 1) p
                        where p.rn =1)                        q
on a.serialno = q.contractserialno	
	  left join (
                   select relativeserialno 
                         ,objectno 
                         ,row_number() over (partition by objectno order by serialno desc)  as rn     
                     from odata.als_cl_occupy g1 --额度占用关系表
                    where objecttype='BusinessContract'
                      and data_date='${DATA_DATE}'
                      and bddw_end_date='9999-99-99'
                   --   and nvl(remark,'') <> 'INVALID'  --无效的               --生效的肯定为最新的流水号
                      and  not exists (  select serialno
                                           from odata.als_cl_occupy g2--额度占用关系表
                                          where data_date='${DATA_DATE}'
                                            and bddw_end_date='9999-99-99'
                                            and serialno between '2022061600001673' and '2022061600002687'           --历史问题数据
                                            and relativeserialno ='BC2022061500000006'
                                            and g1.serialno=g2.serialno)
                  ) g
        on a.serialno=g.objectno
       and g.rn=1
      left join (select userid
	                   ,customerid
                       ,row_number() over(partition by customerid order by inputdate desc) as rn
                   from odata.als_customer_belong h --客户所属列表
                  where belongattribute='1' --客户主办权
                    and data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                ) h  --update 20230919 yuguorui 取最新录入日期的工号
        on a.customerid=h.customerid
       and h.rn = 1
      left join (select loan_contract_no,project_id 
                   from odata.supacct_enterprise_loan_info
                  where data_date = '${DATA_DATE}'
                    and bddw_end_date = '9999-99-99'
               group by loan_contract_no,project_id) i 
             on a.serialno = i.loan_contract_no
     where a.data_date='${DATA_DATE}'
       and a.bddw_end_date='9999-99-99'
       and a.businesstype not like '30%' --授信
       and a.businesstype <>'1020010'  --剔除贴现
       and a.serialno not like 'KCAM%' --金城
    union all ---金城
    select /*+ REPARTITION(1) */ 
           nvl(a.serialno,'')                           as cont_no              --合同号
          ,nvl(a.customerid,'')                         as cust_id              --客户号
          ,nvl(a.customername,'')                       as cust_name            --客户名称
          ,''                                           as prod_code            --产品编号
          ,''                                           as prod_name            --产品名称
          ,'CNY'                                        as ccy                  --币种
          ,nvl(a.businesssum,0)                         as cont_amt             --合同金额
          ,nvl(regexp_replace(a.putoutdate,'/','-'),'') as cont_start_date      --合同生效日期
          ,nvl(regexp_replace(a.maturity,'/','-'),'')   as cont_mature_date     --合同到期日期
          ,nvl(a.vouchtype,'')                          as guar_mode            --担保方式  update 20230905 yuguorui 新增逻辑
          ,nvl(a.purpose,'经营贷款')                    as loan_purp            --贷款用途  update 20230908 yuguorui 新增逻辑  
          ,''                                           as loan_area_code       --贷款投向地区      
          ,nvl(a.direction,'')                          as loan_indust_type     --贷款投向行业
          ,nvl(e.relativeserialno,'')                   as credit_cont_no       --授信合同号
          ,nvl(regexp_replace(a.putoutdate,'/','-'),'') as approve_date         --批准日期
          ,nvl(a.status,'')                             as loan_cont_status     --贷款合同状态
          ,nvl(a.businesstype,'')                       as loan_biz_class       --业务分类 
          ,''                                           as loan_biz_detail      --贷款业务细类  B9 -单位其他普通贷款
          ,coalesce(f.userid,a.operateuserid,'')        as cust_magr_id         --客户经理工号
		  ,nvl(a.occurtype,'')                          as occur_type           --发生类型            --2023-07-17新增字段
          ,nvl(o.username,'')                           as approver             --审批人员工号
          ,nvl(u.project_id,'scp0015090023')            as project_id           --项目id
	  from odata.als_business_contract a --业务合同信息表          
      left join (
                 select relativeserialno 
                       ,objectno 
                       ,row_number() over (partition by objectno order by serialno desc)  as rn     
                   from odata.als_cl_occupy g1 --额度占用关系表
                  where objecttype='BusinessContract'
                    and data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    --and nvl(remark,'') <> 'INVALID'  --无效的
                    and not exists  (  select serialno
                                         from odata.als_cl_occupy g2--额度占用关系表
                                        where data_date='${DATA_DATE}'
                                          and bddw_end_date='9999-99-99'
                                          and serialno between '2022061600001673' and '2022061600002687'        --历史问题数据
                                          and relativeserialno ='BC2022061500000006'
                                          and g1.serialno=g2.serialno)
                  ) e
        on a.serialno = e.objectno
       and e.rn=1
      left join (select userid
	                   ,customerid
                       ,row_number() over(partition by customerid order by inputdate desc) as rn
                   from odata.als_customer_belong h --客户所属列表
                  where belongattribute='1' --客户主办权
                    and data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                ) f  --update 20230919 yuguorui 取最新录入日期的工号
        on a.customerid=f.customerid
       and f.rn = 1
	  left join 
	          (select  apply_no,username from   
                   ( select  *,row_number()over(partition by apply_no order by create_time  desc ,operate_task desc) rn             --供应链取最后一笔为审批人员     
                     from odata.suprisk_use_credit_apply_status_record
                     where data_date = '${DATA_DATE}' 
                     and bddw_end_date = '9999-99-99' 
                     and operate_result not in ('00','01','02','03','04')  ) t             --剔除非人工审批                                               
                left join odata.sso_upms_user t2                --审批人员工号
                     on t.operator=t2.user_id 
                     and t2.data_date='${DATA_DATE}' 
                     and t2.bddw_end_date='9999-99-99' 
					  where  t.rn=1   ) o
	on o.apply_no=regexp_replace(a.artificialno,'L','')  
      left join (select loan_contract_no,project_id 
                   from odata.supacct_enterprise_loan_info
                  where data_date = '${DATA_DATE}'
                    and bddw_end_date = '9999-99-99'
               group by loan_contract_no,project_id) u 
             on a.serialno = u.loan_contract_no
	  where a.data_date='${DATA_DATE}'
       and a.bddw_end_date='9999-99-99'
       and a.businesstype not like '30%' --授信
       and a.serialno like 'KCAM%' --金城 
    union all ---锡惠贷企业融、锡享贷、孚厘
    select /*+ REPARTITION(1) */ distinct
           coalesce(t3.contract_no,t62.contract_no,'')  as cont_no --合同号
          ,nvl(t1.client_no,'')                         as cust_id --客户号
          ,nvl(t4.ch_client_name,'')                    as cust_name --客户名称
          ,nvl(t1.prod_type,'')                         as prod_code --产品编号
          ,nvl(t10.prod_desc,'')                        as prod_name --产品名称
          ,'CNY'                                        as ccy --币种
          --,nvl(t3.apply_amount,0)                       as cont_amt --合同金额
          ,case when t1.prod_type='120111' then nvl(t3.apply_amount,0)
                else nvl(t2.apply_amount,0)             
           end                                          as cont_amt --合同金额
          --,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as cont_start_date --合同生效日期
          --,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')      as cont_mature_date --合同到期日期
          ,''                                           as cont_start_date --合同生效日期
          ,''                                           as cont_mature_date --合同到期日期
          --,case when t5.loan_method = '2' then 'D'  
		  --      when t5.loan_method = '3' then 'C99' 
          --      else ''
          --  end                       as guar_mode --担保方式
          ,case when nvl(t1.prod_type,'')= '120115' then '010' --保证 
		        when t1.prod_type in('120113','120114') and t63.loan_id is not null then '010'
                when t15.loan_id  is null  then '005'
                when t15.loan_id  is not null then '010'
                else ''   
		    end                                         as guar_mode --担保方式  update 20230905 yuguorui 新增逻辑
          ,case when t5.loan_need_type in (1,3) then '经营贷款' 
		        else '其他'
			end                                         as loan_purp --贷款用途  update 20230908 yuguorui 新增逻辑  
          ,nvl(t5.loan_cast_area,'')                    as loan_area_code --贷款投向地区      
          ,coalesce(substr(t14.industry_involved,-5),t5.loan_cast_industry_code,'')     
                                                        as loan_indust_type  --贷款投向行业
          ,nvl(t2.credit_order_id,'')                   as credit_cont_no --授信合同号
          --,coalesce(substr(t6.process_time,1,10),t2.loan_time,'') as approve_date --批准日期
          ,''                                           as approve_date --批准日期
          --,case when t1.acct_status<>'C' and t1.accounting_status<>'ZHC' then '107' 
          --      when t1.acct_status<>'C' and t1.accounting_status='ZHC' then '105'
          --      when t1.acct_status='C' and t1.acct_close_reason='发放冲正' then '111' 
		  --    when t1.acct_status='C' and t1.acct_close_reason<>'发放冲正' then '106'
          --      when t2.status in(1,2,13,14) then '101'
          --      when t2.status in(4,5) then '103'   
		  --    when t2.status = 8 then '106'
          --      when t2.status = 11 then '104'
          --      when t2.status = 12 then '102'
          --      when t2.status = 15 then '111'
          --  end                                         as loan_cont_status --贷款合同状态
		  --,''                                           as loan_cont_status --贷款合同状态
          ,case when t1.prod_type in('120113','120114','120115')
                 then case when t1.acct_status<>'C' and t1.accounting_status<>'ZHC' then 'EFFECTIVE'  --已生效
                           when t1.acct_status<>'C' and t1.accounting_status='ZHC' then 'EFFECTIVE'
                           when t1.acct_status='C' and t1.acct_close_reason='发放冲正' then 'IsNullify' --已作废
                           when t1.acct_status='C' and t1.acct_close_reason<>'发放冲正' then 'INVALID' --已终结
                           when t2.status in(4,5) then 'EFFECTIVE'
                           when t2.status = 8 then 'INVALID'
                           when t2.status = 11 then 'IsNullify'
                           when t2.status = 12 then 'IsNullify'
                           when t2.status = 15 then 'IsNullify'
                      end                                        
                 else ''
            end                                         as loan_cont_status  --合同状态
          ,case when  t1.prod_type='120115' and t5.loan_period_unit = 'M' and  t5.actual_loan_period < 12  then '1010010'    -- 短期 
                when  t1.prod_type='120115' and t5.loan_period_unit = 'M' and  t5.actual_loan_period >= 12 then '1010020'	-- 中长期
                when  t1.prod_type='120115' and t5.loan_period_unit = 'Y' and  t5.actual_loan_period < 1 then   '1010010'
				when  t1.prod_type='120115' and t5.loan_period_unit = 'Y' and  t5.actual_loan_period >= 1 then  '1010020'  
                when  t1.prod_type='120115' and t5.loan_period_unit = 'D' and  t5.actual_loan_period < 360 then '1010010'
				when  t1.prod_type='120115' and t5.loan_period_unit = 'D' and  t5.actual_loan_period >= 360 then'1010020' 
              else  ''            
			     end                                    as loan_biz_class --贷款业务分类
          ,case when t1.prod_type in('120113','120114','120115')
                then 'B2'
                else ''
           end                                          as loan_biz_detail --贷款业务细类
          ,case when  t1.prod_type ='120115' 
                then 'xs0347'		  
				else ''                   
	       end                                          as cust_magr_id   --客户经理工号
		  ,''                                           as occur_type    --发生类型         --2023-07-17新增字段
--      ,nvl(p.username,'')                             as approver      --审批人员工号
        ,''                                             as approver      --审批人员工号
        ,''                                             as project_id
	 from odata.sllv_mb_acct t1
      left join odata.order_main_loan_order t2
        on t1.cmisloan_no = t2.loan_id
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99'
--取授信合同下对应的借款合同      
        left join 
          (
           select b.credit_order_id,a.contract_no,sum(apply_amount) apply_amount
           from odata.order_contract_sign a
           inner join odata.order_main_loan_order b
           on a.loan_id = b.loan_id
           and b.data_date = '${DATA_DATE}'
           and b.bddw_end_date = '9999-99-99'
           and b.status in ('7','8') --还款中、已结清（首次用信成功）
           where a.data_date = '${DATA_DATE}'
           and a.bddw_end_date = '9999-99-99'
           and a.sub_product_type = '25' --锡惠贷产品子分类
           and a.signer_type = '6'   -- 企业法人
           and a.contract_type = '41' -- 人民币流动资金贷款合同
           group by b.credit_order_id,a.contract_no
           )  t3
        on t2.credit_order_id=t3.credit_order_id
      left join odata.xscontract_business_contract_records t62
         on t2.loan_id = t62.loan_id
         and t62.data_date = '${DATA_DATE}'
         and t62.bddw_end_date = '9999-99-99'
         and t62.contract_type = '41' --人民币流动资金贷款合同
         and t62.status ='1'  --合同已生成
      left join odata.xscontract_business_contract_records t63
         on t2.loan_id = t63.loan_id
         and t63.data_date = '${DATA_DATE}'
         and t63.bddw_end_date = '9999-99-99'
         and t63.contract_type = '53' --最高额度保证合同
         and t63.status ='1'  --合同已生成
      left join odata.sym_cif_client t4
        on t1.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
      left join odata.order_product_loan_info t5
        on t1.cmisloan_no = t5.loan_id
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
--      left join (select process_time
--                       ,loan_id
--                       ,row_number() over(partition by loan_id order by process_time desc) as seq 
--               from odata.order_order_audit_operation_log 
--              where data_date='${DATA_DATE}' 
--                and bddw_end_date='9999-99-99' 
--                and process_node in('MACHINE_LOAN_RECHECK','LOAN_RECHECK') 
--                and process_result = 1) t6 
--        on t2.loan_id = t6.loan_id 
--       and t6.seq = 1
      left join odata.order_company_info t14
        on t2.credit_order_id = t14.loan_id
       and t14.data_date = '${DATA_DATE}'
       and t14.bddw_end_date = '9999-99-99'   
      left join (select loan_id
	               from odata.order_coborrower_info  
                  where data_date = '${DATA_DATE}'
                    and bddw_end_date = '9999-99-99'
	                and borrower_type='2'                     --有担保人
	              group by loan_id
                ) t15
        on t2.credit_order_id = t15.loan_id			
--  left join 
--	   (select  t7.loan_id,t13.username,t13.user_id
--	              from  odata.order_main_loan_order t7
--	 left join odata.work_act_hi_procinst t8  
--       on t7.loan_id = t8.business_key_
--                 and t8.data_date='${DATA_DATE}'
--                 and t8.bddw_end_date='9999-99-99'
--     left join (select proc_inst_id_
--                      ,assignee_ 
--                       ,row_number() over(partition by proc_inst_id_ order by end_time_ desc) as rn
--                        from odata.work_act_hi_taskinst 
--                        where data_date='${DATA_DATE}' 
--                        and bddw_end_date='9999-99-99'
--                        and task_def_key_ in  ('XHD_LOAN_FIRST_TRIAL','XHD_LOAN_RECHECK')  --用信人审岗 
--                                                                                         ) t9 
--       on t8.proc_inst_id_ = t9.proc_inst_id_
--                        and t9.rn = 1
-- left join (select t11.username,t11.user_id
--                        from odata.sso_upms_user t11
--     inner join odata.oa_hrmresource t12  
--       on t11.username = t12.workcode
--                        and t12.data_date = '${DATA_DATE}' 
--                        and t12.bddw_end_date = '9999-99-99'
--                        where t11.data_date = '${DATA_DATE}' 
--                        and t11.bddw_end_date = '9999-99-99'
--                        and t11.locked = 0  --0正常 1锁定
--                                          ) t13
--       on t9.assignee_ = t13.user_id
--                         where t7.data_date = '${DATA_DATE}' 
--                         and t7.bddw_end_date = '9999-99-99'
--                         and t7.sub_product_type = '25' --
--                         ) p
--	on p.loan_id = t1.cmisloan_no
     left join odata.sym_mb_prod_type t10
       on t1.prod_type=t10.prod_type
       and t10.data_date = '${DATA_DATE}' 
       and t10.bddw_end_date = '9999-99-99'
	    where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
       and t1.prod_type in('120111','120113','120114','120115')