--2.yuguorui.dwd_d_corp_loan_app_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：对公贷款申请表取数逻辑.sql
--功能描述：用于创建 dwd.dwd_d_corp_loan_app_p
--作    者：于国睿
--开发日期：2023-03-14
--直属经理：方杰
--来源表:
--1.odata.als_business_putout            贷款申请信息表 
--2.odata.als_flow_object                业务流程信息表
--3.odata.als_cl_occupy                  额度占用关系表
--4.odata.als_business_duebill           业务借据(账户)信息表
--5.odata.sym_mb_acct                    账户基本信息表
--6.adm.ods_code_mapping                 源系统接口与ADM目标表参数对应表
--7.odata.suprisk_use_credit_apply_info  用信申请表
--8.odata.suporder_scp_credit_apply_finance_product  用信申请金融产品信息快照表
--9.odata.suporder_scp_payment_record    支付流水表
--10.odata.supacct_enterprise_loan_info  贷款信息表
--11.odata.als_customer_info             客户信息表
--12.odata.order_main_loan_order         订单主表
--13.odata.sllv_mb_acct                  账户基本信息表
--14.odata.sym_cif_client                客户信息表
--目标表：dwd.dwd_d_corp_loan_app_p      对公贷款申请表
--修改历史：
--          1.于国睿   2023-03-14    新建
--          2.高源     2023-05-09    新增供应链贷款申请范围，新增锡惠贷企业融贷款申请，新增业务细类字段,授信申请号字段逻辑调整为授信号
--          3.杨琦浩   2024-03-20    新增锡享贷产品
--          4.姚威     2024-04-11    修改逻辑：有重复数据
--          5.姚威     2024-05-14    新增孚厘企业贷
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_corp_loan_app_p partition(data_date = '${DATA_DATE}')
    select /*+ REPARTITION(1) */
           nvl(t1.serialno,'')                            as loan_app_no  --支用申请号
          ,nvl(g.relativeserialno  ,'')                   as credit_cont_no  --授信申请号
          ,nvl(t1.customerid,'')                          as cust_id  --客户号
          ,nvl(t1.customername,'')                        as cust_name  --客户名称
          ,'CNY'                                          as ccy  --币种
          ,nvl(t1.businesssum,0)                          as loan_app_amt  --申请金额
          ,case when t2.phasetype in (1010,1020,1030) then '001'
                when t2.phasetype = 1050 then '002' 
                when t2.phasetype = 1040 then '003'  
                else ''             
            end                                           as loan_app_status    --支用申请状态
          ,nvl(regexp_replace(t1.occurdate,'/','-'),'')   as loan_app_date      --支用申请时间
          ,nvl(t1.businesstype,'')                        as loan_biz_class     --业务分类
          ,coalesce(q1.t_code,q2.t_code,'')               as loan_biz_detail    --贷款业务细类
      from odata.als_business_putout t1
     inner join odata.als_flow_object t2
        on t1.serialno = t2.objectno
       and t2.applytype = 'PutOutApply'           --放款流程
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_Date = '9999-99-99'
     left join (     select relativeserialno 
                           ,objectno 
                           ,row_number() over (partition by objectno order by serialno desc)  as rn     
                     from odata.als_cl_occupy g1 --额度占用关系表
                    where objecttype='BusinessContract'
                      and data_date='${DATA_DATE}'
                      and bddw_end_date='9999-99-99'
                   --   and nvl(remark,'') <> 'INVALID'  --无效的               --生效的肯定为最新的流水号
                ) g
        on t1.contractserialno=g.objectno
       and g.rn=1                                                               --取最新的授信号
     left join odata.als_business_duebill t3 --业务借据(账户)信息表
       on t3.relativeserialno1=t1.serialno
      and t3.data_date='${DATA_DATE}'
      and t3.bddw_end_date='9999-99-99'
      and nvl(t3.businesstype,'') not in ('1020010','2010') --剔除贴现、银承
     left join (select * from odata.sym_mb_acct --账户基本信息表
               where data_date='${DATA_DATE}'
               and bddw_end_date='9999-99-99'
               and source_module = 'CL'     --贷款
               and lead_acct_flag = 'N'
               and from_unixtime(unix_timestamp(acct_open_date,'yyyyMMdd'),'yyyy-MM-dd') <= '${DATA_DATE}'
               and substr(prod_type,1,2)='12'
               ) t4     --限制非主账户
       on t4.cmisloan_no=t3.serialno
      left join adm.ods_code_mapping q1 --源系统接口与ADM目标表参数对应表
        on t4.prod_type=q1.s_code
       and q1.convert_id='6'                --6 贷款业务细类
      left join adm.ods_code_mapping q2 --源系统接口与ADM目标表参数对应表
        on t1.businesstype=q2.s_code
       and q2.convert_id='21'               --21 信贷业务类型
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_Date = '9999-99-99'
-------------------------------------------供应链用信------------------------------------
union  all   
    select /*+ REPARTITION(1) */
           nvl(t1.apply_no,'')                                  as loan_app_no  --支用申请号
          ,nvl(g.relativeserialno  ,'')                         as credit_cont_no  --授信申请号
          ,nvl(t1.cust_id,'')                                   as cust_id  --客户号
          ,nvl(t5.customername,'')                              as cust_name  --客户名称
          ,'CNY'                                                as ccy  --币种
          ,nvl(t1.credit_payment_amount,0)/100                  as loan_app_amt  --申请金额
          ,case when  t1.audit_status='03'  then '003'
                when  t1.audit_status='02'  then '002'
                else  '001'   end                               as loan_app_status    --支用申请状态
          ,nvl(substr(t1.create_time,1,10),'')                  as loan_app_date      --支用申请时间
          ,nvl(b.businesstype  ,'')                             as loan_biz_class     --业务分类
          ,nvl(q.t_code,'')                                     as loan_biz_detail    --贷款业务细类
    from  odata.suprisk_use_credit_apply_info t1  --用信申请表
    left join odata.suporder_scp_credit_apply_finance_product t2  --用信申请金融产品信息快照表
      on t1.apply_no=t2.credit_apply_no
     and t2.data_date ='${DATA_DATE}'
     and t2.bddw_end_date='9999-99-99'
    left join odata.suporder_scp_payment_record t3
      on t1.apply_no=t3.credit_apply_no
     and t3.data_date ='${DATA_DATE}'
     and t3.bddw_end_date='9999-99-99'
     and t3.payment_status='10'                  --支付成功状态
    left join odata.supacct_enterprise_loan_info t4
      on t4.pay_order_no =t3.payment_no
     and t4.data_date ='${DATA_DATE}'
     and t4.bddw_end_date='9999-99-99'
     and t4.iou_status='03'
    left join odata.als_business_duebill b --业务借据(账户)信息表
      on t4.iou_no = b.serialno
     and b.data_date='${DATA_DATE}'
     and b.bddw_end_date='9999-99-99' 
     and nvl(b.businesstype,'') not in ('1020010','2010') --剔除贴现、银承
     left join (     select relativeserialno 
                           ,objectno 
                           ,row_number() over (partition by objectno order by serialno desc)  as rn     
                     from odata.als_cl_occupy g1 --额度占用关系表
                    where objecttype='BusinessContract'
                      and data_date='${DATA_DATE}'
                      and bddw_end_date='9999-99-99'
                   --   and nvl(remark,'') <> 'INVALID'  --无效的               --生效的肯定为最新的流水号
                ) g
        on b.relativeserialno2=g.objectno
       and g.rn=1                                                               --取最新的授信号
    left join odata.als_customer_info t5 --客户信息表
        on t1.cust_id = t5.customerid
       and t5.data_date ='${DATA_DATE}'
       and t5.bddw_end_date='9999-99-99'  
    left join adm.ods_code_mapping q --源系统接口与ADM目标表参数对应表
        on t2.base_product_no=q.s_code
       and q.convert_id='6' --6 贷款业务细类
    where t1.data_date ='${DATA_DATE}'
      and t1.bddw_end_date='9999-99-99'
      and substr(t2.base_product_no,1,2)= '12'             --对公产品
      and ( b.businesssum <>0 or b.businesssum is null)                             --剔除有问题的借据
union  all   
--------------------------------------------------锡惠贷、锡享贷用信、孚厘---------------------------------------------------
select    /*+ REPARTITION(1) */
           nvl(t1.loan_id,'')                              as loan_app_no    --支用申请号
          ,nvl(t1.credit_order_id ,'')                     as credit_cont_no  --授信申请号
          ,nvl(t7.client_no,'')                            as cust_id  --客户号
          ,coalesce(t5.ch_client_name,t7.company_name,'')    as cust_name  --客户名称
          ,'CNY'                                           as ccy  --币种
          ,nvl(t1.apply_amount,0)                          as loan_app_amt  --申请金额
          ,case when t1.status in(1,2)   then '001'
                when t1.status in(11,12) then '002'
                else  '003'
           end                                             as loan_app_status    --支用申请状态
          ,nvl(substr(t1.apply_time,1,10) ,'')             as loan_app_date      --支用申请时间
         ,case when  t1.sub_product_type='45' and t8.loan_period_unit = 'M' and  t8.actual_loan_period < 12  then '1010010'    -- 短期 
                when t1.sub_product_type='45' and t8.loan_period_unit = 'M' and  t8.actual_loan_period >= 12 then '1010020'	-- 中长期
                when t1.sub_product_type='45' and t8.loan_period_unit = 'Y' and  t8.actual_loan_period < 1 then   '1010010'
				when t1.sub_product_type='45' and t8.loan_period_unit = 'Y' and  t8.actual_loan_period >= 1 then  '1010020'  
                when t1.sub_product_type='45' and t8.loan_period_unit = 'D' and  t8.actual_loan_period < 360 then '1010010'
				when t1.sub_product_type='45' and t8.loan_period_unit = 'D' and  t8.actual_loan_period >= 360 then'1010020' 
              else  ''            
			     end                                    as loan_biz_class --贷款业务分类
          ,'B2'                                            as loan_biz_detail    --贷款业务细类
 from odata.order_main_loan_order t1
 left join odata.sllv_mb_acct t3        
   on t1.loan_id=t3.cmisloan_no 
  and t3.data_date='${DATA_DATE}' 
  and t3.bddw_end_date='9999-99-99' 
  and t3.prod_type in('120111' ,'120113','120114','120115')
left join  odata.sym_cif_client t5
   on t3.client_no = t5.client_no
  and t5.data_date='${DATA_DATE}'
  and t5.bddw_end_date='9999-99-99' 
left join odata.order_main_loan_order t6
 on t6.loan_id=t1.loan_id 
  and t6.data_date='${DATA_DATE}' 
  and t6.bddw_end_date='9999-99-99' 
  and t6.order_type='2'--用信阶段
left join odata.order_company_info t7
 on t6.credit_order_id=t7.loan_id
   and t7.data_date='${DATA_DATE}' 
   and t7.bddw_end_date='9999-99-99' 
left join odata.order_product_loan_info t8
  on t8.loan_id=t1.loan_id
 and t8.data_date='${DATA_DATE}' 
 and t8.bddw_end_date='9999-99-99' 
where t1.data_date = '${DATA_DATE}'
  and t1.bddw_end_date='9999-99-99'
  and t1.product_type in (14,15,16)                    --产品类型 
  and t1.sub_product_type in('25','42','44','45')              --25 锡惠贷对公 42 锡享贷找钢 44 锡享贷厚沃企业 45孚厘企业贷