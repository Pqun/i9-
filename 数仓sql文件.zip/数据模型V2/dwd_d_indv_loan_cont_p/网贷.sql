--2.yuguorui.dwd.dwd_d_indv_loan_cont_p
--脚本名称:dwd_d_indv_loan_cont_p
--功能描述:个人贷款合同信息表
--作    者:于国睿
--开发日期:2022-07-05
--直属经理:方杰
--目标表: dwd.dwd_d_indv_loan_cont_p 
--来源表: odata.sllv_mb_acct             账户基本信息表
--来源表: odata.ols_loan_cont_info       网贷支用合同表
--来源表: odata.ols_loan_prd_info        网贷产品表
--来源表: odata.sym_gl_prod_accounting   科目信息表          
--修改历史:
--         1、于国睿     2022-07-05     新建
--         2. 于国睿     2023-09-19     贷款用途逻辑调整
--         3、杨琦浩     2023-11-16     新增审批员工号
-------------------------------------------------------------------
--行内产品(网贷)
insert overwrite table dwd.dwd_d_indv_loan_cont_p partition(data_date='${DATA_DATE}',prod_code)
    select  /*+ REPARTITION(1) */
            nvl(t1.bill_no,'')           as cont_no  --合同号
           ,nvl(t1.cust_id_core,'')      as cust_id  --客户号
           ,nvl(t1.cust_name,'')         as cust_name  --客户名称
           ,nvl(t4.prd_name,'')          as prod_type --产品名称
           ,nvl(t4.loan_no,'')           as biz_prod_code  --业务产品号
           ,''                           as sub_biz_prod_code  --业务子产品号
           ,nvl(t1.currency,'')          as ccy  --币种
           ,nvl(t1.loan_amt,0)           as cont_amt  --合同金额
           ,nvl(t1.loan_start_date,'')   as cont_start_date  --合同生效日期
           ,nvl(t1.loan_end_date,'')     as cont_mature_date  --合同到期日期
           ,'C'                          as guar_mode  --主要担保方式
           ,case when t1.loan_purpose ='100' then '资金周转'
                 when t1.loan_purpose ='101' then '投资需求'
                 when t1.loan_purpose ='102' then '扩大经营规模'
                 when t1.loan_purpose ='103' then '店面装修改造'
                 when t1.loan_purpose ='104' then '购房'
                 when t1.loan_purpose ='105' then '购车（自用型）'
                 when t1.loan_purpose ='106' then '购买车位'
                 when t1.loan_purpose ='107' then '房屋装修'
                 when t1.loan_purpose ='108' then '购买大额耐用消费品'
                 when t1.loan_purpose ='109' then '旅游'
                 when t1.loan_purpose ='110' then '出国留学'
                 when t1.loan_purpose ='111' then '教育'
                 when t1.loan_purpose ='112' then '婚嫁'
                 when t1.loan_purpose ='113' then '医疗保健'
                 when t1.loan_purpose ='114' then '购买大额人寿保险'
                 when t1.loan_purpose ='115' then '资产置换'
                 when t1.loan_purpose ='116' then '其他'
                 when t1.loan_purpose ='117' then '土地储备'
                 when t1.loan_purpose ='118' then '房地产开发'
                 when t1.loan_purpose ='119' then '个人住房'
                 when t1.loan_purpose ='120' then '商业用房'
                 when t1.loan_purpose ='121' then '基本建设'
                 when t1.loan_purpose ='122' then '技术改造'
                 when t1.loan_purpose ='123' then '基础设施'
                 when t1.loan_purpose ='124' then '个人日常消费'
                 else '其他'  
             end                         as loan_pupr  --贷款用途  --update 20230919 yuguorui 改为贷款用途细类
           ,''                           as loan_invest_area_code  --贷款投向地区
           ,''                           as loan_invest_indust_code  --贷款投向行业
           ,'0'                          as limit_indust_code  --是否国家限制行业
           ,nvl(t1.crd_cont_no,'')       as credit_cont_no  --授信合同号
           ,nvl(t1.loan_start_date,'')   as approve_date  --批准日期
           ,nvl(t1.cont_status,'')       as loan_cont_status  --合同状态
           ,'1'                          as loan_biz_class  --业务分类
           ,case when t2.prod_type ='110164' and t6.corporate_type ='01' then 'A18'
                 when t2.prod_type ='110164' and t6.corporate_type ='02' then 'A17' 
                 else  'A29'  
             end                         as loan_biz_detail  --贷款业务细类
           ,nvl(t9.username,'')          as approver --审批员工号
           ,''                           as project_id
           ,t2.prod_type                 as prod_code  --产品号
      from odata.ols_loan_cont_info t1 
     inner join odata.sllv_mb_acct t2
        on t2.cmisloan_no = t1.bill_no 
       and t2.bddw_end_date = '9999-99-99'
       and t2.data_date = '${DATA_DATE}' 
      left join odata.ols_loan_prd_info t4
        on trim(t1.prd_code) = trim(t4.loan_no) 
       and t4.data_date = '${DATA_DATE}' 
       and t4.bddw_end_date = '9999-99-99'
      left join odata.ols_crd_cont_info t5
        on t5.crd_cont_no = t1.crd_cont_no
       and t5.data_date = '${DATA_DATE}' 
       and t5.bddw_end_date = '9999-99-99'
      left join odata.ols_biz_corporate_info t6 
        on t5.app_no = t6.app_no  
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
       and t6.prd_code = '10061001002'
      left join odata.ols_loan_app_info t7 
	    --on t1.bill_no=t7.bill_no
        on t1.app_no=t7.app_no
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date ='9999-99-99'
      left join (
                select app_no
                       ,curr_operator
                       ,row_number() over(partition by app_no order by input_time desc) rn
                from odata.ols_manual_audit_info
                where data_date = '${DATA_DATE}'
                and bddw_end_date ='9999-99-99' 
                and order_type='2'
                and is_invalid<>'1'
                ) t8
         on t7.app_no=t8.app_no
        and t8.rn=1
       left join odata.sso_upms_user t9
         on t8.curr_operator=t9.user_id
        and t9.data_date = '${DATA_DATE}'
        and t9.bddw_end_date ='9999-99-99' 
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date ='9999-99-99'
       and from_unixtime(unix_timestamp(t2.acct_open_date,'yyyymmdd'),'yyyy-mm-dd')<='${DATA_DATE}'
	   and t1.app_no not in ('DKSQ202209246364750','DKSQ202207065741076')  --剔除两笔脏数据
        and t1.prd_code <> '10021001001' --剔除迁移前的锡锡贷自营数据