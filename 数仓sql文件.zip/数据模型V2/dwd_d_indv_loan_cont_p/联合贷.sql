--2.yuguorui.dwd.dwd_d_indv_loan_cont_p
--脚本名称:dwd_d_indv_loan_cont_p
--功能描述:个人贷款合同信息表
--作    者:于国睿
--开发日期:2022-07-05
--直属经理:方杰
--目标表: dwd.dwd_d_indv_loan_cont_p 
--来源表: odata.sllv_nl_acct                       线上账户基本信息表
--来源表: odata.order_main_loan_order              订单主表
--来源表: odata.order_product_loan_info            产品贷款信息
--来源表: odata.sym_cif_client                     客户信息表
--来源表: odata.order_contract_sign                合同信息表
--来源表: odata.order_order_audit_operation_log    审核日志表
--来源表: odata.ols_asset_loan_cont_info           资产支用合同表
--修改历史:
--         1、于国睿     2022-07-05     新建
--         2、于国睿     2023-09-04     担保方式,贷款用途逻辑调整
--         3、于国睿     2023-11-09     新增乐云小贷，宁波通商联合贷
--         4、杨琦浩     2023-11-18     新增审批员工号
--         5、于国睿     2023-11-28     合同金额，贷款用途修改逻辑
--         6、姚威       2023-02-01     新增小赢通商联合贷，小赢兰州联合贷
-------------------------------------------------------------------
--新生贷，洋钱罐联合贷（线上），张家港二期，伊春联合贷
insert overwrite table dwd.dwd_d_indv_loan_cont_p partition(data_date='${DATA_DATE}',prod_code)
    select  /*+ REPARTITION(1) */
            case when t1.prod_type in ('110135','110169','110174','110176','110181','110182','110185','110186') then nvl(t1.cmisloan_no,'') --网贷合同号就取借据号
                 when t5.contract_no is not null then nvl(t5.contract_no,'')
                 else nvl(t1.cmisloan_no,'')
             end                                             as cont_no  --合同号
           ,nvl(t1.client_no,'')                             as cust_id  --客户号
           ,nvl(t4.ch_client_name,'')                        as cust_name  --客户名称
           ,nvl(t6.prod_desc,'')                             as prod_type --产品名称
           ,nvl(t2.product_type,'')                          as biz_prod_code  --业务产品号
           ,nvl(t2.sub_product_type,'')                      as sub_biz_prod_code  --业务子产品号
           ,'CNY'                                            as ccy  --币种
           ,coalesce(t3.actual_loan_amount,t10.loan_amt,0)   as cont_amt  --合同金额
           ,nvl(substr(t1.acct_open_date,1,10),'')           as cont_start_date  --合同生效日期
           ,nvl(substr(t1.maturity_date ,1,10),'')           as cont_mature_date  --合同到期日期
           ,case when t1.prod_type in ('110135','110169','110174','110176','110181','110182','110185','110186') then 'C' 
                 when t1.prod_type in ('110118','110119','110127') then 'D' 
             end                                             as guar_mode  --主要担保方式  --update 20230919 yuguorui
           ,case when t1.prod_type = '110119' then '个人消费贷款'
                 when t1.prod_type not in ('110135','110174','110169','110176','110181','110182','110185','110186') 
                 then case when t3.loan_need is null then 
                                                          case when t3.loan_need_type = '1' then '企业经营性贷款'
                                                               when t3.loan_need_type = '2' then '个人消费贷款'
                                                               when t3.loan_need_type = '3' then '个人经营性贷款'
                                                               else ''
                                                           end
                           else nvl(t3.loan_need,'') 
                       end
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '100' then '资金周转'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '101' then '投资需求'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '102' then '扩大经营规模'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '103' then '店面装修改造'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '104' then '购房'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '105' then '购车（自用型）'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '106' then '购买车位'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '107' then '房屋装修'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '108' then '购买大额耐用消费品'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '109' then '旅游'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '110' then '出国留学'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '111' then '教育'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '112' then '婚嫁'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '113' then '医疗保健'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '114' then '购买大额人寿保险'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '115' then '资产置换'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '116' then '其他'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '117' then '土地储备'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '118' then '房地产开发'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '119' then '个人住房'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '120' then '商业用房'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '121' then '基本建设'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '122' then '技术改造'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '123' then '基础设施'
                 when t1.prod_type in ('110135','110174','110169','110176','110181','110182','110185','110186') and t10.loan_purpose = '124' then '个人日常消费'
                 else '其他'   
             end
                                                             as loan_pupr  --贷款用途  --update 20230919 yuguorui
           ,nvl(t3.loan_cast_area,'')                        as loan_invest_area_code  --贷款投向地区
           ,nvl(substr(t3.loan_cast_industry_code,19,5),'')  as loan_invest_indust_code  --贷款投向行业
           ,'0'                                              as limit_indust_code  --是否国家限制行业
           ,coalesce(t2.loan_id,t9.crd_cont_no,'')           as credit_cont_no  --授信合同号
           ,coalesce(t8.process_time,substr(t2.loan_time,1,10),'')   
                                                             as approve_date  --批准日期
           ,case when t1.acct_status<>'C' and t1.accounting_status<>'ZHC' then '107' 
                 when t1.acct_status<>'C' and t1.accounting_status='ZHC' then '105'
                 when t1.acct_status='C' and t1.acct_close_reason='发放冲正' then '111'
                 when t1.acct_status='C' and t1.acct_close_reason<>'发放冲正' then '106'
                 when t2.status in(1,2,13,14) then '101'
                 when t2.status in(4,5) then '103'
                 when t2.status =11 then '104'
                 when t2.status =12 then '102'
                 when t2.status =15 then '111'
             end                                             as loan_cont_status  --合同状态    
           ,case when t1.prod_type in ('110135','110169','110174','110176','110181','110182','110185','110186') then '1' 
                 when t1.prod_type in ('110118','110119','110127') then '2'   
             end                                             as loan_biz_class  --业务分类
           ,case when t3.loan_need_type = 3 and t3.person_business_type = 1 then 'A18'   --个体工商户                                                                       
                 when t3.loan_need_type = 3 and t3.person_business_type = 2 then 'A17'   --小微企业主                                                                       
                 when t3.loan_need_type = 3 and t3.person_business_type = 3 then 'A19'   --其他经营贷 
                 when t3.loan_need_type = 3 and t3.person_business_type is null then 'A19'   --其他经营贷
                 when t3.loan_need_type = 2 then 'A29'    --其他个人消费贷
                 else 'A29'                                                                                                            
             end                                             as loan_biz_detail --贷款业务细类
           ,nvl(t15.username,'')                             as approver --审批员工号
           ,''                                               as project_id
           ,t1.prod_type                                     as prod_code  --产品号
      from odata.sllv_nl_acct t1
      left join odata.order_main_loan_order t2 
        on t1.cmisloan_no = t2.receipt_no
       and t2.data_date='${DATA_DATE}' 
       and t2.bddw_end_date='9999-99-99' 
       and t2.product_type=4 
       and t2.sub_product_type=7 
      left join odata.order_product_loan_info t3
        on trim(t2.loan_id)=trim(t3.loan_id)
       and t3.data_date='${DATA_DATE}' 
       and t3.bddw_end_date='9999-99-99' 
      left join odata.sym_cif_client t4
        on t1.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
      left join odata.order_contract_sign t5 
        on trim(t2.loan_id)=trim(t5.loan_id) 
       and t5.data_date='${DATA_DATE}' 
       and t5.bddw_end_date='9999-99-99' 
       and t5.signer_type=1 
       and t5.contract_type=2
      left join odata.sym_mb_prod_type t6
        on t1.prod_type=t6.prod_type
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
      left join odata.sym_gl_prod_accounting t7 --通过科目号来取消费还是经营
        on t7.data_date='${DATA_DATE}'
       and t7.bddw_end_date='9999-99-99'
       and t1.prod_type = t7.prod_type
       and t7.accounting_status = 'ZHC'
       and t7.tran_category = 'ALL'
      left join (select process_time
                       ,loan_id
                       ,row_number() over(partition by loan_id order by process_time desc) as seq 
                   from odata.order_order_audit_operation_log 
                  where data_date='${DATA_DATE}' 
                    and bddw_end_date='9999-99-99' 
                    and process_node='MACHINE_RISK_RECHECK' 
                    and process_result=1) t8 
        on t2.loan_id = t8.loan_id 
       and t8.seq = 1
      left join (select crd_cont_no,bill_no
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code in ('10071001001','10061001001','10211001001')  --洋钱罐,张家港,伊春联合贷,乐云,宁波通商,兰州
                    and financial_id in ('ZJG','DXAL','yichun','LYXD','NBTS','LANZ') 
                         ) t9
        on t1.cmisloan_no = t9.bill_no
      left join odata.ols_loan_cont_info t10
        on t1.cmisloan_no = t10.bill_no
       and t10.data_date = '${DATA_DATE}'
       and t10.bddw_end_date = '9999-99-99'
      left join (select loan_id
                       ,processor
                       ,row_number() over(partition by loan_id order by process_time desc) as seq 
                   from odata.order_order_audit_operation_log 
                  where data_date='${DATA_DATE}' 
                    and bddw_end_date='9999-99-99' 
                    and process_node is not null 
                ) t14
        on t2.loan_id = t14.loan_id 
       and t14.seq = 1
      left join odata.sso_upms_user t15
        on t14.processor=t15.user_id
       and t15.data_date='${DATA_DATE}' 
       and t15.bddw_end_date='9999-99-99'
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
       and substr(t1.acct_open_date,1,10) <= '${DATA_DATE}'
       and t1.prod_type in ('110118','110119','110127','110135','110169','110174','110176','110181','110182','110185','110186')