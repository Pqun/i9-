--2.yuguorui.dwd.dwd_d_indv_loan_cont_p
--脚本名称:dwd_d_indv_loan_cont_p
--功能描述:个人贷款合同信息表
--作    者:于国睿
--开发日期:2022-07-05
--直属经理:方杰
--来源表: odata.order_main_loan_order                 订单主表
--来源表: odata.sllv_mb_acct                          账户基本信息表
--来源表: odata.sym_cif_client                        客户信息表
--来源表: odata.sym_gl_prod_accounting                产品科目信息表
--来源表: odata.order_product_loan_info               产品贷款合同表
--来源表: odata.xscontract_business_contract_records  合同信息表
--目标表: dwd.dwd_d_indv_loan_cont_p   个贷合同信息表
--修改历史:
--         1、于国睿     2022-07-05     新建
--         2、于国睿     2023-02-23     剔除合同信息表失效合同
--         3、于国睿     2023-03-21     新增51半自营，乐花借钱产品，修改批准日期逻辑
--         4、于国睿     2023-07-21     新增锡望贷-聚盟
--         5、于国睿     2023-09-19     担保方式，贷款用途逻辑调整
--         6、杨琦浩     2023-11-18     新增审批员工号
--         7、姚威       2024-01-18     新增vivo维易贷产品
--         8、彭群       2024-03-12     修改客户名称字段逻辑
--         9、杨琦浩     2024-03-20     新增锡享贷产品
--         10、杨琦浩    2024-03-20     修改贷款投向行业取数逻辑
-------------------------------------------------------------------
--新合同表产品
insert overwrite table dwd.dwd_d_indv_loan_cont_p partition(data_date='${DATA_DATE}',prod_code)
    select  /*+ REPARTITION(1) */
            nvl(t2.contract_no,'')                               as cont_no  --合同号
           ,nvl(t1.client_no,'')                                 as cust_id  --客户号
           ,nvl(t3.ch_client_name,'')                            as cust_name  --客户名称		--updata20240304		pengqun
           ,nvl(t2.product_name,'')                              as prod_type --产品名称
           ,nvl(t5.product_type,'')                              as biz_prod_code  --业务产品号
           ,nvl(t2.product_code,'')                              as sub_biz_prod_code  --业务子产品号
           ,'CNY'                                                as ccy  --币种
           ,coalesce(t4.actual_loan_amount,0)                    as cont_amt  --合同金额
           ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyymmdd'),'yyyy-mm-dd'),'')  
                                                                 as cont_start_date  --合同生效日期
           ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyymmdd'),'yyyy-mm-dd'),'')  
                                                                 as cont_mature_date  --合同到期日期
           ,case when t1.prod_type in ('110165','110168','110163','110172','110175','110180','110183') then 'C' 
                 when t1.prod_type = '110166' and t4.loan_method = 2 then 'D' 
                 when t1.prod_type = '110166' and t4.loan_method = 3 then 'C' 
                 when t1.prod_type in ('110170','110171','110173','110187') then 'D'  
                 else '' 
             end                                                 as guar_mode  --主要担保方式  --update 20230919 yuguorui
           ,case when t4.loan_need is null then 
                                                 case when t4.loan_need_type = '1' then '企业经营性贷款'
                                                      when t4.loan_need_type = '2' then '个人消费贷款'
                                                      when t4.loan_need_type = '3' then '个人经营性贷款'
                                                      else ''
                                                  end                                                   
                 else nvl(t4.loan_need,'') 
             end                                                 as loan_purp  --贷款用途  --update 20231024 yuguorui
           ,coalesce(t4.loan_cast_area,'')                       as loan_invest_area_code  --贷款投向地区
           --,coalesce(substr(t4.loan_cast_industry_code,19,5),'') as loan_invest_indust_code  --贷款投向行业
           ,case when length(t4.loan_cast_industry_code)=23 then substr(t4.loan_cast_industry_code,19,5)
                 else nvl(t4.loan_cast_industry_code,'')
            end                                                  as loan_invest_indust_code  --贷款投向行业
           ,'0'                                                  as limit_indust_code  --是否国家限制行业
           ,coalesce(t5.loan_id,'')                              as credit_cont_no  --授信合同号
           ,coalesce(substr(t2.template_generate_time,1,10),'')  as approve_date  --批准日期
           ,case when t1.acct_status<>'C' and t1.accounting_status<>'ZHC' then '107' 
                 when t1.acct_status<>'C' and t1.accounting_status='ZHC' then '105'
                 when t1.acct_status='C' and t1.acct_close_reason='发放冲正' then '111' 
                 when t1.acct_status='C' and t1.acct_close_reason<>'发放冲正' then '106'
                 when t5.status in(1,2,13,14) then '101'
                 when t5.status in(4,5) then '103'
                 when t5.status = 8 then '106'
                 when t5.status = 11 then '104'
                 when t5.status = 12 then '102'
                 when t5.status = 15 then '111'
             end                                                 as loan_cont_status  --合同状态
           ,'2'                                                  as loan_biz_class  --业务分类
           ,case when t4.loan_need_type = 3 and t4.person_business_type = 1 then 'A18'   --个体工商户                                                                       
                 when t4.loan_need_type = 3 and t4.person_business_type = 2 then 'A17'   --小微企业主                                                                       
                 when t4.loan_need_type = 3 and t4.person_business_type = 3 then 'A19'   --其他经营贷 
                 when t4.loan_need_type = 3 and t4.person_business_type is null then 'A19'   --其他经营贷
                 when t4.loan_need_type = 2 then 'A29'    --其他个人消费贷
                 else 'A29'                                                                                                            
             end                                                   as loan_biz_detail --贷款业务细类
           ,nvl(t15.username,'')                                       as approver --审批员工号
           ,''                                                   as project_id --项目ID
           ,t1.prod_type                                         as prod_code  --产品号   
      from odata.sllv_mb_acct t1
      left join odata.xscontract_business_contract_records t2
        on t1.cmisloan_no = t2.loan_id
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99' 
       and t2.contract_type = 2  --个人借款合同
      left join odata.sym_cif_client t3            
        on t1.client_no=t3.client_no       
       and t3.data_date='${DATA_DATE}' 
       and t3.bddw_end_date='9999-99-99'
      left join odata.order_product_loan_info t4
        on t1.cmisloan_no = trim(t4.loan_id) 
       and t4.data_date='${DATA_DATE}' 
       and t4.bddw_end_date='9999-99-99'  
      left join odata.order_main_loan_order t5
        on t1.cmisloan_no = t5.loan_id 
       and t5.data_date='${DATA_DATE}' 
       and t5.bddw_end_date='9999-99-99'
      left join odata.sym_gl_prod_accounting t6 --通过科目号来取消费还是经营
        on t6.data_date='${DATA_DATE}'
       and t6.bddw_end_date='9999-99-99'
       and t1.prod_type = t6.prod_type
       and t6.accounting_status = 'ZHC'
       and t6.tran_category = 'ALL'
      left join (select loan_id
                       ,processor
                       ,row_number() over(partition by loan_id order by process_time desc) as seq 
                   from odata.order_order_audit_operation_log 
                  where data_date='${DATA_DATE}' 
                    and bddw_end_date='9999-99-99' 
                    and process_node is not null 
                ) t14
        on t2.loan_id = t14.loan_id 
       and t14.seq = 1
      left join odata.sso_upms_user t15
        on t14.processor=t15.user_id
       and t15.data_date='${DATA_DATE}' 
       and t15.bddw_end_date='9999-99-99'
     where t1.data_date='${DATA_DATE}' 
       and t1.bddw_end_date='9999-99-99'
       and t2.status <> '3'    --剔除失效的合同
       and from_unixtime(unix_timestamp(t1.acct_open_date,'yyyymmdd'),'yyyy-mm-dd') <= '${DATA_DATE}'
       and t1.prod_type in('110165'  --锡望贷-上牌车
                          ,'110166'  --锡望贷-非上牌车
                          ,'110168'  --锡锡贷-哈啰贷
                          ,'110170'  --饿了么经营贷
                          ,'110171'  --饿了么消费贷
                          ,'110172'  --锡锡贷-51半自营
                          ,'110163'  --乐花借钱
                          ,'110175'  --小赢拒量
                          ,'110173'  --锡望贷-聚盟
                          ,'110180'  --锡望贷-京东
                          ,'110183'  --vivo维易贷
                          ,'110187'  --锡享贷-厚沃个人
                          )
