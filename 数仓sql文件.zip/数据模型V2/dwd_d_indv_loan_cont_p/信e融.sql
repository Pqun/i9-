--2.yuguorui.dwd.dwd_d_indv_loan_cont_p
--脚本名称:dwd_d_indv_loan_cont_p
--功能描述:个人贷款合同信息表
--作    者:于国睿
--开发日期:2022-07-05
--直属经理:方杰
--目标表  :dwd.dwd_d_indv_loan_cont_p 
--数据原表:odata.supacct_enterprise_loan_info
--         odata.sym_mb_acct
--         odata.sym_cif_client
--修改历史:
--         1、于国睿     2022-07-05     新建
--         2、于国睿     2023-09-19     担保方式,贷款用途逻辑调整
--         3、杨琦浩     2023-11-18     新增审批员工号
--         4、姚威       2023-12-07     新增药师帮个人
--         5、邓权       2023-12-18     新增供应链项目编号
--		   6、彭群   	 2024-03-12 	修改客户名称字段逻辑
--         7、姚威      2024-03-28     修复合同数据重复问题
--         8、姚威      2024-04-02     引入新产品易收网
-------------------------------------------------------------------
--信e融-个人
insert overwrite table dwd.dwd_d_indv_loan_cont_p partition(data_date='${DATA_DATE}',prod_code)
    select  /*+ REPARTITION(1) */
            coalesce(t1.iou_no,'')                  as cont_no  --合同号
           ,nvl(t5.client_no,'')                    as cust_id  --客户号
           ,nvl(t6.ch_client_name,'')               as cust_name  --客户名称				--updata20240304       pengqun
           ,nvl(t11.prod_desc,'')                   as prod_name --产品名称
           ,''                                      as biz_prod_code  --业务产品号
           ,''                                      as sub_biz_prod_code  --业务子产品号
           ,'CNY'                                   as ccy  --币种
           ,nvl(t1.loan_amount,0)/100               as cont_amt  --合同金额
           ,nvl(from_unixtime(unix_timestamp(t5.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')               
                                                    as cont_start_date  --合同生效日期
           ,nvl(from_unixtime(unix_timestamp(t5.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                
                                                    as cont_mature_date  --合同到期日期
           ,case when t1.project_id='scp0012010020' then 'D'  --金润ETC
                 when t1.project_id='scp0019510027' then 'C'  --大数金融
                 when t1.project_id='scp0022510031' then 'C'  --人上融融
                 when t1.project_id='scp0024510034' then 'C'  --卫城征信
                 when t1.project_id='scp0026510033' then 'D'  --小雨点
                 when t1.project_id='scp0013510043' then 'D'  --药师帮
                 when t1.project_id='scp0022510049' then 'C'  --人上融融-新
                 when t1.project_id='scp0013510059' then 'D'  --药师帮个人 
				 when t1.project_id='scp0049130069' then 'D'  --易收网
				else ''
             end                                    as guar_mode  --主要担保方式  --update 20230919 yuguorui
           ,nvl(t7.loan_usage,'')                   as loan_pupr  --贷款用途  --update 20230919 yuguorui
           ,''                                      as loan_invest_area_code  --贷款投向地区
           ,''                                      as loan_invest_indust_code  --贷款投向行业
           ,'0'                                     as limit_indust_code  --是否国家限制行业
           ,nvl(t1.loan_contract_no,'')             as credit_cont_no  --授信合同号
           ,nvl(substr(t1.start_date,1,10),'')      as approve_date  --批准日期
           ,case when t5.acct_status<>'C' and t5.accounting_status<>'ZHC' then '107' 
                 when t5.acct_status<>'C' and t5.accounting_status='ZHC' then '105'
                 when t5.acct_status='C' and t5.acct_close_reason='发放冲正' then '111' 
                 when t5.acct_status='C' and t5.acct_close_reason<>'发放冲正' then '106'
                 else ''
             end                                    as loan_cont_status  --合同状态
           ,'2'                                     as loan_biz_class  --业务分类
           ,case when t5.prod_type in('110150','110184') and t13.enterprise_type='210' then 'A18'
		         when t5.prod_type in('110150','110184') and (t13.enterprise_type <>'210' or t13.enterprise_type is null) then nvl(t7.loan_type,'')
				  else ''
		          end                               as loan_biz_detail --贷款业务细类
           ,nvl(t10.username,'')                    as approver --审批员工号
           ,nvl(t1.project_id,'')                   as project_id --项目ID
           ,nvl(t5.prod_type,'')                    as prod_code -- 产品编号
      from odata.supacct_enterprise_loan_info t1
      left join odata.sym_mb_acct t5
        on t1.iou_no=t5.cmisloan_no 
       and t5.data_date='${DATA_DATE}' 
       and t5.bddw_end_date='9999-99-99' 
       and t5.prod_type in('110150','110184')
      left join odata.sym_cif_client t6
        on t5.client_no = t6.client_no
       and t6.data_date='${DATA_DATE}' 
       and t6.bddw_end_date='9999-99-99' 
      left join odata.suppimp_scp_project_info t7  --金融项目表
        on t1.platform_id = t7.partner_platform_id
       and t1.project_id = t7.project_id
       and t7.data_date='${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
      left join odata.suporder_scp_payment_record t8
        on t1.pay_order_no  = t8.payment_no 
        and t8.data_date='${DATA_DATE}'
        and t8.bddw_end_date='9999-99-99'
      left join (
                 select *
                        ,row_number() over(partition by apply_no order by create_time desc ,operate_task desc ) rn 
                 from odata.suprisk_use_credit_apply_status_record
                 where data_date='${DATA_DATE}'
                 and bddw_end_date='9999-99-99'
                 and operate_result not in ('00','01','02','03','04')
                ) t9
        on t8.credit_apply_no=t9.apply_no
       and t9.rn=1
      left join odata.sso_upms_user t10
        on t9.operator=t10.user_id
       and t10.data_date='${DATA_DATE}' 
       and t10.bddw_end_date='9999-99-99'
	   left join odata.sym_mb_prod_type t11
	    on t5.prod_type=t11.prod_type
	   and t11.data_date='${DATA_DATE}'
       and t11.bddw_end_date = '9999-99-99'
      left join odata.supwall_scp_personal_cust_info t12
	   on t1.cust_id=t12.cust_id
	   and t12.data_date='${DATA_DATE}'
       and t12.bddw_end_date = '9999-99-99'
      left join odata.suprisk_scp_pcl_grant_credit_apply t14
        on t1.loan_contract_no=t14.apply_no
       and t14.data_date='${DATA_DATE}'
       and t14.bddw_end_date='9999-99-99'
	   left join odata.supwall_scp_personal_cust_enterprise_info t13
	   on t13.social_credit_code=t14.social_credit_code
       and t13.status='10'
	   and t13.data_date='${DATA_DATE}'
       and t13.bddw_end_date = '9999-99-99'
     where t1.data_date='${DATA_DATE}' 
       and t1.bddw_end_date='9999-99-99'
       and t1.product_type in('110150','110184')
       and t5.lead_acct_flag='N' --是否主账户 
     union all
    select  /*+ REPARTITION(1) */
            coalesce(t5.cmisloan_no,'')             as cont_no  --合同号
           ,nvl(t5.client_no,'')                    as cust_id  --客户号
           ,nvl(t6.ch_client_name,'')               as cust_name  --客户名称		--updata20240305     pengqun
           ,'个人经营贷款'                          as prod_type --产品名称
           ,''                                      as biz_prod_code  --业务产品号
           ,''                                      as sub_biz_prod_code  --业务子产品号
           ,'CNY'                                   as ccy  --币种
           ,nvl(t7.total_amount,0)                  as cont_amt  --合同金额
           ,nvl(from_unixtime(unix_timestamp(t5.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')               
                                                    as cont_start_date  --合同生效日期
           ,nvl(from_unixtime(unix_timestamp(t5.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                
                                                    as cont_mature_date  --合同到期日期
           ,'D'                                     as guar_mode  --主要担保方式
           ,case when t5.prod_type='110101' and t8.purpose ='100' then '资金周转'
                 when t5.prod_type='110101' and t8.purpose ='101' then '投资需求'
                 when t5.prod_type='110101' and t8.purpose ='102' then '扩大经营规模'
                 when t5.prod_type='110101' and t8.purpose ='103' then '店面装修改造'
                 when t5.prod_type='110101' and t8.purpose ='104' then '购房'
                 when t5.prod_type='110101' and t8.purpose ='105' then '购车（自用型）'
                 when t5.prod_type='110101' and t8.purpose ='106' then '购买车位'
                 when t5.prod_type='110101' and t8.purpose ='107' then '房屋装修'
                 when t5.prod_type='110101' and t8.purpose ='108' then '购买大额耐用消费品'
                 when t5.prod_type='110101' and t8.purpose ='109' then '旅游'
                 when t5.prod_type='110101' and t8.purpose ='110' then '出国留学'
                 when t5.prod_type='110101' and t8.purpose ='111' then '教育'
                 when t5.prod_type='110101' and t8.purpose ='112' then '婚嫁'
                 when t5.prod_type='110101' and t8.purpose ='113' then '医疗保健'
                 when t5.prod_type='110101' and t8.purpose ='114' then '购买大额人寿保险'
                 when t5.prod_type='110101' and t8.purpose ='115' then '资产置换'
                 when t5.prod_type='110101' and t8.purpose ='116' then '其他'
                 when t5.prod_type='110101' and t8.purpose ='117' then '土地储备'
                 when t5.prod_type='110101' and t8.purpose ='118' then '房地产开发'
                 when t5.prod_type='110101' and t8.purpose ='119' then '个人住房'
                 when t5.prod_type='110101' and t8.purpose ='120' then '商业用房'
                 when t5.prod_type='110101' and t8.purpose ='121' then '基本建设'
                 when t5.prod_type='110101' and t8.purpose ='122' then '技术改造'
                 when t5.prod_type='110101' and t8.purpose ='123' then '基础设施'
                 when t5.prod_type='110101' and t8.purpose ='124' then '个人日常消费'
                 else '其他'  
             end 
                                                    as loan_pupr  --贷款用途  --update 20230919 yuguorui
           ,''                                      as loan_invest_area_code  --贷款投向地区
           ,''                                      as loan_invest_indust_code  --贷款投向行业
           ,'0'                                     as limit_indust_code  --是否国家限制行业
           ,nvl(t5.cmisloan_no,'')                  as credit_cont_no  --授信合同号
           ,nvl(from_unixtime(unix_timestamp(t5.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')      
                                                    as approve_date  --批准日期
           ,case when t5.acct_status<>'C' and t5.accounting_status<>'ZHC' then '107' 
                 when t5.acct_status<>'C' and t5.accounting_status='ZHC' then '105'
                 when t5.acct_status='C' then '106'
                 else ''
             end                                    as loan_cont_status  --合同状态
           ,'1'                                     as loan_biz_class  --业务分类
           ,'A19'                                   as loan_biz_detail --贷款业务细类
           ,''                                      as approver --审批员工号
           ,''                                      as project_id --项目ID
           ,'110101'                                as prod_code  --产品号 
      from odata.sym_mb_acct t5
      left join odata.sym_cif_client t6
        on t5.client_no = t6.client_no
       and t6.data_date = '${DATA_DATE}' 
       and t6.bddw_end_date = '9999-99-99' 
      left join odata.sym_mb_acct_balance t7
        on t5.internal_key = t7.internal_key
       and t7.amt_type ='DDA'
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
      left join odata.sym_mb_agreement_loan t8
        on t5.parent_internal_key = t8.internal_key
       and t8.data_date='${DATA_DATE}'
       and t8.bddw_end_date='9999-99-99'
     where t5.data_date='${DATA_DATE}' 
       and t5.bddw_end_date='9999-99-99'
       and t5.prod_type='110101'
       and t5.lead_acct_flag='N' --是否主账户 
