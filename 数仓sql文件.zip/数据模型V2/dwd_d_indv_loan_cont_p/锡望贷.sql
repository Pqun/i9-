--2.yuguorui.dwd.dwd_d_indv_loan_cont_p
--脚本名称:dwd_d_indv_loan_cont_p
--功能描述:个人贷款合同信息表
--作    者:于国睿
--开发日期:2022-07-05
--直属经理:方杰
--目标表  :dwd.dwd_d_indv_loan_cont_p 
--数据原表:odata.order_main_loan_order
--         odata.sllv_mb_acct
--         odata.order_loan_order_house
--         odata.order_contract_sign  
--         odata.sym_mb_prod_type
--         odata.sym_cif_client
--         odata.sym_gl_prod_accounting
--         odata.pawn_pawn_base
--         odata.pawn_pawn_machine
--         odata.order_product_loan_info
--         odata.order_xwd_loandetail
--         odata.order_job_info
--修改历史:
--         1、于国睿     2022-07-05     新建
--         2、于国睿     2023-09-19     担保方式，贷款用途逻辑调整
--         3、于国睿     2023-10-24     贷款用途空值按贷款类型码值转换
--         4、杨琦浩     2023-11-18     新增审批员工号
-------------------------------------------------------------------
--锡望贷
insert overwrite table dwd.dwd_d_indv_loan_cont_p partition(data_date='${DATA_DATE}',prod_code)
    select  /*+ REPARTITION(1) */
            nvl(t4.withdraw_contract_no,'')                   as cont_no  --合同号
           ,nvl(t13.client_no,'')                             as cust_id  --客户号
           ,nvl(t7.user_name,'')                              as cust_name  --客户名称
           ,nvl(t6.prod_desc,'')                              as prod_type --产品名称
           ,nvl(t2.product_type,'')                           as biz_prod_code  --业务产品号
           ,nvl(t2.sub_product_type,'')                       as sub_biz_prod_code  --业务子产品号
           ,'CNY'                                             as ccy  --币种
           ,nvl(t12.actual_loan_amount,0)                     as cont_amt  --合同金额
           ,nvl(substr(t2.loan_time,1,10),'')                 as cont_start_date  --合同生效日期
           ,nvl(add_months(t2.loan_time,cast(t12.actual_loan_period as int)),'')   
                                                              as cont_mature_date  --合同到期日期
           ,'D'                                               as guar_mode  --主要担保方式 --update 20230919 yuguorui
           ,case when t12.loan_need is null then 
                                                 case when t12.loan_need_type = '1' then '企业经营性贷款'
                                                      when t12.loan_need_type = '2' then '个人消费贷款'
                                                      when t12.loan_need_type = '3' then '个人经营性贷款'
                                                      else ''
                                                  end                                                   
                 else nvl(t12.loan_need,'') 
             end                                              as loan_pupr  --贷款用途  --update 20231024 yuguorui
           ,nvl(t12.loan_cast_area,'')                        as loan_invest_area_code  --贷款投向地区
           ,nvl(t12.loan_cast_industry_code,'')               as loan_invest_indust_code  --贷款投向行业
           ,'0'                                               as limit_indust_code  --是否国家限制行业
           ,nvl(t1.loan_id,'')                                as credit_cont_no  --授信合同号
           ,coalesce(substr(t2.apply_time,1,10),substr(t3.create_time,1,10),'')    
                                                              as approve_date  --批准日期
           ,case when t2.status in(1,2,13,14) then '101'
                 when t2.status in(4,5) then '103'
                 when t2.status = 8 then '106'
                 when t2.status = 11 then '104'
                 when t2.status = 12 then '102'
                 when t2.status = 15 then '111'
                 when t1.loan_status='1' then '105' 
                 when t1.loan_status in('2','3') then '107'
                 when t1.loan_status='4' then '106'
                 when t1.loan_status='5' then '111'
             end                                              as loan_cont_status  --合同状态
           ,'2'                                               as loan_biz_class  --业务分类
           ,case when t5.work_kind = '1' then 'A18'
                 when t5.work_kind = '3' then 'A17'
                 when t5.work_kind = '9' then 'A19'
                 else ''
             end                                              as loan_biz_detail --贷款业务细类
           ,nvl(t15.username,'')                              as approver --审批员工号
           ,''                                                as project_info
           ,t1.prod_type                                      as prod_code  --产品号   
      from odata.slur_acc_duebill_info t1
      left join odata.order_main_loan_order t2 
        on t2.loan_id=t1.loan_id
       and t2.data_date='${DATA_DATE}' 
       and t2.bddw_end_date='9999-99-99' 
       and t2.product_type<>'9'
      left join (select create_time
                       ,loan_id
                       ,row_number() over(partition by loan_id order by create_time desc) as seq 
                   from odata.order_pay_operate_log 
                  where data_date = '${DATA_DATE}' 
                    and bddw_end_date = '9999-99-99') t3 
        on t1.loan_id = t3.loan_id 
       and t3.seq = 1
      left join (select withdraw_contract_no
                       ,loan_no
                   from odata.order_xwd_loandetail
                  where data_date = '${DATA_DATE}' 
                    and bddw_end_date = '9999-99-99'
                  group by withdraw_contract_no
                          ,loan_no) t4
        on t1.loan_id = t4.loan_no
      left join odata.order_job_info t5 
        on t1.loan_id = t5.loan_id 
       and t5.data_date = '${DATA_DATE}' 
       and t5.bddw_end_date = '9999-99-99'
      left join odata.sym_mb_prod_type t6
        on t1.prod_type=t6.prod_type
       and t6.data_date='${DATA_DATE}' 
       and t6.bddw_end_date='9999-99-99'
      left join odata.order_custom_info t7
        on t1.loan_id=t7.loan_id 
       and t7.data_date='${DATA_DATE}' 
       and t7.bddw_end_date='9999-99-99'
      left join odata.uc_um_participant_user t13
        on t2.user_id = t13.user_id
       and t13.data_date = '${DATA_DATE}' 
       and t13.bddw_end_date = '9999-99-99'
      left join odata.sym_gl_prod_accounting t8 --通过科目号来取消费还是经营
        on t8.data_date='${DATA_DATE}'
       and t8.bddw_end_date='9999-99-99'
       and t1.prod_type = t8.prod_type
       and t8.accounting_status = 'ZHC'
       and t8.tran_category = 'ALL'
      left join odata.order_product_loan_info t12
        on trim(t2.loan_id)=trim(t12.loan_id) 
       and t12.data_date='${DATA_DATE}' 
       and t12.bddw_end_date='9999-99-99'  
      left join (select loan_id
                       ,processor
                       ,row_number() over(partition by loan_id order by process_time desc) as seq 
                   from odata.order_order_audit_operation_log 
                  where data_date='${DATA_DATE}' 
                    and bddw_end_date='9999-99-99' 
                    and process_node is not null 
                ) t14
        on t2.loan_id = t14.loan_id 
       and t14.seq = 1
      left join odata.sso_upms_user t15
        on t14.processor=t15.user_id
       and t15.data_date='${DATA_DATE}' 
       and t15.bddw_end_date='9999-99-99'
     where t1.data_date='${DATA_DATE}' 
       and t1.bddw_end_date='9999-99-99'
   