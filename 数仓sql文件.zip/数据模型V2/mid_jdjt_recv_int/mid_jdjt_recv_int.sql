insert overwrite table dwd.mid_jdjt_recv_int partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */ 
nvl(t1.bill_no,'') as bill_no
       ,'' 
       ,case when t2.yuq_flag='1' and t2.yuq_days>=89  then 0+nvl(t2.zhc_int,0)
        else nvl(t2.int_accrued,0)+nvl(t2.odp_accrued,0) 
        end as receiv_int 
from odata.ols_loan_cont_info t1
left join odata.slur_jd_loan_data_hist_clear t2
  on t1.bill_no=t2.loan_no 
  and t2.data_date='${DATA_DATE}' 
  and t2.bddw_end_date='9999-99-99' 
where t1.data_date='${DATA_DATE}' and t1.bddw_end_date='9999-99-99' 
    and t1.prd_code in ('10011001003') 
    and substr(t1.input_time,1,10)<='${DATA_DATE}'
    and t1.cont_status in ('105','106','107')  