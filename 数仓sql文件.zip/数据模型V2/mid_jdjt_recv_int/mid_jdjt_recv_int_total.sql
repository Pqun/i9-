insert overwrite table dwd.mid_jdjt_recv_int partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */ 
a.bill_no
       ,'' 
       ,nvl(a.receiv_int,0)+nvl(b.receiv_int,0)
from dwd.mid_jdjt_recv_int a 
left join dwd.mid_jdjt_recv_int_scene_tran_total b 
on a.bill_no=b.bill_no
and b.data_date='${DATA_DATE}'
where a.data_date='${DATA_DATE}'