-------------------------------------------------------------------
--脚本名称:dwd_f_inner_acct_p
--功能描述:数仓内部分户账明细表
--作    者:邓权
--开发日期:2022-08-26
--直属经理:方杰
--目标表  :dwd.dwd_f_inner_acct_p                     内部分户账明细表
--数据原表:odata.sym_mb_acct                          账户基本信息表
--         odata.sym_mb_acct_attach                   账户辅助信息表    
--         odata.sym_mb_acct_balance                  账户余额表
--         odata.sym_cif_client                       客户信息表
--         odata.sym_gl_prod_accounting               产品科目表         
--         odata.gl_v_gl_subject                  
--         odata.sym_mb_restraints                    帐户限制表
--         odata.sym_fm_restraint_type                账户限制类型定义表                        
--修改历史:
--         1、邓权     20220826     新建
------------------------------------------------------------------
 insert overwrite table dwd.dwd_f_inner_acct_p partition(data_date='${DATA_DATE}')
 select  /*+ REPARTITION(1) */
       concat(sma.base_acct_no,sma.acct_seq_no)      as acct_no         --内部分户账账号
       ,vgs.balance_dir                               as dr_cr_ind       --借贷标志
       ,sma.acct_name                                as acct_name       --账户名称
       ,sma.acct_type                                as acct_type       --账户类型代码
       ,sma.ccy                                      as ccy             --币种
       ,sma.home_branch                              as org_id          --内部机构号
       ,coalesce(maa.gl_code,t1.gl_code_l,t2.gl_code_l,t3.gl_code_l)  as subj_no         --明细科目编号
       ,sma.prod_type                                as prod_code       --产品号
       ,sma.client_no                                as cust_id         --客户号
       ,nvl(mab.total_amount,0)                      as acct_bal        --账户余额
	   ,case when vgs.balance_dir = 'D' or (vgs.balance_dir = 'A' and mab.total_amount >= 0) then nvl(mab.total_amount_prev,0)
	         else 0 end                              as d_bal --借方余额
	   ,case when vgs.balance_dir = 'C' or (vgs.balance_dir = 'A' and mab.total_amount < 0) then nvl(-1 * mab.total_amount_prev,0)
	         else 0 end                              as c_bal --贷方余额    
       ,0                                            as accr_flag --计息标志    
       ,nvl(from_unixtime(unix_timestamp(sma.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'), '9999-12-31') as acct_open_date --开户日期                                                                                                                       
       ,nvl(from_unixtime(unix_timestamp(sma.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'), '9999-12-31') as acct_close_date --销户日期 
       ,nvl(from_unixtime(unix_timestamp(sma.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'), '9999-12-31') as acct_mature_date --到期日期 
       ,case when smr.internal_key is not null then 'F'
	         when smr2.internal_key is not null then 'Q'           
	         else sma.acct_status end                as acct_status --账户状态
	   from  odata.sym_mb_acct sma
	   left join odata.sym_mb_acct_attach maa
	          on sma.internal_key = maa.internal_key
	         and maa.data_date='${DATA_DATE}'
	         and maa.bddw_end_date='9999-99-99'
	   left join odata.sym_mb_acct_balance mab
	          on sma.internal_key=mab.internal_key
	         and mab.data_date='${DATA_DATE}'
	         and mab.bddw_end_date='9999-99-99'
	         and mab.amt_type='BAL'  --取余额
	   left join (select sma.internal_key, gpa.gl_code_l
	              from odata.sym_mb_acct sma
	            inner join odata.sym_cif_client scc
	               on sma.client_no = scc.client_no
	              and scc.data_date='${DATA_DATE}'
	              and scc.bddw_end_date='9999-99-99'
	            inner join odata.sym_gl_prod_accounting gpa
	               ON sma.prod_type = gpa.prod_type
	              and sma.accounting_status = gpa.accounting_status
	              and scc.category_type = gpa.tran_category
	              and gpa.data_date='${DATA_DATE}'
	              and gpa.bddw_end_date='9999-99-99'
	            where sma.data_date='${DATA_DATE}'
	              and sma.bddw_end_date='9999-99-99'
	              and sma.ccy = 'CNY'
	              and sma.source_module = 'RB'
	              and sma.acct_real_flag = 'Y' --实账户
	   ) t1
	          on sma.internal_key=t1.internal_key     
	   left join (select sma.internal_key, gpa.gl_code_l
	                from odata.sym_mb_acct sma
	          inner join odata.sym_gl_prod_accounting gpa
	                  on sma.prod_type = gpa.prod_type
	                 and sma.accounting_status = gpa.accounting_status
	                 and gpa.tran_category = 'ALL'
	                 and gpa.data_date='${DATA_DATE}'
	                 and gpa.bddw_end_date='9999-99-99'
	               where sma.data_date='${DATA_DATE}'
	                 and sma.bddw_end_date='9999-99-99'
	                 and sma.ccy = 'CNY'
	                 and sma.source_module = 'RB'
	                 and sma.acct_real_flag = 'Y' --实账户
	   )  t2
	          on sma.internal_key=t2.internal_key 
	   left join (select distinct gpa.prod_type, gpa.gl_code_l
	                from odata.sym_gl_prod_accounting gpa
	               where gpa.accounting_status = 'ALL'
	                 and gpa.tran_category = 'ALL'   
	                 and gpa.data_date='${DATA_DATE}'
	                 and gpa.bddw_end_date='9999-99-99'          
	   ) t3
	   on sma.prod_type=t3.prod_type   
	   left join odata.gl_v_gl_subject vgs
	          on coalesce(maa.gl_code,t1.gl_code_l,t2.gl_code_l,t3.gl_code_l) = vgs.gl_code 
	         and vgs.data_date='${DATA_DATE}'
	         and vgs.bddw_end_date='9999-99-99'   
	   left join(select smr.internal_key
                   from odata.sym_mb_restraints smr  
	              where smr.restraint_type in ('004','005','006','008') --司法冻结
	                and smr.data_date = '${DATA_DATE}'  
	                and smr.bddw_end_date='9999-99-99'
	           group by smr.internal_key 
	   ) smr
	          on sma.internal_key=smr.internal_key
	   left join (select smr2.internal_key
	                from odata.sym_mb_restraints smr2 
	          inner join odata.sym_fm_restraint_type frt
                      on smr2.restraint_type=frt.restraint_type
	                 and frt.restraint_class in ('SW','AS')  --止付 
	                 and frt.data_date = '${DATA_DATE}'  
	                 and frt.bddw_end_date='9999-99-99' 
	               where smr2.data_date = '${DATA_DATE}'  
	                 and smr2.bddw_end_date='9999-99-99' 
	            group by smr2.internal_key
	   ) smr2
	          on sma.internal_key=smr2.internal_key
	   where (sma.source_module = 'GL' or  vgs.gl_code ='20730101')
	     and sma.data_date='${DATA_DATE}'
	     and sma.bddw_end_date='9999-99-99'
	   --   and (sma.acct_close_date>regexp_replace(add_months('${DATA_DATE}',-1),'-','')  or sma.acct_close_date is null)
	   --   and (CASE WHEN '${DATA_DATE}' = '2022-05-31' THEN
	   --              (sma.acct_close_date>regexp_replace(add_months('${DATA_DATE}',-5),'-','')  or sma.acct_close_date is null)
	   --         WHEN SUBSTR('${DATA_DATE}',1,4) = '2020' OR SUBSTR('${DATA_DATE}',1,4) = '2021' THEN 
	   --              (sma.acct_close_date>regexp_replace(add_months('${DATA_DATE}',-6),'-','')  or sma.acct_close_date is null)
	   --         ELSE
	   --              (sma.acct_close_date>regexp_replace(add_months('${DATA_DATE}',-1),'-','')  or sma.acct_close_date is null)
	   --          END )   --销户日期是当月的或者是未销户的