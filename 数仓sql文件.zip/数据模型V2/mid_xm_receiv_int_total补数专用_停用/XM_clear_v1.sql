insert overwrite table dwd.mid_xm_recv_int_scene_tran partition(data_date='2022-03-17')
  select
    yjlx.bill_no,
    '',
  sum(case 
        when yjlx.scene in ('XM003','XM005','XM023','XM024') then yjlx.receiv_int
        else -yjlx.receiv_int 
       end ) as amt
from dwd.mid_xm_recv_int_scene_tran yjlx
where yjlx.data_date = '2022-03-17'
  and yjlx.receiv_int<>0
group by yjlx.bill_no 