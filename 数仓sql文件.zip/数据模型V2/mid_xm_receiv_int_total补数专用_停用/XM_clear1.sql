with tmp as (
 select
   yjlx.bill_no as loan_id ,
   '',
   nvl(yjlx.receiv_int,0) as amt 
 from dwd.mid_xm_recv_int_scene_tran yjlx
 where yjlx.data_date = date_add('${DATA_DATE}',-1)
  
union all 

select 
 yjlx.bill_no as loan_id ,
 '',
 nvl(yjlx.receiv_int,0) as amt 
from dwd.mid_xm_recv_int_scene_tran yjlx
where yjlx.data_date = '${DATA_DATE}' 

union all

select
   dzz.loan_no as loan_id,
   '',
   -sum(dzz.comps_int+dzz.comps_prin_pnlt) as amt
from odata.slur_dzz_compensatory_detail dzz 
where dzz.data_date ='${DATA_DATE}'
  and dzz.comps_date = regexp_replace('${DATA_DATE}','-','')
  and dzz.prod_type ='110126'
  and dzz.comps_status = 'S'
  and dzz.loan_type <>'O'
  group by dzz.loan_no
)

insert overwrite table dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}')

select 
 tmp.loan_id,
 '',
  sum(tmp.amt)
from tmp 
group by tmp.loan_id 