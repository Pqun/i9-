---------------------------------------------------------------------------------------------------------------
--脚本名称：贷款账号表取数逻辑.sql
--功能描述：用于在hive gdata层创建dwd.dwd_d_loan_acct_p
--作    者：张礼娟
--开发日期：2020-12-22
--直属经理：程宏明
--修改历史：
--          1.张礼娟   2020-12-22    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_loan_acct_p partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(5) */
     t1.acct_key            as    acct_key      --帐户主键
    ,t1.acct_no             as    acct_no       --账号
    ,t1.bill_no             as    bill_no       --借据号
    ,t1.cust_type           as    cust_type     --客户类型
    ,t1.cust_id             as    cust_id       --客户号
    ,t1.prod_type           as    prod_type     --产品类型
    ,t1.ccy                 as    ccy           --币种
    ,t1.organ               as    org           --机构代码
    ,t1.organ_id            as    org_id            --机构代码
    ,t1.acct_status         as    acct_status       --账户状态
    ,t1.acct_type           as    acct_type         --账户类型
    ,t1.acctng_status       as    acctng_status     --核算状态/贷款状态
    ,t1.acct_name           as    acct_name         --账户名称
    ,t1.acct_open_date      as    acct_open_date    --账户开户日期
    ,t1.acct_close_date     as    acct_close_date   --账户关闭日期
    ,t1.ori_mature_date     as    ori_mature_date   --账户原始到期日期，即第一次开立时的到期日期，未进行期限变更时的到期日
    ,t1.mature_date         as    mature_date       --账户到期日
    ,t1.tran_timestamp      as    tran_timestamp    --时间戳
    ,t1.source_id           as    source_id         --系统来源
    ,null                   as    remark1           --备用字段1
    ,null                   as    remark2           --备用字段2
    ,null                   as    remark3           --备用字段3
    ,null                   as    remark4           --备用字段4
    ,null                   as    remark5           --备用字段5  
from 
(
    select
        internal_key as acct_key
        ,base_acct_no as acct_no
        ,cmisloan_no as bill_no
        ,client_type as cust_type
        ,client_no as cust_id
        ,prod_type as prod_type
        ,ccy as ccy
        ,branch as organ
        ,lender as organ_id
        ,acct_status as acct_status
        ,acct_type as acct_type
        ,accounting_status as acctng_status
        ,acct_name as acct_name
        ,from_unixtime(unix_timestamp(acct_open_date,'yyyymmdd'),'yyyy-mm-dd') as acct_open_date
        ,from_unixtime(unix_timestamp(acct_close_date,'yyyymmdd'),'yyyy-mm-dd') as acct_close_date
        ,from_unixtime(unix_timestamp(ori_maturity_date,'yyyymmdd'),'yyyy-mm-dd') as ori_mature_date
        ,from_unixtime(unix_timestamp(maturity_date,'yyyymmdd'),'yyyy-mm-dd') as mature_date
        ,tran_timestamp as tran_timestamp
        ,'sllv_mb_acct' as source_id
    from odata.sllv_mb_acct 
	where data_date='${DATA_DATE}' 
	and bddw_end_date='9999-99-99'
    union all
    select
        internal_key as acct_key
        ,base_acct_no as acct_no
        ,cmisloan_no as bill_no
        ,client_type as cust_type
        ,client_no as cust_id
        ,prod_type as prod_type
        ,ccy as ccy
        ,branch as organ
        ,lender as organ_id
        ,acct_status as acct_status
        ,acct_type as acct_type
        ,accounting_status as acctng_status
        ,acct_name as acct_name
        ,substr(acct_open_date,1,10) as acct_open_date
        ,substr(acct_close_date,1,10) as acct_close_date
        ,substr(ori_maturity_date,1,10) as ori_mature_date
        ,substr(maturity_date,1,10) as mature_date
        ,tran_timestamp as tran_timestamp
        ,'sllv_nl_acct' as source_id
    from odata.sllv_nl_acct 
	where data_date='${DATA_DATE}' 
	and bddw_end_date='9999-99-99'
    union all
    select
        internal_key as acct_key
        ,base_acct_no as acct_no
        ,cmisloan_no as bill_no
        ,client_type as cust_type
        ,client_no as cust_id
        ,prod_type as prod_type
        ,ccy as ccy
        ,branch as organ
        ,lender as organ_id
        ,acct_status as acct_status
        ,acct_type as acct_type
        ,accounting_status as acctng_status
        ,acct_name as acct_name
        ,from_unixtime(unix_timestamp(acct_open_date,'yyyymmdd'),'yyyy-mm-dd') as acct_open_date
        ,from_unixtime(unix_timestamp(acct_close_date,'yyyymmdd'),'yyyy-mm-dd') as acct_close_date
        ,from_unixtime(unix_timestamp(ori_maturity_date,'yyyymmdd'),'yyyy-mm-dd') as ori_mature_date
        ,from_unixtime(unix_timestamp(maturity_date,'yyyymmdd'),'yyyy-mm-dd') as mature_date
        ,tran_timestamp as tran_timestamp
        ,'sym_mb_acct' as source_id
    from odata.sym_mb_acct 
	where data_date='${DATA_DATE}' 
	and bddw_end_date='9999-99-99'
    and client_type = '02' --对公
    and source_module = 'CL' 
) t1 
