--2.zhanglijuan.dwd_d_passbook_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：dwd_d_passbook_p.sql
--功能描述：存折信息表
--作    者：于国睿
--开发日期：2022-08-22
--直属经理：方杰
--来源表  ：odata.sym_tb_voucher_info            --凭证出售后登记簿表
--来源表  ：odata.sym_tb_voucher_def             --凭证类型定义表   
--来源表  ：odata.sym_mb_acct                    --账户基本信息表    
--来源表  ：odata.sym_cif_client                 --客户信息表
--来源表  ：odata.sym_cif_client_document        --客户证件信息
--来源表  ：odata.sym_cd_card_arch               --卡片基本信息表
--来源表  ：odata.sym_mb_restraints              --帐户限制表 
--来源表  ：odata.sym_cif_document_type          --证件类型表
--目标表  ：dwd.dwd_d_passbook_p
--修改历史：
--          1.于国睿   2022-08-22   新建
--          2.张礼娟   2023-02-22   新增开户柜员
--          3.刘丽红   2023-11-14   新增介质状态
--          4.杨琦浩   2023-12-15   修改启用日期、销折日期取数逻辑
--          5.刘丽红   2024-04-11   新增协议号
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_passbook_p partition(data_date='${DATA_DATE}')
    select /*+ REPARTITION(1) */
	      nvl(t1.voucher_no_c,'')       as passbook_id	       --存折号
          ,nvl(t3.base_acct_no,'')       as acct_no	           --账号
          ,nvl(t1.branch,'')             as org_id	           --开折机构号
          ,nvl(t3.prod_type,'')          as prod_code	       --产品号
          --,nvl(from_unixtime(unix_timestamp(t3.acct_open_date,'yyyymmdd'),'yyyy-mm-dd'),'')    as start_date	       --启用日期
          ,nvl(substr(t7.tran_date,1,10),'')
		                                 as start_date	       --启用日期
		  ,nvl(t3.source_type,'')        as channel_id	       --启用渠道号
          --,nvl(from_unixtime(unix_timestamp(t3.acct_close_date,'yyyymmdd'),'yyyy-mm-dd'),'')   as close_date	       --销折日期
          ,nvl(substr(t8.tran_date,1,10),'')
		                                 as close_date	       --销折日期
		  ,nvl(t4.document_type,'')      as cert_type	       --证件类型
          ,nvl(t4.document_id,'')        as cert_no	           --证件号码
          ,case when t2.doc_type_desc like '%大额定期存单%' 
		        then '3'
	            when t2.doc_type_desc like '%存单%' and t2.doc_type_desc not like '%大额定期存单%' 
				then '2'
                when t2.doc_type_desc like '%一本通%' 
				then '4'
                when t2.doc_type_desc like '%存折%' 
				then '1'
                else '5'
            end                         as passbook_type	   --存折类型代码
          ,''                           as emp_flag	           --是否员工标志
          ,case when t3.acct_status = 'H' then '04'                 --未激活
                when t3.acct_status in ('A','N') then '01'          --正常
                when t3.acct_status = 'C' then '03'                 --注销
                when t3.acct_status = 'D' then '05'                 --睡眠
                when t3.acct_status in ('I','P','O','S') then '08'  --其他
                when t5.lost_status in ('1' , '2') then '06'        --挂失      
                when t6.internal_key is not null then '02'          --冻结
            end                         as passbook_status	   --存折状态代码
          ,nvl(t3.client_no,'')         as cust_id	           --客户号
          ,nvl(t3.user_id,'')           as open_tlr_no	--启用柜员
          ,nvl(t1.voucher_status,'')    as medium_status --介质状态  --update llh 20231114
          ,nvl(t1.link_value,'')        as cont_no       --协议号    --update llh 20240411
	  from odata.sym_tb_voucher_info t1
	 inner join odata.sym_tb_voucher_def t2                              --凭证类型定义表      
        on t1.doc_type = t2.doc_type
	   and t2.doc_class in ('PBK','DCT')   --PBK 存折 DCT存单
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99'  
	  left join odata.sym_mb_acct t3                                       --账户基本信息表
        on t1.link_value = t3.internal_key
       and t3.data_date ='${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
	  left join odata.sym_cif_client_document t4                           --客户证件信息
        on t4.client_no = t3.client_no 
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
	   and t4.pref_flag = 'Y'     
      left join odata.sym_cd_card_arch t5                                 --卡片基本信息表
        on t3.card_no = t5.card_no
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
      left join odata.sym_mb_restraints t6                                 --帐户限制表 
        on t3.internal_key=t6.internal_key
       and t6.restraint_type in ('004','005','006','008')                 --司法冻结
       and t6.data_date = '${DATA_DATE}'  
       and t6.bddw_end_date='9999-99-99'
      left join odata.sym_tb_voucher_journal t7
        on t1.voucher_no_c=t7.voucher_no_c 
	   and t1.doc_type=t7.doc_type
	   and t7.voucher_status='ACT' --已出售
	   and t7.old_status='NUS' --未使用
	   and t7.data_date = '${DATA_DATE}'  
       and t7.bddw_end_date='9999-99-99'
	  left join (
	             select *
				        ,row_number() over(partition by voucher_no_c,doc_type order by time_stamp desc )rn 
		         from odata.sym_tb_voucher_journal
				 where voucher_status in ('DES','CAN') --DES 销毁 CAN 已作废
				 and data_date = '${DATA_DATE}'  
                 and bddw_end_date='9999-99-99'
	            ) t8
	   on t1.voucher_no_c=t8.voucher_no_c 
	   and t1.doc_type=t8.doc_type
	   and t8.rn=1
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
	   and t3.acct_open_date <= regexp_replace('${DATA_DATE}','-','')    --限制账户开户日期小于等于抽数日期