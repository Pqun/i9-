--2.zhanglijuan.dwd.dwd_c_corp_cust_info_p
--------------------------------------------------------------------------------------------------------------------------------------
--脚本名称:dwd_c_corp_cust_info_p
--功能描述:主题模型对公客户信息表
--作    者:施金才
--开发日期:2020-09-27
--直属经理:程宏明
--目标表  :dwd_c_corp_cust_info_p      对公客户信息表
--数据原表:sym_cif_client					客户信息表		
--         sym_cif_client_corp				法人客户附加信息表
--         sym_bat_cif_base_corp			对公客户基本信息表
--         sym_cif_client_contact_address	客户联系地址表
--         sym_cif_client_document			客户证件信息表
--         sym_mb_acct					    账户基本信息表
--         sym_cif_cross_relations			客户关系表
--		     sym_cif_client_contact_tbl		客户联系信息表
--		     als_ent_info						企业基本信息表
--修改历史:
--         1、施金才     20200927     新建
--         2、施金才     20201104     更新缩写
--         3、于国睿     20210426     注册地址和注册地区代码字段改从sym_cif_client_contact_address和sym_cif_client_document表中取
--                                    去除client_type='03'条件
--         4、华天顺     20210513     修改授信额度取数逻辑，已用额度取余额
--         5、华天顺     20210608     修改企业规模代码取数逻辑
--         6、华天顺     20210624     修改国民经济部门代码取数逻辑
--         7. 华天顺     20210706     新增行业门类，行业大类，行业中类，修改行业类型代码取数逻辑
--         8. 华天顺     20210706     授信额度改成取有效期内额度+有贷款余额但不在授信有效期内的额度
--         9. 华天顺     20220119     注册地址先取核心地址表注册地址,取不到取首选地址和联系地址
--         10.华天顺     20220224     企业规模优先取信贷系统，授信额度取数逻辑调整
--		   11.吴镇宇	 20220818	  新增营业执照编码，营业执照有效截至日期，集团授信标志，是否上市标志，上市地点代码，上市时间，
--									  邮编，传真号，联系电话，(开户)证件有效截止日期，基本账户状态，内部评级生效日期，
--									  全球法人机构识别编码代码取数逻辑
--		   11.张礼娟	 20221027
-- cust_type_code 变更字段英文名为 cust_type  --客户类型代码
-- cert_type_code 变更字段英文名为 cert_type   --(开户)证件类型代码
-- cert_no 变更字段英文名为 cert_no  --(开户)证件号码
-- cust_crdt_lvl 变更字段英文名为 cust_crdt_lvl   --内部客户信用等级
-- contact_addr_area_code 变更字段英文名为 contact_addr_code  --联系地址行政区划代码
-- crdt_amt 变更字段英文名为 credit_limit   --授信额度
-- used_amt 变更字段英文名为 used_limit   --已用额度
-- cust_loc_area 变更字段英文名为 cust_area_code   --客户类型代码
-- 新增字段：贷款卡号loan_card_no
--         12. 张礼娟     20230214  新增字段：风险预警信号，是否农村企业
--         13. 张礼娟     20230321  修改客户名称逻辑，对字段做非空处理
--         14. 刘丽红     20231026  新增字段：所有制形式
--         15. 刘丽红     20231114  调整企业出资人经济成分代码,行业小类
--         16. 刘丽红     20231207  调整上市公司标识字段名为上市类型,并调整该字段逻辑
--         17. 杨琦浩     20231215  调整联系电话、基本账户号、基本账户开户行号、基本账户开户行名取数逻辑
--         18. 杨琦浩     20240306  剔除已被删除、状态失效的关联客户信息
--         19. 张礼娟     20240306  紧急投产，supwall_scp_enterprise_cust_info 供应链企业客户信息增加状态生效条件
--		   20. 彭群		  20240514  
--	     	                        字段逻辑进行修改，修改字段内容如下 ：法定代表人名称、法定代表人身份证件号码、
--		 	                        法定代表人身份证件类型、税收身份、经营状态、注册资本金额、注册资本币种代码
--		                            注册地址、办公地址、经营地址、注册地区代码、上市类型、从业人数、企业出资人经济成分代码
--		                            企业规模代码、成立日期、国民经济部门代码、营业收入总资产、实收资本、注册资本、经营范围
--		                            营业执照编码、所有制形式、行业小类、基本账户号、基本账户开户行号、基本账户开户行名		  	                            	
-------------------------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_c_corp_cust_info_p partition(data_date='${DATA_DATE}')
select  /*+ REPARTITION(1) */
    t1.client_no                                        as     cust_id                          -- 客户号
   ,t1.client_type                                      as     cust_type                        -- 客户类型代码
   ,t1.category_type                                    as     cust_subdiv_type                 -- 客户细分类型
   ,t1.ch_client_name                                   as     cust_name                        -- 客户名称
   ,nvl(t1.client_name,'')                              as     cust_en_name                     -- 客户英文名称
   ,nvl(t6.document_type,'')         					as     cert_type                        -- (开户)证件类型代码
   ,nvl(t6.document_id,'')    							as     cert_no                          -- (开户)证件号码
   ,coalesce(t24.customername,t36.legal_person,'')      as     lgl_name                         -- 法定代表人名称
   ,coalesce(t24.certtype,t36.cert_type,'')   			as     lgl_cert_type                    -- 法定代表人身份证件类型
   ,coalesce(t24.certid,t36.legal_person_id_card,'')    as     lgl_cert_no                      -- 法定代表人身份证件号码
   ,nvl(t7.CreditLevel,'')                              as     cust_crdt_lvl                    -- 客户信用等级
   ,'4'                                                 as     cust_crdt_lvl_cont               -- 客户信用等级数
   ,nvl(t1.creation_channel,'')                         as     create_chan                      -- 创建渠道
   ,coalesce(t1.resident_status,t36.tax_resident_flag,'')as    tax_id                           -- 税收身份
   ,nvl(t1.tran_status,'')                              as     cust_tran_status                 -- 客户交易状态
   ,nvl(t3.internal_ind,'N')                            as     is_inner_cust                    -- 是否为内部客户
   ,nvl(t12.address,'')                                 as     contact_addr                     -- 联系地址
   ,nvl(t12.dist,'')                                    as     contact_addr_code                -- 联系地址行政区划代码
   ,coalesce(t7.totalassets * 10000,t36.total_assets,0) as     total_asset                      -- 总资产				--updatapengqun 20240428
   ,coalesce(t7.sellsum * 10000,t36.annual_income,0)    as     opra_income                      -- 营业收入				--updatapengqun 20240428
   ,coalesce(t7.operationstate,t36.registered_status,'')as     opra_status                      -- 经营状态
   ,nvl(t1.system_id,'')                                as     source_sys_code                  -- 来源系统代码
   ,coalesce(t7.registercapital*10000,t36.registered_fund,0) 
														as     regist_capital                   -- 注册资本金额 --updatapengqun 20240428
   ,coalesce(t2.capital_ccy,t36.registered_currency,'') as     regist_capital_ccy               -- 注册资本币种代码
   ,coalesce(t23.address,t36.regist_addr,'')        	as     regist_addr                     		 -- 注册地址
   ,coalesce(t5.address,t36.office_addr,'')             as     office_addr                      -- 办公地址/经营地址
   ,nvl(from_unixtime(unix_timestamp(t6.iss_date,'yyyymmdd'),'yyyy-mm-dd'),'')           
														as     regist_date                      -- 注册日期
   ,nvl(from_unixtime(unix_timestamp(t6.expiry_date,'yyyymmdd'),'yyyy-mm-dd'),'')       
														as     regist_end_date   -- 注册到期日期
   ,nvl(from_unixtime(unix_timestamp(t6.last_change_date,'yyyymmdd'),'yyyy-mm-dd'),'')  
														as     regist_update_date -- 登记注册更新日期
   ,nvl(t6.iss_country,'')                              as     regist_country_code              -- 注册国别代码
   ,coalesce(t6.dist_code,t36.regist_area_code,'')      as     regist_area_code                 -- 注册地区代码
   ,coalesce(t2.business_scope,t36.business_scope,'')   as     opra_scope  -- 经营范围			--updatapengqun20240428
   ,''                                                  as     pare_cust_id                     -- 母公司客户编号
   ,case when coalesce(t7.listingcorpornot,t37.listed_company_type,'')='2' then 'N' 
         else coalesce(t7.listingcorpornot,t37.listed_company_type,t36.listed_company_type,'')  
         end		 
                                                        as     listing_type                     -- 上市类型('上市类型 N 非上市,A A股上市,B B股上市,F 海外上市,H 香港上市,O 其他上市公司')   --update llh 20231207
   ,coalesce(t7.employeenumber,t36.employee_number,0)   as     emp_cnt                          -- 员工数		updatapengqun	20240428
   ,coalesce(t7.scope,t2.corp_size,t36.firm_size,'')    as     corp_scale                       -- 企业规模代码
   ,coalesce(t7.enterpriseeconomiccomponents,t2.sponsor_fin,t36.control_type,'')            
                                       as     investor_econ_type_code 		-- 企业出资人经济成分代码  --update llh 20231114            
   ,''                                                  as     is_rela_cust_flag                -- 是否我行关联方客户标志Y 是N 否
   ,coalesce(t7.paiclupcapital * 10000,t36.actual_fund,0)	
														as     paid_captial_amt                 -- 实收资本金额		--updatapengqun 20240428
   ,coalesce(from_unixtime(unix_timestamp(t2.incor_date,'yyyymmdd'),'yyyy-mm-dd'),t36.create_date,'')         
														as     create_date   					-- 成立日期
   ,''                    							    as     stock_mkt_type_code              -- 股票市场类型代码
   ,nvl(t1.inland_offshore,'')                          as     overseas_flag                    -- 境外标志
   ,nvl(t2.group_client_sidn,'')                        as     grp_cust_flag                    -- 集团客户标志
   ,nvl(from_unixtime(unix_timestamp(t1.creation_date,'yyyymmdd'),'yyyy-mm-dd'),'')      as     cust_create_date  -- 客户创建日期
   ,nvl(t1.ctrl_branch,'')                              as     cust_create_org_id               -- 客户创建机构代码
   ,nvl(t1.ctrl_branch,'')                              as     cust_belong_org_id               -- 客户归属机构号
   ,''                                                  as     sholder_flag                     -- 是否本行股东Y 是N 否
   ,0                                                   as     sholder_ratio                    -- 本行股份持股比例
   ,nvl(t1.acct_exec,'')                                as     cust_magr_id                     -- 客户经理号
   ,coalesce(t7.IndustryType,t1.industry_four,t36.industry_involved,'')       
														as     indust_type_code                 -- 行业类型代码		
   ,nvl(t9.document_id,'')                              as     unif_soc_crdt                    -- 统一社会信用代码
   ,coalesce(t8.businesssum,t81.businesssum,0)          as     credit_limit                     -- 授信额度
   ,nvl(t27.businesssum,0)                              as     used_limit                       -- 已用额度
   --,nvl(t16.base_acct_no,'')                          as     base_acct_no                  	-- 基本账户号
   ,coalesce(t2.basic_acct_no,t7.basicaccount,t36.bank_account,'')       
														as     base_acct_no                     -- 基本账户号
   --,nvl(t16.branch,'')                                as     base_acct_org_no               	-- 基本账户开户行号
   ,nvl(t36.bank_code,'')                               as     base_acct_org_no                 -- 基本账户开户行号
   ,case when t2.basic_acct_no is not null then nvl(t2.basic_acct_openat,'')
         when t7.basicaccount is not null then nvl(t7.basicbank,'')
		 when t36.client_no is not null then nvl(t36.bank_name,'')
		 else '' end                                    as     base_acct_org_name               -- 基本账户开户行名
   ,coalesce(t7.budgettype,t2.natiomal_economy,t36.review_department,'')      
														as     nat_econ_depar_code              -- 国民经济部门代码
   ,nvl(t2.tax_file_no,'')                              as     nat_tax_cert_no                  -- 国税证号
   ,nvl(t2.local_tax_file_no,'')                        as     local_tax_cert_no                -- 地税证号
   ,nvl(t1.state_loc,'')                                as     cust_area_code                   -- 客户所在地区
   ,nvl(t1.country_loc,'')                              as     cust_country_code                -- 客户所在国别
   ,nvl(t18.relation,'')                                as     rela_cust_type_code              -- 我行关联方类型代码
   ,nvl(t1.industry_one,'')                             as     indust_type_class      			--行业门类
   ,nvl(t1.industry_two,'')                             as     indust_type_big        			--行业大类
   ,nvl(t1.industry_three,'')                           as     indust_type_mid        			--行业中类
   ,''                                                  as     remark4                			--备用字段4
   ,''                                                  as     remark5                			--备用字段5    
   ,coalesce(t1.industry_four,t7.industrytype,t36.industry_involved,'')
                                                        as	   indust_type_small				--行业小类 --update llh 20231114
   ,coalesce(t31.document_id,t36.business_license,'') 	as	   biz_license_no					--营业执照编码
   ,nvl(from_unixtime(unix_timestamp(nvl(t31.expiry_date,'99991231'),'yyyyMMdd'),'yyyy-MM-dd'),'') 
														as 	   biz_license_expire_date			--营业执照有效截止日期
   ,''											        as 	   group_credit_flag				--集团授信标志
   ,''													as	   listing_flag						--是否上市标志
   ,''											        as 	   listing_space_code				--上市地点代码
   ,''											        as 	   listing_date						--上市时间
   ,nvl(t32.postal_code,'')								as 	   post								--邮编
   ,nvl(t7.officefax,'')								as     fax_no							--传真号
   ,coalesce(t38.contact_tel,t24.telephone,'')			as     contact_tel_no					--联系电话
   ,nvl(from_unixtime(unix_timestamp(t6.expiry_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as	   cert_expire_date	--(开户)证件有效截止日期
   ,''											        as 	   base_acct_status					--基本账户状态
   ,''											        as	   risk_effect_date					--内部评级生效日期
   ,''											        as	   lei_code							--全球法人机构识别编码
   ,nvl(t7.loancardno,'')                               as     loan_card_no                     --贷款卡号
   ,nvl(t1.risk_weight,'0')	                            as     risk_weight	                    --风险预警信号    
   ,case when t7.isfarmers='1' then '1' else '0' end    as     is_farmers 	                    --是否农村企业  
   ,nvl(coalesce(t7.economytype,t10.enterprise_type,t30.category_type,t33.category_type,t36.economic_type),'')     
                                                        as     ownership_forms    				--所有制形式 --add liulihong 20231026
from odata.sym_cif_client t1        
left join odata.sym_cif_client_corp t2 
on t1.client_no = t2.client_no 
and t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99'
left join odata.sym_bat_cif_base_corp t3 
on t1.client_no = t3.party_id 
and t3.data_date='${DATA_DATE}' 
and t3.bddw_end_date='9999-99-99'
left join odata.sym_cif_client_document t6 
on t1.client_no = t6.client_no 
and t6.pref_flag='Y'    --首选信息
and t6.data_date='${DATA_DATE}' 
and t6.bddw_end_date='9999-99-99'
left join (select t10.business_license
                 ,case when t10.enterprise_type = '有限责任公司' then '1'
                       else t10.enterprise_type
                       end                                as enterprise_type
             from (select  get_json_object(company_base_info,'$.businessLicense') as business_license
                          ,get_json_object(company_base_info,'$.enterpriseType') as enterprise_type
                          ,row_number() over(partition by get_json_object(company_base_info,'$.businessLicense')
                           order by create_time desc,modified_time desc) as rn 
                      from  odata.order_company_investigate_info
                      where data_date = '${DATA_DATE}'
                        and bddw_end_date = '9999-99-99'
                        and nvl(company_base_info,'')<>'')t10 
             where t10.rn=1 )t10
   on t6.document_id = t10.business_license
left join odata.sym_cif_client_document t9 
on t1.client_no = t9.client_no 
and t9.document_type='231'   --231 统一社会信用代码
and t9.data_date='${DATA_DATE}' 
and t9.bddw_end_date='9999-99-99'
left join odata.sym_cif_client_document t31 
on t1.client_no=t31.client_no 
and t31.document_type in ('211','251','236','240')  --211营业执照,251民办非企业单位登记证,236事业法人登记证书,240工会社会团体法人资格证
and t31.data_date='${DATA_DATE}' 
and t31.bddw_end_date='9999-99-99' 
left join odata.sym_cif_client_contact_address t32 
on t1.client_no = t32.client_no 
and t32.pref_flag = 'Y'   --首选信息
and t32.data_date='${DATA_DATE}'
and t32.bddw_end_date='9999-99-99' 
left join odata.sym_cif_client_contact_address t5  
on t1.client_no = t5.client_no  
and t5.contact_type = '04'   --01联系地址，02注册地址，03单位地址，04办公地址，05居住地址，06户籍地址，07综合账单地址，08信用卡账单地址，09其他物理地址
and t5.data_date='${DATA_DATE}' 
and t5.bddw_end_date='9999-99-99'
left join odata.sym_cif_client_contact_address t12    
on t1.client_no = t12.client_no  
and t12.contact_type = '01'  --联系地址
and t12.data_date='${DATA_DATE}' 
and t12.bddw_end_date='9999-99-99'
left join odata.sym_cif_client_contact_address t23  
on t1.client_no = t23.client_no  
and t23.contact_type = '02' --注册地址
and t23.data_date='${DATA_DATE}' 
and t23.bddw_end_date='9999-99-99'
--left join odata.sym_cif_client_contact_tbl t15
--on t1.client_no = t15.client_no 
--and t15.pref_flag='Y' --首选信息
--and t15.data_date='${DATA_DATE}'
--and t15.bddw_end_date='9999-99-99'
left join odata.sym_mb_acct t16 
on t1.client_no = t16.client_no 
and t16.acct_nature='4'    --基本户
and t16.data_date='${DATA_DATE}' 
and t16.bddw_end_date='9999-99-99'
left join odata.sym_cif_cross_relations t18 
on t1.client_no = t18.client_a 
and t18.data_date='${DATA_DATE}' 
and t18.bddw_end_date='9999-99-99'					--update llh 20231114 行业小类
left join odata.als_ent_info  t7
on t1.client_no=t7.customerid
and t7.data_date='${DATA_DATE}'
and t7.bddw_end_date='9999-99-99'
left join(select 
  business_scope			--经营范围
 ,actual_fund				--实收资本
 ,annual_income				--营业收入
 ,total_assets 				--总资产
 ,employee_number			--从业人数
 ,legal_person				--法定代表人名称
 ,legal_person_id_card		--法人身份证
 ,'101'		as	cert_type   --身份证类型
 ,tax_resident_flag			--税收身份
 ,registered_status			--经营状态
 ,registered_fund			--注册资本金额
 ,registered_currency		--注册资本币种代码
 ,regist_addr				--注册地址
 ,office_addr 				--办公地址/经营地址
 ,regist_area_code			--注册地区代码
 ,listed_company_type		--上市类型
 ,firm_size					--企业规模代码			
 ,control_type				--企业出资人经济成分代码
 ,create_date				--成立日期
 ,review_department			--国民经济部门代码
 ,business_license			--营业执照编码
 ,listed_company_flag		--是否上市标志
 ,economic_type				--所有制形式
 ,industry_involved 
 ,client_no
 ,bank_account
 ,bank_code
 ,bank_name
 from (select 
  t1.business_scope
 ,t1.actual_fund
 ,t1.annual_income
 ,t1.total_assets 
 ,t1.employee_number
 ,t1.legal_person				--法定代表人名称
 ,t1.legal_person_id_card		--法人身份证
 ,'101'		as	cert_type		--身份证类型
 ,t1.tax_resident_flag			--税收身份
 ,t1.registered_status			--经营状态
 ,t1.registered_fund			--注册资本金额
 ,t1.registered_currency		--注册资本币种代码
 ,concat(t1.company_address_code_desc,t1.company_address) as regist_addr    					--注册地址  
 ,concat(t1.business_operation_code_desc,t1.business_operation_address) as office_addr 			--办公地址/经营地址   
 ,substr(t1.company_address_code,-6) 									as regist_area_code		--注册地区代码
 ,t1.listed_company_type		--上市类型
 ,t1.firm_size					--企业规模代码			
 ,t1.control_type				--企业出资人经济成分代码
 ,substr(t1.registered_date,1,10) as create_date --成立日期
 ,t1.review_department			--国民经济部门代码
 ,t1.business_license			--营业执照编码
 ,t1.listed_company_flag		--是否上市标志
 ,t1.economic_type				--所有制形式
 ,substr(t1.industry_involved,-5)  as industry_involved 
 ,t2.client_no
 ,t3.bank_account
 ,t3.bank_code  
 ,t3.bank_name
 ,row_number()over(partition by t1.business_license order by t1.create_time desc ,t1.modified_time desc,t1.loan_id desc)  as rn
 from odata.order_company_info t1 
 inner join odata.sym_cif_client_document t2
 on t1.business_license = t2.document_id 
 and t2.document_type='231'   															--231 统一社会信用代码
 and t2.data_date = '${DATA_DATE}'
 and t2.bddw_end_date='9999-99-99'
 left join odata.order_company_info_ext t3 
 on t1.business_license = t3.business_license
 and t3.data_date = '${DATA_DATE}'
 and t3.bddw_end_date='9999-99-99'
 where t1.data_date = '${DATA_DATE}'
 and t1.bddw_end_date='9999-99-99') t
 where rn = 1)t36																		--updatapengqun 20240428
on t1.client_no = t36.client_no
left join odata.als_customer_relative t24 
on t1.client_no = t24.customerid 
and t24.relationship='0100'   --法人
and nvl(t24.operatetype,'')<>'03' --删除
and t24.effstatus = '1' --有效
and t24.data_date='${DATA_DATE}' 
and t24.bddw_end_date='9999-99-99'
left join
(
    select  
    customerid
    ,sum(businesssum) as businesssum
    from
    (
        --循环授信
        select a.customerid,
        a.customername,
        a.businesssum
        from odata.als_business_contract a
        where a.data_date = '${DATA_DATE}'
        and a.bddw_end_date = '9999-99-99'
        and a.businesstype like '30%'
        and a.status <> 'INVALID'
        --单笔授信
        union all
        select a.customerid,
        a.customername,
        a.businesssum
        from odata.als_business_contract a
        where a.data_date = '${DATA_DATE}'
        and a.bddw_end_date = '9999-99-99'
        and a.applytype = 'EntSingleApply'
        and a.status = 'EFFECTIVE'
    ) as a1
    group by a1.customerid
)t8
on t1.client_no = t8.customerid
left join
(
    select customerid,sum(businesssum) as businesssum
    from
    (
        --(不含供应链)提取授信(30的授信)已经过期但是还有贷款余额的
        select a.customerid,
        a.businesssum
        from odata.als_business_contract a
        where a.data_date = '${DATA_DATE}'
        and a.bddw_end_date = '9999-99-99'
        and a.businesstype like '30%'
        and a.businesstype <> '3050020'
        and a.status = 'INVALID'
        and exists(select 1
        from odata.als_business_duebill b
        left join odata.als_business_contract c
        on b.relativeserialno2 = c.serialno
        and c.data_date = '${DATA_DATE}'
        and c.bddw_end_date = '9999-99-99'
        where b.data_date = '${DATA_DATE}'
        and b.bddw_end_date = '9999-99-99'
        and b.businesstype not in ('1020010','2010')
        and c.relativeserialno is not null
        and b.balance > 0
        and a.relativeserialno = c.relativeserialno)
        union all
        --(供应链单独处理)提取授信(3050020的授信)已经过期但是还有贷款余额的
        select a.customerid,
        a.businesssum
        from odata.als_business_contract a
        left join odata.als_cl_occupy d
        on a.serialno = d.relativeserialno
        and d.data_date = '${DATA_DATE}'
        and d.bddw_end_date = '9999-99-99'
        where a.data_date = '${DATA_DATE}'
        and a.bddw_end_date = '9999-99-99'
        and a.businesstype = '3050020'
        and a.status = 'INVALID'
        and exists(select 1
        from odata.als_business_duebill b
        where b.data_date = '${DATA_DATE}'
        and b.bddw_end_date = '9999-99-99'
        and b.businesstype not in ('1020010','2010')
        and b.balance > 0
        and d.objectno = b.relativeserialno2)
    ) as a2
    group by a2.customerid
)t81
on t1.client_no = t81.customerid
left join 
(
    select customerid,sum(businesssum) as businesssum 
    from 
    (
        select  t2.client_no as  customerid
        ,t6.total_amount_prev as businesssum 
        from odata.als_business_duebill t1
        inner join odata.sym_mb_acct t2
        on t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
        and t1.serialno = t2.cmisloan_no
        and t2.lead_acct_flag = 'N'
        and t2.source_module = 'CL'  --贷款
        left join odata.sym_mb_acct_balance t6
        on t6.data_date='${DATA_DATE}'
        and t6.bddw_end_date='9999-99-99'
        and t2.internal_key = t6.internal_key
        and t6.amt_type='BAL'
        where t1.data_date='${DATA_DATE}'
        and t1.bddw_end_date='9999-99-99'
        and t1.businesstype not in ('1020010','2010') --剔除贴现
        and regexp_replace(t1.putoutdate,'/','-') <= '${DATA_DATE}'
        union all 
        select t1.customerid,t5.loan_bal 
        from odata.als_business_duebill t1
        left join odata.supacct_enterprise_loan_info t6
        on t6.data_date='${DATA_DATE}'
        and t6.bddw_end_date='9999-99-99'
        and t1.serialno = t6.iou_no
        and t6.reversal_flag = '00'  --冲正标志
        inner join odata.slur_jcb_loan_info_final t5
        on t5.data_date='${DATA_DATE}'
        and t5.bddw_end_date='9999-99-99'
        and t6.partner_loan_no=t5.loan_no
        where t1.data_date='${DATA_DATE}'
        and t1.bddw_end_date='9999-99-99'
    ) as a3
    group by a3.customerid
)t27 
on t1.client_no=t27.customerid 
left join(select * from
                      (select t28.all_licence_code                           as all_licence_code  --组织机构代码
                              ,row_number()over(partition by t28.all_licence_code order by t28.commit_time desc)  as rn  
                              ,t29.category_type                             as category_type     --客户分类
                         from odata.uc_um_uia_enter_status t28
                         left join odata.uc_um_enter_client t29
                           on t28.uia_status_id = t29.uia_status_id 
                           and t29.data_date = '${DATA_DATE}'
                           and t29.bddw_end_date = '9999-99-99'
                         where t28.data_date = '${DATA_DATE}' 
                           and t28.bddw_end_date = '9999-99-99'
                           and t28.uia_status = '3')t30    --3:审批通过
                         where t30.rn=1)t30
  on t6.document_id = t30.all_licence_code
left join odata.supwall_scp_enterprise_cust_info t33 
  on t33.social_credit_code = t6.document_id
  and t33.data_date='${DATA_DATE}'
  and t33.bddw_end_date='9999-99-99'
  and t33.status = '10' --有效
left join odata.supwall_scp_enterprise_cust_info t37  --客户信息表
  on t1.client_no = t37.cust_id 
  and t37.data_date  = '${DATA_DATE}'
  and t37.bddw_end_date='9999-99-99'
  and t37.status = '10' --有效   --20240415 新增
left join (
           select client_no
		          ,contact_tel
				  ,row_number() over(partition by client_no order by iss_date desc ) rn
	       from odata.sym_cif_client_contacts_info t38 --关联人信息表
		   where t38.people_type='100' --法人或负责人
           and t38.data_date  = '${DATA_DATE}'
           and t38.bddw_end_date='9999-99-99'
          ) t38
  on t1.client_no=t38.client_no
  and t38.rn=1
where t1.data_date='${DATA_DATE}' 
  and t1.bddw_end_date='9999-99-99' 
  and t1.client_type in ('02', '04','05','09')  --02公司，04内部，05政府，09其他