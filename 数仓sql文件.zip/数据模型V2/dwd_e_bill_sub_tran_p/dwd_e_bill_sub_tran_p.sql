--2.gaoyuan.dwd.dwd_e_bill_sub_tran_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：票据类资产穿透流水表.sql
--功能描述：生成每日结果数据并插入hive dwd层 dwd_e_bill_sub_tran_p 分区表
--作    者：高源
--开发日期：2023-03-30
--直属经理：颜华
--来源表  ：odata.nbms_bms_trade_detail       --记账分录表
--来源表  ：odata.nbms_cpes_quote_contract    --对话报价协议表
--来源表  ：odata.nbms_cpes_quote_details     --对话报价明细表
--来源表  ：odata.nbms_cpes_quote_due         --对话报价到期表
--来源表  ：odata.nbms_bms_customer_info      --客户信息表
--目标表  ：dwd.dwd_d_repo_cont_p
--修改历史：
--                1.高源   2023-03-30    新建
--                2.高源   2023-12-14    新增到期结算金额，交易对手行号逻辑调整
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_bill_sub_tran_p partition(data_date = '${DATA_DATE}')  
  select  /*+ REPARTITION(1) */
               nvl(t1.trade_detail_id  ,'')    as  tran_seqno          --交易流水号
               ,nvl(t3.contract_no     ,'')    as  deal_id             --业务编码
               ,'100000'                       as  org_id              --机构号
               ,nvl(t1.draft_number    ,'')    as  asset_code          --资产编号
               ,nvl(t1.cd_range       ,'-')    as  sub_asset_code      --次资产编码
               ,'CNY'                          as  ccy                 --币种
               ,nvl(t1.sub_no          ,'')    as  subj_no             --科目
               ,nvl(t1.dr_cr           ,'')    as  debit_flag          --交易方向
               ,nvl(from_unixtime(unix_timestamp(t3.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')    as  tran_date           --交易日期
               ,nvl(t2.settle_amt       ,0)    as  tran_amt            --交易金额
               ,nvl(t3.cust_no         ,'')    as  tran_party_id       --交易对手号
               ,coalesce(t4.cust_name,t3.cust_name ,'')    as  tran_party_name     --交易对手名称
               ,coalesce(t3.cust_bank_no,tm.ubank_no,'')   as  counter_bank_code   --交易对手行号
			   ,nvl(t2.due_settle_amt  ,0 )    as  mature_settle_amt   --到期结算金额
          from odata.nbms_bms_trade_detail t1
     left join odata.nbms_cpes_quote_details  t2
            on t1.detail_id = t2.id
           and t2.data_date = '${DATA_DATE}'
           and t2.bddw_end_date='9999-99-99'
     left join odata.nbms_cpes_quote_contract t3
            on t2.contract_id=t3.id
           and t3.data_date = '${DATA_DATE}'
           and t3.bddw_end_date='9999-99-99'
           and t3.trade_direct in ('CRD01','CRD02')
           and t3.busi_type in ('BT02','BT03')
           and t3.account_status = '02'
	 left join odata.nbms_ces_quote_deal td
            on t3.deal_id=td.dealed_no
           and td.data_date='${DATA_DATE}' 
           and td.bddw_end_date='9999-99-99'
      left join odata.nbms_mem_brh_info tm 
            on td.adver_brh_no = tm.brh_no
           and tm.data_date = '${DATA_DATE}'
           and tm.bddw_end_date = '9999-99-99' 
     left join odata.nbms_bms_customer_info t4
            on t3.cust_no = t4.cust_no
           and t4.data_date = '${DATA_DATE}'
           and t4.bddw_end_date = '9999-99-99'
           and t4.cust_type='2'
         where t1.data_date = '${DATA_DATE}'
           and t1.bddw_end_date='9999-99-99'
           and t1.sub_no in ('10200201','10200203','20200201')  
           and t1.protocol_no like 'QUOT%'          --票据回购发生协议号
         union all
  select  /*+ REPARTITION(1) */
               nvl(t1.trade_detail_id  ,'')    as  tran_seqno          --交易流水号
               ,nvl(t3.contract_no     ,'')    as  deal_id             --业务编码
               ,'100000'                       as  org_id              --机构号
               ,nvl(t1.draft_number    ,'')    as  asset_code          --资产编号
               ,nvl(t1.cd_range       ,'-')    as  sub_asset_code      --次资产编码
               ,'CNY'                          as  ccy                 --币种
               ,nvl(t1.sub_no          ,'')    as  subj_no             --科目
               ,nvl(t1.dr_cr           ,'')    as  debit_flag          --交易方向
               ,nvl(from_unixtime(unix_timestamp(t.busi_date,'yyyyMMdd'),'yyyy-MM-dd'),'')    as  tran_date           --交易日期
               ,nvl(t2.due_settle_amt   ,0)    as  tran_amt            --交易金额
               ,nvl(t3.cust_no         ,'')    as  tran_party_id       --交易对手号
               ,coalesce(t4.cust_name,t3.cust_name ,'')    as  tran_party_name     --交易对手名称
               ,coalesce(t3.cust_bank_no,tm.ubank_no,'')   as  counter_bank_code   --交易对手行号
			   ,nvl(t2.due_settle_amt  ,0 )    as  mature_settle_amt   --到期结算金额
          from odata.nbms_bms_trade_detail t1
     left join odata.nbms_cpes_quote_due t     
            on t1.protocol_no = t.contract_no
           and t.data_date = '${DATA_DATE}'
           and t.bddw_end_date='9999-99-99'
     left join odata.nbms_cpes_quote_details  t2
            on t1.detail_id = t2.id
           and t2.data_date = '${DATA_DATE}'
           and t2.bddw_end_date='9999-99-99'
     left join odata.nbms_cpes_quote_contract t3
            on t2.contract_id=t3.id
           and t3.data_date = '${DATA_DATE}'
           and t3.bddw_end_date='9999-99-99'
           and t3.trade_direct   in  ('CRD01','CRD02')
           and t3.busi_type in ('BT02','BT03')
           and t3.account_status = '02'
	 left join odata.nbms_ces_quote_deal td
            on t3.deal_id=td.dealed_no
           and td.data_date='${DATA_DATE}' 
           and td.bddw_end_date='9999-99-99'
      left join odata.nbms_mem_brh_info tm 
            on td.adver_brh_no = tm.brh_no
           and tm.data_date = '${DATA_DATE}'
           and tm.bddw_end_date = '9999-99-99' 
     left join odata.nbms_bms_customer_info t4
            on t3.cust_no = t4.cust_no
           and t4.data_date = '${DATA_DATE}'
           and t4.bddw_end_date = '9999-99-99'
         where t1.data_date = '${DATA_DATE}'
           and t1.bddw_end_date='9999-99-99'
           and t1.sub_no in ('10200201','10200203','20200201')  
           and t1.protocol_no  like 'DUE%'          --票据回购到期协议号