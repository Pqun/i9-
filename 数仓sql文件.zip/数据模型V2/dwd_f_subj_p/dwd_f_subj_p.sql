---------------------------------------------------------------------------------------------------------------
--脚本名称：科目表加工逻辑.sql
--功能描述：生成每日结果数据并插入hive gdata层dwd.dwd_f_subj_p
--作    者：吴龙昊
--开发日期：2021-02-09
--直属经理：程宏明
--来源表  ：odata.gl_v_gl_subject
--目标表  ：dwd.dwd_f_subj_p         科目表
--修改历史：
--          1.吴龙昊   2021-02-09    新建

---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_f_subj_p partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
 t1.gl_code             as subj_no                 --科目号   
,t1.gl_code_name        as subj_name               --科目名称  
,t1.gl_level            as subj_lvl                --科目级别  
,t1.upper_gl_code       as up_subj_no              --上级科目号 
,t1.bspl_type           as subj_type               --科目类型  
,t1.bspl_name           as subj_type_name          --科目类型名称
,t1.balance_dir         as bal_debit_crdt_direct   --余额借贷方向
,t1.outflag             as is_out_subj             --是否表外科目
,null                   as remark1                 --备用字段1 
,null                   as remark2                 --备用字段2 
,null                   as remark3                 --备用字段3 
,null                   as remark4                 --备用字段4 
,null                   as remark5                 --备用字段5 
from odata.gl_v_gl_subject t1
where t1.data_date = '${DATA_DATE}'
and t1.bddw_end_date = '9999-99-99'