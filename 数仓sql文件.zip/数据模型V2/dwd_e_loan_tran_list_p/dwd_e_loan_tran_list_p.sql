--2.yangqihao.dwd_e_loan_tran_list_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：dwd贷款交易流水表加工.sql
--功能描述：生成每日结果数据并插入hive gdata层dwd.dwd_e_loan_tran_list_p
--作    者：华天顺
--开发日期：2022-10-17
--直属经理：方杰
--来源表  ：odata.sym_mb_tran_hist              --金融交易流水表
--来源表  ：odata.sym_mb_acct                   --账户基本信息表
--来源表  ：odata.sym_gl_prod_accounting        --产品科目表
--来源表  ：odata.sllv_nl_tran_hist             --线上贷款账户交易流水表
--来源表  ：odata.sllv_nl_acct                  --线上贷款账户基本信息表
--来源表  ：odata.slur_xm_loan_file             --小米日初借据信息表
--来源表  ：odata.slur_xm_repay_file            --小米还款借据文件
--来源表  ：odata.ols_loan_cont_info            --支用合同信息表
--来源表  ：odata.ols_bat_jd_flow_jt_his        --(jt)京东账务文件明细_贷款还款明细信息_落地表
--来源表  ：odata.slur_dxm_loan_file            --度小满借据文件表
--来源表  ：odata.slur_dxm_repay_file           --度小满回收文件表
--来源表  ：odata.slur_dzz_loan_file            --百度债转借据文件表
--来源表  ：odata.slur_dzz_repay_file           --百度债转回收文件表
--来源表  ：odata.slur_bdvc_loan_file           --百度虚拟卡借据文件表
--来源表  ：odata.slur_bdvc_repay_file          --百度虚拟卡回收文件表
--来源表  ：odata.slur_bdzz_loan_detail         --百度周转贷放款明细文件表
--来源表  ：odata.slur_bdzz_repay_file          --百度周转贷回收文件表
--来源表  ：odata.slur_acc_loan_detail          --放款信息表
--来源表  ：odata.slur_acc_repay_detail         --还款明细
--来源表  ：odata.order_custom_info             --客户信息表
--来源表  ：odata.sym_cif_client_document       --客户证件信息
--来源表  ：odata.slur_bdul_open_file           --百度联合贷放款明细表
--来源表  ：odata.slur_bdul_repay_file          --百度联合贷借据还款信息文件表
--来源表  ：odata.slur_jcb_loan                 --金城放款明细表
--来源表  ：odata.slur_jcb_repay_detail         --金城网贷还款明细表
--来源表  ：odata.supacct_enterprise_loan_info  --贷款信息表
--来源表  ：odata.als_business_duebill          --业务借据(账户)信息表
--目标表  ：dwd.dwd_e_loan_tran_list_p
--修改历史：
--          1.华天顺 2022-10-17 新建
--          2.华天顺 2022-10-28 小米回收表取交易日期字段格式转换
--          3.华天顺 2022-11-03 新增清分标志字段
--          4.华天顺 2022-12-05 新增核算状态字段,交易时间逻辑调整
--          5.华天顺 2023-01-09 百度周转贷剔除状态为放款中借据
--          6.华天顺 2023-02-15 京东回收取数从网贷改为从核算取
--          6.华天顺 2023-02-20 给锡锡贷加上清分标志
--          7.杨琦浩 2023-08-25 新增授权柜员号、现转标志字段
--          8.于国睿 2023-10-24 虚拟卡和债转停批，大于等于2023-09-21的日期写死
--          9.彭群   2023-10-31 联合贷交易时间逻辑调整
--          10.杨琦浩 2023-11-10 新增交易后余额字段
--          11.杨琦浩 2023-11-30 新增实际交易日期
--          12.杨琦浩 2023-12-11 联合贷部分冲正日期逻辑调整
--          13.姚威   2024-01-09 新增摘要，交易附言，交易描述字段
--          14.杨琦浩 2024-04-15 修改交易后余额取数逻辑，新增字节产品
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_loan_tran_list_p partition(data_date='${DATA_DATE}')
--------------------------------------------------核心------------------------------------------------
             select  /*+ REPARTITION(20) */
                     t1.seq_no                                                                                                   as tran_seqno           --交易流水号
                    ,t1.reference                                                                                                as sub_tran_seqno       --子交易流水号
                    ,t1.base_acct_no                                                                                             as acct_no              --贷款账户
                    ,t2.client_no                                                                                                as cust_id              --客户号
                    ,t2.client_type                                                                                              as cust_type            --客户类型
                    ,t2.cmisloan_no                                                                                              as bill_no              --借据号
                    ,from_unixtime(unix_timestamp(t1.tran_date,'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd')                              as tran_date            --交易日期
                    ,concat(substr(t1.tran_timestamp,9,2),':',substr(t1.tran_timestamp,11,2),':',substr(t1.tran_timestamp,13,2)) as tran_time            --交易时间
                    ,t1.tran_type                                                                                                as tran_type            --交易类型
                    ,t1.tran_status                                                                                              as tran_status          --交易状态
                    ,t1.cr_dr_maint_ind                                                                                          as debit_flag           --借贷标志
                    ,t1.ccy                                                                                                      as ccy                  --币种
                    ,t1.tran_amt                                                                                                 as tran_amt             --交易金额
                    ,t1.amt_type                                                                                                 as amt_type             --金额类型
                    ,t1.source_type                                                                                              as tran_chan            --交易渠道
                    ,t1.reversal                                                                                                 as corr_flag            --冲正标志
                    ,nvl(t1.reversal_tran_type,'')                                                                               as corr_tran_type       --冲正交易类型
                    ,nvl(from_unixtime(unix_timestamp(t1.reversal_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                             as corr_date            --冲正日期
                    ,coalesce(t1.user_id,'')                                                                                     as tran_tlr_no          --交易柜员号
                    ,t1.prod_type                                                                                                as prod_code            --产品号
                    ,t3.gl_code_a                                                                                                as subj_no              --科目号
                    ,t2.acct_seq_no                                                                                              as acct_seq_no          --账户序列号
                    ,'sym'                                                                                                       as source_system        --来源系统
                    ,t1.reference                                                                                                as reference            --交易参考号
                    ,'0'                                                                                                         as clear_flag           --清分还款标志
                    ,t1.accounting_status                                                                                        as accting_status       --核算状态
                    ,coalesce(t1.auth_user_id,'')                                                                                as crdt_tlr_no          --授权柜员号
                    ,case when t4.cash_tran='Y' then '01' else '02' end                                                          as cash_tran_flag       --现转标志
                    ,nvl(t5.tran_bal,0)                                                                                          as tran_bal             --交易后余额
                    ,from_unixtime(unix_timestamp(substr(t1.tran_timestamp,1,8),'yyyyMMdd'),'yyyy-MM-dd')                        as actual_tran_date     --实际交易日期
                    ,nvl(t1.narrative,'')                                                                                        as abst                 -- 摘要
                    ,nvl(t1.tran_note,'')                                                                                        as tran_note            --交易附言
                    ,nvl(t1.tran_desc,'')                                                                                        as tran_desc            --交易描述
              from  odata.sym_mb_tran_hist t1
        inner join  odata.sym_mb_acct t2
                on  t1.internal_key = t2.internal_key
               and  t2.data_date='${DATA_DATE}'
               and  t2.bddw_end_date='9999-99-99'
               and  t2.lead_acct_flag = 'N'
         left join  odata.sym_gl_prod_accounting t3  --通过科目号来取消费还是经营
                on  t3.data_date='${DATA_DATE}'
               and  t3.bddw_end_date='9999-99-99'
               and  t1.prod_type = t3.prod_type
               and  t3.accounting_status = 'ZHC'
               and  t3.tran_category = 'ALL'
         left join odata.sym_mb_tran_def t4 
                on  t1.tran_type=t4.tran_type
               and  t4.data_date='${DATA_DATE}'
               and  t4.bddw_end_date='9999-99-99'
         left join (
		            select seq_no
                           ,internal_key
                           ,tran_type
                           ,tran_amt
                           ,amt_type
                           ,tran_timestamp
                           ,rn_2-rn_1 as tran_bal
                          from (
                                select seq_no 
                                       ,internal_key
                                       ,tran_type
                                       ,tran_amt
                                       ,amt_type
                                       ,tran_timestamp
                                       ,sum(case when tran_type in('REC1','REC3') and tran_status='N' 
                                                 then tran_amt 
                                                 else 0 
                                             end) over(partition by internal_key order by tran_timestamp,seq_no) rn_1
                                       ,max(case when tran_type='DRW1' and tran_status='N' 
                                                 then tran_amt 
                                                 else 0 
                                            end) over(partition by internal_key order by tran_timestamp,seq_no) rn_2
                                from odata.sym_mb_tran_hist
                                where data_date='${DATA_DATE}'
                                and bddw_end_date='9999-99-99'
                                and amt_type in ('OSL','PRD','GRACE_PRD','PRI')
                                and (substr(tran_type,1,3)='REC' or tran_type='DRW1')
                                )
		           ) t5
                on t1.seq_no=t5.seq_no
			   and t1.internal_key=t5.internal_key
             where t1.data_date='${DATA_DATE}'
               and t1.bddw_end_date='9999-99-99'
               and t2.source_module = 'CL' -- 贷款
-----------------------------------------------------------核算-----------------------------------------------------------
union all
             select  /*+ REPARTITION(30) */
                     t1.seq_no                                                                                                      as tran_seqno           --交易流水号
                    ,t1.reference                                                                                                   as sub_tran_seqno       --子交易流水号
                    ,t1.base_acct_no                                                                                                as acct_no              --贷款账户
                    ,t2.client_no                                                                                                   as cust_id              --客户号
                    ,t2.client_type                                                                                                 as cust_type            --客户类型
                    ,t2.cmisloan_no                                                                                                 as bill_no              --借据号
                    ,from_unixtime(unix_timestamp(t1.tran_date,'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd')                                 as tran_date            --交易日期
                    ,concat(substr(t1.tran_timestamp,9,2),':',substr(t1.tran_timestamp,11,2),':',substr(t1.tran_timestamp,13,2))    as tran_time            --交易时间
                    ,t1.tran_type                                                                                                   as tran_type            --交易类型
                    --,t1.tran_status                                                                                                 as tran_status          --交易状态
                    ,case when t1.reversal='Y' then 'X' else t1.tran_status end                                                     as tran_status          --交易状态
                    ,t1.cr_dr_maint_ind                                                                                             as debit_flag           --借贷标志
                    ,t1.ccy                                                                                                         as ccy                  --币种
                    ,t1.tran_amt                                                                                                    as tran_amt             --交易金额
                    ,t1.amt_type                                                                                                    as amt_type             --金额类型
                    ,t1.source_type                                                                                                 as tran_chan            --交易渠道
                    ,t1.reversal                                                                                                    as corr_flag            --冲正标志
                    ,nvl(t1.reversal_tran_type,'')                                                                                  as corr_tran_type       --冲正交易类型
                    ,nvl(from_unixtime(unix_timestamp(t1.reversal_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                                as corr_date            --冲正日期
                    ,coalesce(t1.user_id,'')                                                                                        as tran_tlr_no          --交易柜员号
                    ,t1.prod_type                                                                                                   as prod_code            --产品号
                    ,t3.gl_code_a                                                                                                   as subj_no              --科目号
                    ,t2.acct_seq_no                                                                                                 as acct_seq_no          --账户序列号
                    ,'sllv'                                                                                                         as source_system        --来源系统
                    ,t1.reference                                                                                                   as reference            --交易参考号
                    ,case when t4.loan_no is not null and from_unixtime(unix_timestamp(t1.tran_date,'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd')>substr(t4.tran_date,1,10) 
                          then '1' 
                          else '0' 
                      end                                                                                                           as clear_flag           --清分还款标志
                    ,t1.accounting_status                                                                                           as accting_status       --核算状态
                    ,coalesce(t1.auth_user_id,'')                                                                                   as crdt_tlr_no          --授权柜员号
                    ,'02'                                                                                                           as cash_tran_flag       --现转标志
                    ,nvl(t5.tran_bal,0)                                                                                             as tran_bal             --交易后余额
                    ,from_unixtime(unix_timestamp(substr(t1.tran_timestamp,1,8),'yyyyMMdd'),'yyyy-MM-dd')                           as actual_tran_date     --实际交易日期
                    ,nvl(t1.narrative,'')                                                                                           as abst                 -- 摘要
                    ,nvl(t1.tran_note,'')                                                                                           as tran_note            --交易附言
                    ,nvl(t1.tran_desc,'')                                                                                           as tran_desc            --交易描述
              from  odata.sllv_mb_tran_hist t1
        inner join  odata.sllv_mb_acct t2
                on  t1.internal_key = t2.internal_key
               and  t2.data_date='${DATA_DATE}'
               and  t2.bddw_end_date='9999-99-99'
         left join  odata.sym_gl_prod_accounting t3  --通过科目号来取消费还是经营
                on  t3.data_date='${DATA_DATE}'
               and  t3.bddw_end_date='9999-99-99'
               and  t1.prod_type = t3.prod_type
               and  t3.accounting_status = 'ZHC'
               and  t3.tran_category = 'ALL'
         left join  odata.slur_acc_writeoff_detail t4
                on  t2.cmisloan_no = t4.loan_no 
               and  t4.status = 'S'
               and  t4.data_date='${DATA_DATE}'
               and  t4.bddw_end_date='9999-99-99'
         left join (
		            select seq_no
                           ,internal_key
                           ,tran_type
                           ,tran_amt
                           ,amt_type
                           ,tran_timestamp
                           ,rn_2-rn_1 as tran_bal
                          from (
                                select seq_no 
                                       ,internal_key
                                       ,tran_type
                                       ,tran_amt
                                       ,amt_type
                                       ,tran_timestamp
                                       ,sum(case when tran_type in('REC1','REC3') and tran_status='N' 
                                                 then tran_amt 
                                                 else 0 
                                             end) over(partition by internal_key order by tran_timestamp,seq_no) rn_1
                                       ,max(case when tran_type='DRW1' and tran_status='N' 
                                                 then tran_amt 
                                                 else 0 
                                            end) over(partition by internal_key order by tran_timestamp,seq_no) rn_2
                                from odata.sllv_mb_tran_hist
                                where data_date='${DATA_DATE}'
                                and bddw_end_date='9999-99-99'
                                and amt_type in ('OSL','PRD','GRACE_PRD','PRI')
                                and (substr(tran_type,1,3)='REC' or tran_type='DRW1')
                                )
		           ) t5
                on t1.seq_no=t5.seq_no
			   and t1.internal_key=t5.internal_key
             where  t1.data_date='${DATA_DATE}'
               and  t1.bddw_end_date='9999-99-99'
               and  t2.source_module = 'CL' -- 贷款
------------------------------------------------------核算联合贷----------------------------------------------------------------
union all
             select  /*+ REPARTITION(10) */
                     t1.seq_no                                                                                                    as tran_seqno           --交易流水号
                    ,t1.reference                                                                                                 as sub_tran_seqno       --子交易流水号
                    ,t1.base_acct_no                                                                                              as acct_no              --贷款账户
                    ,t2.client_no                                                                                                 as cust_id              --客户号
                    ,t2.client_type                                                                                               as cust_type            --客户类型
                    ,t2.cmisloan_no                                                                                               as bill_no              --借据号
                    ,from_unixtime(unix_timestamp(t1.tran_date,'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd')                               as tran_date            --交易日期
                    ,nvl(substr(case when length(t1.tran_timestamp) = 9 then from_unixtime(cast(t1.tran_timestamp as int),'yyyyMMdd HH:mm:ss')
                                 else t1.tran_timestamp end,10,8),'')                                                             as tran_time   --交易时间20231031update             
                    ,t1.tran_type                                                                                                 as tran_type            --交易类型
                    ,case when (t1.reversal='Y' or t1.reversal_date is not null or t1.reversal_seq_no is not null ) then 'X' else 'N' end                            
                                                                                                                                  as tran_status          --交易状态
                    ,nvl(t1.cr_dr_maint_ind,'')                                                                                   as debit_flag           --借贷标志(核算状态变更类交易无借贷方向)
                    ,t1.ccy                                                                                                       as ccy                  --币种
                    ,t1.tran_amt                                                                                                  as tran_amt             --交易金额
                    ,t1.amt_type                                                                                                  as amt_type             --金额类型
                    ,t1.source_type                                                                                               as tran_chan            --交易渠道
                    ,t1.reversal                                                                                                  as corr_flag            --冲正标志
                    ,nvl(t1.reversal_tran_type,'')                                                                                as corr_tran_type       --冲正交易类型
                    ,nvl(substr(t1.reversal_date,1,10),'')                                                                        as corr_date            --冲正日期
                    ,coalesce(t1.user_id,'')                                                                                      as tran_tlr_no          --交易柜员号
                    ,t1.prod_type                                                                                                 as prod_code            --产品号
                    ,t3.gl_code_a                                                                                                 as subj_no              --科目号
                    ,t2.acct_seq_no                                                                                               as acct_seq_no          --账户序列号
                    ,'sllv'                                                                                                       as source_system        --来源系统
                    ,t1.reference                                                                                                 as reference            --交易参考号
                    ,'0'                                                                                                          as clear_flag           --清分还款标志
                    ,t1.accounting_status                                                                                         as accting_status       --核算状态
                    ,coalesce(t1.auth_user_id,'')                                                                                 as crdt_tlr_no          --授权柜员号
                    ,'02'                                                                                                         as cash_tran_flag       --现转标志
                    ,case when t1.tran_type='ZZ02' then 0 --债转
                          when t1.tran_type in('LWRE','LWDR') then coalesce(t6.tran_bal_own,t5.tran_bal_own,0)
                          when t1.tran_type in('LWHB','LWFB') then coalesce(t6.tran_bal_par,t5.tran_bal_par,0)
                          else 0 
                     end as tran_bal             --交易后余额
                    ,from_unixtime(unix_timestamp(t1.tran_date,'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd')                               as actual_tran_date     --实际交易日期
                    ,nvl(t1.narrative,'')                                                                                         as abst                 -- 摘要
                    ,''                                                                                                           as tran_note            --交易附言
                    ,''                                                                                                           as tran_desc         
               from (
                   select *
                          ,row_number() over(partition by internal_key,tran_date,tran_type,amt_type order by seq_no) rn
                   from odata.sllv_nl_tran_hist
                   where data_date='${DATA_DATE}'
                   and bddw_end_date='9999-99-99'
                   ) t1
        inner join  odata.sllv_nl_acct t2
                on  t1.internal_key = t2.internal_key
               and  t2.data_date='${DATA_DATE}'
               and  t2.bddw_end_date='9999-99-99'
         left join  odata.sym_gl_prod_accounting t3  --通过科目号来取消费还是经营
                on  t3.data_date='${DATA_DATE}'
               and  t3.bddw_end_date='9999-99-99'
               and  t1.prod_type = t3.prod_type
               and  t3.accounting_status = 'ZHC'
               and  t3.tran_category = 'ALL'
         left join (
                    select seq_no
                           ,internal_key
                           ,tran_type
                           ,tran_amt
                           ,amt_type
                           ,tran_date
                           ,rn_1-rn_3 as tran_bal_own
                           ,rn_2-rn_4 as tran_bal_par
                          from (
                                select seq_no 
                                       ,internal_key
                                       ,tran_type
                                       ,tran_amt
                                       ,amt_type
                                       ,tran_date
                                       ,max(case when tran_type in('LWDR') and (reversal='N' and nvl(reversal_date,'')='')
                                                 then tran_amt 
                                                 else 0 
                                             end) over(partition by internal_key order by tran_date,seq_no) rn_1
                                       ,max(case when tran_type in('LWFB') and (reversal='N' and nvl(reversal_date,'')='')
                                                 then tran_amt 
                                                 else 0 
                                             end) over(partition by internal_key order by tran_date,seq_no) rn_2
                                       ,sum(case when tran_type='LWRE' and (reversal='N' and nvl(reversal_date,'')='')
                                                 then tran_amt 
                                                 else 0 
                                            end) over(partition by internal_key order by tran_date,seq_no) rn_3
                                       ,sum(case when tran_type='LWHB' and (reversal='N' and nvl(reversal_date,'')='')
                                                 then tran_amt 
                                                 else 0 
                                            end) over(partition by internal_key order by tran_date,seq_no) rn_4
                                from odata.sllv_nl_tran_hist
                                where data_date='${DATA_DATE}'
                                and bddw_end_date='9999-99-99'
                                and amt_type in ('OSL','PRD','GRACE_PRD','PRI')
                                and  tran_type in('LWRE','LWHB','LWDR','LWFB')
                                )
                    ) t5 
             on t1.seq_no = t5.seq_no
left join (select seq_no 
       ,0 as tran_bal_own
       ,tran_bal_zz-rn as tran_bal_par
from (
select b.seq_no 
       ,a.tran_bal_own
       ,a.tran_bal_par
       ,a.tran_bal_zz 
       ,sum(case when c.tran_type='LWHB'
                            then c.tran_amt 
                            else 0 
                       end) over(partition by c.internal_key order by c.tran_date,c.seq_no) rn
from
(select seq_no
                           ,internal_key
                           ,tran_type
                           ,tran_amt
                           ,amt_type
                           ,tran_date
                           ,rn_1-rn_3 as tran_bal_own
                           ,rn_2-rn_4 as tran_bal_par
                           ,case when tran_type='ZZ02' then rn_1-rn_3+rn_2-rn_4 
                                 else 0 end tran_bal_zz
                          from (
                                select seq_no 
                                       ,internal_key
                                       ,tran_type
                                       ,tran_amt
                                       ,amt_type
                                       ,tran_date
                                       ,max(case when tran_type in('LWDR') and (reversal='N' and nvl(reversal_date,'')='')
                                                 then tran_amt 
                                                 else 0 
                                             end) over(partition by internal_key order by tran_date,seq_no) rn_1
                                       ,max(case when tran_type in('LWFB') and (reversal='N' and nvl(reversal_date,'')='')
                                                 then tran_amt 
                                                 else 0 
                                             end) over(partition by internal_key order by tran_date,seq_no) rn_2
                                       ,sum(case when tran_type='LWRE' and (reversal='N' and nvl(reversal_date,'')='')
                                                 then tran_amt 
                                                 else 0 
                                            end) over(partition by internal_key order by tran_date,seq_no) rn_3
                                       ,sum(case when tran_type='LWHB' and (reversal='N' and nvl(reversal_date,'')='')
                                                 then tran_amt 
                                                 else 0 
                                            end) over(partition by internal_key order by tran_date,seq_no) rn_4
                                from odata.sllv_nl_tran_hist
                                where data_date='${DATA_DATE}'
                                and bddw_end_date='9999-99-99'
                                and amt_type in ('OSL','PRD','GRACE_PRD','PRI')
                                and  tran_type in('ZZ02','LWRE','LWHB','LWDR','LWFB')
                                ) t1 where t1.tran_type='ZZ02') a
left join  odata.sllv_nl_tran_hist b 
on a.internal_key=b.internal_key
and  b.data_date='${DATA_DATE}'
and b.bddw_end_date='9999-99-99'
left join odata.sllv_nl_tran_hist c
on b.seq_no=c.seq_no
and c.data_date='${DATA_DATE}'
and c.bddw_end_date='9999-99-99'
and c.amt_type in ('OSL','PRD','GRACE_PRD','PRI')
and c.tran_type in('LWRE','LWHB','LWDR','LWFB')
where  b.amt_type in ('OSL','PRD','GRACE_PRD','PRI')
and  b.tran_type in('LWRE','LWHB','LWDR','LWFB')
and a.seq_no<b.seq_no
)) t6
on t1.seq_no=t6.seq_no
--------------------------------------------------小米（行外产品暂时金额类型都按未到期的来（OSL,INT,ODP），退款，撤销，冲销，冲正都算冲正）---------
union all
             select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                                       as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                                   as sub_tran_seqno       --子交易流水号
                    ,''                                                                                  as acct_no              --贷款账户
                    ,t2.cust_id_core                                                                     as cust_id              --客户号
                    ,'01'                                                                                as cust_type            --客户类型
                    ,t1.bill_no                                                                          as bill_no              --借据号
                    ,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd')                 as tran_date            --交易日期
                    ,'00:00:00'                                                                          as tran_time            --交易时间
                    ,t1.tran_type                                                                        as tran_type            --交易类型
                    ,'N'                                                                                 as tran_status          --交易状态
                    ,t1.debit_flag                                                                       as debit_flag           --借贷标志
                    ,'CNY'                                                                               as ccy                  --币种
                    ,t1.tran_amt                                                                         as tran_amt             --交易金额
                    ,t1.amt_type                                                                         as amt_type             --金额类型
                    ,''                                                                                  as tran_chan            --交易渠道
                    ,'N'                                                                                 as corr_flag            --冲正标志
                    ,''                                                                                  as corr_tran_type       --冲正交易类型
                    ,''                                                                                  as corr_date            --冲正日期
                    ,''                                                                                  as tran_tlr_no          --交易柜员号
                    ,'110126'                                                                            as prod_code            --产品号
                    ,'10400101'                                                                          as subj_no              --科目号
                    ,''                                                                                  as acct_seq_no          --账户序列号
                    ,'slur'                                                                              as source_system        --来源系统
                    ,''                                                                                  as reference            --交易参考号
                    ,clear_flag                                                                          as clear_flag           --清分还款标志
                    ,''                                                                                  as accting_status       --核算状态
                    ,''                                                                                  as crdt_ltr             --授权柜员号
                    ,'02'                                                                                as cash_tran_flag       --现转标志
                    ,tran_bal                                                                            as tran_bal             --交易后余额
                    ,from_unixtime(unix_timestamp(t1.channel_date,'yyyyMMdd'),'yyyy-MM-dd')              as actual_tran_date     --实际交易日期
                    ,''                                                                                  as abst                 -- 摘要
                    ,''                                                                                  as tran_note            --交易附言
                    ,''                                                                                  as tran_desc            --交易描述
             from ( 
                     select  loan_id                 as tran_seqno
                            ,''                      as sub_tran_seqno
                            ,loan_id                 as bill_no
                            ,tran_date               as tran_date
                            ,'DRW1'                  as tran_type      
                            ,'D'                     as debit_flag  
                            ,encash_amt/100          as tran_amt
                            ,'OSL'                   as amt_type       
                            ,'0'                     as clear_flag
                            ,nvl(encash_amt/100,0)   as tran_bal
                            ,channel_date
                     from 
                        (  
                            select loan_id
                                   ,tran_date
                                   ,encash_amt
                                   ,cur_date
                                   ,channel_date
                              from (select row_number() over (partition by loan_id order by tran_date asc) as row_num,*
                                      from odata.slur_xm_loan_file
                                     where data_date='${DATA_DATE}'
                                       and bddw_end_date='9999-99-99'
                                       and loan_status in  ('1', '2', '3', '4', '5', '6') --2:已放款 6:已结清 其他暂无(1:放款中,3:已冲正,4:已撤销,5:已还款)
                                       and from_unixtime(unix_timestamp(cur_date,'yyyyMMdd'),'yyyy-MM-dd') <= date_add('${DATA_DATE}',-1)) a
                             where a.row_num=1
                        ) t
                    union all
                    select  a.xm_seq_no               as tran_seqno
                           ,seq_no                    as sub_tran_seqno
                           ,a.loan_id                 as bill_no
                           ,regexp_replace(substr(a.tran_date,1,10),'-','')                 
                                                      as tran_date
                           ,'REC1'                    as tran_type      
                           ,'C'                       as debit_flag
                           ,amount                    as tran_amt
                           ,a.amt_type                as amt_type   
                           ,case when b.loan_no is not null or (c.loan_no is not null and substr(a.tran_date,1,10)>substr(c.tran_date,1,10)) 
                                 then '1' else '0' 
                                 end                  as clear_flag
                           ,nvl(d.rec_amt,0)          as tran_bal
                           ,a.channel_date
                    from  (         
                                select * 
                                from odata.slur_xm_repay_item_file a 
                                lateral view explode(str_to_map(concat('OSL=',nvl(prin_amt/100    ,0),'&'  --本金
                                                                        'INT=',nvl(int_amt/100,0)+nvl(int_today/100,0),'&'  --利息
                                                                        'ODP=',nvl(pnlt_int_amt/100,0)+nvl(int_pnlt_amt/100,0),'&'  --罚息
                                                                       ),'&','='
                                                                 )
                                                     ) b as amt_type,amount
                                where a.data_date='${DATA_DATE}'
                                  and a.bddw_end_date='9999-99-99'
                                  and from_unixtime(unix_timestamp(a.cur_date,'yyyyMMdd'),'yyyy-MM-dd')<=date_add('${DATA_DATE}',-1)
                                  and cast(amount as decimal(18,2))<>0
                         ) a 
                 left join (     select 
                                         loan_no
                                        ,term
                                        ,clear_date
                                  from  odata.slur_compensatory_clear_detail
                                 where  data_date='${DATA_DATE}'
                                   and  bddw_end_date='9999-99-99'
                                 group by  loan_no,term,clear_date
                            ) b
                        on a.loan_id = b.loan_no 
                       and a.term_no = b.term
                       and regexp_replace(substr(a.tran_date,1,10),'-','')=b.clear_date
                 left join odata.slur_acc_writeoff_detail c
                        on a.loan_id = c.loan_no 
                       and c.status = 'S'
                       and c.data_date='${DATA_DATE}'
                       and c.bddw_end_date='9999-99-99'
             left join (select a.xm_seq_no
                               ,a.loan_id
                               ,a.amt_type
                               ,b.encash_amt-a.sn as rec_amt
                        from 
                       (select xm_seq_no
                               ,loan_id
                               ,tran_timestamp
                               ,b.amount
                               ,b.amt_type
                               ,sum(b.amount) over(partition by loan_id order by tran_timestamp,xm_seq_no) sn
                               from odata.slur_xm_repay_item_file a 
                               lateral view explode(str_to_map(concat('OSL=',nvl(prin_amt/100    ,0),'&'  --本金
                                                                      'INT=',nvl(int_amt/100,0)+nvl(int_today/100,0),'&'  --利息
                                                                      'ODP=',nvl(pnlt_int_amt/100,0)+nvl(int_pnlt_amt/100,0),'&'  --罚息
                                                                      ),'&','='
                                                               )
                                                   ) b as amt_type,amount
                                      where a.data_date='${DATA_DATE}'
                                        and a.bddw_end_date='9999-99-99'
                                        and from_unixtime(unix_timestamp(a.cur_date,'yyyyMMdd'),'yyyy-MM-dd')<=date_add('${DATA_DATE}',-1)
                                        and cast(amount as decimal(18,2))<>0
                                        and amt_type='OSL'
                                      )a 
                           left join (
                                      select 
                                             loan_id
                                             ,max(encash_amt/100) as encash_amt
                                             from odata.slur_xm_loan_file
                                             where data_date='${DATA_DATE}'
                                             and bddw_end_date='9999-99-99'
                                             group by loan_id
                                      ) b 
                                      on a.loan_id=b.loan_id
                          ) d
             on a.xm_seq_no=d.xm_seq_no
             and a.amt_type=d.amt_type
             )t1
             left join odata.ols_loan_cont_info t2
                    on t1.bill_no = t2.bill_no
                   and t2.data_date='${DATA_DATE}'
                   and t2.bddw_end_date='9999-99-99'
 union all
 ----------------------------------------------插入京东金条交易流水------------------------------------------------------------
             select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                                       as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                                   as sub_tran_seqno       --子交易流水号
                    ,''                                                                                  as acct_no              --贷款账户
                    ,t1.cust_id                                                                          as cust_id              --客户号
                    ,'01'                                                                                as cust_type            --客户类型
                    ,t1.bill_no                                                                          as bill_no              --借据号
                    ,t1.tran_date                                                                        as tran_date            --交易日期
                    ,'00:00:00'                                                                          as tran_time            --交易时间
                    ,t1.tran_type                                                                        as tran_type            --交易类型
                    ,case when t1.status in ('04','05') then 'X' else 'N' end                            as tran_status          --交易状态                                                      as tran_status          --交易状态
                    ,t1.debit_flag                                                                       as debit_flag           --借贷标志
                    ,'CNY'                                                                               as ccy                  --币种
                    ,t1.tran_amt                                                                         as tran_amt             --交易金额
                    ,t1.amt_type                                                                         as amt_type             --金额类型
                    ,''                                                                                  as tran_chan            --交易渠道
                    ,case when t1.status in ('04','05') then 'Y' else 'N' end                            as corr_flag            --冲正标志
                    ,''                                                                                  as corr_tran_type       --冲正交易类型
                    ,''                                                                                  as corr_date            --冲正日期
                    ,''                                                                                  as tran_tlr_no          --交易柜员号
                    ,'110104'                                                                            as prod_code            --产品号
                    ,'10400101'                                                                          as subj_no              --科目号
                    ,''                                                                                  as acct_seq_no          --账户序列号
                    ,'slur'                                                                              as source_system        --来源系统
                    ,''                                                                                  as reference            --交易参考号
                    ,clear_flag                                                                          as clear_flag           --清分还款标志
                    ,''                                                                                  as accting_status       --核算状态
                    ,''                                                                                  as crdt_ltr             --授权柜员号
                    ,'02'                                                                                as cash_tran_flag       --现转标志
                    ,tran_bal                                                                            as tran_bal             --交易后余额
                    ,case when t1.amt_type='OSL' then date_sub(t1.tran_date,1) else t1.channel_date end  as actual_tran_date     --实际交易日期
                    ,''                                                                                  as abst                 -- 摘要
                    ,''                                                                                  as tran_note            --交易附言
                    ,''                                                                                  as tran_desc            --交易描述
             from (
                     select  bill_no                 as tran_seqno
                            ,''                      as sub_tran_seqno
                            ,cust_id_core            as cust_id
                            ,bill_no                 as bill_no
                            ,date_add(loan_start_date,1)         
                                                     as tran_date
                            ,'DRW1'                  as tran_type      
                            ,'D'                     as debit_flag 
                            ,loan_amt                as tran_amt
                            ,'OSL'                   as amt_type    
                            ,''                      as status
                            ,'0'                     as clear_flag
                            ,nvl(loan_amt,0)         as tran_bal
                            ,''                      as channel_date
                     from odata.ols_loan_cont_info
                    where data_date='${DATA_DATE}'
                      and bddw_end_date='9999-99-99'
                      and loan_start_date<=date_add('${DATA_DATE}',-1)
                      and prd_code='10011001003'
                      and substr(input_time,1,10)<='${DATA_DATE}'
                      and cont_status in ('105', '106', '107', '108', '109', '110','111')  --105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
                  union all
                     select  a.receipt_no                  as tran_seqno
                            ,''                       as sub_tran_seqno
                            ,b.cust_id_core           as cust_id
                            ,b.bill_no                as bill_no
                            ,substr(a.tran_date,1,10)              as tran_date
                            ,case when a.receipt_type in ('04','05')
                                  then 'REC2'
                                  else 'REC1' 
                              end                     as tran_type     
                            ,'C'                      as debit_flag 
                            ,amount                   as tran_amt
                            ,a.amt_type               as amt_type
                            ,a.receipt_type           as status --04:退款 05:冲销
                            ,case when c.loan_no is not null or (d.loan_no is not null and substr(a.tran_date,1,10)>d.tran_date) then '1' else '0' end 
                                                      as clear_flag
                            ,nvl(e.tran_bal,0)        as tran_bal
                            ,substr(a.channel_date,1,10)
                                                      as channel_date
                      from
                           (
                               select *
                               from odata.slur_jd_loan_receipt_hist
                               lateral view explode(str_to_map(concat('OSL=',nvl(rec_pri_amt    ,0),'&'  --本金
                                                                      'INT=',nvl(rec_int_amt     ,0),'&'  --利息
                                                                      'ODP=',nvl(rec_odp_amt,0),'&'  --罚息
                                                                       ),'&','='
                                                             )
                                                  ) b as amt_type,amount
                               where data_date='${DATA_DATE}'
                                 and bddw_end_date='9999-99-99'
                        --         and busi_date<=regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                                 and cast(amount as decimal(18,2))<> 0
                            ) a
                      left join odata.ols_loan_cont_info b
                             on trim(a.loan_no)=trim(b.bill_no)
                            and b.data_date='${DATA_DATE}'
                            and b.bddw_end_date='9999-99-99'
                            and b.cont_status in ('105', '106', '107', '108', '109', '110','111')  --105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
                      left join 
                            (    
                                select 
                                         loan_no
                                        ,term
                                        ,clear_date
                                 from  odata.slur_compensatory_clear_detail
                                where  data_date='${DATA_DATE}'
                                   and  bddw_end_date='9999-99-99'
                                group by  loan_no,term,clear_date
                            ) c
                        on a.loan_no = c.loan_no 
                       and a.stage_no = c.term
                       and regexp_replace(substr(a.tran_date,1,10),'-','')=c.clear_date
                 left join odata.slur_acc_writeoff_detail d
                        on a.loan_no = d.loan_no 
                       and d.status = 'S'
                       and d.data_date='${DATA_DATE}'
                       and d.bddw_end_date='9999-99-99'
                 left join (
                           select jd_seq_no 
                                 ,a.loan_no
                                 ,a.amt_type
                                 ,b.loan_amt-a.sn as tran_bal
                          from (
                          select jd_seq_no
                                 ,loan_no
                                 ,b.amount
                                 ,b.amt_type
                                 ,sum(amount) over(partition by loan_no order by jd_seq_no ) sn
                                                         from  odata.slur_jd_loan_receipt_hist
                                                         lateral view explode(str_to_map(concat('OSL=',nvl(rec_pri_amt    ,0),'&'  --本金
                                                                                                'INT=',nvl(rec_int_amt     ,0),'&'  --利息
                                                                                                'ODP=',nvl(rec_odp_amt,0),'&'  --罚息
                                                                                                 ),'&','='
                                                                                       )
                                                                            ) b as amt_type,amount
                                                         where data_date='${DATA_DATE}'
                                                           and bddw_end_date='9999-99-99'
                                                  --         and busi_date<=regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                                                           and cast(amount as decimal(18,2))<> 0
                                                           and amt_type='OSL'
                                 ) a 
                          left join (
                                    select     bill_no 
                                               ,nvl(loan_amt,0) as loan_amt
                                               from odata.ols_loan_cont_info
                                              where data_date='${DATA_DATE}'
                                                and bddw_end_date='9999-99-99'
                                                and loan_start_date<=date_add('${DATA_DATE}',-1)
                                                and prd_code='10011001003'
                                                and substr(input_time,1,10)<='${DATA_DATE}'
                                                and cont_status in ('105', '106', '107', '108', '109', '110','111')  --105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
                                    ) b 
                                  on a.loan_no=b.bill_no 
                           ) e 
                        on a.jd_seq_no=e.jd_seq_no
                       and a.amt_type=e.amt_type
               )t1
union all
--------------------------------------------------度小满交易流水-------------------------------------------------------------
                          select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                             as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                         as sub_tran_seqno       --子交易流水号
                    ,''                                                                        as acct_no              --贷款账户
                    ,t2.cust_id_core                                                           as cust_id              --客户号
                    ,'01'                                                                      as cust_type            --客户类型
                    ,t1.bill_no                                                                as bill_no              --借据号
                    ,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd')       as tran_date            --交易日期
                    ,'00:00:00'                                                                as tran_time            --交易时间
                    ,t1.tran_type                                                              as tran_type            --交易类型
                    ,case when status='Y' then 'X' else 'N' end                                as tran_status          --交易状态
                    ,t1.debit_flag                                                             as debit_flag           --借贷标志
                    ,'CNY'                                                                     as ccy                  --币种
                    ,t1.tran_amt                                                               as tran_amt             --交易金额
                    ,t1.amt_type                                                               as amt_type             --金额类型
                    ,''                                                                        as tran_chan            --交易渠道
                    ,t1.status                                                                 as corr_flag            --冲正标志
                    ,''                                                                        as corr_tran_type       --冲正交易类型
                    ,''                                                                        as corr_date            --冲正日期
                    ,''                                                                        as tran_tlr_no          --交易柜员号
                    ,'110114'                                                                  as prod_code            --产品号
                    ,'10400101'                                                                as subj_no              --科目号
                    ,''                                                                        as acct_seq_no          --账户序列号
                    ,'slur'                                                                    as source_system        --来源系统
                    ,''                                                                        as reference            --交易参考号
                    ,clear_flag                                                                as clear_flag           --清分还款标志
                    ,''                                                                        as accting_status       --核算状态
                    ,''                                                                        as crdt_ltr             --授权柜员号
                    ,'02'                                                                      as cash_tran_flag       --现转标志
                    ,tran_bal                                                                  as tran_bal             --交易后余额
                    ,from_unixtime(unix_timestamp(t1.channel_date,'yyyyMMdd'),'yyyy-MM-dd')    as actual_tran_date     --实际交易日期
                    ,''                                                                        as abst                 -- 摘要
                    ,''                                                                        as tran_note            --交易附言
                    ,''                                                                        as tran_desc            --交易描述
             from  (
                        select  loan_no                  as tran_seqno
                                ,''                      as sub_tran_seqno
                                ,loan_no                 as bill_no
                                ,tran_date               as tran_date
                                ,case when a.loan_status in ('104','111') 
                                      then 'DRW2'
                                      else 'DRW1'
                                  end                    as tran_type      
                                ,'D'                     as debit_flag 
                                ,loan_amt                as tran_amt
                                ,'OSL'                   as amt_type
                                ,case when a.loan_status in ('104','111') 
                                      then 'Y'
                                      else 'N'
                                  end                    as status
                                ,'0'                     as clear_flag
                                ,case when a.loan_status in ('104','111') then 0
                                      else nvl(loan_amt,0)
                                 end                     as tran_bal
                                ,a.channel_date
                        from (
                                select *,
                                       row_number() over (partition by loan_no order by biz_date asc) as row_num
                                 from odata.slur_dxm_loan_file
                                where data_date='${DATA_DATE}'
                                  and bddw_end_date='9999-99-99'
                                  and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd')<=date_add('${DATA_DATE}',-1)
                                  and loan_status in ('104','105', '106', '107', '108', '109', '110','111')
                              ) a
                         where row_num=1
                   union all
                        select  a.dxm_seq_no                 as tran_seqno
                                ,repay_ref_nbr             as sub_tran_seqno
                                ,a.loan_no                 as bill_no
                                ,a.tran_date               as tran_date
                                ,'REC1'                    as tran_type    
                                ,'C'                       as debit_flag  
                                ,amount                    as tran_amt
                                ,a.amt_type                  as amt_type       
                                ,'N'                       as status
                                ,case when b.loan_no is not null 
                                       or (c.loan_no is not null and from_unixtime(unix_timestamp(a.tran_date,'yyyyMMdd'),'yyyy-MM-dd')>substr(c.tran_date,1,10)) 
                                      then '1' else '0' 
                                      end                  as clear_flag
                                ,nvl(d.tran_bal,0)         as tran_bal
                                ,a.channel_date
                        from (
                                select * 
                                from odata.slur_dxm_repay_file
                                 lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                        'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                        'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                        ),'&','='
                                                                )
                                                        ) b as amt_type,amount
                        where data_date='${DATA_DATE}'
                          and bddw_end_date='9999-99-99'
                          and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd') <= date_add('${DATA_DATE}',-1)
                          and cast(amount as decimal(18,2)) <> 0
                             ) a 
                   left join (    
                                select 
                                         loan_no
                                        ,term
                                        ,clear_date
                                  from  odata.slur_compensatory_clear_detail
                                 where  data_date='${DATA_DATE}'
                                   and  bddw_end_date='9999-99-99'
                              group by  loan_no,term,clear_date
                            ) b
                        on a.loan_no = b.loan_no 
                       and a.term_no = b.term
                       and a.tran_date=b.clear_date
                   left join odata.slur_acc_writeoff_detail c
                        on a.loan_no = c.loan_no 
                       and c.status = 'S'
                       and c.data_date='${DATA_DATE}'
                       and c.bddw_end_date='9999-99-99'
                   left join (
                              select a.dxm_seq_no
                                     ,a.loan_no
                                     ,a.amt_type
                                     ,b.loan_amt-a.sn as tran_bal
                              from   (
                                        select dxm_seq_no
                                               ,loan_no
                                               ,b.amount
                                               ,b.amt_type
                                               ,a.tran_timestamp
                                               ,sum(amount) over(partition by loan_no order by tran_time,tran_timestamp,partner_tran_date,partner_tran_timestamp,dxm_seq_no )sn
                                                                        from odata.slur_dxm_repay_file a
                                                                         lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                                                                'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                                                                'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                                                                ),'&','='
                                                                                                        )
                                                                                                ) b as amt_type,amount
                                               where data_date='${DATA_DATE}'
                                                 and bddw_end_date='9999-99-99'
                                                 and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd') <= date_add('${DATA_DATE}',-1)
                                                 and cast(amount as decimal(18,2)) <> 0
                                                 and amt_type='OSL'
                                     ) a 
                              left join (
                                         select bill_no
                                                ,loan_amt
                                         from odata.ols_loan_cont_info 
                                         where data_date='${DATA_DATE}'
                                         and bddw_end_date='9999-99-99'
                                        ) b 
                              on a.loan_no=b.bill_no
                             ) d 
                       on a.dxm_seq_no=d.dxm_seq_no
                      and a.amt_type=d.amt_type
                    )t1
             left join odata.ols_loan_cont_info t2
                    on t1.bill_no = t2.bill_no
                   and trim(t2.cont_status) in ('104','105', '106', '107', '108', '109', '110','111')  --104:贷款作废105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
                   and t2.data_date='${DATA_DATE}'
                   and t2.bddw_end_date='9999-99-99'
union all
------------------------------------------------------百度债转---------------------------------------------------------
             select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                       as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                   as sub_tran_seqno       --子交易流水号
                    ,''                                                                  as acct_no              --贷款账户
                    ,t2.cust_id_core                                                     as cust_id              --客户号
                    ,'01'                                                                as cust_type            --客户类型
                    ,t1.bill_no                                                          as bill_no              --借据号
                    ,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd') as tran_date            --交易日期
                    ,'00:00:00'                                                          as tran_time            --交易时间
                    ,t1.tran_type                                                        as tran_type            --交易类型
                    ,case when status='Y' then 'X' else 'N' end                          as tran_status          --交易状态
                    ,t1.debit_flag                                                       as debit_flag           --借贷标志
                    ,'CNY'                                                               as ccy                  --币种
                    ,t1.tran_amt                                                         as tran_amt             --交易金额
                    ,t1.amt_type                                                         as amt_type             --金额类型
                    ,''                                                                  as tran_chan            --交易渠道
                    ,status                                                              as corr_flag            --冲正标志
                    ,''                                                                  as corr_tran_type       --冲正交易类型
                    ,''                                                                  as corr_date            --冲正日期
                    ,''                                                                  as tran_tlr_no          --交易柜员号
                    ,'110128'                                                            as prod_code            --产品号
                    ,'10400101'                                                          as subj_no              --科目号
                    ,''                                                                  as acct_seq_no          --账户序列号
                    ,'slur'                                                              as source_system        --来源系统
                    ,''                                                                  as reference            --交易参考号
                    ,clear_flag                                                          as clear_flag           --清分还款标志
                    ,''                                                                  as accting_status       --核算状态
                    ,''                                                                  as crdt_ltr             --授权柜员号
                    ,'02'                                                                as cash_tran_flag       --现转标志
                    ,t1.tran_bal                                                         as tran_bal             --交易后余额
                    ,from_unixtime(unix_timestamp(t1.channel_date,'yyyyMMdd'),'yyyy-MM-dd') 
                                                                                         as actual_tran_date     --实际交易日期
                    ,''                                                                  as abst                 -- 摘要
                    ,''                                                                  as tran_note            --交易附言
                    ,''                                                                  as tran_desc            --交易描述
             from (
                    select  loan_no                 as tran_seqno
                          ,''                      as sub_tran_seqno
                          ,loan_no                 as bill_no
                          ,tran_date               as tran_date
                          ,case when a.loan_status in ('104','111') 
                                then 'DRW2'
                                else 'DRW1'
                            end                    as tran_type      
                          ,'D'                     as debit_flag 
                          ,loan_amt                as tran_amt
                          ,'OSL'                   as amt_type
                          ,case when a.loan_status in ('104','111') 
                                then 'Y'
                                else 'N'
                            end                    as status
                          ,'0'                     as clear_flag
                          ,case when a.loan_status in ('104','111') then 0
                                else nvl(loan_amt,0)
                           end                     as tran_bal
                          ,a.channel_date
                    from  (
                            select *,
                                   row_number() over (partition by loan_no order by biz_date asc) as row_num
                            from odata.slur_dzz_loan_file
                           where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                                else '2023-09-21'
                                            end  --update 20231024 yuguorui 债转停批
                             and bddw_end_date='9999-99-99'
                             and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd')<=date_add('${DATA_DATE}',-1)
                             and loan_status in ('104','105', '106', '107', '108', '109', '110','111')
                           ) a
                     where row_num=1
                   union all
                    select  a.dzz_seq_no                  as tran_seqno
                            ,repay_ref_nbr              as sub_tran_seqno
                            ,a.loan_no                  as bill_no
                            ,a.tran_date                as tran_date
                            ,'REC1'                     as tran_type    
                            ,'C'                        as debit_flag  
                            ,amount                     as tran_amt
                            ,a.amt_type                   as amt_type       
                            ,'N'                        as status
                            ,case when b.loan_no is not null and a.tran_date > b.tran_date 
                                  then '1' else '0' 
                                  end                   as clear_flag
                            ,nvl(c.tran_bal,0)          as tran_bal
                            ,a.channel_date
                     from (
                            select * 
                            from odata.slur_dzz_repay_file
                            lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                   'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                   'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                    ),'&','='
                                                                    )
                                                                    ) b as amt_type,amount
                     where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                          else '2023-09-21'
                                      end  --update 20231024 yuguorui 债转停批
                       and bddw_end_date='9999-99-99'
                       and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd') <= date_add('${DATA_DATE}',-1)
                       and cast(amount as decimal(18,2)) <> 0
                             ) a 
                left join odata.slur_dzz_compensatory_detail b
                      on a.loan_no = concat('ZZ',b.loan_no)
                     and b.data_date='${DATA_DATE}'
                     and b.bddw_end_date='9999-99-99'
                     and b.comps_status='S'
                     and b.sl_id = 'DDC'
                     and b.prod_class='01'
                left join (
                          select a.dzz_seq_no
                                 ,a.loan_no
                                 ,a.amt_type
                                 ,b.loan_amt-a.sn as tran_bal
                          from (
                          select a.dzz_seq_no
                                 ,a.loan_no
                                 ,b.amount
                                 ,b.amt_type
                                 ,a.tran_timestamp
                                 ,sum(amount) over(partition by loan_no order by tran_timestamp,dzz_seq_no )sn
                                                      from odata.slur_dzz_repay_file a
                                                      lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                                             'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                                             'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                                              ),'&','='
                                                                                              )
                                                                                              ) b as amt_type,amount
                                               where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                                                    else '2023-09-21'
                                                                end  --update 20231024 yuguorui 债转停批
                                                 and bddw_end_date='9999-99-99'
                                                 and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd') <= date_add('${DATA_DATE}',-1)
                                                 and cast(amount as decimal(18,2)) <> 0
                                                 and b.amt_type='OSL'
                               )a 
                          left join (
                                     select bill_no
                                            ,loan_amt
                                     from odata.ols_loan_cont_info 
                                     where data_date='${DATA_DATE}'
                                     and bddw_end_date='9999-99-99'
                                    ) b 
                                    on a.loan_no=b.bill_no
                          ) c 
                  on a.dzz_seq_no=c.dzz_seq_no
                 and a.amt_type=c.amt_type
              )t1
        left join odata.ols_loan_cont_info t2
                   on t1.bill_no = t2.bill_no
                  and trim(t2.cont_status) in ('104','105', '106', '107', '108', '109', '110','111')  --104:贷款作废105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
                  and t2.data_date='${DATA_DATE}'
                  and t2.bddw_end_date='9999-99-99'
                  --where t1.bill_no='ZZ4051613556629168742'
union all
---------------------------------------------------百度虚拟卡---------------------------------------------------------------
             select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                        as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                    as sub_tran_seqno       --子交易流水号
                    ,''                                                                   as acct_no              --贷款账户
                    ,t2.cust_id_core                                                      as cust_id              --客户号
                    ,'01'                                                                 as cust_type            --客户类型
                    ,t1.bill_no                                                           as bill_no              --借据号
                    ,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd')  as tran_date            --交易日期
                    ,'00:00:00'                                                           as tran_time            --交易时间
                    ,t1.tran_type                                                         as tran_type            --交易类型
                    ,case when status='Y' then 'X' else 'N' end                           as tran_status          --交易状态
                    ,t1.debit_flag                                                        as debit_flag           --借贷标志
                    ,'CNY'                                                                as ccy                  --币种
                    ,t1.tran_amt                                                          as tran_amt             --交易金额
                    ,t1.amt_type                                                          as amt_type             --金额类型
                    ,''                                                                   as tran_chan            --交易渠道
                    ,status                                                               as corr_flag            --冲正标志
                    ,''                                                                   as corr_tran_type       --冲正交易类型
                    ,''                                                                   as corr_date            --冲正日期
                    ,''                                                                   as tran_tlr_no          --交易柜员号
                    ,'110132'                                                             as prod_code            --产品号
                    ,'10400101'                                                           as subj_no              --科目号
                    ,''                                                                   as acct_seq_no          --账户序列号
                    ,'slur'                                                               as source_system        --来源系统
                    ,''                                                                   as reference            --交易参考号
                    ,clear_flag                                                           as clear_flag           --清分还款标志
                    ,''                                                                   as accting_status       --核算状态
                    ,''                                                                   as crdt_ltr             --授权柜员号
                    ,'02'                                                                 as cash_tran_flag       --现转标志
                    ,t1.tran_bal                                                          as tran_bal             --交易后余额
                    ,from_unixtime(unix_timestamp(t1.channel_date,'yyyyMMdd'),'yyyy-MM-dd')
                                                                                          as actual_tran_date     --实际交易日期
                    ,''                                                                   as abst                 -- 摘要
                    ,''                                                                   as tran_note            --交易附言
                    ,''                                                                   as tran_desc            --交易描述
             from ( 
                      select  loan_no                 as tran_seqno
                            ,''                      as sub_tran_seqno
                            ,loan_no                 as bill_no
                            ,tran_date               as tran_date
                            ,case when a.loan_status in ('104','111') 
                                  then 'DRW2'
                                  else 'DRW1'
                              end                    as tran_type      
                            ,'D'                     as debit_flag 
                            ,loan_amt                as tran_amt
                            ,'OSL'                   as amt_type
                            ,case when a.loan_status in ('104','111') 
                                  then 'Y'
                                  else 'N'
                              end                    as status
                            ,'0'                     as clear_flag
                            ,case when a.loan_status in ('104','111') then 0
                                  else nvl(loan_amt,0)
                             end                     as tran_bal
                            ,a.channel_date
                      from (
                              select *
                            from odata.slur_bdvc_loan_file_clear
                            where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                                 else '2023-09-21'
                                             end  --update 20231024 yuguorui 虚拟卡停批
                                and bddw_end_date='9999-99-99'
                                and loan_status in ('104','105', '106', '107', '108', '109', '110','111')
                           ) a
                   union all
                      select  a.bdvc_seq_no                as tran_seqno
                             ,repay_ref_nbr              as sub_tran_seqno
                             ,a.loan_no                  as bill_no
                             ,a.tran_date                as tran_date
                             ,'REC1'                     as tran_type    
                             ,'C'                        as debit_flag  
                             ,amount                     as tran_amt
                             ,a.amt_type                   as amt_type       
                             ,'N'                        as status
                             ,case when b.loan_no is not null and a.tran_date > b.tran_date 
                                   then '1' else '0' 
                                   end                   as clear_flag
                             ,nvl(c.tran_bal,0)          as tran_bal
                             ,a.channel_date
                        from  (   
                                select * 
                                from odata.slur_bdvc_repay_file
                                lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                       'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                       'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                       ),'&','=')
                                                     ) b as amt_type,amount
                        where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                             else '2023-09-21'
                                             end  --update 20231024 yuguorui 虚拟卡停批
                          and bddw_end_date='9999-99-99'
                          and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd') <= date_add('${DATA_DATE}',-1)
                          and cast(amount as decimal(18,2)) <> 0
                                ) a 
                   left join odata.slur_dzz_compensatory_detail b
                          on a.loan_no = b.loan_no
                         and b.data_date='${DATA_DATE}'
                         and b.bddw_end_date='9999-99-99'
                         and b.comps_status='S'
                         and b.sl_id = 'BDVC'
                         and b.prod_class='01'
                   left join (
                              select a.bdvc_seq_no
                                     ,a.loan_no
                                     ,a.amt_type
                                     ,b.loan_amt-a.sn as tran_bal
                              from (
                              select bdvc_seq_no
                                     ,loan_no
                                     ,b.amt_type
                                     ,b.amount
                                     ,a.tran_timestamp
                                     ,sum(amount) over(partition by loan_no order by tran_timestamp,bdvc_seq_no )sn
                                                              from odata.slur_bdvc_repay_file a
                                                              lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                                                     'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                                                     'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                                                     ),'&','=')
                                                                                   ) b as amt_type,amount
                                                      where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                                                           else '2023-09-21'
                                                                           end  --update 20231024 yuguorui 虚拟卡停批
                                                        and bddw_end_date='9999-99-99'
                                                        and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd') <= date_add('${DATA_DATE}',-1)
                                                        and cast(amount as decimal(18,2)) <> 0
                                                        and amt_type='OSL'
                                    ) a 
                              left join (
                                         select bill_no
                                         ,loan_amt
                                         from odata.ols_loan_cont_info 
                                         where data_date='${DATA_DATE}'
                                         and bddw_end_date='9999-99-99'
                                         ) b 
                            on a.loan_no=b.bill_no
                             ) c 
                   on a.bdvc_seq_no=c.bdvc_seq_no
                  and a.amt_type=c.amt_type
             ) t1
        left join odata.ols_loan_cont_info t2
               on t1.bill_no = t2.bill_no
              and trim(t2.cont_status) in ('104','105', '106', '107', '108', '109', '110','111')  --104:贷款作废105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
              and t2.data_date='${DATA_DATE}'
              and t2.bddw_end_date='9999-99-99'
union all
--百度周转贷
             select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                       as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                   as sub_tran_seqno       --子交易流水号
                    ,''                                                                  as acct_no              --贷款账户
                    ,t2.cust_id_core                                                     as cust_id              --客户号
                    ,'01'                                                                as cust_type            --客户类型
                    ,t1.bill_no                                                          as bill_no              --借据号
                    ,t1.tran_date                                                        as tran_date            --交易日期
                    ,'00:00:00'                                                          as tran_time            --交易时间
                    ,t1.tran_type                                                        as tran_type            --交易类型
                    ,case when status='Y' then 'X' else 'N' end                          as tran_status          --交易状态
                    ,t1.debit_flag                                                       as debit_flag           --借贷标志
                    ,'CNY'                                                               as ccy                  --币种
                    ,t1.tran_amt                                                         as tran_amt             --交易金额
                    ,t1.amt_type                                                         as amt_type             --金额类型
                    ,''                                                                  as tran_chan            --交易渠道
                    ,t1.status                                                           as corr_flag            --冲正标志
                    ,''                                                                  as corr_tran_type       --冲正交易类型
                    ,''                                                                  as corr_date            --冲正日期
                    ,''                                                                  as tran_tlr_no          --交易柜员号
                    ,'110145'                                                            as prod_code            --产品号
                    ,'10400201'                                                          as subj_no              --科目号
                    ,''                                                                  as acct_seq_no          --账户序列号
                    ,'slur'                                                              as source_system        --来源系统
                    ,''                                                                  as reference            --交易参考号
                    ,clear_flag                                                          as clear_flag           --清分还款标志
                    ,''                                                                  as accting_status       --核算状态
                    ,''                                                                  as crdt_ltr             --授权柜员号
                    ,'02'                                                                as cash_tran_flag       --现转标志
                    ,t1.tran_bal                                                         as tran_bal             --交易后余额
                    ,t1.channel_date                                                     as actual_tran_date     --实际交易日期
                    ,''                                                                   as abst                 -- 摘要
                    ,''                                                                   as tran_note            --交易附言
                    ,''                                                                   as tran_desc            --交易描述
             from (
                        select  bdzz_seq_no                  as tran_seqno
                              ,''                            as sub_tran_seqno
                              ,concat('ZZD',loan_id)         as bill_no
                              ,substr(tran_time,1,10)        as tran_date
                              ,case when fund_status in ('3','4') 
                                    then 'DRW2'
                                    else 'DRW1'
                                end                          as tran_type      
                              ,'D'                           as debit_flag 
                              ,encash_amt/100                as tran_amt
                              ,'OSL'                         as amt_type
                              ,case when fund_status in ('3','4') 
                                    then 'Y'
                                    else 'N'
                                end                          as status
                              ,'0'                           as clear_flag
                              ,case when fund_status in ('3','4') then 0
                                    else encash_amt/100
                               end                           as tran_bal
                              ,substr(cur_date,1,10)         as channel_date
                        from   odata.slur_bdzz_loan_detail
                        where   data_date='${DATA_DATE}'
                            and   bddw_end_date='9999-99-99'
                            and   fund_status <> '1'
                      union all
                        select  a.bdzz_seq_no                as tran_seqno
                                ,repay_ref_nbr               as sub_tran_seqno
                                ,a.loan_no                   as bill_no
                                ,substr(a.tran_date,1,10)    as tran_date
                                ,'REC1'                      as tran_type    
                                ,'C'                         as debit_flag  
                                ,amount                      as tran_amt
                                ,a.amt_type                    as amt_type      
                                ,'N'                         as status
                                ,case when b.loan_no is not null and regexp_replace(substr(a.tran_date,1,10),'-','') > b.tran_date 
                                      then '1' else '0' 
                                      end                    as clear_flag
                                ,nvl(c.tran_bal,0)           as tran_bal
                                ,from_unixtime(unix_timestamp(a.channel_date,'yyyyMMdd'),'yyyy-MM-dd')
                                                             as channel_date
                        from (
                                    select * 
                                    from odata.slur_bdzz_repay_file
                                    lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                           'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                           'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                           ),'&','=')
                                                         ) b as amt_type,amount
                                    where data_date='${DATA_DATE}'
                                        and bddw_end_date='9999-99-99'
                                        and cast(amount as decimal(18,2)) <> 0
--                                      and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd') <= date_add('${DATA_DATE}',-1)
                                ) a 
                   left join odata.slur_dzz_compensatory_detail b
                         on a.loan_no = b.loan_no
                        and b.data_date='${DATA_DATE}'
                        and b.bddw_end_date='9999-99-99'
                        and b.comps_status='S'
                        and b.sl_id = 'BDZZ'
                        and b.prod_class='01'
                   left join (
                             select a.bdzz_seq_no
                                     ,a.loan_no
                                     ,a.amt_type
                                     ,b.loan_amt-a.sn as tran_bal
                             from (
                             select  bdzz_seq_no
                                     ,loan_no
                                     ,b.amt_type
                                     ,b.amount
                                     ,a.tran_timestamp
                                     ,sum(amount) over(partition by loan_no order by tran_timestamp,bdzz_seq_no )sn
                                                                 from odata.slur_bdzz_repay_file a
                                                                 lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                                                        'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                                                        'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                                                        ),'&','=')
                                                                                      ) b as amt_type,amount
                                                                 where data_date='${DATA_DATE}'
                                                                     and bddw_end_date='9999-99-99'
                                                                     and cast(amount as decimal(18,2)) <> 0
                             --                                      and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd') <= date_add('${DATA_DATE}',-1)
                                                                     and amt_type='OSL'
                             ) a 
                             left join (
                                        select bill_no
                                        ,loan_amt
                                        from odata.ols_loan_cont_info 
                                        where data_date='${DATA_DATE}'
                                        and bddw_end_date='9999-99-99'
                                        ) b 
                            on a.loan_no=b.bill_no
                            ) c 
                          on a.bdzz_seq_no=c.bdzz_seq_no
                         and a.amt_type=c.amt_type
                   where (nvl(b.loan_no,'')<>'ZZD6161618120553157664' or nvl(b.tran_date,'')<>'20220625') 
                     and (nvl(b.loan_no,'')<>'ZZD6162309575928550812' or nvl(b.tran_date,'')<>'20220625')
                )t1
        left join odata.ols_loan_cont_info t2
              on t1.bill_no = t2.bill_no
             and trim(t2.cont_status)  in ('104','105', '106', '107', '108', '109', '110','111')  --104:贷款作废105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
             and t2.data_date='${DATA_DATE}'
             and t2.bddw_end_date='9999-99-99'
union all
--大额锡望贷
             select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                        as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                    as sub_tran_seqno       --子交易流水号
                    ,''                                                                   as acct_no              --贷款账户
                    ,t4.client_no                                                         as cust_id              --客户号
                    ,'01'                                                                 as cust_type            --客户类型
                    ,t1.bill_no                                                           as bill_no              --借据号
                    ,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd')  as tran_date            --交易日期
                    ,'00:00:00'                                                           as tran_time            --交易时间
                    ,t1.tran_type                                                         as tran_type            --交易类型
                    ,'N'                                                                  as tran_status          --交易状态
                    ,t1.debit_flag                                                        as debit_flag           --借贷标志
                    ,'CNY'                                                                as ccy                  --币种
                    ,t1.tran_amt                                                          as tran_amt             --交易金额
                    ,t1.amt_type                                                          as amt_type             --金额类型
                    ,''                                                                   as tran_chan            --交易渠道
                    ,'N'                                                                  as corr_flag            --冲正标志
                    ,''                                                                   as corr_tran_type       --冲正交易类型
                    ,''                                                                   as corr_date            --冲正日期
                    ,''                                                                   as tran_tlr_no          --交易柜员号
                    ,'110143'                                                             as prod_code            --产品号
                    ,'10400101'                                                           as subj_no              --科目号
                    ,''                                                                   as acct_seq_no          --账户序列号
                    ,'slur'                                                               as source_system        --来源系统
                    ,''                                                                   as reference            --交易参考号
                    ,'0'                                                                  as clear_flag           --清分还款标志
                    ,''                                                                   as accting_status       --核算状态
                    ,''                                                                   as crdt_ltr             --授权柜员号
                    ,'02'                                                                 as cash_tran_flag       --现转标志
                    ,t1.tran_bal                                                          as tran_bal             --交易后余额
                    ,from_unixtime(unix_timestamp(t1.channel_date,'yyyyMMdd'),'yyyy-MM-dd')
                                                                                          as actual_tran_date     --实际交易日期
                    ,''                                                                   as abst                 -- 摘要
                    ,''                                                                   as tran_note            --交易附言
                    ,''                                                                   as tran_desc            --交易描述
             from (     
                        select   serial_no                     as tran_seqno
                                ,''                            as sub_tran_seqno
                                ,loan_id                       as bill_no
                                ,loan_start_date               as tran_date
                                ,'DRW1'                        as tran_type      
                                ,'D'                           as debit_flag 
                                ,encash_amt                    as tran_amt
                                ,'OSL'                         as amt_type
                                ,prod_type
                                ,encash_amt                    as tran_bal
                                ,channel_date
                        from   odata.slur_acc_loan_detail
                        where   data_date='${DATA_DATE}'
                          and   bddw_end_date='9999-99-99'
                     union all
                        select  channel_seq_no                 as tran_seqno
                               ,''                             as sub_tran_seqno
                               ,a.loan_id                        as bill_no
                               ,a.repay_date                     as tran_date
                               ,'REC1'                         as tran_type    
                               ,'C'                            as debit_flag  
                               ,amount                         as tran_amt
                               ,a.amt_type                     as amt_type      
                               ,prod_type
                               ,nvl(c.tran_bal,0)              as tran_bal
                               ,a.channel_date
                        from (
                              select * 
                                    from odata.slur_acc_repay_detail
                                   lateral view explode(str_to_map(concat('OSL=',nvl(repay_prin_amt    ,0),'&'  --本金
                                                                          'INT=',nvl(repay_int_amt     ,0),'&'  --利息
                                                                          'ODP=',nvl(repay_odp_amt,0),'&'  --罚息
                                                                          ),'&','=')
                                                        ) b as amt_type,amount
                             where data_date='${DATA_DATE}'
                         and bddw_end_date='9999-99-99'
                         and cast(amount as decimal(18,2)) <> 0
                             ) a 
                        left join (
                                 select a.loan_id
                                       ,a.period
                                       ,a.amt_type
                                       ,b.encash_amt-a.sn as tran_bal
                                from (
                                select  loan_id
                                        ,period
                                        ,amt_type 
                                        ,amount
                                        ,run_date
                                        ,sum(amount) over(partition by loan_id order by period,run_date) sn 
                                                        from  odata.slur_acc_repay_detail
                                                             lateral view explode(str_to_map(concat('OSL=',nvl(repay_prin_amt    ,0),'&'  --本金
                                                                                                    'INT=',nvl(repay_int_amt     ,0),'&'  --利息
                                                                                                    'ODP=',nvl(repay_odp_amt,0),'&'  --罚息
                                                                                                    ),'&','=')
                                                                                  ) b as amt_type,amount
                                                       where data_date='${DATA_DATE}'
                                                         and bddw_end_date='9999-99-99'
                                                         and cast(amount as decimal(18,2)) <> 0
                                                         and amt_type='OSL'
                                ) a 
                                left join (
                                          select loan_id 
                                                 ,encash_amt
                                          from odata.slur_acc_loan_detail 
                                          where data_date='${DATA_DATE}'
                                          and bddw_end_date='9999-99-99'
                                          ) b 
                                on a.loan_id=b.loan_id
                                 ) c 
                        on a.loan_id=c.loan_id
                       and a.period=c.period
                       and a.amt_type=c.amt_type
                )t1
           left join  odata.order_custom_info t8
                  on  t1.bill_no=t8.loan_id
                 and  t8.data_date='${DATA_DATE}' 
                 and  t8.bddw_end_date='9999-99-99'
           left join odata.sym_cif_client_document t4
                 on t8.id_card=t4.document_id
                 and t4.data_date='${DATA_DATE}' 
                 and t4.bddw_end_date='9999-99-99'
                 and t4.document_type = '101'
union all
--张家港
             select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                        as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                    as sub_tran_seqno       --子交易流水号
                    ,''                                                                   as acct_no              --贷款账户
                    ,t2.cust_id_core                                                      as cust_id              --客户号
                    ,'01'                                                                 as cust_type            --客户类型
                    ,t1.bill_no                                                           as bill_no              --借据号
                    ,t1.tran_date                                                         as tran_date            --交易日期
                    ,'00:00:00'                                                           as tran_time            --交易时间
                    ,t1.tran_type                                                         as tran_type            --交易类型
                    ,case when status='Y' then 'X' else 'N' end                           as tran_status          --交易状态
                    ,t1.debit_flag                                                        as debit_flag           --借贷标志
                    ,'CNY'                                                                as ccy                  --币种
                    ,t1.tran_amt                                                          as tran_amt             --交易金额
                    ,t1.amt_type                                                          as amt_type             --金额类型
                    ,''                                                                   as tran_chan            --交易渠道
                    ,status                                                               as corr_flag            --冲正标志
                    ,''                                                                   as corr_tran_type       --冲正交易类型
                    ,''                                                                   as corr_date            --冲正日期
                    ,''                                                                   as tran_tlr_no          --交易柜员号
                    ,'110142'                                                             as prod_code            --产品号
                    ,'10400101'                                                           as subj_no              --科目号
                    ,''                                                                   as acct_seq_no          --账户序列号
                    ,'slur'                                                               as source_system        --来源系统
                    ,''                                                                   as reference            --交易参考号
                    ,'0'                                                                  as clear_flag           --清分还款标志
                    ,''                                                                   as accting_status       --核算状态
                    ,''                                                                   as crdt_ltr             --授权柜员号
                    ,'02'                                                                 as cash_tran_flag       --现转标志
                    ,t1.tran_bal                                                          as tran_bal             --交易后余额
                    ,from_unixtime(unix_timestamp(t1.channel_date,'yyyyMMdd'),'yyyy-MM-dd')
                                                                                          as actual_tran_date     --实际交易日期
                    ,''                                                                   as abst                 -- 摘要
                    ,''                                                                   as tran_note            --交易附言
                    ,''                                                                   as tran_desc            --交易描述
             from (
                        select  bdul_seq_no                    as tran_seqno
                                ,''                            as sub_tran_seqno
                                ,loan_id                       as bill_no
                                ,substr(tran_date,1,10)        as tran_date
                                ,case when fund_status in ('3','4') 
                                        then 'DRW2'
                                        else 'DRW1'
                                    end                        as tran_type      
                                ,'D'                           as debit_flag 
                                ,encash_amt/100                as tran_amt
                                ,'OSL'                         as amt_type      
                                ,case when fund_status in ('3','4') 
                                        then 'Y'
                                        else 'N'
                                    end                        as status
                                ,case when fund_status in ('3','4') then 0
                                      else encash_amt/100
                                 end                           as tran_bal
                                ,channel_date
                        from   odata.slur_bdul_open_file
                        where   data_date='${DATA_DATE}'
                            and   bddw_end_date='9999-99-99'
                            and   loan_mode = '01'
                    union all
                        select  a.bdul_seq_no                  as tran_seqno
                                ,seq_no                        as sub_tran_seqno
                                ,a.loan_id                     as bill_no
                                ,substr(tran_date,1,10)        as tran_date
                                ,'REC1'                        as tran_type    
                                ,'C'                           as debit_flag  
                                ,amount                        as tran_amt
                                ,a.amt_type                    as amt_type      
                                ,'N'
                                ,nvl(b.tran_bal,0)             as tran_bal
                                ,a.channel_date
                        from 
                        (select *
                        from odata.slur_bdul_repay_file
                                                        lateral view explode(str_to_map(concat('OSL=',nvl(prin_amt/100    ,0),'&'  --本金
                                                                        'INT=',nvl(int_amt/100     ,0),'&'  --利息
                                                                        'ODP=',nvl(pnlt_int_amt/100,0),'&'  --罚息
                                                                                               ),'&','=')
                                                                             ) b as amt_type,amount
                                                where data_date='${DATA_DATE}'
                                                    and bddw_end_date='9999-99-99'
                                                    and   loan_mode = '01'
                                                    and  cast(amount as decimal(18,2))<>0
                        )a left join 
                        (
                        select a.bdul_seq_no
                               ,a.loan_id
                               ,a.amt_type
                               ,b.loan_amt-a.sn as tran_bal
                        from (
                              select  bdul_seq_no
                                      ,loan_id
                                      ,b.amt_type
                                      ,b.amount
                                      ,a.tran_timestamp
                                      ,sum(amount) over(partition by loan_id order by a.tran_timestamp,bdul_seq_no) sn
                                                      from odata.slur_bdul_repay_file a
                                                              lateral view explode(str_to_map(concat('OSL=',nvl(prin_amt/100    ,0),'&'  --本金
                                                                              'INT=',nvl(int_amt/100     ,0),'&'  --利息
                                                                              'ODP=',nvl(pnlt_int_amt/100,0),'&'  --罚息
                                                                                                     ),'&','=')
                                                                                   ) b as amt_type,amount
                                                      where data_date='${DATA_DATE}'
                                                          and bddw_end_date='9999-99-99'
                                                          and   loan_mode = '01'
                                                          and  cast(amount as decimal(18,2))<>0
                                                          and b.amt_type='OSL'
                              ) a 
                              left join 
                              (
                              select bill_no
                                     ,loan_amt
                              from odata.ols_loan_cont_info 
                              where data_date='${DATA_DATE}'
                              and bddw_end_date='9999-99-99'
                              ) b 
                              on a.loan_id=b.bill_no
                        ) b
                        on a.bdul_seq_no=b.bdul_seq_no
                       and a.amt_type=b.amt_type
                    )t1
         left join odata.ols_loan_cont_info t2
                on t1.bill_no = t2.bill_no
               and trim(t2.cont_status)  in ('104','105', '106', '107', '108', '109', '110','111')  --104:贷款作废105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
               and t2.data_date='${DATA_DATE}'
               and t2.bddw_end_date='9999-99-99'
union all
--金城
             select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                        as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                    as sub_tran_seqno       --子交易流水号
                    ,''                                                                   as acct_no              --贷款账户
                    ,nvl(t7.customerid,'')                                                as cust_id              --客户号
                    ,'02'                                                                 as cust_type            --客户类型
                    ,nvl(t7.serialno,'')                                                  as bill_no              --借据号
                    ,t1.tran_date                                                         as tran_date            --交易日期
                    ,'00:00:00'                                                           as tran_time            --交易时间
                    ,t1.tran_type                                                         as tran_type            --交易类型
                    ,case when  t6.reversal_flag = '00' then 'N' else 'X' end             as tran_status          --交易状态
                    ,t1.debit_flag                                                        as debit_flag           --借贷标志
                    ,'CNY'                                                                as ccy                  --币种
                    ,t1.tran_amt                                                          as tran_amt             --交易金额
                    ,t1.amt_type                                                          as amt_type             --金额类型
                    ,''                                                                   as tran_chan            --交易渠道
                    ,case when t6.reversal_flag = '00' then 'N' else 'Y' end              as corr_flag            
                    ,''                                                                   as corr_tran_type       --冲正交易类型
                    ,''                                                                   as corr_date            --冲正日期
                    ,''                                                                   as tran_tlr_no          --交易柜员号
                    ,'120108'                                                             as prod_code            --产品号
                    ,'10410101'                                                           as subj_no              --科目号
                    ,''                                                                   as acct_seq_no          --账户序列号
                    ,'slur'                                                               as source_system        --来源系统
                    ,''                                                                   as reference            --交易参考号
                    ,'0'                                                                  as clear_flag           --清分还款标志
                    ,''                                                                   as accting_status       --核算状态
                    ,''                                                                   as crdt_ltr             --授权柜员号
                    ,'02'                                                                 as cash_tran_flag       --现转标志
                    ,t1.tran_bal                                                          as tran_bal             --交易后余额
                    ,date_sub(t1.tran_date,1)                                             as actual_tran_date     --实际交易日期
                    ,''                                                                   as abst                 -- 摘要
                    ,''                                                                   as tran_note            --交易附言
                    ,''                                                                   as tran_desc            --交易描述
             from (
                        select  trans_seq_no                     as tran_seqno
                                ,batch_no                        as sub_tran_seqno
                                ,loan_no                         as bill_no
                                ,date_add(substr(sl_tran_date,1,10),1)       
                                                                 as tran_date
                                ,case when trans_type='L10' then 'DRW2'
                                      else  'DRW1' end           as tran_type      
                                ,'D'                             as debit_flag 
                                ,trans_amt                       as tran_amt
                                ,'OSL'                           as amt_type
                                ,case when trans_type='L10' then 0 
                                      else trans_amt
                                 end                             as tran_bal
                        from   odata.slur_jcb_loan
                        where   data_date='${DATA_DATE}'
                          and   bddw_end_date='9999-99-99'
                    union all
                        select  a.trans_seq_no                   as tran_seqno
                                ,batch_no                        as sub_tran_seqno
                                ,a.loan_no                       as bill_no
                                ,date_add(substr(sl_tran_date,1,10),1)               
                                                                 as tran_date
                                ,'REC1'                          as tran_type    
                                ,'C'                             as debit_flag  
                                ,amount                          as tran_amt
                                ,a.amt_type                      as amt_type      
                                ,nvl(b.tran_bal,0)               as tran_bal
                        from 
                        (select * from 
                         odata.slur_jcb_repay_detail
                                lateral view explode(str_to_map(concat('OSL=',nvl(prin_amt    ,0),'&'  --本金
                                                'INT=',nvl(int_amt     ,0),'&'  --利息
                                                'ODP=',nvl(oint_amt,0),'&'  --罚息
                                                ),'&','=')) b as amt_type,amount
                        where data_date='${DATA_DATE}'
                            and bddw_end_date='9999-99-99'
                            and cast(amount as decimal(18,2))<>0
                        ) a 
                        left join (
                                   select a.trans_seq_no
                                          ,a.loan_no
                                          ,a.amt_type
                                          ,b.trans_amt-a.sn as tran_bal
                                   from 
                                   (select 
                                              a.trans_seq_no
                                              ,a.loan_no
                                              ,b.amt_type
                                              ,b.amount
                                              ,sum(amount) over(partition by loan_no order by a.tran_timestamp,trans_seq_no) sn
                                              from  odata.slur_jcb_repay_detail a
                                                                   lateral view explode(str_to_map(concat('OSL=',nvl(prin_amt    ,0),'&'  --本金
                                                                                   'INT=',nvl(int_amt     ,0),'&'  --利息
                                                                                   'ODP=',nvl(oint_amt,0),'&'  --罚息
                                                                                   ),'&','=')) b as amt_type,amount
                                                           where data_date='${DATA_DATE}'
                                                               and bddw_end_date='9999-99-99'
                                                               and cast(amount as decimal(18,2))<>0
                                                               and b.amt_type='OSL'
                                   )a left join 
                                   (
                                   select loan_no
                                          ,max(trans_amt) as trans_amt
                                   from odata.slur_jcb_loan
                                   where data_date='${DATA_DATE}'
                                   and bddw_end_date='9999-99-99'
                                   group by loan_no
                                   ) b 
                                   on a.loan_no=b.loan_no
                                  ) b 
                        on a.trans_seq_no=b.trans_seq_no
                       and a.amt_type=b.amt_type
                    )t1
        left join odata.supacct_enterprise_loan_info t6
                 on t6.data_date='${DATA_DATE}'
                and t6.bddw_end_date='9999-99-99'
                and t1.bill_no = t6.partner_loan_no
            --    and t6.reversal_flag = '00'
        left join  odata.als_business_duebill t7
                 on t7.data_date='${DATA_DATE}'
                and t7.bddw_end_date='9999-99-99'
                and t6.iou_no = t7.serialno
union all
--满意贷交易流水
             select  /*+ REPARTITION(1) */
                     t1.tran_seqno                                                             as tran_seqno           --交易流水号
                    ,t1.sub_tran_seqno                                                         as sub_tran_seqno       --子交易流水号
                    ,''                                                                        as acct_no              --贷款账户
                    ,t2.cust_id_core                                                           as cust_id              --客户号
                    ,'01'                                                                      as cust_type            --客户类型
                    ,t1.bill_no                                                                as bill_no              --借据号
                    ,t1.tran_date                                                              as tran_date            --交易日期
                    ,'00:00:00'                                                                as tran_time            --交易时间
                    ,t1.tran_type                                                              as tran_type            --交易类型
                    ,case when status='Y' then 'X' else 'N' end                                as tran_status          --交易状态
                    ,t1.debit_flag                                                             as debit_flag           --借贷标志
                    ,'CNY'                                                                     as ccy                  --币种
                    ,t1.tran_amt                                                               as tran_amt             --交易金额
                    ,t1.amt_type                                                               as amt_type             --金额类型
                    ,''                                                                        as tran_chan            --交易渠道
                    ,t1.status                                                                 as corr_flag            --冲正标志
                    ,''                                                                        as corr_tran_type       --冲正交易类型
                    ,''                                                                        as corr_date            --冲正日期
                    ,''                                                                        as tran_tlr_no          --交易柜员号
                    ,'110162'                                                                  as prod_code            --产品号
                    ,'10400101'                                                                as subj_no              --科目号
                    ,''                                                                        as acct_seq_no          --账户序列号
                    ,'slur'                                                                    as source_system        --来源系统
                    ,''                                                                        as reference            --交易参考号
                    ,clear_flag                                                                as clear_flag           --清分还款标志
                    ,''                                                                        as accting_status       --核算状态
                    ,''                                                                        as crdt_ltr             --授权柜员号
                    ,'02'                                                                      as cash_tran_flag       --现转标志
                    ,t1.tran_bal                                                               as tran_bal             --交易后余额
                    ,t1.channel_date                                                           as actual_tran_date     --实际交易日期
                    ,''                                                                        as abst                 -- 摘要
                    ,''                                                                        as tran_note            --交易附言
                    ,''                                                                        as tran_desc            --交易描述
             from (
                        select  loan_no                     as tran_seqno
                            ,''                             as sub_tran_seqno
                            ,loan_no                        as bill_no
                            ,from_unixtime(unix_timestamp(nvl(tran_date,''),'yyyyMMdd'),'yyyy-MM-dd')  as tran_date
                            ,case when a.loan_status in ('104','111') 
                                    then 'DRW2'
                                    else 'DRW1'
                                end                         as tran_type      
                            ,'D'                            as debit_flag 
                            ,loan_amt                       as tran_amt
                            ,'OSL'                          as amt_type
                            ,case when a.loan_status in ('104','111') 
                                    then 'Y'
                                    else 'N'
                                end                         as status
                            ,'0'                            as clear_flag
                            ,case when a.loan_status in ('104','111') then 0 
                                  else loan_amt
                             end                            as tran_bal
                            ,substr(a.channel_date,1,10)    as channel_date
                        from (
                                    select *,
                                           row_number() over (partition by loan_no order by biz_date asc) as row_num
                                    from odata.slur_bddd_loan_file
                                    where data_date='${DATA_DATE}'
                                        and bddw_end_date='9999-99-99'
                                        and substr(biz_date,1,10)<=date_add('${DATA_DATE}',-1)
                                        and loan_status in ('104','105', '106', '107', '108', '109', '110','111')
                              ) a
                        where row_num=1
                    union all
                        select  a.bddd_seq_no                 as tran_seqno
                                ,repay_ref_nbr              as sub_tran_seqno
                                ,a.loan_no                  as bill_no
                                ,from_unixtime(unix_timestamp(nvl(a.tran_date,''),'yyyyMMdd'),'yyyy-MM-dd')                  
                                                            as tran_date
                                ,'REC1'                     as tran_type    
                                ,'C'                        as debit_flag  
                                ,amount                     as tran_amt
                                ,a.amt_type                   as amt_type       
                                ,'N'                        as status
                                ,case when b.loan_no is not null or (c.loan_no is not null and   
                                           from_unixtime(unix_timestamp(nvl(a.tran_date,''),'yyyyMMdd'),'yyyy-MM-dd')>substr(c.tran_date,1,10)) 
                                      then '1' else '0' 
                                      end                   as clear_flag
                                ,nvl(d.tran_bal,0)          as tran_bal
                                ,substr(a.channel_date,1,10)    as channel_date
                        from (  
                                select * 
                                from odata.slur_bddd_repay_file
                                lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                       'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                       'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                       ),'&','=')
                                                     ) b as amt_type,amount
                        where data_date='${DATA_DATE}'
                            and bddw_end_date='9999-99-99'
                            and substr(biz_date,1,10) <= date_add('${DATA_DATE}',-1)
                            and cast(amount as decimal(18,2)) <> 0
                                ) a 
                 left join (   
                                select 
                                         loan_no
                                        ,term
                                        ,clear_date
                                  from  odata.slur_compensatory_clear_detail
                                 where  data_date='${DATA_DATE}'
                                   and  bddw_end_date='9999-99-99'
                                 group by  loan_no,term,clear_date
                            ) b
                        on a.loan_no = b.loan_no 
                       and a.term_no = b.term
                       and a.tran_date=b.clear_date
                 left join odata.slur_acc_writeoff_detail c
                        on a.loan_no = c.loan_no 
                       and c.status = 'S'
                       and c.data_date='${DATA_DATE}'
                       and c.bddw_end_date='9999-99-99'
                 left join (
                           select a.bddd_seq_no
                                  ,a.loan_no
                                  ,a.amt_type
                                  ,b.loan_amt-a.sn as tran_bal
                           from (select a.bddd_seq_no
                                  ,a.loan_no
                                  ,b.amt_type
                                  ,b.amount
                                  ,a.tran_timestamp
                                  ,sum(amount) over(partition by loan_no order by tran_timestamp,substr(bddd_seq_no,5) )sn
                                                           from odata.slur_bddd_repay_file a
                                                           lateral view explode(str_to_map(concat('OSL=',nvl(principal_amt    ,0),'&'  --本金
                                                                                                  'INT=',nvl(interest_amt     ,0),'&'  --利息
                                                                                                  'ODP=',nvl(penalty_amt,0),'&'  --罚息
                                                                                                  ),'&','=')
                                                                                ) b as amt_type,amount
                                                   where data_date='${DATA_DATE}'
                                                       and bddw_end_date='9999-99-99'
                                                       and substr(biz_date,1,10) <= date_add('${DATA_DATE}',-1)
                                                       and cast(amount as decimal(18,2)) <> 0
                                                       and b.amt_type='OSL'
                           ) a left join 
                           (
                           select bill_no
                                  ,loan_amt
                           from odata.ols_loan_cont_info 
                           where data_date='${DATA_DATE}'
                           and bddw_end_date='9999-99-99'
                           ) b 
                           on a.loan_no=b.bill_no
                           ) d 
                  on a.bddd_seq_no=d.bddd_seq_no
                 and a.amt_type=d.amt_type
             )t1
      left join odata.ols_loan_cont_info t2
             on t1.bill_no = t2.bill_no
            and trim(t2.cont_status) in ('104','105', '106', '107', '108', '109', '110','111')  --104:贷款作废105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
            and t2.data_date='${DATA_DATE}'
            and t2.bddw_end_date='9999-99-99'
union all
--字节交易流水
             select  /*+ REPARTITION(1) */
                     nvl(t1.tran_seqno,'')                                                     as tran_seqno           --交易流水号
                    ,nvl(t1.sub_tran_seqno,'')                                                 as sub_tran_seqno       --子交易流水号
                    ,''                                                                        as acct_no              --贷款账户
                    ,nvl(t2.cust_id_core,'')                                                   as cust_id              --客户号
                    ,'01'                                                                      as cust_type            --客户类型
                    ,nvl(t2.bill_no,'')                                                        as bill_no              --借据号
                    ,nvl(t1.tran_date,'')                                                      as tran_date            --交易日期
                    ,'00:00:00'                                                                as tran_time            --交易时间
                    ,nvl(t1.tran_type,'')                                                      as tran_type            --交易类型
                    ,case when status='Y' then 'X' else 'N' end                                as tran_status          --交易状态
                    ,nvl(t1.debit_flag,'')                                                     as debit_flag           --借贷标志
                    ,'CNY'                                                                     as ccy                  --币种
                    ,nvl(t1.tran_amt,0)                                                        as tran_amt             --交易金额
                    ,nvl(t1.amt_type,'')                                                       as amt_type             --金额类型
                    ,''                                                                        as tran_chan            --交易渠道
                    ,nvl(t1.status,'')                                                         as corr_flag            --冲正标志
                    ,''                                                                        as corr_tran_type       --冲正交易类型
                    ,nvl(t1.corr_date,'')                                                      as corr_date            --冲正日期
                    ,''                                                                        as tran_tlr_no          --交易柜员号
                    ,nvl(t1.prod_code,'')                                                      as prod_code            --产品号
                    ,'10400101'                                                                as subj_no              --科目号
                    ,''                                                                        as acct_seq_no          --账户序列号
                    ,'slur'                                                                    as source_system        --来源系统
                    ,''                                                                        as reference            --交易参考号
                    ,nvl(clear_flag,'')                                                        as clear_flag           --清分还款标志
                    ,nvl(t1.accting_status,'')                                                 as accting_status       --核算状态
                    ,''                                                                        as crdt_ltr             --授权柜员号
                    ,'02'                                                                      as cash_tran_flag       --现转标志
                    ,nvl(t1.tran_bal,0)                                                        as tran_bal             --交易后余额
                    ,nvl(t1.channel_date,'')                                                   as actual_tran_date     --实际交易日期
                    ,''                                                                        as abst                 -- 摘要
                    ,''                                                                        as tran_note            --交易附言
                    ,''                                                                        as tran_desc            --交易描述
             from (
                        select  b.bill_no                         as tran_seqno
                                ,''                               as sub_tran_seqno
                                ,a.loan_id                        as bill_no
                                ,nvl(substr(a.run_date,1,10),'')  as tran_date
                                ,case when b.cont_status in ('104','111') 
                                    then 'DRW2'
                                    else 'DRW1'
                                end                               as tran_type
                                ,'D'                              as debit_flag 
                                ,a.encash_amt                     as tran_amt
                                ,'OSL'                            as amt_type
                                ,case when b.cont_status in ('104','111') 
                                    then 'Y'
                                    else 'N'
                                end                               as status
                                ,a.reversal_date                  as corr_date
                                ,c.accounting_status              as accting_status
                                ,'0'                              as clear_flag
                                ,case when b.cont_status in ('104','111') then 0 
                                      else loan_amt
                                 end                              as tran_bal
                                ,substr(a.channel_date,1,10)      as channel_date
                                ,a.prod_type                      as prod_code
                                from (select loan_id
                                             ,run_date
                                             ,encash_amt
                                             ,reversal_status
                                             ,channel_date
                                             ,accounting_status
                                             ,prod_type
                                             ,from_unixtime(unix_timestamp(nvl(reversal_date,''),'yyyyMMdd'),'yyyy-MM-dd') as reversal_date
                                             ,row_number() over (partition by loan_id order by run_date asc) as row_num
                                      from odata.slur_ac_loan_file
                                     where data_date='${DATA_DATE}'
                                       and bddw_end_date='9999-99-99'
                                     ) a
                                   left join odata.ols_loan_cont_info b
                                         on a.loan_id = b.app_no
                                        and b.data_date='${DATA_DATE}'
                                        and b.bddw_end_date='9999-99-99'
                                        and b.cont_status in ('104','105', '106', '107', '108', '109', '110','111')
                                   left join odata.sllv_ac_loan c 
                                         on a.loan_id=c.loan_id
                                        and c.data_date='${DATA_DATE}'
                                        and c.bddw_end_date='9999-99-99'
                                 where a.row_num=1
                    union all
                        select  a.ac_seq_no                 as tran_seqno
                                ,''                         as sub_tran_seqno
                                ,a.loan_id                  as bill_no
                                ,nvl(substr(run_date,1,10),'')
                                                            as tran_date
                                ,'REC1'                     as tran_type    
                                ,'C'                        as debit_flag  
                                ,amount                     as tran_amt
                                ,a.amt_type                 as amt_type
                                ,'N'                        as status
                                ,''                         as corr_date
                                ,nvl(e.accounting_status,'')as accting_status
                                ,'0'                        as clear_flag
                                ,nvl(d.tran_bal,0)          as tran_bal
                                ,substr(a.channel_date,1,10)    as channel_date
                                ,a.prod_type                as prod_code
                        from (  
                                select * 
                                from odata.slur_ac_repay_file
                                lateral view explode(str_to_map(concat('OSL=',nvl(prin_amt,0),'&'  --本金
                                                                       'INT=',nvl(int_amt,0),'&'  --利息
                                                                       'ODP=',nvl(pnlt_int_amt,0),'&'  --罚息
                                                                       ),'&','=')
                                                     ) b as amt_type,amount
                        where data_date='${DATA_DATE}'
                            and bddw_end_date='9999-99-99'
                            and cast(amount as decimal(18,2)) <> 0
                                ) a 
                 left join (
                           select a.ac_seq_no
                                  ,a.loan_id
                                  ,a.amt_type
                                  ,b.loan_amt-a.sn as tran_bal
                           from (select a.ac_seq_no
                                        ,a.loan_id
                                        ,b.amt_type
                                        ,b.amount
                                        ,a.tran_timestamp
                                        ,sum(amount) over(partition by loan_id order by tran_timestamp,ac_seq_no )sn
                                 from odata.slur_ac_repay_file a
                                 lateral view explode(str_to_map(concat('OSL=',nvl(prin_amt,0),'&'  --本金
                                                                        'INT=',nvl(int_amt,0),'&'  --利息
                                                                        'ODP=',nvl(pnlt_int_amt,0),'&'  --罚息
                                                                        ),'&','=')
                                                      ) b as amt_type,amount
                                                   where data_date='${DATA_DATE}'
                                                       and bddw_end_date='9999-99-99'
                                                       and cast(amount as decimal(18,2)) <> 0
                                                       and b.amt_type='OSL'
                           ) a left join 
                           (
                           select bill_no
                                  ,loan_amt
                                  ,app_no
                           from odata.ols_loan_cont_info 
                           where data_date='${DATA_DATE}'
                           and bddw_end_date='9999-99-99'
                           ) b 
                           on a.loan_id=b.app_no
                           ) d 
                  on a.ac_seq_no=d.ac_seq_no
                 and a.amt_type=d.amt_type
               left join odata.sllv_ac_loan e 
                  on a.loan_id=e.loan_id
                 and e.data_date='${DATA_DATE}'
                 and e.bddw_end_date='9999-99-99'
             )t1
      left join odata.ols_loan_cont_info t2
             on t1.bill_no = t2.app_no
            and trim(t2.cont_status) in ('104','105', '106', '107', '108', '109', '110','111')  --104:贷款作废105:已放款 106:已结清 107:逾期 108:核销 109:终止 110:关闭 111:冲正
            and t2.data_date='${DATA_DATE}'
            and t2.bddw_end_date='9999-99-99'