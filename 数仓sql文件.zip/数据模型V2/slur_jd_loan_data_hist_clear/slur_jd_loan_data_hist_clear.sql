with temp1 as (
select 
     *     
     from odata.slur_jd_loan_data_hist_clear 
     where data_date=date_add('${DATA_DATE}',-1)  and bddw_end_date='9999-99-99' 
),temp2 as (
select 
    t1.*,t2.first_tran_date as first_tran_date
    from (
    select
    row_number() over (partition by loan_no order by busi_date desc) as row_num,* from odata.slur_jd_loan_data_hist
    where  data_date='${DATA_DATE}' and bddw_end_date='9999-99-99'  and database_name='slur' and substr(tran_date,1,10)='${DATA_DATE}'
    ) t1 
    left join
	(
	 select
     loan_no,min(substr(from_unixtime(unix_timestamp(tran_date,'yyyy-mm-dd'),'yyyymmdd'),1,10)) as first_tran_date
    from odata.slur_jd_loan_data_hist
    where data_date='${DATA_DATE}' and bddw_end_date='9999-99-99' group by loan_no
    )t2 on t1.loan_no=t2.loan_no
    where t1.row_num=1
)
insert overwrite table odata.slur_jd_loan_data_hist_clear partition(data_date='${DATA_DATE}',database_name='slur')
select
       t1.jd_seq_no               
      ,t1.batch_no                
      ,t1.prod_class              
      ,t1.tran_date               
      ,t1.channel_date            
      ,t1.busi_date               
      ,t1.loan_no                 
      ,t1.jd_client_no            
      ,t1.prod_no                 
      ,t1.limit_amt_no            
      ,t1.acct_no                 
      ,t1.ccy                     
      ,t1.accouting_status        
      ,t1.open_date               
      ,t1.pri_amt                 
      ,t1.maturity_date           
      ,t1.inland_offshore         
      ,t1.pri_freq                
      ,t1.int_freq                
      ,t1.pay_amt                 
      ,t1.trust_pay_amt           
      ,t1.yuq_flag                
      ,t1.yuq_days                
      ,t1.yuq_grace_day           
      ,t1.pri_yuq_date            
      ,t1.int_yuq_date            
      ,t1.next_cycle_date         
      ,t1.int_type                
      ,t1.osl_amt                 
      ,t1.yuq_amt                 
      ,t1.yuq_int                 
      ,t1.fyj_int                 
      ,t1.int_ind                 
      ,t1.int_accrued             
      ,t1.int_accrued_ctd         
      ,t1.odp_accred_ctd          
      ,t1.pay_acct_no             
      ,t1.rec_acct_no             
      ,t1.guaranty_style          
      ,t1.repay_mode              
      ,t1.int_rate                
      ,t1.odp_rate                
      ,t1.cl_int_type             
      ,t1.odp_type                
      ,t1.repay_amend_type        
      ,t1.jd_reference            
      ,t1.normal_osl_amt          
      ,t1.normal_yuq_amt          
      ,t1.stage_osl               
      ,t1.stage_yuq_amt           
      ,t1.zhc_int                 
      ,t1.ord_yuq_int             
      ,t1.stage_int               
      ,t1.stage_yuq_int           
      ,t1.normal_odp              
      ,t1.stage_odp               
      ,t1.purpose                 
      ,t1.busi_mode               
      ,t1.real_rate               
      ,t1.real_int_type           
      ,t1.cash_fee                
      ,t1.cash_fee_ctd            
      ,t1.fee_rate                
      ,t1.fee_type                
      ,t1.bocd_accrued            
      ,t1.bocd_accrued_ctd        
      ,t1.bocd_rate               
      ,t1.bocd_type               
      ,t1.stage                   
      ,t1.rec_stage               
      ,t1.yuq_stage               
      ,t1.fyj_stage               
      ,t1.odp_accrued             
      ,t1.drawdwon_date           
      ,t1.client_no               
      ,t1.branch                  
      ,t1.userid                  
      ,t1.company                 
      ,t1.repeat_times            
      ,t1.tran_status             
      ,t1.tran_time               
      ,t1.tran_timestamp          
      ,t1.router_key              
      ,'${DATA_DATE}'    as bddw_start_date
      ,'9999-99-99'      as bddw_end_date 
      ,t1.first_tran_date
    from temp1 t1 left join temp2 t2  on t1.loan_no=t2.loan_no 
    where t2.loan_no is  null
union all
    select 
     jd_seq_no               
    ,batch_no                
    ,prod_class              
    ,tran_date               
    ,channel_date            
    ,busi_date               
    ,loan_no                 
    ,jd_client_no            
    ,prod_no                 
    ,limit_amt_no            
    ,acct_no                 
    ,ccy                     
    ,accouting_status        
    ,open_date               
    ,pri_amt                 
    ,maturity_date           
    ,inland_offshore         
    ,pri_freq                
    ,int_freq                
    ,pay_amt                 
    ,trust_pay_amt           
    ,yuq_flag                
    ,yuq_days                
    ,yuq_grace_day           
    ,pri_yuq_date            
    ,int_yuq_date            
    ,next_cycle_date         
    ,int_type                
    ,osl_amt                 
    ,yuq_amt                 
    ,yuq_int                 
    ,fyj_int                 
    ,int_ind                 
    ,int_accrued             
    ,int_accrued_ctd         
    ,odp_accred_ctd          
    ,pay_acct_no             
    ,rec_acct_no             
    ,guaranty_style          
    ,repay_mode              
    ,int_rate                
    ,odp_rate                
    ,cl_int_type             
    ,odp_type                
    ,repay_amend_type        
    ,jd_reference            
    ,normal_osl_amt          
    ,normal_yuq_amt          
    ,stage_osl               
    ,stage_yuq_amt           
    ,zhc_int                 
    ,ord_yuq_int             
    ,stage_int               
    ,stage_yuq_int           
    ,normal_odp              
    ,stage_odp               
    ,purpose                 
    ,busi_mode               
    ,real_rate               
    ,real_int_type           
    ,cash_fee                
    ,cash_fee_ctd            
    ,fee_rate                
    ,fee_type                
    ,bocd_accrued            
    ,bocd_accrued_ctd        
    ,bocd_rate               
    ,bocd_type               
    ,stage                   
    ,rec_stage               
    ,yuq_stage               
    ,fyj_stage               
    ,odp_accrued             
    ,drawdwon_date           
    ,client_no               
    ,branch                  
    ,userid                  
    ,company                 
    ,repeat_times            
    ,tran_status             
    ,tran_time               
    ,tran_timestamp          
    ,router_key              
    ,'${DATA_DATE}'    as bddw_start_date
    ,'9999-99-99'      as bddw_end_date
    ,first_tran_date
    from  temp2