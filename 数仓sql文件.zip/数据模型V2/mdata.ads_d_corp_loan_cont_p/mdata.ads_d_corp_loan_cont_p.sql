---------------------------------------------------------------------------------------------------------------
--脚本名称：对公贷款合同信息取数逻辑.sql
--功能描述：用于在hive mdata层创建mdata.ads_d_corp_loan_cont_p
--作    者：施金才
--开发日期：2020-11-19
--直属经理：程宏明
--修改历史：
--          1.施金才   2020-11-19    新建
--          2.张礼娟   2021-05-07    源表由gdata.ads_d_corp_loan_cont_p改为dwd.dwd_d_corp_loan_cont_p
---------------------------------------------------------------------------------------------------------------
insert overwrite table mdata.ads_d_corp_loan_cont_p partition(data_date='${DATA_DATE}')
select
    cont_no                  
    ,acct_mask(cust_id)                  
    ,name_mask(cust_name)                
    ,biz_type                 
    ,biz_name                 
    ,cont_sign_date           
    ,occur_type               
    ,is_cycle                 
    ,ccy                      
    ,cont_amt                 
    ,term_m                   
    ,rate_type                
    ,benc_rate_type           
    ,benc_rate                
    ,rate_float_mode          
    ,rate_float_value         
    ,exec_rate_m              
    ,exec_rate_y              
    ,pay_mode                 
    ,repay_mode               
    ,indust_invest            
    ,purp                     
    ,cont_start_date          
    ,cont_mature_date         
    ,end_date                 
    ,guar_mode                
    ,is_other_guar_mode       
    ,bal                      
    ,norm_bal                 
    ,overdue_amt              
    ,magr_ratio               
    ,magr_ccy                 
    ,magr_amt                 
    ,acct_mask(magr_acct)                
    ,postloan_manage_org_id   
    ,postloan_manage_user_id  
    ,oper_org_id              
    ,operr_id                 
    ,oper_date                
    ,remark1                  
    ,remark2                  
    ,remark3                  
    ,remark4                  
    ,remark5                  
from dwd.dwd_d_corp_loan_cont_p
where data_date='${DATA_DATE}'