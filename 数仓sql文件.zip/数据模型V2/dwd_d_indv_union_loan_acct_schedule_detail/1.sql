--------------------------------------------------------------------------------------------------------
--脚本名称：个人联合贷还款计划明细表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive dwd层dwd.dwd_d_indv_union_loan_acct_schedule_detail
--作    者：华天顺
--开发日期：2021-03-11
--直属经理：程宏明
--来源表  ：odata.sllv_nl_acct_schedule_detail 线上贷款账户计划明细表
--来源表  ：odata.sllv_nl_receipt_detail  线上贷款回收明细表
--来源表  ：odata.sllv_nl_acct    线上贷款账户基本信息表
--来源表  ：odata.sllv_nl_drawdown  线上贷款发放表
--来源表  ：odata.sllv_nl_noschedule_invoice    线上贷款非计划单据表
--目标表  ：dwd.dwd_d_indv_union_loan_acct_schedule_detail
--修改历史：
--          1.华天顺   2021-08-20    新建

--------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_indv_union_loan_acct_schedule_detail partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */ 
c.cmisloan_no as bill_no                  --借据号
      ,c.client_no as cust_id                    --客户号
      ,null as acct_no                           --账号
      ,a.stage_no as term_no                     --期次
      ,a.term_start_date                         --本期开始日期
      ,a.term_end_date  as term_mature_date      --本期到期日期
      ,a.grace_period_date as term_grace_date    --本期宽限到期日
      ,null as grace_days                        --宽限天数
      ,a.receipt_date as repay_date             --实际还款日
      ,case when a.are_int_flag ='Y' then '2'  --结清
            when a.term_end_date <= '${DATA_DATE}' then '1'--逾期
            when a.term_end_date > '${DATA_DATE}' then '0' --正常未结清
        end as term_repay_status --还款状态
      ,a.sched_amt_pri as  matured_prin         --本期应还本金
      ,b.rec_amt_pri as repaid_prin             --本期已还本金
      ,null          as overdue_prin            --本期逾期本金
      ,a.sched_amt_int as  matured_int          --本期应还利息
      ,b.rec_amt_int    as  repaied_int         --本期已还利息
      ,null   as overdue_int                    --本期逾期利息
      ,a.sched_amt_fee  as  matured_fee         --本期应还担保费
      ,b.rec_amt_fee   as repaied_fee           --本期已还担保费 
      ,a.matured_pena                     --本期应还罚息
      ,a.matured_pena-a.pena_bal as repaied_pena                     --本期已还罚息
      ,null as matured_compo                    --本期应还复利
      ,null as repaied_compo                    --本期已还复利
      ,case when a.are_int_flag = 'Y' 
            then a.receipt_date
            else null
        end as clear_date                       --结清日期  
      ,nvl(a.actual_yq_days,0) as overdue_days --逾期天数
      ,c.prod_type --产品类别
from (select internal_key,
            cast(stage_no as int)                  as stage_no
           ,min(case when is_invoice = 'Y' then nvl(fully_settled,'N') else null end) as are_int_flag
           ,substr(min(start_date),1,10)           as term_start_date
           ,substr(max(end_date),1,10)             as term_end_date
           ,substr(max(grace_period_date),1,10)    as grace_period_date
           ,substr(max(paid_date),1,10)            as receipt_date
           ,max(actual_yq_days)       as actual_yq_days
           ,sum(case when amt_type = 'PRI' then sched_amt else 0 end) as sched_amt_pri
           ,sum(case when amt_type = 'INT' then sched_amt else 0 end) as sched_amt_int
           ,sum(case when amt_type = 'FEE' then sched_amt else 0 end) as sched_amt_fee
		   ,sum(case when amt_type = 'ODP' then billed_amt else 0 end) as matured_pena
		   ,sum(case when amt_type = 'ODP' then outstanding else 0 end) as pena_bal
     from odata.sllv_nl_acct_schedule_detail
    where data_date = '${DATA_DATE}'
      and bddw_end_date = '9999-99-99'
 group by internal_key,stage_no) a 
left join(select internal_key,
                 stage_no,
                 sum(case when amt_type = 'INT' then rec_amt else 0 end) as rec_amt_int,
                 sum(case when amt_type = 'PRI' then rec_amt else 0 end) as rec_amt_pri,
                 sum(case when amt_type = 'FEE' then rec_amt else 0 end) as rec_amt_fee,
                 substr(max(due_date),1,10) as receipt_date
            from odata.sllv_nl_receipt_detail a
           where a.data_date = '${DATA_DATE}'
             and a.bddw_end_date = '9999-99-99'
             and a.sched_flag='Y'
           group by internal_key,stage_no)b
       on a.internal_key = b.internal_key
      and a.stage_no = b.stage_no
 left join odata.sllv_nl_acct c
       on c.data_date = '${DATA_DATE}'
      and c.bddw_end_date = '9999-99-99'
      and a.internal_key = c.internal_key
--left join  odata.sllv_nl_drawdown d
--    on d.data_date = '${DATA_DATE}'
--      and d.bddw_end_date = '9999-99-99'
--      and d.reversal = 'Y'
--      and a.internal_key = d.internal_key
--where d.internal_key is null  --剔除冲正借据
union all
select /*+ REPARTITION(1) */ 
e.cmisloan_no as bill_no                  --借据号
      ,e.client_no as cust_id                    --客户号
      ,null as acct_no                           --账号
      ,a.stage_no as term_no                     --期次
      ,g.term_start_date --本期开始日期
      ,g.term_end_date  as term_mature_date      --本期到期日期
      ,null as term_grace_date    --本期宽限到期日
      ,null as grace_days                        --宽限天数
      ,c.receipt_date as repay_date             --实际还款日
      ,'2' as term_repay_status --还款状态
      ,a.sched_amt_pri as  matured_prin         --本期应还本金     
      ,a.sched_amt_pri as repaid_prin             --本期已还本金
      ,null          as overdue_prin            --本期逾期本金
      ,a.sched_amt_int as  matured_int          --本期应还利息
      ,a.sched_amt_int  as  repaied_int         --本期已还利息
      ,null   as overdue_int                    --本期逾期利息
      ,a.sched_amt_fee  as  matured_fee         --本期应还担保费
      ,a.sched_amt_fee   as repaied_fee           --本期已还担保费 
      ,null as matured_pena                     --本期应还罚息
      ,null as repaied_pena                     --本期已还罚息
      ,null as matured_compo                    --本期应还复利
      ,null as repaied_compo                    --本期已还复利
      ,c.receipt_date   as clear_date           --结清日期  
      ,0 as overdue_days --逾期天数
      ,e.prod_type --产品类别
     from  (select internal_key
                   ,cast(stage_no as int)                  as stage_no
                   ,substr(max(due_date),1,10)            as receipt_date
                   ,sum(case when amt_type = 'PRI' then billed_amt else 0 end) as sched_amt_pri
                   ,sum(case when amt_type = 'INT' then billed_amt else 0 end) as sched_amt_int
                   ,sum(case when amt_type = 'FEE' then billed_amt else 0 end) as sched_amt_fee
     from odata.sllv_nl_noschedule_invoice
    where data_date = '${DATA_DATE}'
      and bddw_end_date = '9999-99-99'
 group by internal_key,stage_no)  a   --涉及提前还款的借据
 left join (select receipt_no
                 ,internal_key 
                 ,stage_no
                 ,substr(max(due_date),1,10) as receipt_date
        from odata.sllv_nl_receipt_detail
    where data_date = '${DATA_DATE}'
      and bddw_end_date = '9999-99-99'
      and sched_flag='N'
      group by receipt_no,internal_key,stage_no )c
      on a.internal_key=c.internal_key
      and a.stage_no=c.stage_no    --获取还款编号
 inner join (select internal_key,receipt_no  
     from odata.sllv_nl_receipt  
    where data_date = '${DATA_DATE}'
      and bddw_end_date = '9999-99-99'
      and receipt_type in ('PO','ER')
      group by  internal_key,receipt_no)d
on c.internal_key=d.internal_key
and c.receipt_no=d.receipt_no    --取整笔提前结清的借据
 left join odata.sllv_nl_acct e
       on e.data_date = '${DATA_DATE}'
      and e.bddw_end_date = '9999-99-99'
      and a.internal_key = e.internal_key
left join (select internal_key
           ,stage_no
           ,substr(min(start_date),1,10)           as term_start_date
           ,substr(max(end_date),1,10)             as term_end_date
     from odata.sllv_nl_acct_schedule_detail_amend
    where data_date = '${DATA_DATE}'
      and bddw_end_date = '9999-99-99'
 group by internal_key,stage_no) g
on a.internal_key=g.internal_key
and a.stage_no=g.stage_no
--left join  odata.sllv_nl_drawdown f
--    on f.data_date = '${DATA_DATE}'
--      and f.bddw_end_date = '9999-99-99'
--      and f.reversal = 'Y'
--      and a.internal_key = f.internal_key
--where f.internal_key is null  --剔除冲正借据