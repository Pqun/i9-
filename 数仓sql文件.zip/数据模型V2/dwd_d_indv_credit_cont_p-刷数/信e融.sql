--2.yuguorui.dwd_d_indv_credit_cont_p_110150
--脚本名称：授信合同表dwd.dwd_d_indv_credit_cont_p取数逻辑.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2021-11-20
--直属经理：方杰
--来源表  :odata.ols_crd_app_info                 授信申请表
--来源表  :odata.ols_loan_prd_info                贷款产品信息表
--来源表  :odata.ols_crd_cont_info                授信合同信息表
--来源表  :odata.ols_admin_sm_user                系统用户表
--目标表  :dwd.dwd_d_indv_credit_cont_p
--修改历史：
--          1.于国睿   2022-10-09    新建
--          2.于国睿   2023-05-11    修改授信合同状态逻辑，剔除关联额度信息表渠道限制
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_indv_credit_cont_p partition(data_date='${DATA_DATE}',prod_code='110150')
    select /* REPARTITION(1) */
	       ''                         as credit_app_no        --授信申请号   
          ,nvl(t2.apply_no,'')        as credit_cont_no       --授信合同编号
          ,'01'                       as cust_type            --客户类型
          ,nvl(t3.client_no,'')       as cust_id              --客户号
          ,nvl(t4.client_short,'')    as cust_name            --客户姓名
          ,'个人经营贷款-通用'        as prod_name            --产品名称
          ,''                         as biz_prod_code        --源业务系统产品号
          ,''                         as biz_sub_prod_code    --源业务系统子产品号
          ,nvl(t5.document_type,'')   as cert_type            --证件类型
          ,nvl(t5.document_id,'')     as cert_no              --证件号码
          ,case when t2.status in ('01','02') 
		        then '001'
				when t2.status in ('03','06')
                then '002'
				when t2.status in ('04','07') 
		        then '003'
                else ''				
			end                       as credit_app_status    --授信申请状态
          ,case when t6.effective_status = '1' --生效
		        then '103'
				when t6.effective_status = '2' --失效
                then '104'
				when t6.effective_status = '3' --冻结
                then '105' 
                else ''				  
			end                       as credit_cont_status   --授信合同状态
          ,'1'         		          as cycle_flag           --循环标识
          ,'CNY'                      as ccy                  --币种
          ,nvl(t2.credit_amount/100,0)    as credit_limit         --授信额度
          ,nvl(round(months_between(substr(t6.limit_end_time,1,10),substr(t6.limit_begin_time,1,10)),0),'') as credit_terms         --授信期限
          ,'M'                        as credit_term_type     --授信期限类型
          ,nvl(substr(t6.limit_begin_time,1,10),'')  as credit_start_date    --授信起始日期
          ,nvl(substr(t6.limit_end_time,1,10),'')    as credit_mature_date   --授信到期日期
          ,case when t6.effective_status in (1,3) 
		        then '01'
				when t2.status in ('04','07') and (t6.effective_status = 2 or t6.credit_order_no is null)
                then '02'
                else ''				
			end                       as credit_status        --授信状态
          ,nvl(substr(t2.approve_time,1,10),'')    as credit_app_date      --申请日期
          ,''                         as approver             --审批人
          ,nvl(t2.risk_audit_opinion,'') as approve_opinion      --审批意见
          ,'1'                        as loan_biz_class       --业务分类
          ,''                         as third_party_app_no   --第三方申请流水号
          ,nvl(t7.year_interest_rate*100,0)   as loan_rate            --贷款年利率(年%)
          ,''                         as credit_manage_status --授信处理状态
          ,''                         as ip                   
          ,''                         as device_id            --设备ID
		  ,nvl(t2.project_id,'')      as project_id           --项目ID
      from odata.supentry_scp_pcl_grant_credit_apply t2
	  left join (select loan_contract_no
	                   ,max(iou_no) as iou_no
				   from odata.supacct_enterprise_loan_info 
				  where data_date='${DATA_DATE}' 
                    and bddw_end_date='9999-99-99'
                    and product_type='110150'
				  group by loan_contract_no) t1
	    on t1.loan_contract_no = t2.apply_no
      left join odata.sym_mb_acct t3
        on t1.iou_no = t3.cmisloan_no
       and t3.data_date='${DATA_DATE}'
       and t3.bddw_end_date='9999-99-99'
      left join odata.sym_cif_client t4
        on t3.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
	  left join odata.sym_cif_client_document t5
        on t3.client_no = t5.client_no
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
       and t5.pref_flag='Y' 
	  left join odata.uquam_ps_product_limit t6
        on t6.document_id = t5.document_id
	   and t6.credit_order_no = t2.apply_no
       and t6.data_date='${DATA_DATE}'
       and t6.bddw_end_date='9999-99-99'
	  left join odata.supacct_enterprise_loan_info t7
	    on t1.iou_no = t7.iou_no
	   and t7.data_date='${DATA_DATE}' 
       and t7.bddw_end_date='9999-99-99'
	   and t7.product_type='110150'
     where t2.data_date='${DATA_DATE}' 
       and t2.bddw_end_date='9999-99-99'
       and t3.lead_acct_flag='N' --是否主账户 
	   and t3.prod_type='110150' 
