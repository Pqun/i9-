--2.yuguorui.dwd_d_indv_credit_cont_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：个人授信合同表基塔石.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2022-03-21
--直属经理：方杰
--来源表  :odata.order_main_loan_order            订单主表
--来源表  :odata.order_credit_order_info          授信信息表
--来源表  :odata.order_custom_info                客户信息表
--来源表  :odata.order_order_audit_operation_log  订单审核操作日志记录表
--来源表  :odata.sllv_mb_acct                     账户基本信息表
--来源表  :odata.sym_cif_client                   客户信息表
--来源表  :odata.sym_cif_client_document          客户证件信息
--来源表  :odata.sso_upms_user                    历史流程实例表
--目标表  :dwd.dwd_d_indv_credit_cont_p
--修改历史：
--          1.于国睿   2022-03-21    新建  
--          2.于国睿   2022-04-08    新增洋钱罐自营产品
--          3.于国睿   2022-05-10    调整客户号，第三方流水号逻辑
--          4.于国睿   2022-07-14    从额度中心判断额度失效状态 
--          5.于国睿   2022-08-29    增加老板花，锡望贷-易起投产品 
--          6.于国睿   2022-12-13    增加锡锡贷-哈啰贷产品
--          7.于国睿   2023-02-06    增加饿了么产品
--          8.于国睿   2023-03-21    增加51半自营产品
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_indv_credit_cont_p partition(data_date='${DATA_DATE}',prod_code)
     select  /* REPARTITION(1) */ 
             ''                                       as     credit_app_no        --授信申请号
            ,nvl(t1.loan_id,'')                       as     credit_cont_no       --授信合同号
            ,'01'                                     as     cust_type            --客户类型
            ,nvl(t11.client_no,'')                    as     cust_id              --客户号
            ,nvl(t8.user_name,'')                     as     cust_name            --客户姓名
            ,case when t1.sub_product_type = 14
                  then '锡锡贷'
                  when t1.sub_product_type = 16
                  then '大鹅贷消费'
                  when t1.sub_product_type = 15
                  then '大鹅贷经营'
                  when t1.sub_product_type in (17,18)
                  then '锡望贷-铁甲'
                  when t1.sub_product_type = 19
                  then '洋钱罐自营'
                  when t1.sub_product_type = 12
                  then '老板花标准助贷'
                  when t1.sub_product_type = 21
                  then '锡望贷-易起投'
                  when t1.sub_product_type = 22
                  then '锡望贷-家电汇'
                  when t1.sub_product_type = 24
                  then '锡惠贷个人融'
                  when t1.sub_product_type = 26
                  then '锡锡贷-霖梓H5'
                  when t1.sub_product_type = 28
                  then '锡锡贷-哈啰贷'
                  when t1.sub_product_type = 31
                  then '饿了么消费贷'
                  when t1.sub_product_type = 32
                  then '饿了么经营贷'
                  when t1.sub_product_type = 33
                  then '锡锡贷-51半自营'
                  when t1.sub_product_type = 35
                  then '小赢拒量'
              end                                     as     prod_name            --产品名称
            ,nvl(t1.product_type,'')                  as     biz_prod_code        --源业务系统产品名称
            ,nvl(t1.sub_product_type,'')              as     biz_sub_prod_code    --源业务系统子产品号
            ,nvl(t5.document_type,'101')              as     cert_type            --证件类型
            ,coalesce(t5.document_id,t8.id_card,'')   as     cert_no              --证件号码
            ,case when t1.status in (1,2)   --申请中，审批中
                  then '001'
                  when t1.status = 3   --授信成功，授信失效
                  then '003'
                  when t1.status in (4,6)        --审批失败 
                  then '002'
                  else ''
              end                                     as     credit_app_status    --授信申请状态
            ,case when t1.status = 3 and (t12.effective_status = 2 or t12.credit_order_no is null)  --于国睿 20220714 update 从额度中心判断额度失效
                  then '104'
                  when t1.status in (1,2)   --申请中，审批中
                  then '101'
                  when t12.effective_status in (1,3)
                  then '103'
                  when t1.status in (4,6)
                  then '102'
                  else ''                              
              end                                     as     credit_cont_status   --授信合同状态
            ,'2'                                      as     cycle_flag           --循环标识   
            ,'CNY'                                    as     ccy                  --币种
            ,coalesce(t13.target_total_limit,t1.credit_amount,0)            as     credit_limit         --授信额度
            ,coalesce(round(months_between(substr(t13.limit_end_time,1,10),substr(t13.limit_begin_time,1,10)),0),t1.credit_period,'')   as     credit_terms          --授信期限
            ,'M'                                      as     credit_term_type     --授信期限类型
            ,coalesce(substr(t13.limit_begin_time,1,10),substr(t1.credit_start_time,1,10),'') as     credit_start_date    --授信起始日期
            ,coalesce(substr(t13.limit_end_time,1,10),substr(t1.credit_end_time,1,10),'')  as     credit_mature_date   --授信到期日期
            ,case when t1.status = 3 and (t12.effective_status = 2 or t12.credit_order_no is null)  
                  then '02'
                  when t12.effective_status in (1,3) 
                  then '01' --有效
                  else ''
              end                                     as     credit_status        --授信状态
            ,substr(t1.apply_time,1,10)               as     app_date             --申请日期
            ,nvl(t7.realname,'')                      as     approver             --审批人  --应该获取不到
            ,nvl(t6.process_result,'')                as     approve_opinion      --审批意见(得物，颐而信授信订单在日志表里无审批流程)
            ,'2'                                      as     loan_biz_class       --业务分类
            ,nvl(t10.seq_no,'')                       as     third_party_app_no   --第三方流水号
            ,nvl(t14.loan_rate*100,0)                 as     loan_rate            --贷款年利率
            ,''                                       as     credit_manage_status --授信处理状态
            ,''                                       as     ip 
            ,''                                       as     device_id
            ,''                                       as     project_id
            ,case when t1.sub_product_type = 14
                  then '110105'
                  when t1.sub_product_type = 16
                  then '110152'
                  when t1.sub_product_type = 15
                  then '110153'
                  when t1.sub_product_type in (17,18)
                  then '110151'
                  when t1.sub_product_type = 19
                  then '110154'
                  when t1.sub_product_type = 12
                  then '110144'
                  when t1.sub_product_type = 21
                  then '110156'
                  when t1.sub_product_type = 22
                  then '110158'
                  when t1.sub_product_type = 24
                  then '110160'
                  when t1.sub_product_type = 26
                  then '110161'
                  when t1.sub_product_type = 28
                  then '110168'
                  when t1.sub_product_type = 31
                  then '110171'
                  when t1.sub_product_type = 32
                  then '110170'
                  when t1.sub_product_type = 33
                  then '110172'
                  when t1.sub_product_type = 35
                  then '110175'
              end                     as     prod_code            --产品编号 --有空，核心产品划分较细，未走到放款获取不到产品号
      from odata.order_main_credit_order t1
      left join (select  credit_order_id
                        ,min(loan_id)  as loan_id
                   from odata.order_main_loan_order
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and order_type = 2
                   -- and sub_product_type in(12,14,15,16,17,18,19,21,22,24)
                    and status in (7,8,15)
                  group by credit_order_id
                          ,product_model
                ) t2 --取授信下一笔有效借据用于关联核算取核心客户号及产品号
        on t1.loan_id = t2.credit_order_id
      left join odata.sllv_mb_acct t3
        on t2.loan_id = t3.cmisloan_no
       and t3.data_date='${DATA_DATE}'
       and t3.bddw_end_date='9999-99-99'
      left join odata.sym_cif_client t4
        on t3.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
      left join odata.sym_cif_client_document t5
        on t3.client_no = t5.client_no
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
      left join (select  loan_id
                        ,processor
                        ,case when process_result = 1  then '通过'
                              when process_result = 2  then '回退'
                              when process_result = -1 then '拒绝'
                              when process_result = -2 then '取消'
                          end     as process_result
                        ,row_number() over(partition by loan_id order by process_time desc) as seq 
                   from odata.order_order_audit_operation_log 
                  where data_date='${DATA_DATE}' 
                    and bddw_end_date='9999-99-99'
                ) t6
        on t1.loan_id=t6.loan_id  
       and t6.seq=1
      left join odata.sso_upms_user t7 
        on t6.processor=t7.user_id 
       and t7.data_date='${DATA_DATE}' 
       and t7.bddw_end_date='9999-99-99'
      left join odata.order_custom_info t8
        on t1.loan_id=t8.loan_id
       and t8.data_date='${DATA_DATE}' 
       and t8.bddw_end_date='9999-99-99'
      left join odata.order_contract_sign t9
        on t1.loan_id = t9.loan_id
       and t9.data_date='${DATA_DATE}'
       and t9.bddw_end_date='9999-99-99'
       and t9.contract_type=23
      left join (select loan_id
                       ,max(seq_no) as seq_no
                   from odata.order_process_monitoring
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and business_type = 1
                  group by loan_id) t10
        on t1.loan_id = t10.loan_id
      left join odata.uc_um_participant_user t11
        on t11.user_id = t1.user_id
       and t11.data_date='${DATA_DATE}'
       and t11.bddw_end_date='9999-99-99'
      left join odata.uquam_ps_product_limit t12
        on t12.credit_order_no = t1.loan_id
       and t12.data_date='${DATA_DATE}'
       and t12.bddw_end_date='9999-99-99'
      left join(select row_number()over(partition by credit_order_no order by create_time desc)rn,
                       limit_type,
                       credit_order_no,
                       target_total_limit,
                       limit_begin_time,
                       limit_end_time
                  from odata.uquam_ps_product_limit_change  
                 where data_date='${DATA_DATE}'
                   and bddw_end_date ='9999-99-99') t13
        on t1.loan_id = t13.credit_order_no 
       and t13.rn = 1
      left join odata.order_product_loan_info t14 
        on t2.loan_id = t14.loan_id   
       and t14.data_date = '${DATA_DATE}' 
       and t14.bddw_end_date = '9999-99-99'
     where t1.data_date='${DATA_DATE}'
       and t1.bddw_end_date='9999-99-99'
      -- and t1.sub_product_type in(12,14,15,16,17,18,19,21,22)
       and substr(t1.apply_time,1,10) <= '${DATA_DATE}'
       and t1.sub_product_type <> 25
