--2.ygr.个人授信合同表-网贷
--脚本名称：授信合同表dwd.dwd_d_indv_credit_cont_p取数逻辑.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2021-11-20
--直属经理：方杰
--来源表:odata.ols_crd_app_info                 授信申请表
--来源表:odata.ols_crd_un_app_info              联合贷授信申请表
--来源表:odata.ols_crd_un_jd_app_info           京东金条授信申请表
--来源表:odata.ols_loan_prd_info                贷款产品信息表
--来源表:odata.ols_crd_cont_info                授信合同信息表
--来源表:odata.ols_admin_sm_user                系统用户表
--目标表:dwd.dwd_d_indv_credit_cont_p
--修改历史：
--          1.于国睿   2021-11-20    新建
--          2.于国睿   2022-12-19    增加伊春联合贷产品
--          3.于国睿   2023-03-08    优先取ols_crd_cont_info的客户号
--          4.于国睿   2023-05-17    授信到期日改成直取
--          5.于国睿   2023-06-14    新增小赢张家港联合贷和微财数科助贷产品
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_indv_credit_cont_p partition(data_date='${DATA_DATE}',prod_code)
--行内网贷
     select  /*+ REPARTITION(1) */
	         nvl(t1.app_no,'')           as credit_app_no        --授信申请号
            ,nvl(t1.crd_cont_no,'')      as credit_cont_no       --授信合同号
            ,'01'                        as cust_type            --客户类型
            ,coalesce(t3.cust_id_core,t1.cust_id_core,t10.client_no,'')     as cust_id              --客户号
            ,nvl(t1.cust_name,'')        as cust_name            --客户姓名
            ,case when t1.prd_code='10071001001' and t5.crd_cont_no is not null 
			      then '洋钱罐联合贷'
				  when t1.prd_code='10071001001' and t7.crd_cont_no is not null 
			      then '张家港联合贷二期'
				  when t1.prd_code='10071001001' and t8.crd_cont_no is not null 
			      then '伊春联合贷'
				  when t1.prd_code='10061001001' and t9.crd_cont_no is not null 
				  then '小赢张家港联合贷'
				  else nvl(t2.prd_name,'')
              end       				 as prod_name            --产品名称
            ,nvl(t1.prd_code,'')         as biz_prod_code        --源业务系统产品号
            ,''                          as biz_sub_prod_code    --源业务系统子产品号(网贷无)
            ,nvl(t1.cert_type,'')        as cert_type            --证件类型
            ,nvl(t1.cert_code,'')        as cert_no              --证件号码
            ,nvl(t1.app_status,'')       as credit_app_status    --授信申请状态
            ,nvl(t3.cont_status,'')           as credit_cont_status   --授信合同状态
            ,case when t1.cycle_flag='Y'  
                  then '1'
                  when t1.cycle_flag='N'  
                  then '0'  
                  else ''
              end                        as     cycle_flag           --循环标识   
            ,'CNY'                       as     ccy                  --币种
            ,nvl(t3.crd_amt,0)           as     credit_limit         --授信额度
            ,nvl(case when t1.app_term='000300'
                      then '3'
                      when t1.app_term='000600'
                      then '6'
                      when t1.app_term='000900'
                      then '9'
                      when t1.app_term='010000'
                      then '1'
                      when t1.app_term='030000'
                      then '3'
                      when t1.app_term='990000'
                      then '99'
                  end,'0'
                 )                       as     credit_term          --授信期限
            ,case when t1.app_term in('000300','000600','000900')
                  then 'M'
                  when t1.app_term in('010000','030000','990000')
                  then 'Y'
                  else ''
              end                        as     credit_term_type     --授信期限类型
            ,nvl(t3.crd_start_date,t1.input_date)   as     credit_start_date    --授信起始日期
            ,nvl(t3.crd_end_date,'')     as     credit_mature_date   --授信到期日期
            ,case when t3.cont_status in ('103','105') 
                  then '01' 
                  else '02' 
              end                        as     credit_status        --授信状态
            ,nvl(t1.app_date,'')         as     app_date             --申请日期
            ,case when t3.prd_code='10151001001' then '杨柳'    --萨摩耶授信员工号为空
                  when t3.biz_manager_id='xs0116' then '包科红'  --小花分期查出来为空
                  else nvl(t4.user_name,'') 
              end                        as     approver             --审批人  --应该获取不到
            ,''                          as     approve_opinion      --审批意见
            ,'1'                         as     loan_biz_class       --业务分类 
            ,nvl(t1.tp_no,'')            as     third_party_app_no   --第三方流水号
            ,nvl(t3.appr_year_rate,0)    as     loan_rate            --贷款年利率
            ,nvl(t1.manage_status,'')    as     credit_manage_status     --处理状态
			,nvl(t6.af_ip_address,'')    as     ip 
            ,''                          as     device_id  --设备ID
			,''                          as     project_id
            ,case when t1.prd_code='10011001003' then '110104'
                  when t1.prd_code='10151001001' then '110139'
                  when t1.prd_code='10101001001' then '110117'  
                  when t1.prd_code='10091004003' then '110132'
                  when t1.prd_code='10091001001' then '110114'
                  when t1.prd_code='10091004002' then '110128'
                  when t1.prd_code='10121001001' then '110131'
                  when t1.prd_code='10031001001' then '110106'
                  when t1.prd_code='10131001001' then '110133'
                  when t1.prd_code='10051001001' then '110109'
                  when t1.prd_code='10081001001' then '110111'
                  when t1.prd_code='10111001001' then '110126'
                  when t1.prd_code='10061001001' then '110112'
                  when t1.prd_code='10071001001' and t5.crd_cont_no is null and t7.crd_cont_no is null and t8.crd_cont_no is null then '110113'  
				  when t1.prd_code='10071001001' and t5.crd_cont_no is not null then '110135'
                  when t1.prd_code='10071001001' and t7.crd_cont_no is not null then '110169'
                  when t1.prd_code='10071001001' and t8.crd_cont_no is not null then '110174'				  
                  when t1.prd_code='10181001001' then '110148'
                  when t1.prd_code='10171001001' then '110147'  
                  when t1.prd_code='10161001001' then '110141'  
                  when t1.prd_code in ('10091004','10091004007') then '110145'
                  when t1.prd_code='10091004004' then '110142'
                  when t1.prd_code='10051001002' then '110149'
				  when t1.prd_code='10061001002' then '110164'
				  when t1.prd_code='10191001001' then '110167'
				  when t1.prd_code='10061001001' and t9.crd_cont_no is not null then '110176'
				  when t1.prd_code='10201001001' then '110177'
              end                        as prod_code                --产品编号 --有空，核心产品划分较细，未走到放款获取不到产品号
       from odata.ols_crd_app_info t1
       left join odata.ols_loan_prd_info t2
         on t1.prd_code=t2.loan_no
        and t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
       left join odata.ols_crd_cont_info t3
         on t1.crd_cont_no=t3.crd_cont_no
        and t3.data_date='${DATA_DATE}'
        and t3.bddw_end_date='9999-99-99'
       left join odata.ols_admin_sm_user  t4
         on case when t3.prd_code='10151001001' then 'xs0094'
                 when t3.biz_manager_id='xs0179' and '${DATA_DATE}'>='2021-07-09' then 'xs0251'
                 else t3.biz_manager_id 
             end = t4.login_code
        and t4.data_date='${DATA_DATE}' 
        and t4.bddw_end_date='9999-99-99'
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10071001001'     
                     and financial_id = 'DXAL'       --洋钱罐大兴安岭 
					 ) t5
		 on t1.crd_cont_no = t5.crd_cont_no
	   left join odata.ols_rat_decision_dcl_address t6
         on t3.app_no = t6.business_no
        and t6.data_date = '${DATA_DATE}' 
        and t6.bddw_end_date = '9999-99-99'
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10071001001'     
                     and financial_id = 'ZJG'       --张家港联合贷二期
					 ) t7
		 on t1.crd_cont_no = t7.crd_cont_no
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10071001001'     
                     and financial_id = 'yichun'       --伊春联合贷
					 ) t8
		 on t1.crd_cont_no = t8.crd_cont_no
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10061001001'     
                     and financial_id = 'ZJG'       --小赢张家港联合贷
					 ) t9
		 on t1.crd_cont_no = t9.crd_cont_no
	   left join odata.sym_cif_client_document t10
         on t1.cert_code = t10.document_id
        and t10.pref_flag = 'Y'   --是否首选地址
        and t10.data_date = '${DATA_DATE}'
        and t10.bddw_end_date = '9999-99-99'
      where t1.data_date = '${DATA_DATE}' 
        and t1.bddw_end_date='9999-99-99' 
        and substr(t1.input_time,1,10)<='${DATA_DATE}'
        and t1.prd_code <> '10021001001' --剔除迁移前的锡锡贷自营数据
     union all
--行外网贷
     select  nvl(t1.app_no,'')           as credit_app_no        --授信申请号
            ,nvl(t1.crd_cont_no,'')      as credit_cont_no       --授信合同号
            ,'01'                        as cust_type            --客户类型
            ,coalesce(t3.cust_id_core,t1.cust_id_core,t7.client_no,'')     as cust_id              --客户号
            ,nvl(t1.cust_name,'')        as cust_name            --客户姓名
            ,nvl(t2.prd_name,'')		 as prod_name            --产品名称
            ,nvl(t1.prd_code,'')         as biz_prod_code        --源业务系统产品号
            ,''                          as biz_sub_prod_code    --源业务系统子产品号(网贷无)
            ,nvl(t1.cert_type,'')        as cert_type            --证件类型
            ,nvl(t1.cert_code,'')        as cert_no              --证件号码
            ,nvl(t1.app_status,'')       as credit_app_status    --授信申请状态
            ,nvl(t3.cont_status,'')      as credit_cont_status   --授信合同状态
            ,case when t1.cycle_flag='Y'  
                  then '1'
                  when t1.cycle_flag='N'  
                  then '0'  
                  else ''
              end                        as     cycle_flag           --循环标识   
            ,'CNY'                       as     ccy                  --币种
            ,nvl(t3.crd_amt,0)           as     credit_limit         --授信额度
            ,nvl(case when t1.app_term='000300'
                      then '3'
                      when t1.app_term='000600'
                      then '6'
                      when t1.app_term='000900'
                      then '9'
                      when t1.app_term='010000'
                      then '1'
                      when t1.app_term='030000'
                      then '3'
                      when t1.app_term='990000'
                      then '99'
                  end,'0'
                 )                       as     credit_term          --授信期限
            ,case when t1.app_term in('000300','000600','000900')
                  then 'M'
                  when t1.app_term in('010000','030000','990000')
                  then 'Y'
                  else ''
              end                        as     credit_term_type     --授信期限类型
            ,nvl(t3.crd_start_date,t1.input_date)   as     credit_start_date    --授信起始日期
            ,nvl(t3.crd_end_date,'')     as     credit_mature_date   --授信到期日期
            ,case when t3.cont_status in ('103','105') 
                  then '01' 
                  else '02' 
              end                        as     credit_status        --授信状态
            ,nvl(t1.app_date,'')         as     app_date             --申请日期
            ,nvl(t4.user_name,'')        as     approver             --审批人  
            ,''                          as     approve_opinion      --审批意见
            ,'1'                         as     loan_biz_class       --业务分类 
            ,nvl(t1.tp_no,'')            as     third_party_app_no   --第三方流水号
            ,nvl(t3.appr_year_rate,0)    as     loan_rate            --贷款年利率
            ,nvl(t1.manage_status,'')    as     credit_manage_status     --处理状态
			,nvl(t6.af_ip_address,'')    as     ip 
            ,''                          as     device_id  --设备ID
			,''                          as     project_id
            ,case when t1.prd_code='10011001003' then '110104'
                  when t1.prd_code='10151001001' then '110139'
                  when t1.prd_code='10101001001' then '110117'  
                  when t1.prd_code='10091004003' then '110132'
                  when t1.prd_code='10091001001' then '110114'
                  when t1.prd_code='10091004002' then '110128'
                  when t1.prd_code='10121001001' then '110131'
                  when t1.prd_code='10031001001' then '110106'
                  when t1.prd_code='10131001001' then '110133'
                  when t1.prd_code='10051001001' then '110109'
                  when t1.prd_code='10081001001' then '110111'
                  when t1.prd_code='10111001001' then '110126'
                  when t1.prd_code='10061001001' then '110112'	  
                  when t1.prd_code='10181001001' then '110148'
                  when t1.prd_code='10171001001' then '110147'  
                  when t1.prd_code='10161001001' then '110141'  
                  when t1.prd_code in('10091004','10091004007') then '110145'
                  when t1.prd_code='10091004004' then '110142'
                  when t1.prd_code='10051001002' then '110149'
				  when t1.prd_code='10061001002' then '110164'
				  when t1.prd_code='10091001002' then '110162'
				  when t1.prd_code='10191001001' then '110167'
              end                        as prod_code                --产品编号 --有空，核心产品划分较细，未走到放款获取不到产品号
       from odata.ols_crd_un_app_info t1
       left join odata.ols_loan_prd_info t2
         on t1.prd_code=t2.loan_no
        and t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
       left join odata.ols_crd_cont_info t3
         on t1.crd_cont_no=t3.crd_cont_no
        and t3.data_date='${DATA_DATE}'
        and t3.bddw_end_date='9999-99-99'
       left join odata.ols_admin_sm_user  t4
         on case when t3.prd_code='10151001001' then 'xs0094'
                 when t3.biz_manager_id='xs0179' and '${DATA_DATE}'>='2021-07-09' then 'xs0251'
                 else t3.biz_manager_id 
             end = t4.login_code
        and t4.data_date='${DATA_DATE}' 
        and t4.bddw_end_date='9999-99-99'
	   left join odata.ols_rat_decision_dcl_address t6
         on t3.app_no = t6.business_no
        and t6.data_date = '${DATA_DATE}' 
        and t6.bddw_end_date = '9999-99-99'
	   left join odata.sym_cif_client_document t7
         on t1.cert_code = t7.document_id
        and t7.pref_flag = 'Y'   --是否首选地址
        and t7.data_date = '${DATA_DATE}'
        and t7.bddw_end_date = '9999-99-99'
      where t1.data_date = '${DATA_DATE}' 
        and t1.bddw_end_date='9999-99-99' 
        and substr(t1.input_time,1,10)<='${DATA_DATE}'
        and t1.prd_code <> '10021001001' --剔除迁移前的锡锡贷自营数据
	 union all
--京东金条
     select  nvl(t1.app_no,'')           as credit_app_no        --授信申请号
            ,nvl(t1.crd_cont_no,'')      as credit_cont_no       --授信合同号
            ,'01'                        as cust_type            --客户类型
            ,coalesce(t3.cust_id_core,t1.cust_id_core,'')     as cust_id              --客户号
            ,nvl(t1.user_name,'')        as cust_name            --客户姓名
            ,nvl(t2.prd_name,'')		 as prod_name            --产品名称
            ,nvl(t1.prd_code,'')         as biz_prod_code        --源业务系统产品号
            ,''                          as biz_sub_prod_code    --源业务系统子产品号(网贷无)
            ,nvl(t1.cert_type,'')        as cert_type            --证件类型
            ,nvl(t1.cert_no,'')        as cert_no              --证件号码
            ,nvl(t1.app_status,'')       as credit_app_status    --授信申请状态
            ,nvl(t3.cont_status,'')      as credit_cont_status   --授信合同状态
            ,case when t1.cycle_flag='Y'  
                  then '1'
                  when t1.cycle_flag='N'  
                  then '0'  
                  else ''
              end                        as     cycle_flag           --循环标识   
            ,'CNY'                       as     ccy                  --币种
            ,nvl(t3.crd_amt,0)           as     credit_limit         --授信额度
            ,nvl(case when t1.app_term='000300'
                      then '3'
                      when t1.app_term='000600'
                      then '6'
                      when t1.app_term='000900'
                      then '9'
                      when t1.app_term='010000'
                      then '1'
                      when t1.app_term='030000'
                      then '3'
                      when t1.app_term='990000'
                      then '99'
                  end,'0'
                 )                       as     credit_term          --授信期限
            ,case when t1.app_term in('000300','000600','000900')
                  then 'M'
                  when t1.app_term in('010000','030000','990000')
                  then 'Y'
                  else ''
              end                        as     credit_term_type     --授信期限类型
            ,nvl(t3.crd_start_date,t1.input_date)   as     credit_start_date    --授信起始日期
            ,nvl(t3.crd_end_date,'')     as     credit_mature_date   --授信到期日期
            ,case when t3.cont_status in ('103','105') 
                  then '01' 
                  else '02' 
              end                        as     credit_status        --授信状态
            ,nvl(t1.app_date,'')         as     app_date             --申请日期
            ,nvl(t4.user_name,'')        as     approver             --审批人  
            ,''                          as     approve_opinion      --审批意见
            ,'1'                         as     loan_biz_class       --业务分类 
            ,''                          as     third_party_app_no   --第三方流水号
            ,nvl(t3.appr_year_rate,0)    as     loan_rate            --贷款年利率
            ,nvl(t1.manage_status,'')    as     credit_manage_status     --处理状态
			,nvl(t6.af_ip_address,'')    as     ip 
            ,''                          as     device_id    --设备ID
			,''                          as     project_id
            ,'110104'                    as     prod_code    --产品编号 
       from odata.ols_crd_un_jd_app_info t1
       left join odata.ols_loan_prd_info t2
         on t1.prd_code=t2.loan_no
        and t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
       left join odata.ols_crd_cont_info t3
         on t1.crd_cont_no=t3.crd_cont_no
        and t3.data_date='${DATA_DATE}'
        and t3.bddw_end_date='9999-99-99'
       left join odata.ols_admin_sm_user  t4
         on case when t3.prd_code='10151001001' then 'xs0094'
                 when t3.biz_manager_id='xs0179' and '${DATA_DATE}'>='2021-07-09' then 'xs0251'
                 else t3.biz_manager_id 
             end = t4.login_code
        and t4.data_date='${DATA_DATE}' 
        and t4.bddw_end_date='9999-99-99'
	   left join odata.ols_rat_decision_dcl_address t6
         on t3.app_no = t6.business_no
        and t6.data_date = '${DATA_DATE}' 
        and t6.bddw_end_date = '9999-99-99'
      where t1.data_date = '${DATA_DATE}' 
        and t1.bddw_end_date='9999-99-99' 
        and substr(t1.input_time,1,10)<='${DATA_DATE}'
		and t1.business_type = 'JT'
        and t1.prd_code <> '10021001001' --剔除迁移前的锡锡贷自营数据
		--目前网贷产品：
        --            '110104'	--个人消费贷款-京东金条
		--	         ,'110106'	--霖梓贷
        --           ,'110109'	--还享借
        --           ,'110111'	--小花钱包
        --           ,'110112'	--小赢易贷
        --           ,'110113'	--洋钱罐借款
        --           ,'110114'	--有钱花贷款
        --           ,'110117'	--人品贷
        --           ,'110126'	--小米消费贷款
        --           ,'110128'	--度小满债转贷款
        --           ,'110131'	--即有钱
        --           ,'110132'	--百度虚拟卡贷款
        --           ,'110133'	--你我贷
        --           ,'110135'	--洋钱罐联合贷
        --           ,'110139'	--萨摩耶助贷
        --           ,'110141'	--万达标准助贷
        --           ,'110142'	--张家港联合贷
        --           ,'110145'	--百度周转贷
        --           ,'110147'	--拍拍贷标准助贷
        --           ,'110148'	--时光分期标准助贷
        --           ,'110149'	--数禾标准助贷
        --           ,'110164'	--小赢经营贷
        --           ,'110169'  --张家港联合贷二期
        --           ,'110174'  --伊春联合贷
		--           ,'110167'  --维信金科助贷
		--           ,'110162'  --百度满意贷兜底
		--           ,'110176'  --小赢张家港联合贷
		--           ,'110177'  --微财数科助贷
       
       
       
       
       
       
       
       
       
       
       
       
       
       
