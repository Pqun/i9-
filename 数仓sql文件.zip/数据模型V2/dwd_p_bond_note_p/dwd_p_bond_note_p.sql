--2.gaoyuan.dwd.dwd_p_bond_note_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：债券基础信息表.sql
--功能描述：生成每日结果数据并插入hive dwd层dwd_p_bond_note_p分区表
--作    者：华天顺
--开发日期：2022-09-09
--直属经理：方杰
--来源表  ：odata.tb_v_security
--来源表  ：odata.bond_security_extra
--来源表  ：odata.tb_v_security_rating
--目标表  ：dwd.dwd_p_bond_note_p
--修改历史：
--          1.华天顺   2022-09-09    新建
--          2.吴镇宇   2023-05-16    利率类型逻辑调整
--          3.高源     2023-08-25    新增首次付息日字段、重新定价频率字段
--          4.姚威     2023-11-07    新增债券细类字段、是否私募债字段、市场类别字段、选择权类别字段、
--                                   到期兑付日期字段
---------------------------------------------------------------------------------------------------------

insert overwrite table dwd.dwd_p_bond_note_p partition (data_date = '${DATA_DATE}')
         select  /*+ REPARTITION(1) */
                 t1.security_code                                             as bond_id            --债券编码
                ,t1.security_name                                             as bond_name          --债券名称
                ,t1.ccy                                                       as ccy                --币种代码
                ,'100000'                                                     as org_id             --行内机构代码
                ,t1.issuer                                                    as issuer_name        --发行人名称
                ,nvl(t4.rating,'')                                            as issuer_rating      --发行人主体评级
                ,''                                                           as issuer_type        --发行人主体类别
                ,case when t1.security_type = '1' then 'GB03'  --国债
                      when t1.security_type = '4' then 'CB01'  --企业债
                      when t1.security_type = '8' then 'FB00'  --政策性银行
                      when t1.security_type = 'E' then 'CB03'  --公司债
                      when t1.security_type = 'G' then 'PRB'  --项目收益债
                      when t1.security_type = 'L' and t1.security_name = '泛海1A' then 'ABS01'
                      when t1.security_type = 'L' and t1.security_name <> '泛海1A' then 'ABN'
                      when t1.security_type = 'M' and t2.local_government_classify = 'G' then 'GB041'  --地方政府一般债券
                      when t1.security_type = 'M' and t2.local_government_classify = 'S' then 'GB042'  --地方政府专项债券
                      when t1.security_type = 'N' and t1.security_name like '%PPN%' then 'PPN'
                      else  ''   --中期票据
                      end                                                     as bond_type          --债券品种
                ,t1.org_term                                                  as org_term           --原始合约期限
                ,t1.org_term_mult                                             as term_type          --期限类型
                ,nvl(t3.rating,'')                                            as invest_prod_rating --债劵评级代码
                ,t1.number_issued*100000000                                   as bond_amt           --债券发行本金
--                ,case when t1.rate_type in ('0','3') then 'RF01'
--                      when t1.rate_type in ('1','2','4','5') then 'RF02'
--                  end                                                         as rate_type        --利率类型
                ,nvl(t1.rate_type,'')                                         as rate_type          --利率类型        update wuzhenyu 20230516
                ,case when t1.day_count = '1' then '3'
                      when t1.day_count = '0' then '2' 
                      when t1.day_count = '2' then '6' 
                      when t1.day_count = '5' then '1' 
                      when t1.day_count = '3' then '8' 
                      when t1.day_count = '4' then '9'
                      else '7'
                  end                                                         as int_basis          --计息基础
                ,t1.coupon_freq                                               as int_freq           --计息频率
                ,t1.payment_freq                                              as repay_freq         --付息频率
                ,t1.fixed_rate                                                as bond_rate          --债券票面利率
                ,t1.aution_price                                              as bond_price         --债券发行价格
                ,from_unixtime(unix_timestamp(t1.issue_date,'yyyyMMdd'),'yyyy-MM-dd')                     
				                                                              as issuer_date        --发行日期
                ,from_unixtime(unix_timestamp(t1.start_coupon_date,'yyyyMMdd'),'yyyy-MM-dd')              
				                                                              as accr_date          --起息日
                ,from_unixtime(unix_timestamp(t1.stop_trade_date,'yyyyMMdd'),'yyyy-MM-dd')                
				                                                              as stop_trade_date    --停止流通日
                ,t1.collateral_id                                             as guar_obj_type      --担保品
				,from_unixtime(unix_timestamp(t1.fcoupon_date,'yyyyMMdd'),'yyyy-MM-dd')                   
				                                                              as first_repay_int_date   --首次付息日
				,t1.fixing_freq                                               as reprice_freq       --重定价频率
				,nvl(t1.security_type,'')                                     as bond_sub_type 
				--债券细类
				,nvl(t1.prcb_flag, '')                                        as is_private
				--是否私募债
				,nvl(t1.market_type, '')                                      as  market_type
				--市场类别
				,nvl(t1.option_type, '')                                      as option_type
				--选择权类别
				,from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')
				                                                              as bond_mature_date
				--到期兑付日期
          from  odata.tb_v_security t1 
          left join  odata.bond_security_extra t2
                 on  t1.security_code = trim(t2.security_code)
                and  t2.data_date = '${DATA_DATE}'
                and  t2.bddw_end_date = '9999-99-99'
          left join  (
                          select 
                                  rat1.security_code
                                 ,trim(rat2.rating) as rating
                           from  (
                                      select 
                                              max(rating_date) as rating_date
                                             ,security_code
                                       from  odata.tb_v_security_rating
                                      where  data_date = '${DATA_DATE}'
                                        and  bddw_end_date = '9999-99-99'
                                   group by  security_code
                                  )rat1
                           inner join  odata.tb_v_security_rating rat2
                             on  rat1.rating_date = rat2.rating_date
                            and  rat1.security_code = rat2.security_code
                            and  rat2.data_date = '${DATA_DATE}'
                            and  rat2.bddw_end_date = '9999-99-99'
                         )t3
                 on  t1.security_code = t3.security_code
          left join  (
                          select 
                                  *
                                 ,row_number() over (partition by issuer_name_zh order by rating_date desc)  as rn
                           from  odata.tb_v_issuer_rating
                          where  data_date = '${DATA_DATE}'
                            and  bddw_end_date = '9999-99-99'
                      )t4
                 on  t1.issuer = t4.issuer_name_zh
                 and  t4.rn = 1
         where  t1.data_date = '${DATA_DATE}'
           and  t1.bddw_end_date = '9999-99-99'