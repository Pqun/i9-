--2.zhanglijuan.dwd.dwd_e_depo_tran_list_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：存款交易流水取数逻辑.sql
--功能描述：生成每日结果数据并插入dwd.dwd_e_depo_tran_list_p
--作    者：张礼娟
--开发日期：2021-03-11
--直属经理：方杰
--来源表  ：odata.sym_mb_acct            账户基本信息表
--来源表  ：odata.sym_mb_tran_hist            交易流水表
--来源表  ：odata.sym_mb_tran_hist_hist       交易流水表
--来源表  ：odata.sym_cif_client         客户信息表
--来源表  ：odata.sym_mb_tran_hist_def        交易类型定义表
--来源表  ：odata.sym_mb_prod_type       产品类型定义表
--来源表  ：odata.sym_gl_prod_accounting 产品科目表
--来源表  ：odata.sym_mb_acct_attach     产品科目表
--来源表  ：odata.upp_t_txn_collection
--来源表  ：odata.upp_t_txn_payment
--来源表  ：odata.bp_cm_tran_comm 统一流水信息表
--来源表  ：odata.fp_fp_tran_info 金融交易流水表
--来源表  ：odata.fp_cm_tran_comm 统一流水信息表
--来源表  ：odata.sym_mb_acct_doss 久悬户登记簿表
--来源表  ：odata.sym_mb_acct_doss_hist 久悬户登记簿历史表 
--目标表  ：dwd.dwd_e_depo_tran_list_p
--修改历史：
--  1.张礼娟   2021-03-11    新建
--  2.张礼娟   2021-03-15    修改交易日期字段格式处理方法，从from_unixtime(unix_timestamp改为substr
--  3.华天顺   2021-04-26    新增同业存款流水，新增客户类型代码及账户虚实标志
--  4.方杰     2021-06-16    biz_type修改成prod_type, 增加prod_class字段
--  5.华天顺   2021-06-21    修改科目代码取数逻辑
--  6.华天顺   2021-07-09    新增交易状态
--  7.华天顺   2022-03-14    新增交易附言、交易对手行号、交易前余额、交易参考号
--  8.华天顺   2022-04-12    新增转久悬户流水
--  9.张礼娟  2022-10-27     
--      修改 acct_real_flag	账户虚实标志 码值Y N 转化为 1 0
--      prod_type 业务类型 变更字段英文名为 prod_code
--      tran_chan 交易渠道 变更字段英文名为 tran_channel_id
--      org 机构代码 变更字段英文名为 org_id
--      cust_type_code 客户类型代码 变更字段英文名为 cust_type
--      co_id 合作方标识 变更字段英文名为 partner_id
--      counter_acct	中文名由“对方帐号/卡号”修改为“对方账号/卡号” 
--      counter_bank_name	中文名由“交易对手行名称”修改为“交易对手名称”
--      xsbank_counter_acct	中文名由“xsbank对方帐号/卡号”修改为“xsbank对方账号/卡号”
--      新增字段：交易描述tran_desc，ip，mac，imei
--  10.张礼娟  2022-11-17   修改科目代码取数逻辑，因存放同业科目代码为空
--  11.张礼娟  2022-12-13   新增字段：渠道类型source_type
--  12.张礼娟  2023-07-25   新增字段：交易类型描述tran_type_desc
--  13.张礼娟  2023-08-22   新增字段：交易后余额
--  14.张礼娟  2023-09-19   修复ip mac逻辑逻辑关联缺陷问题，特别注意不加reparations
--  15.张礼娟  2023-10-07   修改客户类型逻辑
--  16.高源    2023-10-09   久悬户借贷标志逻辑调整、账户序列号逻辑调整，新增源模块字段
--  17.彭群    2023-10-31   新增交易介质号字段、调整交易时间逻辑
--  18.颜华    2024-01-01   新增对方账户标识字段的取数逻辑
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_depo_tran_list_p partition(data_date='${DATA_DATE}')
	select  
			 a1.seq_no                                 as tran_seqno                     --交易流水号                                         
			,a1.channel_seq_no                         as chan_seqno                     --渠道流水号                                         
			,a1.internal_key                           as cont_no                        --协议号                                                
			,a2.base_acct_no                           as acct_no                        --账号                                                  
			,a2.acct_seq_no                            as acct_seq_no                    --账户序列号                                        
			,a1.client_no                              as cust_id                        --客户号                                                
			,a1.prod_type                              as prod_code                      --业务类型                                            
			,substr(a1.tran_date,1,10)                 as tran_date                      --交易日期                                            
			,nvl(a1.tran_time,'')                      as tran_time                      --交易时间                                           
			,a1.cr_dr_maint_ind                        as debit_flag                     --借贷标志                                           
			,a1.source_type                            as tran_channel_id                --交易渠道                                            
			,a1.ccy                                    as ccy                            --币种                                                      
			,a1.tran_amt                               as tran_amt                       --交易金额                                             
			,case when a5.cash_tran='Y' then '1'                                                                                                      
				when a5.cash_tran='N' then '0'                                                                  
				else a5.cash_tran                                                                                                                   
				end                                    as cash_flag                      --现金转账标识   --Y代表现金，N为转账，A为不区分是否现金                                      
			,a1.tran_type                              as tran_type                      --交易类型                                            
			,a1.branch                                 as org_id                         --机构代码                                                  
			,a1.user_id                                as tran_ltr                       --交易柜员号                                           
			,a1.auth_user_id                           as crdt_ltr                       --授权柜员号                                           
			,a1.reversal_tran_type                     as corr_tran_type                 --冲正交易类型                                   
			,from_unixtime(unix_timestamp(a1.reversal_date,'yyyymmdd'),'yyyy-mm-dd') 
			                                           as corr_date                      --冲正日期                                           
			,a1.reversal                               as corr_flag                      --冲正标志                                            
			,coalesce(a17.gl_code,a14.gl_code_l,a15.gl_code_l,a16.gl_code_l)                    
			                                           as subj_no                        --科目代码                                              
			,a1.narrative                              as abst                           --摘要                                                     
			,nvl(a1.oth_branch      ,'')               as xsbank_counter_acct_open_org   --xsbank对方账户开户机构    
			,nvl(a1.oth_bank_name   ,'')               as xsbank_counter_bank_name       --xsbank对方银行名称            
			,nvl(a1.oth_base_acct_no,'')               as xsbank_counter_acct            --xsbank对方账号/卡号                
			,nvl(a1.oth_acct_desc   ,'')               as xsbank_counter_acct_name       --xsbank对方账户名称            
			,a1.doc_type                               as vouch_type                     --凭证类型                                           
			,a1.voucher_no                             as vouch_no                       --凭证号                                               
			,a1.program_id                             as tran_code                      --交易码                                              
			,''                                        as commit_cust_name               --代办人客户名称                               
			,''                                        as commit_cust_id                 --代办人证件号码                                 
			,''                                        as part_adv_draw_flag             --部分提前支取标志                           
		    ,a1.client_type                            as cust_type                      --客户类型代码          --20231007update                                
			,nvl(a1.acct_real_flag,'')                 as acct_real_flag                 --账户虚实标志                                   
			,a1.partner_id                             as partner_id                     --合作方编码                                              
			,a1.tran_status                            as tran_status                    --交易状态                                          
			,nvl(a1.oth_bank_code,'')                  as xsbank_counter_bank_code       --xsbank交易对手行号                   
			,a6.prod_class                             as prod_class                     --产品类别                                           
			,nvl(a1.tran_note,'')                      as tran_note                      --交易附言                                           
			,a1.previous_bal_amt                       as prev_bal                       --交易前余额                                           
			,a1.reference                              as reference                      --交易参考号                                          
			,nvl(a1.contra_acct_no  ,'')               as counter_acct                   --对方账号/卡号                            
			,nvl(a1.contra_acct_name,'')               as counter_acct_name              --对方账户名称                        
			,nvl(a1.contra_bank_code,'')               as counter_bank_code              --交易对手行号                        
			,nvl(a1.contra_bank_name,'')               as counter_bank_name              --交易对手名称    
			,a1.tran_desc                              as tran_desc                      -- 交易描述
			,a18.ip                                    as ip                             -- ip
			,a18.mac_value                             as mac_value                      -- mac
			,a18.imei_value                            as imei_value                     -- imei 
			,a5.source_type                            as source_type                    --渠道类型
			,a5.tran_type_desc                         as tran_type_desc                 --交易类型描述  20230725新增	
			,a1.actual_bal_amt                         as tran_bal                       --交易后余额  20230822新增	
			,nvl(a1.source_module,'')                  as source_module                  --源模块     --update20231013
			,nvl(a1.base_acct_no,'')                   as tran_medium_no                 --交易介质号    --update20231031
			,nvl(a1.oth_internal_key,'')			   as oth_internal_key               --对方账户标识  --update20240101 yh
	from odata.sym_mb_tran_hist a1
	left join odata.sym_mb_acct a2
		on  a1.internal_key = a2.internal_key 
		and a2.data_date='${DATA_DATE}'
		and a2.bddw_end_date='9999-99-99' 
	left join odata.sym_mb_tran_def a5
		on a1.tran_type = a5.tran_type
		and a5.data_date='${DATA_DATE}' 
		and a5.bddw_end_date='9999-99-99' 
	left join odata.sym_cif_client  a3
		on a1.client_no=a3.client_no
		and a3.data_date='${DATA_DATE}' 
		and a3.bddw_end_date='9999-99-99' 
	left join odata.sym_mb_prod_type a6
		on a1.prod_type = a6.prod_type
		and a6.data_date='${DATA_DATE}' 
		and a6.bddw_end_date='9999-99-99'
	left join odata.sym_gl_prod_accounting a14 --获取科目号、科目名称
		on a1.prod_type = a14.prod_type
		and a1.accounting_status = a14.accounting_status
		and a3.category_type = a14.tran_category
		and a14.data_date='${DATA_DATE}'
		and a14.bddw_end_date='9999-99-99'
	left join odata.sym_gl_prod_accounting a15
		on a1.prod_type = a15.prod_type
		and a1.accounting_status = a15.accounting_status
		and a15.tran_category = 'ALL'
		and a15.data_date='${DATA_DATE}'
		and a15.bddw_end_date='9999-99-99'
	left join odata.sym_gl_prod_accounting a16
		on a1.prod_type = a16.prod_type
		and a16.tran_category = 'ALL'
		and a16.accounting_status = 'ALL'
		and a16.data_date='${DATA_DATE}'
		and a16.bddw_end_date='9999-99-99' 
	left join odata.sym_mb_acct_attach a17
		on a1.internal_key = a17.internal_key
		and a17.data_date = '${DATA_DATE}'
		and a17.bddw_end_date = '9999-99-99'
	left join 
	(
		select distinct
			seq_no             --交易流水号                                         
			,channel_seq_no    --渠道流水号  
			,ip
			,mac_value
			,imei_value    
		from
		(		--二类户充值
			select 
				   a1.seq_no            --交易流水号                                         
				  ,a1.channel_seq_no    --渠道流水号  
				  ,a3.ip
				  ,a3.mac_value
				  ,a3.imei_value    
			from odata.sym_mb_tran_hist a1
			inner join  odata.upp_t_txn_collection a2
				on a1.channel_seq_no=a2.host_no
				and a2.mcht_no='M000000001' 
				and a2.status='00'  --00成功 01失败 02处理中
				and a2.data_date='${DATA_DATE}' 
				and a2.bddw_end_date='9999-99-99'  
			left join odata.bp_cm_tran_comm a3
				on a2.tran_no=a3.source_ref_no
				and a3.service_code='MBSD_BP_EA' 
				and a3.message_type='1000' 
				and a3.message_code in ('0301','4001')   --'0301'手机银行充值,'4001'三方充值
				and a3.ret_code='000000'   --交易成功  
				and a3.data_date='${DATA_DATE}' 
				and a3.bddw_end_date='9999-99-99' 
			where a1.data_date='${DATA_DATE}'
				and  a1.bddw_end_date='9999-99-99'
				and  a1.source_module in ('RB','GL')
			union all 
			--二类户提现，一类户转账
			select 
				   a1.seq_no             --交易流水号                                         
				  ,a1.channel_seq_no    --渠道流水号  
				  ,a3.ip
				  ,a3.mac_value
				  ,a3.imei_value    
			from odata.sym_mb_tran_hist a1
			inner join  odata.upp_t_txn_payment a2
				on a1.channel_seq_no=a2.host_no
				and a2.mcht_no='M000000001' 
				and a2.status='00'  --00成功 01失败 02处理中
				and a2.biz_kind in ('120015','120016')  --聚合支付 120015 提现 120016转账
				and a2.data_date='${DATA_DATE}' 
				and a2.bddw_end_date='9999-99-99'  
			left join odata.bp_cm_tran_comm a3
				on a2.tran_no=a3.source_ref_no
				and a3.service_code='MBSD_BP_EA' 
				and a3.message_type='1000' 
				and a3.message_code in ('0302','0305','0303')   --'0302'手机银行提现,'0305'三方提现,'0303'转账
				and a3.ret_code='000000'   --交易成功  
				and a3.data_date='${DATA_DATE}' 
				and a3.bddw_end_date='9999-99-99' 
			where a1.data_date='${DATA_DATE}'
				and  a1.bddw_end_date='9999-99-99'
				and  a1.source_module in('RB','GL')
			union all 
			--定期 购买,支取
			select 
				    a1.seq_no             --交易流水号                                         
				   ,a1.channel_seq_no     --渠道流水号  
				   ,a3.ip
				   ,a3.mac_value
				   ,a3.imei_value    
			from odata.sym_mb_tran_hist a1
			inner join  odata.fp_fp_tran_info a2
				on a1.channel_seq_no=a2.main_seq_no
				and a2.tran_type in ('FP1001','FP1002') --FP1001 购买,FP1002支取
				and a2.data_date='${DATA_DATE}' 
				and a2.bddw_end_date='9999-99-99'  
			left join odata.fp_cm_tran_comm a3
				on a2.front_seqno=a3.source_ref_no
				and a3.service_code='MBSD_IFP_FP' 
				and a3.message_type='1000' 
				and a3.message_code in ('0405','3001','0402','3002') --'0405'手机银行购买,'3001'三方购买,'0402'手机银行支取,'3002'三方支取
				and a3.ret_code='000000'   --交易成功  
				and a3.data_date='${DATA_DATE}' 
				and a3.bddw_end_date='9999-99-99' 
			where a1.data_date='${DATA_DATE}'
				and   a1.bddw_end_date='9999-99-99'
				and   a1.source_module in('RB','GL')
		)b1   --20230919修改
	)a18
		on a1.seq_no = a18.seq_no
		and a1.channel_seq_no = a18.channel_seq_no
	where a1.data_date='${DATA_DATE}'
		and   a1.bddw_end_date='9999-99-99'
		and   a1.source_module in ('RB','GL')  --'RB'存款,'GL'内部
union all
	select  
			 t1.seq_no
			,''
			,t1.internal_key
			,t1.base_acct_no
			,t3.acct_seq_no                         --20231009update
			,t3.client_no
			,t1.prod_type
			,from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd')
			,nvl(t1.tran_time,'' )       as tran_time                 --交易时间 20231031update  
			,case  when  t1.operate_type  ='DS'  then   'D'                 --DSB不动户转久
			       when  t1.operate_type  in ('SA','SC','SO')  then  'C'    --SA久悬户激活 SC久悬户销户 SO久悬户转营业外
			       end                               --20231009update
			,'020101'
			,t1.ccy
			,t1.por_int_tot
			,'0'
			,'STC'                  --(转久悬)
			,t1.tran_branch
			,t1.user_id
			,t1.auth_user_id
			,''
			,''
			,''
			,a16.gl_code_l
			,''
			,''
			,''
			,''
			,''
			,''
			,''
			,''
			,''
			,''
			,''
			,t3.client_type
			,t3.acct_real_flag
			,''
			,''
			,''
			,a6.prod_class
			,''
			,''
			,t2.reference                  --交易参考号
			,''                           
			,''                           
			,''                           
			,''                           
			,''                            -- 交易描述
			,''                            -- ip
			,''                            -- mac
			,''                            -- imei
			,''         as source_type     --渠道类型
			,''         as tran_type_desc  --交易类型描述  20230725新增	
			,'0'        as tran_bal        --交易后余额  20230822新增	
	        ,nvl(t3.source_module,'')                    as source_module            --源模块        --update20231013
			,nvl(nvl(t3.card_no,t1.base_acct_no),'')     as tran_medium_no           --交易介质号    --update20231031
			,''					                         as oth_internal_key		 --对方账户标识  --update20240101 yh
	from  odata.sym_mb_acct_doss_hist t1
	left join  odata.sym_mb_acct_doss t2
		on  t1.internal_key = t2.internal_key
		and  t2.data_date = '${DATA_DATE}'
		and  t2.bddw_end_date = '9999-99-99'
	left join  odata.sym_mb_acct t3
		on  t1.internal_key = t3.internal_key
		and  t3.data_date = '${DATA_DATE}'
		and  t3.bddw_end_date = '9999-99-99'
	left join  odata.sym_mb_prod_type a6
		on  t1.prod_type = a6.prod_type
		and  a6.data_date='${DATA_DATE}' 
		and  a6.bddw_end_date='9999-99-99' 
	left join  odata.sym_gl_prod_accounting a16
		on  t1.prod_type = a16.prod_type
		and  a16.tran_category = 'ALL'
		and  a16.accounting_status = 'ZHC'
		and  a16.data_date = '${DATA_DATE}'
		and  a16.bddw_end_date = '9999-99-99'
	where  t1.data_date = '${DATA_DATE}'
	  and  t1.bddw_end_date = '9999-99-99'