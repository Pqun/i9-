--2.ygr.个人授信合同得物颐尔信
--脚本名称：dwd_d_indv_credit_cont_p.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2022-08-25
--直属经理：方杰
--来源表  :odata.order_main_loan_order            订单主表
--来源表  :odata.order_credit_order_info          授信信息表
--来源表  :odata.order_custom_info                客户信息表
--来源表  :odata.order_order_audit_operation_log  订单审核操作日志记录表
--来源表  :odata.sllv_mb_acct                     账户基本信息表
--来源表  :odata.sym_cif_client                   客户信息表
--来源表  :odata.sym_cif_client_document          客户证件信息
--来源表  :odata.sso_upms_user                    历史流程实例表
--目标表  :dwd.dwd_d_indv_credit_cont_p   
--修改历史：
--          1.于国睿   2022-08-25    新建  
---------------------------------------------------------------------------------------------------------------
--大额锡望贷
insert overwrite table dwd.dwd_d_indv_credit_cont_p partition(data_date='${DATA_DATE}',prod_code)
    select /* REPARTITION(1) */
          ''                                        as credit_app_no          --授信申请号
          ,coalesce(t1.contract_no,'')              as credit_cont_no         --授信合同编号
          ,'01'                                     as cust_type              --客户类型
          ,nvl(t4.client_no,'')                     as cust_id                --客户号
          ,nvl(t5.client_short,'')                  as cust_name              --客户姓名
          ,nvl(t12.prod_desc,'')                    as prod_name              --产品名称
          ,'10'                                     as biz_prod_code          --源业务系统产品名称
          ,'13'                                     as biz_sub_prod_code      --源业务系统子产品号
          ,nvl(t6.document_type,'')                 as cert_type              --证件类型
          ,coalesce(t6.document_id,'')              as cert_no                --证件号码
          ,case when t14.status in (1,2,19)       
                then '001'  --申请中，审批中
                when t14.status in (4,5,6,7,8,9,13,14,15,16,17,18)     
                then '003'  --审批成功
                when t14.status in (11,12)         
                then '002'  --审批失败 
                else ''
            end                                     as credit_app_status      --授信申请状态
          ,case when t14.status in (1,2,14) 
                then '101'  --合同未签订
                when t14.status in (11,12) 
                then '102'  --审批作废
                when t10.effective_status in (1,3)
                then '103'  --额度生效
                when t14.status in (4,5,6,7,8,9,13,15,16,17,18) and (t10.effective_status = 2 or t10.credit_order_no is null)
                then '104'  --额度失效
                else ''
            end                                     as credit_cont_status     --授信合同状态
          ,case when t3.limit_type = 1 then '0' --单次
                when t3.limit_type = 2 then '1' --循环
                when t14.product_model = 1 then '0'
                when t14.product_model = 2 then '1'
                else ''
            end                                     as cycle_flag             --循环标识
          ,'CNY'                                    as ccy                    --币种
          ,coalesce(t3.target_total_limit,t1.effect_limit,0)             as credit_limit           --授信额度
          ,coalesce(round(months_between(substr(t3.limit_end_time,1,10),substr(t3.limit_begin_time,1,10)),0),round(months_between(t1.invalid_date,t1.quota_start_date),0),'') as credit_terms  --授信期限
          ,'M'                                      as credit_term_type       --授信期限类型
          ,coalesce(substr(t3.limit_begin_time,1,10),regexp_replace(t1.quota_start_date,'/','-'),'') as credit_start_date      --授信起始日期
          ,coalesce(substr(t3.limit_end_time,1,10),regexp_replace(t1.quota_start_date,'/','-'),'')   as credit_mature_date     --授信到期日期
          ,case when t10.effective_status = 2  
                then '02'
                when t10.effective_status in (1,3) 
                then '01' --有效
                when t10.credit_order_no is null  --不在产品额度表的授信订单为失效
                then '02'
                else ''
            end                                     as credit_status          --授信状态
          ,nvl(substr(t14.apply_time,1,10),'')      as credit_app_date        --申请日期
          ,''                                       as approver               --审批人
          ,''                                       as approve_opinion        --审批意见
          ,'2'                                      as loan_biz_class         --业务分类
          ,nvl(t14.apply_no,'')                      as third_party_app_no     --第三方申请流水号
          ,nvl(t9.loan_rate*100,0)                  as loan_rate              --贷款年利率(年%)
          ,''                                       as credit_manage_status   --授信处理状态
          ,''                                       as ip 
          ,''                                       as device_id
          ,''                                       as project_id
          ,nvl(t11.prod_type,'')                    as prod_code 
      from (select contract_no,
                   customer_number,
                   is_loop,
                   effect_limit,
                   quota_start_date,
                   invalid_date,
                   quota_status,
                   normal_interest_rate,
                   row_number() over(partition by contract_no order by create_time desc) as rn
              from odata.order_xwd_credit
             where data_date = '${DATA_DATE}'
               and bddw_end_date = '9999-99-99') t1
      left join (select loan_no
                       ,credit_contract_no
                       ,row_number() over(partition by credit_contract_no order by etl_date desc) as seq 
                   from odata.order_xwd_loandetail
                  where data_date = '${DATA_DATE}'
                    and bddw_end_date = '9999-99-99') t13 
        on t1.contract_no = t13.credit_contract_no
       and t13.seq = 1
      left join odata.order_main_loan_order t14
        on t13.loan_no = t14.loan_id
       and t14.data_date = '${DATA_DATE}' 
       and t14.bddw_end_date = '9999-99-99'
      left join(select row_number()over(partition by credit_order_no order by create_time desc)rn,
                       limit_type,
                       credit_order_no,
                       target_total_limit,
                       limit_begin_time,
                       limit_end_time
                  from odata.uquam_ps_product_limit_change  
                 where data_date='${DATA_DATE}'
                   and bddw_end_date ='9999-99-99') t3
        on t1.contract_no = t3.credit_order_no 
       and t3.rn = 1
      left join odata.uc_um_participant_user t4
        on t4.user_id = t14.user_id
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99' 
      left join odata.sym_cif_client t5
        on t5.client_no = t4.client_no
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
      left join odata.sym_cif_client_document t6
        on t4.client_no = t6.client_no
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
      left join odata.order_product_loan_info t9
        on t14.loan_id = t9.loan_id   
       and t9.data_date = '${DATA_DATE}' 
       and t9.bddw_end_date = '9999-99-99'
      left join odata.uquam_ps_product_limit t10
        on t10.credit_order_no = t1.contract_no
       and t10.data_date='${DATA_DATE}'
       and t10.bddw_end_date='9999-99-99' 
      left join odata.slur_acc_duebill_info t11
        on t14.loan_id = t11.loan_id
       and t11.data_date = '${DATA_DATE}' 
       and t11.bddw_end_date = '9999-99-99'
      left join odata.sym_mb_prod_type t12
        on t11.prod_type = t12.prod_type
       and t12.data_date = '${DATA_DATE}' 
       and t12.bddw_end_date = '9999-99-99'
     where t1.rn = 1
      
