--2.ygr.个人授信合同表-特色业务
--脚本名称：个人授信合同表特色业务.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2022-09-06
--直属经理：方杰
--目标表: dwd.dwd_d_indv_credit_cont_p
--来源表: odata.order_main_loan_order            订单主表
--来源表: odata.order_order_audit_operation_log  订单审核操作日志记录表
--来源表: odata.sso_upms_user                    历史流程实例表
--来源表: odata.uc_um_participant_user           参与人表
--来源表: odata.sllv_mb_acct                     账户基本信息表
--来源表: odata.order_audit_result_info          审批结果信息录入 
--来源表: odata.order_product_loan_info          产品贷款合同表
--修改历史：
--          1.于国睿   2022-09-06    新建
--          2.于国睿   2023-02-03    修改循环标识逻辑
--          3.于国睿   2023-06-19    修改授信额度，授信申请状态，授信合同状态，授信起始日，授信到期日，授信期限，申请日期逻辑
---------------------------------------------------------------------------------------------------------------
--特色业务(锡机贷，锡房贷，锡车贷，锡望贷-上牌车，锡望贷-非上牌车,孚厘,锡惠贷,乐花借钱,长安新生)
insert overwrite table dwd.dwd_d_indv_credit_cont_p_test_20230620 partition(data_date='${DATA_DATE}',prod_code)

    select /* REPARTITION(1) */
           ''                                       as credit_app_no          --授信申请号
          ,nvl(t1.loan_id,'')                       as credit_cont_no         --授信合同编号
          ,'01'                                     as cust_type              --客户类型
          ,nvl(t2.client_no,'')                     as cust_id                --客户号
          ,nvl(t3.client_short,'')                  as cust_name              --客户姓名
          ,nvl(t5.prod_desc,'')                     as prod_name              --产品名称
          ,nvl(t1.product_type,'')                  as biz_prod_code          --源业务系统产品名称
          ,nvl(t1.sub_product_type,'')              as biz_sub_prod_code      --源业务系统子产品号
          ,nvl(t7.document_type,'')                 as cert_type              --证件类型
          ,coalesce(t7.document_id,'')              as cert_no                --证件号码
          ,case when t1.status in (1,2,19)       
                then '001'  --申请中，审批中
                when t1.status in (4,5,6,7,8,9,13,14,15,16,17,18)     
                then '003'  --审批成功
                when t1.status in (11,12)         
                then '002'  --审批失败 
                else ''
            end                                     as credit_app_status      --授信申请状态
          ,case when t1.status in (1,2,14,19) 
                then '101'  --合同未签订
                when t1.status in (11,12) 
                then '102'  --审批作废
                when t8.effective_status in (1,3)
                then '103'  --额度生效
                when t1.status in (4,5,6,7,8,9,13,15,16,17,18) and (t8.effective_status = 2 or t8.credit_order_no is null)
                then '104'  --额度失效
                else ''
            end                                     as credit_cont_status     --授信合同状态
          ,case when t8.limit_type = 1 then '0'
                when t8.limit_type = 2 then '1'
                when t1.product_model = 1 then '0'
                when t1.product_model = 2 then '1'
                else ''
            end                                     as cycle_flag             --循环标识
          ,'CNY'                                    as ccy                    --币种
          ,nvl(t8.total_limit,0)                    as credit_limit           --授信额度
          ,nvl(round(months_between(substr(t8.limit_end_time,1,10),substr(t8.limit_begin_time,1,10)),0),'')  as credit_terms           --授信期限
          ,'M'                                      as credit_term_type       --授信期限类型
          ,nvl(substr(t8.limit_begin_time,1,10),'') as credit_start_date      --授信起始日期
          ,nvl(substr(t8.limit_end_time,1,10),'')   as credit_mature_date     --授信到期日期
          ,case when t8.effective_status = 2  
                then '02'
                when t8.effective_status in (1,3) 
                then '01' --有效
                when t8.credit_order_no is null  --不在产品额度表的授信订单为失效
                then '02'
                else ''
            end                                     as credit_status          --授信状态
          ,nvl(substr(t1.apply_time,1,10),'')      as credit_app_date        --申请日期
          ,''                                       as approver               --审批人
          ,''                                       as approve_opinion        --审批意见
          ,'2'                                      as loan_biz_class         --业务分类
          ,nvl(t1.apply_no,'')                      as third_party_app_no     --第三方申请流水号
          ,nvl(t11.loan_rate*100,0)                 as loan_rate              --贷款年利率(年%)
          ,''                                       as credit_manage_status   --授信处理状态
          ,''                                       as ip 
          ,''                                       as device_id
          ,''                                       as project_id
          ,nvl(t4.prod_type,t9.prod_type)           as prod_code
      from odata.order_main_loan_order t1  
      left join odata.uc_um_participant_user t2
        on t2.user_id = t1.user_id
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99' 
      left join odata.sym_cif_client t3
        on t3.client_no = t2.client_no
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
      left join odata.sllv_mb_acct t4
        on t1.loan_id = t4.cmisloan_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
      left join odata.sym_mb_prod_type t5
        on t4.prod_type = t5.prod_type
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
      left join odata.sym_cif_client_document t7
        on t2.client_no = t7.client_no
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
      left join odata.uquam_ps_product_limit t8
        on t8.credit_order_no = t1.loan_id
       and t8.data_date='${DATA_DATE}'
       and t8.bddw_end_date='9999-99-99'
      left join odata.sllv_nl_acct t9
        on t1.receipt_no = t9.cmisloan_no
       and t9.data_date = '${DATA_DATE}'
       and t9.bddw_end_date = '9999-99-99'
      left join odata.order_product_loan_info t11 
        on t1.loan_id = t11.loan_id   
       and t11.data_date = '${DATA_DATE}' 
       and t11.bddw_end_date = '9999-99-99'
     where t1.data_date = '${DATA_DATE}' 
       and t1.bddw_end_date = '9999-99-99'
       and t1.order_type = 2
       and t1.sub_product_type in (1,2,3,4,5,7,8,9,23,27,29,30)
      