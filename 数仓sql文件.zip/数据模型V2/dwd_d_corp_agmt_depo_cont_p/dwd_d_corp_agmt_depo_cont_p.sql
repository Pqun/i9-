-------------------------------------------------------------------
--脚本名称:dwd_d_corp_agmt_depo_cont_p
--功能描述:对公协定存款协议表
--作    者:华天顺
--开发日期:2022-03-21
--直属经理:程宏明
--目标表  :dwd.dwd_d_corp_agmt_depo_cont_p 
--数据原表:   odata.sym_mb_agreement         协议信息表
--            odata.sym_mb_agreement_accord             
--修改历史:
--         1、华天顺     2022-03-21    新建
-------------------------------------------------------------------

insert overwrite table dwd.dwd_d_corp_agmt_depo_cont_p partition (data_date='${DATA_DATE}')

     select /*+ REPARTITION(1) */
             t1.agreement_id       as agmt_no     --协定协议号
            ,t2.seq_no             as agmt_seq_no --协定协议序号
            ,t1.agreement_type     as cont_type   --协议类型
            ,from_unixtime(unix_timestamp(t1.start_date,'yyyyMMdd'),'yyyy-MM-dd')         as start_date  --生效日期
            ,from_unixtime(unix_timestamp(t1.end_date,'yyyyMMdd'),'yyyy-MM-dd')           as end_date    --终止日期
            ,t1.base_acct_no       as acct_no     --账号
            ,t1.acct_seq_no        as acct_seq_no --账户序列号
            ,t1.prod_type          as prod_code   --产品号
            ,t1.agreement_status   as cont_status --协议状态
            ,t2.near_amt           as near_amt    --靠档金额
            ,t2.int_class          as int_cate    --利息分类
            ,t2.int_type           as rate_type   --利率类型
            ,t2.real_rate          as exec_rate   --执行利率

      from  odata.sym_mb_agreement t1
 left join  odata.sym_mb_agreement_accord t2
        on  t1.agreement_id = t2.agreement_id
       and  t2.data_date = '${DATA_DATE}'
       and  t2.bddw_end_date = '9999-99-99'
     where  t1.data_date = '${DATA_DATE}'
       and  t1.bddw_end_date = '9999-99-99'
       and  t1.agreement_type = 'ACC'
