--2.yangqihao.dwd_e_indv_loan_write_off_tran_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：个人贷款核销流水表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive dwd层dwd.dwd_e_indv_loan_write_off_tran_p
--作    者：杨琦浩
--开发日期：2022-10-20
--直属经理：方杰
--来源表  ：odata.slur_acc_writeoff_detail 核销数据表
--来源表  ：odata.slur_acc_writeoff_hist 呆账核销登记表
--来源表  ：odata.sym_cif_client_document 客户证件信息
--来源表  ：odata.sym_gl_prod_accounting 产品科目表
--目标表  ：dwd.dwd_e_indv_loan_write_off_tran_p 个人贷款核销流水表
--修改历史：
--          1.杨琦浩   2022-10-20    新建
--          2.华天顺   2023-02-09    新增表内外核销利息及罚息
--          3.杨琦浩   2023-11-29    限制个贷产品
--------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_indv_loan_write_off_tran_p partition(data_date = '${DATA_DATE}')
select
/*+ REPARTITION(1) */
case when a.status='S' then b.reference else '' end as reference --交易参考号
,'100000' as org_id --机构号
,nvl(a.loan_no,'') as bill_no --借据号
,'CNY' as ccy --币种代码
,nvl(c.client_no,'') as cust_id --客户号
,substr(a.tran_date,1,10) as write_off_date --核销日期
,nvl(d.gl_code_a,'') as subj_no --科目编号
,nvl(b.prod_type,'') as prod_code --产品编号
,'SLUR' as source_systerm --来源系统
,nvl(a.status,'') as write_off_status --核销状态代码  
,nvl(a.wrn_pri_amt,0) as write_off_prin --核销本金
,nvl(wrn_int_amt_in,0)+nvl(wrn_int_amt_out,0) as write_off_int --核销利息
,nvl(wrn_odp_amt_in,0)+nvl(wrn_odp_amt_out,0) as write_off_pena --核销罚息
,nvl(wrn_int_amt_in,0)          as write_off_int_in    --表内核销利息
,nvl(wrn_int_amt_out,0)         as write_off_int_out   --表外核销利息
,nvl(wrn_odp_amt_in,0)          as write_off_pena_in   --表内核销罚息
,nvl(wrn_odp_amt_out,0)         as write_off_pena_out  --表外核销罚息
from odata.slur_acc_writeoff_detail a --核销数据表
left join odata.slur_acc_writeoff_hist b --呆账核销登记表
on a.loan_no=b.loan_no
and b.data_date='${DATA_DATE}'
and b.bddw_end_date='9999-99-99'
left join odata.sym_cif_client_document c --客户证件信息
on a.document_no=c.document_id
and c.document_type='101' --身份证
and c.pref_flag='Y' --是否首选地址
and c.data_date='${DATA_DATE}'
left join odata.sym_gl_prod_accounting d --产品科目表
on b.prod_type=d.prod_type
and d.accounting_status='ZHC'
and d.data_date='${DATA_DATE}'
and d.bddw_end_date='9999-99-99'
where a.data_date='${DATA_DATE}'
and a.bddw_end_date='9999-99-99'
and nvl(b.prod_type,'')<>'120108'