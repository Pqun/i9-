--2.yuguorui.dwd_d_indv_loan_app_p
-------------------------------------------------------------------
--脚本名称:dwd_d_indv_loan_app_p
--功能描述:个人支用申请表
--作    者:于国睿
--开发日期:2021-09-24
--直属经理:方杰
--来源表:odata.ols_loan_app_info                网贷支用申请表    
--来源表:odata.ols_loan_prd_info                产品贷款信息表
--来源表:odata.ols_rat_decision_dcl_address     决策清洗请求落地表
--来源表:odata.ols_asset_loan_cont_info         资产支用合同表 
--来源表:odata.ols_loan_un_app_info             联合贷支用申请表
--来源表:odata.ols_loan_un_jd_app_info	        京东支用申请表
--来源表:odata.order_main_loan_order            订单主表
--来源表:odata.sllv_mb_acct		                账户信息表
--来源表:odata.sym_mb_prod_type                 产品信息表
--来源表:odata.order_custom_info_ext            客户信息拓展表
--来源表:odata.sllv_nl_acct                     线上账户信息表
--目标表:dwd.dwd_d_indv_loan_app_p              
--修改历史:
--         1、于国睿     2021-09-24     新建
--         2. 于国睿     2023-03-23     新增百度满意贷兜底，维信金科产品
-------------------------------------------------------------------
--行内产品（网贷）
insert overwrite table dwd.dwd_d_indv_loan_app_p partition(data_date='${DATA_DATE}',prod_code)
select  /*+ REPARTITION(1) */
        nvl(t1.app_no,'')           as loan_app_no  --支用申请号
       ,nvl(t1.crd_cont_no,'')      as credit_cont_no  --授信申请号
	   ,nvl(t1.cust_id_core,'')     as cust_id  --客户号
	   ,nvl(t1.cust_name,'')        as cust_name  --客户名称
	   ,nvl(t5.prd_name,'')         as prod_name  --产品名称
	   ,nvl(t1.prd_code,'')         as biz_prod_code  --业务产品号
	   ,''                          as sub_biz_prod_code  --业务子产品号
	   ,nvl(t1.currency,'')         as ccy  --币种
	   ,nvl(t1.app_amt,0)           as loan_app_amt  --申请金额
	   ,nvl(t1.app_status,'')       as loan_app_status  --支用申请状态
	   ,nvl(t1.app_date,'')         as loan_app_date  --支用申请时间
	   ,'1'                         as loan_biz_class  --业务分类
	   ,nvl(t4.af_ip_address,'')    as ip 
       ,''                          as device_id
	   ,case when t1.prd_code='10011001003' then '110104'
             when t1.prd_code='10151001001' then '110139'
             when t1.prd_code='10101001001' then '110117'  
             when t1.prd_code='10091004003' then '110132'
             when t1.prd_code='10091001001' then '110114'
             when t1.prd_code='10091004002' then '110128'
             when t1.prd_code='10121001001' then '110131'
             when t1.prd_code='10031001001' then '110106'
             when t1.prd_code='10131001001' then '110133'
             when t1.prd_code='10051001001' then '110109'
             when t1.prd_code='10081001001' then '110111'
             when t1.prd_code='10111001001' then '110126'
             when t1.prd_code='10061001001' then '110112'
             when t1.prd_code='10071001001' and t6.app_no is null and t7.app_no is null and t8.app_no is null then '110113'  
		     when t1.prd_code='10071001001' and t6.app_no is not null then '110135'
             when t1.prd_code='10071001001' and t7.app_no is not null then '110169'
             when t1.prd_code='10071001001' and t8.app_no is not null then '110174'			 
             when t1.prd_code='10181001001' then '110148'
             when t1.prd_code='10171001001' then '110147'  
             when t1.prd_code='10161001001' then '110141'  
             when t1.prd_code='10091004' then '110145'
             when t1.prd_code='10091004004' then '110142'
             when t1.prd_code='10051001002' then '110149'
			 when t1.prd_code='10061001002' then '110164'
			 when t1.prd_code='10091001002' then '110162'
			 when t1.prd_code='10191001001' then '110167'
         end                as prod_code  --产品号
  from odata.ols_loan_app_info t1
  left join odata.ols_loan_prd_info t5
    on trim(t1.prd_code) = trim(t5.loan_no) 
   and t5.data_date = '${DATA_DATE}' 
   and t5.bddw_end_date = '9999-99-99'
  left join odata.ols_rat_decision_dcl_address t4
    on t1.app_no = t4.business_no
   and t4.data_date = '${DATA_DATE}' 
   and t4.bddw_end_date = '9999-99-99' 
  left join (select app_no
               from odata.ols_asset_loan_cont_info
              where data_date='${DATA_DATE}'
                and bddw_end_date='9999-99-99'
                and prd_code = '10071001001'     
                and financial_id = 'DXAL'       --洋钱罐大兴安岭 
					 ) t6
	on t1.app_no = t6.app_no
  left join (select app_no
               from odata.ols_asset_loan_cont_info
              where data_date='${DATA_DATE}'
                and bddw_end_date='9999-99-99'
                and prd_code = '10071001001'     
                and financial_id = 'ZJG'       --张家港联合贷二期
					 ) t7
	on t1.app_no = t7.app_no
  left join (select app_no
               from odata.ols_asset_loan_cont_info
              where data_date='${DATA_DATE}'
                and bddw_end_date='9999-99-99'
                and prd_code = '10071001001'     
                and financial_id = 'yichun'       --伊春联合贷
					 ) t8
	on t1.app_no = t8.app_no
 where t1.data_date = '${DATA_DATE}' 
   and t1.bddw_end_date = '9999-99-99'
   and t1.prd_code <> '10021001001'
   and t1.app_type = 2
   and t1.app_date <= '${DATA_DATE}' 
union all
--行外网贷
select  nvl(t1.app_no,'')           as loan_app_no  --支用申请号
       ,nvl(t1.crd_cont_no,'')      as credit_cont_no  --授信申请号
	   ,nvl(t1.cust_id_core,'')     as cust_id  --客户号
	   ,nvl(t1.cust_name,'')        as cust_name  --客户名称
	   ,nvl(t5.prd_name,'')         as prod_name  --产品名称
	   ,nvl(t1.prd_code,'')         as biz_prod_code  --业务产品号
	   ,''                          as sub_biz_prod_code  --业务子产品号
	   ,nvl(t1.currency,'')         as ccy  --币种
	   ,nvl(t1.app_amt,0)           as loan_app_amt  --申请金额
	   ,nvl(t1.app_status,'')       as loan_app_status  --支用申请状态
	   ,nvl(t1.app_date,'')         as loan_app_date  --支用申请时间
	   ,'1'                         as loan_biz_class  --业务分类
	   ,nvl(t4.af_ip_address,'')    as ip 
       ,''                          as device_id
	   ,case when t1.prd_code='10011001003' then '110104'
             when t1.prd_code='10151001001' then '110139'
             when t1.prd_code='10101001001' then '110117'  
             when t1.prd_code='10091004003' then '110132'
             when t1.prd_code='10091001001' then '110114'
             when t1.prd_code='10091004002' then '110128'
             when t1.prd_code='10121001001' then '110131'
             when t1.prd_code='10031001001' then '110106'
             when t1.prd_code='10131001001' then '110133'
             when t1.prd_code='10051001001' then '110109'
             when t1.prd_code='10081001001' then '110111'
             when t1.prd_code='10111001001' then '110126'
             when t1.prd_code='10061001001' then '110112'		 
             when t1.prd_code='10181001001' then '110148'
             when t1.prd_code='10171001001' then '110147'  
             when t1.prd_code='10161001001' then '110141'  
             when t1.prd_code='10091004' then '110145'
             when t1.prd_code='10091004004' then '110142'
             when t1.prd_code='10051001002' then '110149'
			 when t1.prd_code='10061001002' then '110164'
			 when t1.prd_code='10091001002' then '110162'
			 when t1.prd_code='10191001001' then '110167'
         end                as prod_code  --产品号
  from odata.ols_loan_un_app_info t1
  left join odata.ols_loan_prd_info t5
    on trim(t1.prd_code) = trim(t5.loan_no) 
   and t5.data_date = '${DATA_DATE}' 
   and t5.bddw_end_date = '9999-99-99'
  left join odata.ols_rat_decision_dcl_address t4
    on t1.app_no = t4.business_no
   and t4.data_date = '${DATA_DATE}' 
   and t4.bddw_end_date = '9999-99-99' 
 where t1.data_date = '${DATA_DATE}' 
   and t1.bddw_end_date = '9999-99-99'
   and t1.prd_code <> '10021001001'
   and t1.app_date<='${DATA_DATE}'
   and t1.app_type = 2
union all 
--特色业务
select  nvl(t1.loan_id,'')                          as loan_app_no  --支用申请号
       ,coalesce(t10.contract_no,t1.credit_order_id,t1.loan_id,'')  as credit_cont_no  --授信申请号
	   ,nvl(t8.client_no,'')                        as cust_id  --客户号
	   ,nvl(t9.client_short,'')                     as cust_name  --客户名称
	   ,coalesce(t6.prod_desc,t7.prod_desc,'')      as prod_name  --产品名称
	   ,nvl(t1.product_type,'')                     as biz_prod_code  --业务产品号
	   ,nvl(t1.sub_product_type,'')                 as sub_biz_prod_code  --业务子产品号
	   ,'CNY'                                       as ccy  --币种
	   ,nvl(t1.apply_amount,0)                      as loan_app_amt  --申请金额
	   ,case when t1.status in (1,2) then '001'     
             when t1.status=12 then '002'           
             else '003'	                            
         end 			                            as loan_app_status  --支用申请状态
	   ,nvl(t1.apply_time,'')                       as loan_app_date  --支用申请时间
	   ,'2'                                         as loan_biz_class  --业务分类
	   ,nvl(t3.ip,'')                               as ip 
       ,nvl(t3.device_id,'')                        as device_id
	   ,coalesce(t2.prod_type,t4.prod_type,'')      as prod_code  --产品号
  from odata.order_main_loan_order t1
  left join odata.sllv_mb_acct t2
    on t2.cmisloan_no=t1.loan_id 
   and t2.bddw_end_date='9999-99-99'
   and t2.data_date='${DATA_DATE}' 
  left join odata.sym_mb_prod_type t6
    on t2.prod_type=t6.prod_type
   and t6.data_date='${DATA_DATE}' 
   and t6.bddw_end_date='9999-99-99'
  left join odata.order_custom_info_ext t3
    on t1.loan_id=t3.loan_id
   and t3.data_date='${DATA_DATE}' 
   and t3.bddw_end_date='9999-99-99'
  left join odata.sllv_nl_acct t4
    on t4.cmisloan_no=t1.receipt_no 
   and t4.bddw_end_date='9999-99-99'
   and t4.data_date='${DATA_DATE}' 
  left join odata.sym_mb_prod_type t7
    on t4.prod_type=t7.prod_type
   and t7.data_date='${DATA_DATE}' 
   and t7.bddw_end_date='9999-99-99'
  left join odata.uc_um_participant_user t8
    on t8.user_id = t1.user_id
   and t8.data_date = '${DATA_DATE}'
   and t8.bddw_end_date = '9999-99-99' 
  left join odata.sym_cif_client t9
    on t9.client_no = t8.client_no
   and t9.data_date = '${DATA_DATE}'
   and t9.bddw_end_date = '9999-99-99'
  left join odata.order_contract_sign t10
    on t1.credit_order_id = t10.loan_id
   and t10.data_date='${DATA_DATE}'
   and t10.bddw_end_date='9999-99-99'
   and t10.contract_type=23
 where t1.data_date='${DATA_DATE}' 
   and t1.bddw_end_date='9999-99-99'
   and t1.apply_time<='${DATA_DATE}'
   and t1.order_type = 2
   and t1.sub_product_type <>25
