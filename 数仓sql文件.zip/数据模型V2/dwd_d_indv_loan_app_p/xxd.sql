insert overwrite table dwd.dwd_d_indv_loan_app_p partition(data_date='${DATA_DATE}',prod_code='110105')
select  nvl(t1.loan_id,'')  as loan_app_no  --支用申请号
       ,nvl(t1.credit_order_id,'')  as credit_cont_no  --授信申请号
	   ,coalesce(t7.client_no,t13.client_no,'')  as cust_id  --客户号
	   ,coalesce(t7.client_short,t4.user_name,'')  as cust_name  --客户名称
	   ,'锡锡贷'  as prod_name  --产品名称
	   ,nvl(t1.product_type,'')  as biz_prod_code  --业务产品号
	   ,nvl(t1.sub_product_type,'')  as sub_biz_prod_code  --业务子产品号
	   ,'CNY'  as ccy  --币种
	   ,nvl(t1.apply_amount,0)  as loan_app_amt  --申请金额
	   ,case when t1.status in (1,2) then '001'
             when t1.status=12 then '002'
             else '003'	
         end           as loan_app_status  --支用申请状态
	   ,nvl(t1.apply_time,'')  as loan_app_date  --支用申请时间
	   ,'2'            as loan_biz_class  --业务分类
  from odata.order_main_loan_order t1
  left join odata.sllv_mb_acct t2
    on t2.cmisloan_no=t1.loan_id 
   and t2.bddw_end_date='9999-99-99'
   and t2.data_date='${DATA_DATE}' 
  left join odata.sym_cif_client t7
    on t2.client_no=t7.client_no 
   and t7.data_date='${DATA_DATE}' 
   and t7.bddw_end_date='9999-99-99'
  left join odata.order_custom_info t4
    on t1.loan_id=t4.loan_id 
   and t4.data_date='${DATA_DATE}' 
   and t4.bddw_end_date='9999-99-99'
  left join odata.uc_um_participant_user t13
    on t1.user_id=t13.user_id
   and t13.data_date='${DATA_DATE}' 
   and t13.bddw_end_date='9999-99-99'
 where t1.data_date='${DATA_DATE}' 
   and t1.bddw_end_date='9999-99-99'
   and t1.order_type=2
   and t1.sub_product_type=14