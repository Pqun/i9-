--2.ygr.dwd_d_indv_loan_app_p--------------------------------------
--脚本名称:dwd_d_indv_loan_app_p
--功能描述:个人支用申请表
--作    者:于国睿
--开发日期:2021-09-24
--直属经理:方杰
--来源表:odata.ols_loan_app_info                网贷支用申请表    
--来源表:odata.ols_loan_prd_info                产品贷款信息表
--来源表:odata.ols_rat_decision_dcl_address     决策清洗请求落地表
--来源表:odata.ols_asset_loan_cont_info         资产支用合同表 
--来源表:odata.ols_loan_un_app_info             联合贷支用申请表
--来源表:odata.ols_loan_un_jd_app_info          京东支用申请表
--来源表:odata.order_main_loan_order            订单主表
--来源表:odata.sllv_mb_acct                     账户信息表
--来源表:odata.sym_mb_prod_type                 产品信息表
--来源表:odata.order_custom_info_ext            客户信息拓展表
--来源表:odata.sllv_nl_acct                     线上账户信息表
--目标表:dwd.dwd_d_indv_loan_app_p              
--修改历史:
--         1、于国睿     2021-09-24     新建
--         2、于国睿     2023-05-12     新增贷款细类字段
--         3、于国睿     2023-06-08     修改百度周转贷贷款业务细类逻辑
--         4、于国睿     2023-06-08     新增小赢张家港，微财数科助贷
--         5、于国睿     2023-06-12     修改信e融贷款业务细类逻辑
--         6.于国睿      2023-07-20     新增锡望贷聚盟
--         7、于国睿     2023-10-31     新增字段渠道编号
--         8、于国睿     2023-11-09     新增乐云小贷，宁波通商联合贷
--         9、姚威       2023-12-07     新增药师帮产品
--        10、姚威       2024-01-18     新增vivo维易贷产品
--        11、姚威       2023-02-01     新增小赢通商联合贷，小赢兰州联合贷
--        12、杨琦浩     2024-03-20     新增锡享贷产品
--        13、姚威       2024-03-28     修复供应链逻辑数据重复问题（行业投向）
--        14、姚威       2024-04-11     新增拍拍联合融担模式消费贷
--        15、姚威       2024-05-14     新增字节星选 
-------------------------------------------------------------------
--行内产品（网贷）
insert overwrite table dwd.dwd_d_indv_loan_app_p partition(data_date='${DATA_DATE}',prod_code)
    select  /*+ REPARTITION(1) */ 
    nvl(t1.app_no,'')                                     as loan_app_no  --支用申请号
           ,nvl(t1.crd_cont_no,'')                         as credit_cont_no  --授信申请号
           ,coalesce(t1.cust_id_core,t10.client_no,'')     as cust_id  --客户号
           ,nvl(t1.cust_name,'')                           as cust_name  --客户名称
           ,nvl(t5.prd_name,'')                            as prod_name  --产品名称
           ,nvl(t1.prd_code,'')                            as biz_prod_code  --业务产品号
           ,''                                             as sub_biz_prod_code  --业务子产品号
           ,nvl(t1.currency,'')                            as ccy  --币种
           ,nvl(t1.app_amt,0)                              as loan_app_amt  --申请金额
           ,nvl(t1.app_status,'')                          as loan_app_status  --支用申请状态
           ,nvl(t1.app_date,'')                            as loan_app_date  --支用申请时间
           ,'1'                                            as loan_biz_class  --业务分类
           ,nvl(t4.af_ip_address,'')                       as ip 
           ,''                                             as device_id
           ,case when t3.corporate_type ='01' then 'A18'
                 when t3.corporate_type ='02' then 'A17' 
                 else 'A29' 
              end               as loan_biz_detail  --贷款细类 
		   ,nvl(t1.channel_type,'')                        as channel_id  --渠道编号  update 20231031 yuguorui 新增字段
           ,case when t1.prd_code='10011001003' then '110104'
                 when t1.prd_code='10151001001' then '110139'
                 when t1.prd_code='10101001001' then '110117'  
                 when t1.prd_code='10091004003' then '110132'
                 when t1.prd_code='10091001001' then '110114'
                 when t1.prd_code='10091004002' then '110128'
                 when t1.prd_code='10121001001' then '110131'
                 when t1.prd_code='10031001001' then '110106'
                 when t1.prd_code='10131001001' then '110133'
                 when t1.prd_code='10051001001' then '110109'
                 when t1.prd_code='10081001001' then '110111'
                 when t1.prd_code='10111001001' then '110126'
                 when t1.prd_code='10071001001' and t6.app_no is null 
				                                and t7.app_no is null 
												and t8.app_no is null 
												and t13.app_no is null then '110113'  
                 when t1.prd_code='10071001001' and t6.app_no is not null then '110135'
                 when t1.prd_code='10071001001' and t7.app_no is not null then '110169'
                 when t1.prd_code='10071001001' and t8.app_no is not null then '110174'
                 when t1.prd_code='10071001001' and t13.app_no is not null then '110182'
                 when t1.prd_code='10181001001' then '110148'
                 when t1.prd_code='10171001001' then '110147'  
                 when t1.prd_code='10161001001' then '110141'  
                 when t1.prd_code in ('10091004','10091004007','10091004006','10091004005') then '110145'
                 when t1.prd_code='10091004004' then '110142'
                 when t1.prd_code='10051001002' then '110149'
                 when t1.prd_code='10061001002' then '110164'
                 when t1.prd_code='10091001002' then '110162'
                 when t1.prd_code='10191001001' then '110167'
				 when t1.prd_code='10061001001' and t11.app_no is not null then '110176'
				 when t1.prd_code='10201001001' then '110177'
				 when t1.prd_code='10211001001' then '110181'
                 when t1.prd_code='10061001001' and t14.financial_id ='NBTS'then '110185' 
                 when t1.prd_code='10061001001' and t14.financial_id ='LANZ'then '110186'
                 when t1.prd_code='10061001001' then '110112'
				 when t1.prd_code='10171001002' then '110190'
             end                as prod_code  --产品号   
      from odata.ols_loan_app_info t1
      left join odata.ols_loan_prd_info t5
        on trim(t1.prd_code) = trim(t5.loan_no) 
       and t5.data_date = '${DATA_DATE}' 
       and t5.bddw_end_date = '9999-99-99'
      left join odata.ols_rat_decision_dcl_address t4
        on t1.app_no = t4.business_no
       and t4.data_date = '${DATA_DATE}' 
       and t4.bddw_end_date = '9999-99-99' 
      left join (select app_no
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code = '10071001001'     
                    and financial_id = 'DXAL'       --洋钱罐大兴安岭 
                         ) t6
        on t1.app_no = t6.app_no
      left join (select app_no
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code = '10071001001'     
                    and financial_id = 'ZJG'       --张家港联合贷二期
                         ) t7
        on t1.app_no = t7.app_no
      left join (select app_no
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code = '10071001001'     
                    and financial_id = 'yichun'       --伊春联合贷
                         ) t8
        on t1.app_no = t8.app_no
      left join odata.ols_crd_cont_info t9
        on t1.crd_cont_no = t9.crd_cont_no  
       and t9.data_date='${DATA_DATE}'
       and t9.bddw_end_date='9999-99-99'
      left join odata.ols_biz_corporate_info t3 
        on t9.app_no = t3.app_no  
       and t3.data_date='${DATA_DATE}'
       and t3.bddw_end_date='9999-99-99'
      left join odata.sym_cif_client_document t10
        on t1.cert_code = t10.document_id
       and t10.pref_flag = 'Y'   --是否首选地址
       and t10.data_date = '${DATA_DATE}'
       and t10.bddw_end_date = '9999-99-99'
	  left join (select app_no
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code = '10061001001'     
                    and financial_id = 'ZJG'       --小赢张家港联合贷
					 ) t11
		 on t1.app_no = t11.app_no
	  left join (select app_no
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code = '10211001001'     
                    and financial_id = 'LYXD'       --乐云小贷联合贷
			    ) t12  --update yuguorui 20231109 
		on t1.app_no = t12.app_no
	  left join (select app_no
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code = '10071001001'     
                    and financial_id = 'NBTS'       --宁波通商联合贷
				) t13  --update yuguorui 20231109 
		on t1.app_no = t13.app_no
       left join (select app_no,financial_id
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code = '10061001001'     
                    and financial_id in('NBTS','LANZ')       --小赢通商联合贷--小赢兰州联合贷
				) t14   
		on t1.app_no = t14.app_no
     where t1.data_date = '${DATA_DATE}' 
       and t1.bddw_end_date = '9999-99-99'
       and t1.prd_code <> '10021001001'
       and t1.app_type = 2
       and t1.app_date <= '${DATA_DATE}' 
     union all
     --行外网贷
    select /*+ REPARTITION(1) */ 
    nvl(t1.app_no,'')           as loan_app_no  --支用申请号
           ,nvl(t1.crd_cont_no,'')      as credit_cont_no  --授信申请号
           ,coalesce(t1.cust_id_core,t6.client_no,'')     as cust_id  --客户号
           ,nvl(t1.cust_name,'')        as cust_name  --客户名称
           ,nvl(t2.prd_name,'')         as prod_name  --产品名称
           ,nvl(t1.prd_code,'')         as biz_prod_code  --业务产品号
           ,''                          as sub_biz_prod_code  --业务子产品号
           ,nvl(t1.currency,'')         as ccy  --币种
           ,nvl(t1.app_amt,0)           as loan_app_amt  --申请金额
           ,nvl(t1.app_status,'')       as loan_app_status  --支用申请状态
           ,nvl(t1.app_date,'')         as loan_app_date  --支用申请时间
           ,'1'                         as loan_biz_class  --业务分类
           ,nvl(t3.af_ip_address,'')    as ip 
           ,''                          as device_id
           ,case when t5.corporate_type ='01' then 'A18'
                 when t5.corporate_type ='02' then 'A17' 
                 when t1.prd_code = '10091004005' then 'A29'
                 when t1.prd_code = '10091004006' then 'A17'     
                 when t1.prd_code = '10091004007' then 'A18'    
                 else 'A29' 
             end                        as loan_biz_detail  --贷款细类
		   ,nvl(t1.channel_type,'')     as channel_id  --渠道编号  update 20231031 yuguorui 新增字段
           ,case when t1.prd_code='10011001003' then '110104'
                 when t1.prd_code='10151001001' then '110139'
                 when t1.prd_code='10101001001' then '110117'  
                 when t1.prd_code='10091004003' then '110132'
                 when t1.prd_code='10091001001' then '110114'
                 when t1.prd_code='10091004002' then '110128'
                 when t1.prd_code='10121001001' then '110131'
                 when t1.prd_code='10031001001' then '110106'
                 when t1.prd_code='10131001001' then '110133'
                 when t1.prd_code='10051001001' then '110109'
                 when t1.prd_code='10081001001' then '110111'
                 when t1.prd_code='10111001001' then '110126'
                 when t1.prd_code='10061001001' then '110112'        
                 when t1.prd_code='10181001001' then '110148'
                 when t1.prd_code='10171001001' then '110147'  
                 when t1.prd_code='10161001001' then '110141'  
                 when t1.prd_code in ('10091004','10091004007','10091004006','10091004005') then '110145'
                 when t1.prd_code='10091004004' then '110142'
                 when t1.prd_code='10051001002' then '110149'
                 when t1.prd_code='10061001002' then '110164'
                 when t1.prd_code='10091001002' then '110162'
                 when t1.prd_code='10191001001' then '110167'
				 when t1.prd_code='10221001001' then '110193'--字节
             end                        as prod_code  --产品号
      from odata.ols_loan_un_app_info t1
      left join odata.ols_loan_prd_info t2
        on trim(t1.prd_code) = trim(t2.loan_no) 
       and t2.data_date = '${DATA_DATE}' 
       and t2.bddw_end_date = '9999-99-99'
      left join odata.ols_rat_decision_dcl_address t3
        on t1.app_no = t3.business_no
       and t3.data_date = '${DATA_DATE}' 
       and t3.bddw_end_date = '9999-99-99' 
      left join odata.ols_crd_cont_info t4
        on t1.crd_cont_no = t4.crd_cont_no  
       and t4.data_date='${DATA_DATE}'
       and t4.bddw_end_date='9999-99-99'
      left join odata.ols_biz_corporate_info t5 
        on t4.app_no = t5.app_no  
       and t5.data_date='${DATA_DATE}'
       and t5.bddw_end_date='9999-99-99'
      left join odata.sym_cif_client_document t6
        on t1.cert_code = t6.document_id
       and t6.pref_flag = 'Y'   --是否首选地址
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
     where t1.data_date = '${DATA_DATE}' 
       and t1.bddw_end_date = '9999-99-99'
       and t1.prd_code <> '10021001001'
       and t1.app_type = 2
  -- union all
  -- --京东
  --select  nvl(t1.app_no,'')           as loan_app_no  --支用申请号
  --       ,''                          as credit_cont_no  --授信申请号
  --       ,''                          as cust_id  --客户号
  --       ,''                          as cust_name  --客户名称
  --       ,'京东金条'                  as prod_name  --产品名称
  --       ,'10011001003'               as biz_prod_code  --业务产品号
  --       ,''                          as sub_biz_prod_code  --业务子产品号
  --       ,'CNY'                       as ccy  --币种
  --       ,''                          as loan_app_amt  --申请金额
  --       ,''                          as loan_app_status  --支用申请状态
  --       ,nvl(from_unixtime(unix_timestamp(substr(t1.apply_time,1,8),'yyyyMMdd'),'yyyy-MM-dd'),'')   as loan_app_date  --支用申请时间
  --       ,'1'                         as loan_biz_class  --业务分类
  --       ,nvl(t4.af_ip_address,'')    as ip 
  --       ,''                          as device_id
  --       ,'A29'                       as loan_biz_detail  --贷款细类
  --       ,'110104'                    as prod_code  --产品号   
  --  from odata.ols_loan_un_jd_app_info t1
  --  left join odata.ols_rat_decision_dcl_address t4
  --    on t1.app_no = t4.business_no
  --   and t4.data_date = '${DATA_DATE}' 
  --   and t4.bddw_end_date = '9999-99-99' 
  -- where t1.data_date = '${DATA_DATE}' 
  --   and t1.bddw_end_date = '9999-99-99'
  --   and t1.business_type = 'JT'
     union all 
     --特色业务
    select  /*+ REPARTITION(1) */ 
    nvl(t1.loan_id,'')                          as loan_app_no  --支用申请号
           ,coalesce(t1.credit_order_id,t1.loan_id,'')  as credit_cont_no  --授信申请号
           ,nvl(t8.client_no,'')                        as cust_id  --客户号
           ,nvl(t9.client_short,'')                     as cust_name  --客户名称
           ,coalesce(t6.prod_desc,t7.prod_desc,'')      as prod_name  --产品名称
           ,nvl(t1.product_type,'')                     as biz_prod_code  --业务产品号
           ,nvl(t1.sub_product_type,'')                 as sub_biz_prod_code  --业务子产品号
           ,'CNY'                                       as ccy  --币种
           ,nvl(t1.apply_amount,0)                      as loan_app_amt  --申请金额
           ,case when t1.status in (1,2,4,13) then '001'     
                 when t1.status in (11,12,17) then '002'           
                 else '003'                             
             end                                        as loan_app_status  --支用申请状态
           ,nvl(t1.apply_time,'')                       as loan_app_date  --支用申请时间
           ,'2'                                         as loan_biz_class  --业务分类
           ,nvl(t3.ip,'')                               as ip 
           ,nvl(t3.device_id,'')                        as device_id
           ,case when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in('110151','110160') then 'A19'  --铁甲,锡惠贷个人融
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110153','110158') then 'A18'  --大额经营贷,家电汇
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110123','110134','110140','110144','110154','110155','110161','110171','110168','110163','110172') then 'A29'  
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110115','110152') and t10.loan_need_type= 2 then 'A29'
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) = '110124' then case when t10.person_business_type = 1 then 'A18'                                                                          
                                                                          when t10.person_business_type = 2 then 'A17' 
                                                                          else 'A19' 
                                                                      end 
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) ='110125' then case when t10.person_business_type = 1 then 'A18'                                                                          
                                                                         when t10.person_business_type = 2 then 'A17'                                                                          
                                                                         when t10.person_business_type in (3,4) then 'A19' 
                                                                         else '' 
                                                                     end 
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) ='110156' then case when t12.person_business_type = 1 then 'A18'                                                                          
                                                                         when t12.person_business_type = 2 then 'A17'                                                                          
                                                                         when t12.person_business_type in (3,4) then 'A19' 
                                                                         else '' 
                                                                     end 
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110116') then case when t10.loan_need_type=3 and t11.work_kind='1' then 'A18'    
                                                                             when t10.loan_need_type=3 and t11.work_kind='3' then 'A17'
                                                                             when t10.loan_need_type=3 then 'A19' 
                                                                             else ''  
                                                                         end 
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110120','110121') then case when t10.loan_need_type=3 and t13.work_kind='1' then 'A18'    
                                                                                      when t10.loan_need_type=3 and t13.work_kind='3' then 'A17'
                                                                                      when t10.loan_need_type=3 then 'A19' 
                                                                                      else ''  
                                                                                  end
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110110','110122','110129') then case when t11.work_kind='1' then 'A18'
                                                                                               when t11.work_kind in ('2','3','9') then 'A17' 
                                                                                               when t11.work_kind='10' then 'A19'
                                                                                               else '' 
                                                                                           end
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110130')  then case when t11.work_kind='1' then 'A18'
                                                                              when t11.work_kind in ('2','3','9') then 'A17' 
                                                                              when t11.work_kind='10' then 'A19'
                                                                              else ''  
                                                                          end
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110165','110166')  then case when t11.work_kind='1' then 'A18'
                                                                                       when t11.work_kind in ('2','3') then 'A17' 
                                                                                       when t11.work_kind='9' then 'A19'
                                                                                       when t11.work_kind='10' then 'A19'
                                                                                       else ''  
                                                                                   end
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110159')  then case when t11.work_kind='1' then 'A18'
                                                                              when t11.work_kind in ('2','3','9') then 'A17' 
                                                                              else ''  
                                                                          end 
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) = '110127'  then case when t10.loan_need_type=3 and t11.work_kind='1' then 'A18'
                                                                           when t10.loan_need_type=3 and t11.work_kind='3' then 'A17' 
                                                                           when t10.loan_need_type=3 then 'A19' 
                                                                           else '' 
                                                                       end 
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) = '110119'  then case when t10.loan_need_type=2 then 'A29' 
                                                                           else '' 
                                                                       end      
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) = '110118'  then case when t10.loan_need_type=3 and t11.work_kind='1' then 'A18'
                                                                           when t10.loan_need_type=3 and t11.work_kind='3' then 'A17' 
                                                                           when t10.loan_need_type=3 then 'A19' 
                                                                           else '' 
                                                                       end 
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) = '110108'  then case when t11.work_kind='1' then 'A18'
                                                                           when t11.work_kind='3' then 'A17'
                                                                           when t11.work_kind='9' then 'A19'
                                                                           else '' 
                                                                       end
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110105','110175','110183')  then 'A29'
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) = '110143'  then case when t15.loan_usage = '8' then 'A29'
                                                                                              when t15.loan_usage = '9' then 'A23'
                                                                                              else ''
                                                                                          end
                 when coalesce(t2.prod_type,t4.prod_type,t14.prod_type) in ('110173','110170','110180','110187') then case when t13.work_kind = '1' then 'A18'
				                                                                             when t13.work_kind = '3' then 'A17'
																							 when t13.work_kind in ('2','9','10') then 'A19'
																							 else ''
																						 end
                 else ''      
             end                   as loan_biz_detail --贷款业务细类
		   ,nvl(t1.channel_code,'')                     as channel_id    --渠道编号  update 20231031 yuguorui 新增字段
           ,coalesce(t2.prod_type,t4.prod_type,t14.prod_type,'')      as prod_code  --产品号
      from odata.order_main_loan_order t1
      left join odata.sllv_mb_acct t2
        on t2.cmisloan_no=t1.loan_id 
       and t2.bddw_end_date='9999-99-99'
       and t2.data_date='${DATA_DATE}' 
      left join odata.sym_mb_prod_type t6
        on t2.prod_type=t6.prod_type
       and t6.data_date='${DATA_DATE}' 
       and t6.bddw_end_date='9999-99-99'
      left join odata.order_custom_info_ext t3
        on t1.loan_id=t3.loan_id
       and t3.data_date='${DATA_DATE}' 
       and t3.bddw_end_date='9999-99-99'
      left join odata.sllv_nl_acct t4
        on t4.cmisloan_no=t1.receipt_no 
       and t4.bddw_end_date='9999-99-99'
       and t4.data_date='${DATA_DATE}' 
      left join odata.sym_mb_prod_type t7
        on t4.prod_type=t7.prod_type
       and t7.data_date='${DATA_DATE}' 
       and t7.bddw_end_date='9999-99-99'
      left join odata.uc_um_participant_user t8
        on t8.user_id = t1.user_id
       and t8.data_date = '${DATA_DATE}'
       and t8.bddw_end_date = '9999-99-99' 
      left join odata.sym_cif_client t9
        on t9.client_no = t8.client_no
       and t9.data_date = '${DATA_DATE}'
       and t9.bddw_end_date = '9999-99-99'
      left join odata.order_product_loan_info t10
        on trim(t1.loan_id)=trim(t10.loan_id) 
       and t10.data_date='${DATA_DATE}' 
       and t10.bddw_end_date='9999-99-99'  
      left join odata.order_job_info t11         
        on t1.loan_id = t11.loan_id 
       and t11.data_date='${DATA_DATE}' 
       and t11.bddw_end_date='9999-99-99'
      left join odata.order_product_loan_info t12
        on t1.credit_order_id = t12.loan_id
       and t12.data_date='${DATA_DATE}' 
       and t12.bddw_end_date='9999-99-99'  
      left join odata.order_job_info t13         
        on t1.credit_order_id = t13.loan_id 
       and t13.data_date='${DATA_DATE}' 
       and t13.bddw_end_date='9999-99-99'
      left join odata.slur_acc_duebill_info t14
        on t1.loan_id = t14.loan_id
       and t14.data_date='${DATA_DATE}'
       and t14.bddw_end_date='9999-99-99'
      left join (select withdraw_contract_no,loan_no,loan_usage
                       ,row_number() over( partition by loan_no order by modified_time desc ) as seq
                   from odata.order_xwd_loandetail
                  where data_date = '${DATA_DATE}' 
                    and bddw_end_date = '9999-99-99') t15
        on t14.loan_id = t15.loan_no 
       and t15.seq=1
     where t1.data_date='${DATA_DATE}' 
       and t1.bddw_end_date='9999-99-99'
       and t1.order_type = 2
       and t1.sub_product_type not in ('25','42','44')
     union all
      --信e融110150、药师帮110184
    select  /*+ REPARTITION(1) */ 
    nvl(t1.apply_no,'')                         as loan_app_no  --支用申请号
           ,nvl(t1.grant_credit_apply_no,'')            as credit_cont_no  --授信申请号
           ,nvl(t2.cust_id,'')                          as cust_id  --客户号
           ,nvl(t2.user_name,'')                        as cust_name  --客户名称
           ,nvl(t3.product_name,'')                     as prod_name  --产品名称
           ,''                                          as biz_prod_code  --业务产品号
           ,''                                          as sub_biz_prod_code  --业务子产品号
           ,'CNY'                                       as ccy  --币种
           ,nvl(t1.credit_payment_amount/100,0)             as loan_app_amt  --申请金额
           ,case when t1.audit_status in ('00','01') then '001'    --审批中     
                 when t1.audit_status = '02' then '002'  --审批拒绝         
                 when t1.audit_status = '03' then '003'  --审批通过                            
             end                                        as loan_app_status  --支用申请状态
           ,nvl(substr(t1.create_time,1,10),'')         as loan_app_date  --支用申请时间
           ,'2'                                         as loan_biz_class  --业务分类
           ,''                                          as ip 
           ,''                                          as device_id
         ,case when t5.enterprise_type = '210' then 'A18'     --20230612 ygr update
              else nvl(t4.loan_type,'') 
		    end                                         as loan_biz_detail --贷款业务细类
		   ,nvl(t4.channel_code,'')                     as channel_id  --渠道编号  update 20231031 yuguorui 新增字段
           ,nvl(t3.base_product_no,'')                  as prod_code  --产品号
      from odata.suprisk_pcl_use_credit_apply_info t1
      left join odata.supwall_scp_personal_cust_info t2
        on t1.idcard_no=t2.idcard_no
       and t2.data_date='${DATA_DATE}'
       and t2.bddw_end_date='9999-99-99' 
      left join odata.suporder_scp_credit_apply_finance_product t3
        on t1.apply_no=t3.credit_apply_no
       and t3.data_date='${DATA_DATE}'
       and t3.bddw_end_date='9999-99-99'
      left join odata.suppimp_scp_project_info t4
        on t1.project_id = t4.project_id
       and t4.data_date = '${DATA_DATE}'
	  left join odata.supwall_scp_personal_cust_enterprise_info t5
	    on t1.social_credit_code = t5.social_credit_code
        and t5.status='10'
	   and t5.data_date = '${DATA_DATE}'
	   and t5.bddw_end_date = '9999-99-99'
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date='9999-99-99'
       and t3.base_product_no in('110150','110184')       --核心基础产品编号
