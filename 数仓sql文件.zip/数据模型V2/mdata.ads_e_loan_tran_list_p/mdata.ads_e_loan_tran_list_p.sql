---------------------------------------------------------------------------------------------------------------
--脚本名称：贷款交易流水表hive建表.sql
--功能描述：用于在hive mdata层创建mdata.ads_e_loan_tran_list_p
--作    者：施金才
--开发日期：2020-11-19
--直属经理：程宏明
--修改历史：
--          1.施金才   2020-11-19    新建
--          2.张礼娟   2021-05-07    源表由gdata.ads_e_loan_tran_list_p改为dwd.dwd_e_loan_tran_list_p
---------------------------------------------------------------------------------------------------------------
insert overwrite table mdata.ads_e_loan_tran_list_p partition(data_date='${DATA_DATE}')
select
     core_tran_seqno  
    ,sub_tran_seqno  
    ,acct_mask(loan_acct) as loan_acct
    ,acct_mask(cust_id) as cust_id
    ,cust_type       
    ,bill_no         
    ,tran_date       
    ,tran_time       
    ,tran_type       
    ,tran_status     
    ,debit_crdt_flag 
    ,ccy             
    ,tran_amt        
    ,amt_type        
    ,tran_chan       
    ,corr_flag       
    ,corr_tran_type  
    ,corr_date       
    ,tran_tlr_no     
    ,remark1         
    ,remark2         
    ,remark3         
    ,remark4         
    ,remark5  
from dwd.dwd_e_loan_tran_list_p
where data_date='${DATA_DATE}'