--2.gaoyuan.dwd.dwd_c_tran_party_info_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：交易对手信息表.sql
--功能描述：生成每日结果数据并插入hive dwd层 dwd_c_tran_party_info_p 分区表
--作    者：高源
--开发日期：2023-02-06
--直属经理：方杰
--来源表  ：odata.tb_vs_cptys                 --提供交易对手基础信息
--来源表  ：odata.tb_v_issuer_rating          --查询债券发行人评级信息
--来源表  ：odata.tb_v_rating_firm            --评级公司视图
--目标表  ：dwd.dwd_c_tran_party_info_p
--修改历史：
--          1.高源     2023-02-06    新建
--          1.高源     2023-04-11    新增交易对手名称-简称字段
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_c_tran_party_info_p partition(data_date = '${DATA_DATE}')  
 select  /*+ REPARTITION(1) */
      nvl(tvc.cptys_id          ,'')  as    tran_party_id               --交易对手编码
     ,nvl(tvc.cptys_name        ,'')  as    tran_party_name             --交易对手名称
     ,nvl(tvc.customer_type_code,'')  as    tran_party_type             --交易对手类型
     ,nvl(tvc.is_bank           ,'')  as    is_bank                     --是否金融机构
     ,nvl(tvc.is_issuer         ,'')  as    is_issuer                   --是否发行人
     ,nvl(tvc.is_guarantee      ,'')  as    is_guarantee                --是否担保人
     ,nvl(trim(vir.rating)      ,'')  as    tran_party_rating           --交易对手评级
     ,nvl(vir.firm_name_zh      ,'')  as    rating_corp_name            --评级机构
     ,nvl(tvc.cptys_shortname   ,'')  as    tran_part_name_short        --交易对手名称-简称
     from  odata.tb_vs_cptys tvc       
left join (select row_number() over(partition by issuer_id order by rating_date desc,trim(a.rating) asc) rn,b.firm_name_zh,a.*
              from odata.tb_v_issuer_rating a                  --发行人评级
         left join odata.tb_v_rating_firm b                    --评级公司视图
                on a.firm_id=b.firm_id
               and b.data_date='${DATA_DATE}'
               and b.bddw_end_date='9999-99-99'
             where a.data_date='${DATA_DATE}'
               and a.bddw_end_date='9999-99-99') vir
       on nvl(tvc.issuer_name, tvc.cptys_name)=vir.issuer_name_zh
      and vir.rn=1
    where tvc.data_date = '${DATA_DATE}'
      and tvc.bddw_end_date= '9999-99-99'