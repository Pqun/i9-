HW_LOAD_DATE=`hive -e "select max(data_date) from odata.check_ods_data_load_success where batch_id='night_batch'"`
if [ ${DATA_DATE} == $HW_LOAD_DATE ];then
	exit 0
else
    exit 1
fi