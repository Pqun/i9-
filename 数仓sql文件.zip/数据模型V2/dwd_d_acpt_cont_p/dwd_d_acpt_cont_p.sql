--2.gaoyuan.dwd.dwd_d_acpt_cont_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：银行承兑汇票协议表取数逻辑.sql
--功能描述：用于创建 dwd.dwd_d_acpt_cont_p
--作    者：高源
--开发日期：2022-07-27 
--直属经理：方杰
--来源表:
--1.odata.nbms_bms_draft_centre_info  票据票面信息表  
--2.odata.nbms_bms_accept_details     承兑明细表
--3.odata.nbms_bms_accept_contract    承兑批次表
--4.odata.als_business_duebill        业务借据(账户)信息表
--5.odata.nbms_bms_accept_status      承兑状态表
--6.odata.nbms_bms_accept_due_pay     解付信息表
--7.odata.nbms_dpc_draft_info         票据票面信息表
--8.odata.nbms_cpes_prmtpay_apply     提示付款申请表
--9.odata.als_cl_occupy               额度占用关系表
--10.odata.als_business_contract      业务合同信息表
--11.odata.als_classify_record        风险分类记录表
--目标表：dwd.dwd_d_acpt_cont_p   银行承兑汇票协议表
--修改历史：
--          1.高源   2022-07-27    新建
--          2.高源   2022-12-01    新增信贷合同号
--          3.高源   2023-01-04    新增贷款投向行业
--          4.高源   2023-01-04    新增授信合同号
--          5.高源   2023-02-01    担保方式逻辑调整
--          6.高源   2023-02-06    新增经办人工号、业务编号、信贷借据号字段
--          7.高源   2023-02-14    新增五级分类、五级分类日期、其他担保方式、合同金额、承兑状态、垫款状态、供应链归属、票据区间字段
--                                 新增电票撤销业务数据
--          8.高源   2023-03-09    业务借据表关联条件变更
--          9.高源   2023-08-09    新增垫款金额字段
--          10.姚威   2023-11-07   新增审批人工号,办人工号逻辑调整
--          11.彭群   2024-01-23   新增信贷经办员工号
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_acpt_cont_p partition(data_date='${DATA_DATE}')
  select   /*+ REPARTITION(1) */
           nvl(t1.draft_number          ,'')    as  bill_no              --票据号
          ,nvl(t2.protocol_no           ,'')    as  cont_no              --协议号
          ,'100000'                             as  org_id               --机构号
          ,case t1.draft_attr
                when 1 then '70020101'       --开出承兑汇票—纸质银行承兑汇票
                when 2 then '70020102'       --开出承兑汇票—电子银行承兑汇票
                else '' end                     as  subj_no              --科目号
          ,nvl(t2.prod_no               ,'')    as  prod_code            --产品号
          ,'CNY'                                as  ccy                  --币种
          ,nvl(t1.draft_attr            ,'')    as  bill_attr            --票据介质
          ,nvl(t1.draft_type            ,'')    as  bill_type            --票据类型
          ,nvl(from_unixtime(unix_timestamp(t1.remit_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                        as  remit_date           --出票日
          ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                        as  bill_expr_date    --票面到期日
          ,nvl(t1.remitter_name         ,'')    as  drawer_name          --出票人名称
          ,nvl(t1.remitter_account      ,'')    as  drawer_acct_no       --出票人账号
          ,nvl(t1.remitter_cmonid       ,'')    as  drawer_cert_no       --出票人证件代码  
          ,nvl(t1.remitter_bank_no      ,'')    as  drawer_bank_no       --出票人开户行号
          ,nvl(t1.remitter_bank_name    ,'')    as  drawer_bank_name     --出票人开户行名称
          ,nvl(t1.acceptor_name         ,'')    as  acceptor_name        --承兑人名称
          ,''                                   as  acceptor_cert_no     --承兑人证件号码
          ,nvl(t1.acceptor_bank_no      ,'')    as  acceptor_bank_no     --承兑人开户行号
          ,nvl(t1.payee_name            ,'')    as  bill_rev_name        --收款人名称    
          ,nvl(t1.payee_organ_code      ,'')    as  rev_cert_no          --票面收款人证件号码
          ,nvl(t1.payee_bank_no         ,'')    as  bill_rev_bank_no     --票面收款人开户行号
          ,nvl(t1.payee_bank_name       ,'')    as  bill_rev_bank_name   --收款人开户行名称
          ,nvl(t.draft_amount           ,0 )    as  acpt_amt             --承兑金额 
          ,nvl(t6.bailaccount           ,'')    as  marg_acct_no         --保证金账号
          ,nvl(t6.bailsum                ,0)    as  marg_bal             --保证金金额
          ,nvl(t2.bail_ratio             ,0)    as  marg_ratio           --保证金比例
          ,case when t5.vouchtype = '005' then 'D'   --信用
                when t5.vouchtype = '010' then 'C'   --保证
                when t5.vouchtype = '020' then 'B'   --抵押
                when t5.vouchtype = '040' then 'A'   --质押
                else '' end                     as  loan_guar_mode       --担保方式
          ,nvl(t.charge                  ,0)    as  fee                  --手续费
          ,case when t.deduct_status ='2'  then '1'
                else  '0'          end          as  status               --票据状态 
          ,nvl(from_unixtime(unix_timestamp(t.deduct_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                        as  bill_clear_date      --票据结清日期 
          ,nvl(t2.remitter_cust_no      ,'')    as  drawer_cust_id       --出票人客户号
          ,case when t8.account_date is not null 
		           then from_unixtime(unix_timestamp(t8.account_date,'yyyyMMdd'),'yyyy-MM-dd')
                when t8.account_date is null and t9.apply_date is not null 
				   then from_unixtime(unix_timestamp(t9.apply_date,'yyyyMMdd'),'yyyy-MM-dd')
                else ''  end                    as  bill_pay_date        --票据解付日期
          ,case when t7.prmtpay_sign_status ='2' then '2'    
                else  '0'    end                as  prmtpay_sign_status  --解付签收状态
          ,case  when t.accept_status='09' then  0       --撤票
                 when t.accept_status='06'  and t.deduct_status=2  then  0
                 else t.draft_amount  end       as  bill_bal             --当前余额
          ,nvl(t2.credit_no             ,'')    as  als_cont_no          --信贷合同号
          ,nvl(t5.direction             ,'')    as  loan_indust_type     --贷款投向行业
          ,nvl(t4.relativeserialno      ,'')    as  credit_cont_no       --授信合同号
          ,nvl(t3.started_user          ,'')    as  oper_emp_id          --经办人工号
          ,nvl(t1.id                    ,'')    as  deal_id              --业务编号
          ,nvl(t.invc_no                ,'')    as  als_bill_no          --信贷借据号
          ,case when t6.classifyresult ='01' then 'FQ01'
                when t6.classifyresult ='02' then 'FQ02'
                when t6.classifyresult ='03' then 'FQ03'
                when t6.classifyresult ='04' then 'FQ04'
                when t6.classifyresult ='05' then 'FQ05'
                else  ''    end                 as  five_risk_level      --五级分类  
          ,nvl(t11.five_risk_date       ,'')    as  five_risk_date       --五级分类日期
          ,case when t5.vouchflag = '005' then 'D'   --信用
                when t5.vouchflag = '010' then 'C'   --保证
                when t5.vouchflag = '020' then 'B'   --抵押
                when t5.vouchflag = '040' then 'A'   --质押
                else '' end                     as  other_loan_guar_mode --其他担保方式
          ,nvl(t5.businesssum            ,0)    as  cont_amt             --合同金额
          ,nvl(t.accept_status           ,0)    as  acpt_status          --承兑状态
          ,nvl(t.advance_status         ,'')    as  adv_status           --垫款状态
          ,nvl(t51.gccustomerid         ,'')    as  supply_chn_belong    --供应链归属
          ,'-'                                  as  bill_range           --票据区间
          ,nvl(t.advance_amount          ,0)    as  adv_amt              --垫款金额
          ,nvl(t2.last_operator_no      ,'')    as  approver	 	     --审批人    20231107update
          ,nvl(t5.operateuserid         ,'')    as  als_oper_emp_id      --信贷经办人员工号                      --20240108updata  pengqun
   from odata.nbms_bms_draft_centre_info  t1
  inner join odata.nbms_bms_accept_details t--承兑明细表
     on t1.id=t.draft_id
    and t.data_date='${DATA_DATE}' 
    and t.bddw_end_date='9999-99-99'
    and t.accept_status in ('06','09')-- 06 - 承兑完成（签发）09--电票撤销
   left join  odata.nbms_bms_accept_contract t2--承兑批次表
     on t.contract_id=t2.id
    and t2.data_date='${DATA_DATE}' 
    and t2.bddw_end_date='9999-99-99'
   left join  odata.flowsharp_tbl_serprocess  t3
     on t3.biz_id=t2.protocol_no
    and t3.data_date='${DATA_DATE}' 
    and t3.bddw_end_date='9999-99-99'	
   left join odata.als_business_duebill t6--业务借据(账户)信息表
     on t.invc_no = t6.serialno
    and t6.businesstype='2010' --银行承兑汇票
    and t6.data_date='${DATA_DATE}'
    and t6.bddw_end_date='9999-99-99'
   left join (
         select objectno,regexp_replace(classifydate,'/','-')  as  five_risk_date
                ,row_number() over(partition by objectno order by classifydate  desc) as rn
           from odata.als_classify_record 
          where data_date='${DATA_DATE}' 
            and bddw_end_date='9999-99-99' ) t11                                
     on t6.serialno=t11.objectno 
    and t11.rn=1
   left join odata.als_business_contract t5--业务合同信息表
     on t2.credit_no=t5.serialno
    and t5.data_date='${DATA_DATE}' 
    and t5.bddw_end_date='9999-99-99'
   left join odata.als_cl_occupy t4        --额度占用关系表
     on t4.objectno=t2.credit_no
    and t4.objecttype='BusinessContract'
    and t4.data_date='${DATA_DATE}' 
    and t4.bddw_end_date='9999-99-99'
    and t4.remark  is  null                --生效部分
   left join odata.als_business_contract t51--授信合同信息表
     on t4.relativeserialno=t51.serialno
    and t51.data_date='${DATA_DATE}' 
    and t51.bddw_end_date='9999-99-99'
   left join odata.nbms_bms_accept_status t7
     on t.draft_number = t7.draft_number
    and t7.data_date = '${DATA_DATE}'
    and t7.bddw_end_date = '9999-99-99'
   left join odata.nbms_bms_accept_due_pay t8  --解付信息表        account_date
     on t8.draft_id=t1.id
    and t8.data_date='${DATA_DATE}'               --未贴现票据解付信息
    and t8.bddw_end_date='9999-99-99'
    and t8.account_flag='2' --记账完成      
  left join (
         select b.bms_draft_id, 
		        c.apply_date
         from odata.nbms_dpc_draft_info b --票据票面信息表
         left join odata.nbms_cpes_prmtpay_apply c             --c.apply_date   
           on b.id=c.draft_id 
          and c.data_date='${DATA_DATE}' 
          and c.bddw_end_date='9999-99-99'
        where b.bms_draft_id is not NULL                  --已贴现票据解付信息
          and c.account_status = '02' --记账成功
          and c.buss_flag ='02' --签收
          and b.data_date='${DATA_DATE}' 
          and b.bddw_end_date='9999-99-99'      
     ) t9
     on t9.bms_draft_id=t1.id  
  where t1.data_date='${DATA_DATE}' 
    and t1.bddw_end_date='9999-99-99'
  union all
  --------------------------------------等分化票据承兑---------------------------------------------------------
   select    /*+ REPARTITION(1) */
            nvl(t1.draft_number          ,'')    as  bill_no              --票据号
           ,nvl(t2.contract_no           ,'')    as  cont_no              --协议号
           ,'100000'                             as  org_id               --机构号
           ,case t1.draft_attr
                 when '1' then '70020101'       --开出承兑汇票—纸质银行承兑汇票
                 when '2' then '70020102'       --开出承兑汇票—电子银行承兑汇票
                 else '' end                     as  subj_no              --科目号
           ,nvl(t2.product_no            ,'')    as  prod_code            --产品号
           ,'CNY'                                as  ccy                  --币种
           ,nvl(t1.draft_attr            ,'')    as  bill_attr            --票据介质
           ,nvl(t1.draft_type            ,'')    as  bill_type            --票据类型
           ,nvl(from_unixtime(unix_timestamp(t1.remit_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                         as  remit_date           --出票日
           ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                         as  bill_expr_date    --票面到期日
           ,nvl(t1.remitter_name         ,'')    as  drawer_name          --出票人名称
           ,nvl(t1.remitter_account      ,'')    as  drawer_acct_no       --出票人账号
           ,nvl(t1.remitter_crt_no       ,'')    as  drawer_cert_no       --出票人证件代码  
           ,nvl(t1.remitter_bank_no      ,'')    as  drawer_bank_no       --出票人开户行号
           ,nvl(t1.remitter_bank_name    ,'')    as  drawer_bank_name     --出票人开户行名称
           ,nvl(t1.acceptor_name         ,'')    as  acceptor_name        --承兑人名称
           ,nvl(t1.acceptor_crt_no       ,'')    as  acceptor_cert_no     --承兑人证件号码
           ,nvl(t1.acceptor_bank_no      ,'')    as  acceptor_bank_no     --承兑人开户行号
           ,nvl(t1.payee_name            ,'')    as  bill_rev_name        --收款人名称    
           ,nvl(t1.payee_crt_no          ,'')    as  rev_cert_no          --票面收款人证件号码
           ,nvl(t1.payee_bank_no         ,'')    as  bill_rev_bank_no     --票面收款人开户行号
           ,nvl(t1.payee_bank_name       ,'')    as  bill_rev_bank_name   --收款人开户行名称
           ,nvl(t1.draft_amount          ,0 )    as  acpt_amt             --承兑金额 
           ,nvl(t6.bailaccount           ,'')    as  marg_acct_no         --保证金账号
           ,nvl(t2.deposit_amt            ,0)    as  marg_bal             --保证金金额  
           ,nvl(t2.deposit_ratio          ,0)    as  marg_ratio           --保证金比例
           ,case when t5.vouchtype = '005' then 'D'   --信用
                 when t5.vouchtype = '010' then 'C'   --保证
                 when t5.vouchtype = '020' then 'B'   --抵押
                 when t5.vouchtype = '040' then 'A'   --质押
                 else '' end                     as  loan_guar_mode       --担保方式
           ,nvl(t.charge                 ,0)     as  fee                  --手续费
           ,case when t.deduct_status ='2'  then '1'
                 else  '0'          end          as  status               --票据状态 
           ,nvl(from_unixtime(unix_timestamp(t.deduct_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                         as  bill_clear_date      --票据结清日期 
           ,nvl(t2.remitter_cust_no      ,'')    as  drawer_cust_id       --出票人客户号
           ,''                                   as  bill_pay_date        --票据解付日期
           ,case when  t1.draft_amount=t10.draft_amount  then  '2'   --完全解付
                 when  t1.draft_amount<>t10.draft_amount and t10.draft_amount >0 then  '1'   --部分解付
                 else  '0'   end   as  prmtpay_sign_status  --解付签收状态
           ,case when t.accept_status='09' then  0       --撤票
                 when t.accept_status='06'  and   t.deduct_status=2  then  0
                 else t.draft_amount  end        as  bill_bal             --当前余额
           ,nvl(t2.credit_no             ,'')    as  als_cont_no          --信贷合同号
           ,nvl(t5.direction             ,'')    as  loan_indust_type     --贷款投向行业
           ,nvl(t4.relativeserialno      ,'')    as  credit_cont_no       --授信合同号
           ,nvl(t3.started_user          ,'')    as  oper_emp_id          --经办人工号
           ,nvl(t1.id                    ,'')    as  deal_id              --业务编号
           ,nvl(t.invc_nb                ,'')    as  als_bill_no          --信贷借据号
           ,case when t6.classifyresult ='01' then 'FQ01'                 
                 when t6.classifyresult ='02' then 'FQ02'                 
                 when t6.classifyresult ='03' then 'FQ03'                 
                 when t6.classifyresult ='04' then 'FQ04'                 
                 when t6.classifyresult ='05' then 'FQ05'                 
                 else  ''    end                 as  five_risk_level      --五级分类  
           ,nvl(t11.five_risk_date       ,'')    as  five_risk_date       --五级分类日期
           ,case when t5.vouchflag = '005' then 'D'   --信用              
                 when t5.vouchflag = '010' then 'C'   --保证              
                 when t5.vouchflag = '020' then 'B'   --抵押              
                 when t5.vouchflag = '040' then 'A'   --质押              
                 else '' end                     as  other_loan_guar_mode --其他担保方式
           ,nvl(t5.businesssum            ,0)    as  cont_amt             --合同金额
           ,nvl(t.accept_status           ,0)    as  acpt_status          --承兑状态
           ,nvl(t.advance_status         ,'')    as  adv_status           --垫款状态
           ,nvl(t51.gccustomerid         ,'')    as  supply_chn_belong    --供应链归属
           ,nvl(t1.cd_range              ,'')    as  bill_range           --票据区间
           ,nvl(t.advance_amount          ,0)    as  adv_amt              --垫款金额
	       ,nvl(t2.last_operator         ,'')    as  approver	 	      --审批人    20231107update
           ,nvl(t5.operateuserid         ,'')    as  als_oper_emp_id      --信贷经办人员工号  
        from odata.nbms_dpc_draft_info t1
  inner join odata.nbms_cpes_accept_details  t  --承兑明细表
          on t.draft_id=t1.id
         and t.data_date='${DATA_DATE}' 
         and t.bddw_end_date='9999-99-99'
         and t.accept_status  in ('06','09')-- 06 - 承兑完成（签发）09--电票撤销
   left join odata.nbms_cpes_accept_contract t2  --承兑批次表
          on t.contract_id=t2.id
         and t2.data_date='${DATA_DATE}' 
         and t2.bddw_end_date='9999-99-99'
   left join odata.flowsharp_tbl_serprocess  t3
          on t3.biz_id=t2.contract_no
         and t3.data_date='${DATA_DATE}' 
         and t3.bddw_end_date='9999-99-99'			 
   left join odata.als_business_duebill t6--业务借据(账户)信息表
          on t.invc_nb = t6.serialno
         and t6.businesstype='2010' --银行承兑汇票
         and t6.data_date='${DATA_DATE}'
         and t6.bddw_end_date='9999-99-99'
   left join (
         select objectno,regexp_replace(classifydate,'/','-')  as  five_risk_date
                ,row_number() over(partition by objectno order by classifydate  desc) as rn
           from odata.als_classify_record 
          where data_date='${DATA_DATE}' 
            and bddw_end_date='9999-99-99' ) t11                                
     on t6.serialno=t11.objectno 
    and t11.rn=1
   left join odata.als_business_contract t5--业务合同信息表
          on t2.credit_no=t5.serialno
         and t5.data_date='${DATA_DATE}' 
         and t5.bddw_end_date='9999-99-99'
   left join odata.als_cl_occupy t4        --额度占用关系表
          on t4.objectno=t2.credit_no
         and t4.objecttype='BusinessContract'
         and t4.data_date='${DATA_DATE}' 
         and t4.bddw_end_date='9999-99-99'
         and t4.remark  is  null                --生效部分
   left join odata.als_business_contract t51--授信合同信息表
          on t4.relativeserialno=t51.serialno
         and t51.data_date='${DATA_DATE}' 
         and t51.bddw_end_date='9999-99-99'
   left join
            (select  sum(draft_amount) as draft_amount ,draft_number
               from odata.nbms_cpes_prmtpay_apply              --c.apply_date   
              where account_status = '02' --记账成功
                and buss_flag ='02' --签收
                and data_date='${DATA_DATE}'                   --新票解付信息
                and bddw_end_date='9999-99-99'
              group by draft_number) t10
          on t1.draft_number=t10.draft_number
       where t1.data_date='${DATA_DATE}' 
         and t1.bddw_end_date='9999-99-99'
         and t1.status != 'S00' --无效
