--2.zhanglijuan.dwd.dwd_f_cust_data_report_p
-------------------------------------------------------------------
--脚本名称:dwd.dwd_f_cust_data_report_p
--功能描述:对公客户财务信息表
--开发日期:2023-04-25
--直属经理:方杰
--目标表  :dwd.dwd_f_cust_data_report_p
--数据原表:
--修改历史:
--         1、张礼娟  20230425 新建
--         2、刘丽红  20240227 新增报表金额单位字段
--         3、刘丽红  20240312 新增报表状态字段
-------------------------------------------------------------------
insert overwrite table dwd.dwd_f_cust_data_report_p partition (data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
     nvl(a1.objectno,'') as cust_id  --客户编号
    ,nvl(a1.reportdate,'') as report_date  --财务报表日期
    ,nvl(a1.reportno,'') as report_no  --财务报表编号
    ,nvl(a1.reportname,'') as report_nm  --财务报表名称
    ,nvl(a3.rowno,'') as report_subj_no  --财报科目编号
    ,nvl(a3.rowname,'') as report_subj_nm  --财报科目名称
    ,nvl(a3.rowsubject,'') as row_subj_no  --对应科目
    ,nvl(a1.reportscope,'') as report_cal  --报表口径
    ,nvl(a2.reportperiod,'') as report_freq  --报表周期
    ,'CNY' as ccy  --币种
    ,nvl(a3.col2value,0) as bal  --期末余额  
    ,case when a2.auditoffice = '无锡嘉誉会计事务所有限公司 ' then  '无锡嘉誉会计事务所有限公司'
          when a2.auditoffice = ' 公证天业会计师事务所' then  '公证天业会计师事务所'  
          else nvl(a2.auditoffice,'') 
          end as audit_corp_nm  --审计机构名称
    ,a2.reportunit            as report_unit  --报表金额单位   --add llh 20240227
    ,a2.reportstatus          as report_status--报表状态(01:新增;02:完成;03:锁定)       --add llh 20240312 
from odata.als_report_record a1          --报表记录表
left join odata.als_customer_fsrecord a2 --客户财务报表记录表
on a1.objectno = a2.customerid
and a1.reportscope = a2.reportscope
and a1.reportdate = a2.reportdate
and a2.data_date = '${DATA_DATE}'
and a2.bddw_end_date = '9999-99-99'
left join odata.als_report_data a3       --报表记录表
on a1.reportno = a3.reportno 
and a3.data_date = '${DATA_DATE}'
and a3.bddw_end_date = '9999-99-99' 
inner join odata.sym_cif_client a4       --客户信息表
on a1.objectno = a4.client_no 
and a4.client_type = '02'                --对公客户
and a4.data_date ='${DATA_DATE}'
and a4.bddw_end_date = '9999-99-99'
where a1.data_date = '${DATA_DATE}'
and a1.bddw_end_date ='9999-99-99'