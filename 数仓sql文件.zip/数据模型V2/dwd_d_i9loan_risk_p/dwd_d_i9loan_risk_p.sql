insert overwrite table dwd.dwd_d_i9loan_risk_p partition(data_date = '${DATA_DATE}')
-- 减值计算明细 
select /*+ REPARTITION(1) */ 
       a.src_busicode                                as  bill_no            --借据编号
	   ,nvl(a.def1,0)                                 as  desc_reserves_bal  --余额减值准备金
	   ,nvl(a.def2,0)                                 as  desc_reserves_int  --利息减值准备金
     ,nvl(a.ecl_i9,0)                               as  desc_reserves_prin  --本金减值准备金
	   ,pd_forw                                       as  break_ratio        --违约概率
  from odata.i9_vip_impairment_detail_his a -- 减值计算明细
 inner join odata.i9_vip_impairment_his b --减值标准
    on a.pk_impairment = b.pk_impairment
   and b.data_date = '${DATA_DATE}'
   and b.bddw_end_date = '9999-99-99' 
 where a.data_date ='${DATA_DATE}'
   and a.bddw_end_date = '9999-99-99' 