--2.gaoyuan.dwd.dwd_d_bond_invest_cont_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：dwd_d_bond_invest_cont_p.sql
--功能描述：
--作    者：于国睿
--开发日期：2022-08-18
--直属经理：方杰
--来源表  ：odata.tb_v_balance                      资产-余额
--来源表  ：odata.tb_vs_accentry2                   原始账务分录
--来源表  ：odata.tb_v_alterbalance                 资产-变动
--来源表  ：odata.tb_v_bondsdeals                   现券交易
--来源表  ：odata.tb_vs_payment_bondsdeals_all      实际收付确认-现券交易-含衍生
--来源表  ：odata.tb_v_security                     债券基本资料视图
--来源表  ：odata.bond_security_extra               查询债券基本资料的扩展信息
--来源表  ：odata.tb_v_security_rating              债券评级
--来源表  ：odata.gl_v_gl_subject                   科目表                                  
--目标表  ：dwd.dwd_d_bond_invest_cont_p            债券投资协议表
--修改历史：
--          1.于国睿  2022-08-18    新建
--          2.高源    2022-12-05    剔除冲正余额 
--          3.高源    2022-12-07    新增应收利息、应收利息科目字段，计提利息逻辑调整 
--          4.高源    2022-12-21    新增托管机构字段
--          5.高源    2023-01-04    新增发行人名称、是否次级债
--          6.高源    2023-02-06    新增结算金额、累计价差收益、累计摊销收益、累计利息收益、累计公允价值变动损益字段
--          7.高源    2023-03-20    新增上次付息日、下次付息日字段
--          8.高源    2023-07-10    新增成交编号字段
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_bond_invest_cont_p_tmp partition(data_date = '${DATA_DATE}')
    select   /*+ REPARTITION(1) */
           nvl(t1.minorassetcode,'')                 as cont_id                     --债券投资协议号
          ,nvl(t2.security_code,'')                  as bond_id                     --债券代码
          ,case when t2.security_type = '1' then 'GB03'  --国债
                when t2.security_type = '4' then 'CB01'  --企业债
                when t2.security_type = '8' then 'FB00'  --政策性银行
                when t2.security_type = 'E' then 'CB03'  --公司债
                when t2.security_type = 'G' then 'PRB'  --项目收益债
                when t2.security_type = 'L' and t2.security_name = '泛海1A' then 'ABS01'  --信贷资产
                when t2.security_type = 'L' and t2.security_name <> '泛海1A' then 'ABN'   --非金融企业资产支持票据 
                when t2.security_type = 'M' and t3.local_government_classify = 'G' then 'GB041'  --地方政府一般债券
                when t2.security_type = 'M' and t3.local_government_classify = 'S' then 'GB042'  --地方政府专项债券
                when t2.security_type = 'N' and t2.security_name like '%PPN%' then 'PPN'  --非公开定向债务融资工具
                else  ''   --中期票据
            end                                      as bond_type                  --债券品种
          ,''                                        as issuer_unif_soc_crdt       --发行人社会统一信用代码
          ,''                                        as issuer_area_code           --发行人地区代码
          ,''                                        as issuer_indust_class        --发行人行业编码
          ,''                                        as issuer_corp_scale          --发行人企业规模
          ,''                                        as issuer_econ_type_code      --发行人经济成份
          ,''                                        as issuer_econ_depar_code     --发行人国民经济部门
          ,nvl(from_unixtime(unix_timestamp(t2.issue_date,'yyyyMMdd'),'yyyy-MM-dd'),'')           as bond_regist_date     --债权债务登记日
          ,nvl(from_unixtime(unix_timestamp(t2.start_coupon_date,'yyyyMMdd'),'yyyy-MM-dd'),'')    as accr_date            --起息日
          ,nvl(from_unixtime(unix_timestamp(t2.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')        as accept_date          --兑付日
          ,nvl(t2.ccy,'')                            as ccy                          --币种
          ,nvl(t4.rating,'')                         as invest_prod_rating           --投资产品评级
          ,nvl(t2.fixed_rate,0)                      as bond_rate                    --票面利率
          ,nvl(t1.holdfaceamount,0)                  as biz_amt                      --业务发生金额（持有成本）
          ,nvl(t1.accountingcode,'')                 as subj_no                      --科目号
          ,nvl(t1.fairvaluealter,0)                  as fair_value_adj_amt           --公允价值变动金额
          ,nvl(t6.gl_code,'')                        as fair_value_adj_subj          --公允价值变动科目号
          ,nvl(t1.interestadjust,0)                  as int_adj                      --利息调整金额
          ,nvl(t5.gl_code,'')                        as int_adj_subj_no              --利息调整科目号
          ,from_unixtime(unix_timestamp(string(t1.tradedate),'yyyyMMdd'),'yyyy-MM-dd') as tran_date   --成交日
          ,nvl(t1.cleanprice,0)                      as clean_price                 --交易净价
          ,nvl(t1.dirtyprice,0)                      as dirty_price                 --交易全价
          ,nvl(t1.realrate,0)                        as exec_rate                   --实际利率
          ,nvl(t.withdraw_int,0)                     as withdraw_int                --日计提利息
          ,nvl(t.sumd,0)-nvl(t.sumc,0)               as recv_int                    --应收应付利息
          ,nvl(t.recv_int_subj_no ,'')               as recv_int_subj_no            --应收应付利息科目
          ,nvl(trim(t3.depository_trust),'')         as trust_agency                --托管机构
          ,nvl(t2.issuer,'')                         as issuer_name                 --发行人名称 
          ,case when t2.collateral_id=4 then '1' else '0' end        as is_subord_debt              --是否次级债 
          ,nvl(t1.settleamount       ,0)             as settleamount                --结算金额 
          ,nvl(t1.priceearning       ,0)             as total_diff_income           --累计价差收益
          ,nvl(t1.amortizeearning    ,0)             as total_amort_income          --累计摊销收益
          ,nvl(t1.interestearning    ,0)             as total_int_income            --累计利息收益
          ,nvl(t1.fairvalueincome    ,0)             as total_fair_value_change     --累计公允价值变动损益
          ,nvl(from_unixtime(unix_timestamp(string(t22.payment_date),'yyyyMMdd'),'yyyy-MM-dd'),'')   as last_repay_int_date --上次付息日
          ,nvl(from_unixtime(unix_timestamp(string(t21.payment_date),'yyyyMMdd'),'yyyy-MM-dd'),'')   as next_repay_int_date --下次付息日
		  ,nvl(t1.ref_number        ,'')             as ref_no                      --成交编号             --2023-07-10新增字段
      from (select  ac1.accountingcode
                   ,b2.minorassetcode
                   ,b2.majorassetcode
                   ,b2.realrate
                   ,bd.tradedate
				   ,bd.ref_number
                   ,sum(bd.settleamount)  as  settleamount
                   ,sum(bd.cleanprice)    as cleanprice
                   ,sum(bd.dirtyprice)    as dirtyprice
                   ,sum(case when b2.assettype = '交易性金融资产' 
                             then b2.cleanpricecost
                             else b2.holdfaceamount
                         end) as holdfaceamount
                   ,sum(ce1.fairvaluealter) as fairvaluealter
                   ,sum(ce1.interestadjust) as interestadjust
                   ,cast(sum(ce1.priceearning   )  as decimal(28,10)) as priceearning
                   ,cast(sum(ce1.amortizeearning)  as decimal(28,10)) as amortizeearning
                   ,cast(sum(ce1.interestearning)  as decimal(28,10)) as interestearning
                   ,cast(sum(ce1.fairvalueincome)  as decimal(28,10)) as fairvalueincome
            from (select max(bls.balance_id) as balance_id
                      from odata.tb_v_balance bls
                     where bls.settledate <= regexp_replace('${DATA_DATE}','-','') -- 统计日期
                       and bls.aspclient_id = '2244' -- 请替换本行部门 ID
                       and bls.buztype = '现券'
                       and bls.majorassetcode <> bls.minorassetcode
                       and bls.assettype in ('交易性金融资产','可供出售金融资产','持有至到期投资','应收款项')
                       and bls.data_date = '${DATA_DATE}'
                       and bls.bddw_end_date = '9999-99-99'
                     group by bls.aspclient_id,
                              bls.keepfolder_id,
                              bls.assettype,
                              bls.buztype,
                              bls.majorassetcode,
                              bls.minorassetcode) b1
            inner join odata.tb_v_balance b2
                    on b1.balance_id = b2.balance_id
                   and b2.data_date = '${DATA_DATE}'
                   and b2.bddw_end_date = '9999-99-99'
             left join odata.tb_v_bondsdeals bd
                    on bd.deal_id = int(b2.minorassetcode)
                   and bd.data_date ='${DATA_DATE}'
                   and bd.bddw_end_date = '9999-99-99'
            inner join odata.tb_vs_payment_bondsdeals_all t2
                    on bd.deal_id = t2.deal_id
                   and t2.data_date = '${DATA_DATE}'
                   and t2.bddw_end_date = '9999-99-99'
             left join (select aspclient_id,
                               keepfolder_id,
                               assettype,
                               majorassetcode,
                               minorassetcode,
                               cast(sum(interestcost) as decimal(20,2)) interestcost,        --利息成本
                               cast(sum(interestadjust) as decimal(20,2)) interestadjust ,   --利息调整
                               --cast(sum(interestearning) as decimal(20,2)) interestearning,  --利息收益
                               cast(sum(fairvaluealter) as decimal(20,2)) fairvaluealter,     --公允价值变动
                               sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                               then priceearning     else 0 end)  as priceearning,            --价差收益
                               sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                               then amortizeearning  else 0 end)  as amortizeearning,         --摊销收益
                               sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                               then interestearning  else 0 end)  as interestearning,         --利息收益
                               sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                               then fairvalueincome  else 0 end)  as fairvalueincome         --公允价值变动损益
                          from odata.tb_v_alterbalance
                         where data_date ='${DATA_DATE}'
                           and bddw_end_date ='9999-99-99'
                         group by aspclient_id,
                                  keepfolder_id,
                                  assettype,
                                  majorassetcode,
                                  minorassetcode) ce1
                    on b2.aspclient_id = ce1.aspclient_id
                   and b2.keepfolder_id = ce1.keepfolder_id
                   and b2.assettype = ce1.assettype
                   and b2.majorassetcode = ce1.majorassetcode
                   and b2.minorassetcode = ce1.minorassetcode
             left join (select  ac.accountingcode,
                               b21.majorassetcode,
                               b21.minorassetcode,
                               b21.buztype,
                               b21.keepfolder_id,
                               b21.aspclient_id,
                               b21.assettype,
                               row_number()over(partition by b21.majorassetcode,b21.minorassetcode order by ac.settledate desc) as rn  
                          from odata.tb_v_alterbalance b21
                          left join odata.tb_vs_accentry2 ac
                            on b21.alterbalance_id = ac.bundlecode
                           and ac.debitcredit in ('D','C')
                           and ac.data_date = '${DATA_DATE}'
                           and ac.bddw_end_date ='9999-99-99'
                           and substr(ac.accountingcode,1,4) in ('1051','1050','1052')
                           and ac.accountingcode like '%01'
                         where b21.data_date = '${DATA_DATE}'
                           and b21.bddw_end_date = '9999-99-99'
                           and b21.settledate <= regexp_replace('${DATA_DATE}','-','')
                           and ac.accountingcode is not null
                           and ac.amount>0) ac1                              --存在资产科目变更，取发生额大于零的最新科目
                    on ac1.majorassetcode = b2.majorassetcode
                   and ac1.minorassetcode = b2.minorassetcode
                   and ac1.buztype = b2.buztype
                   and ac1.keepfolder_id = b2.keepfolder_id
                   and ac1.aspclient_id = b2.aspclient_id
                   and ac1.assettype = b2.assettype
                   and ac1.rn=1
             group by ac1.accountingcode
                     ,b2.minorassetcode
                     ,b2.majorassetcode
                     ,b2.realrate
                     ,bd.tradedate
					 ,bd.ref_number) t1
      left join odata.tb_v_security t2
             on t1.majorassetcode = t2.security_code
            and t2.data_date = '${DATA_DATE}'
            and t2.bddw_end_date = '9999-99-99'
      left join (select security_code, min(payment_date) payment_date  --下一结息日
                   from odata.tb_v_security_pymn_schd
                  where payment_date > regexp_replace('${DATA_DATE}', '-', '')
                    and data_date = '${DATA_DATE}'
                    and bddw_end_date = '9999-99-99'
                  group by security_code) t21
             on  t21.security_code=t2.security_code
      left join (select security_code, max(payment_date)as  payment_date  --上一结息日
                   from odata.tb_v_security_pymn_schd
                  where payment_date <= regexp_replace('${DATA_DATE}', '-', '')
                    and data_date = '${DATA_DATE}'
                    and bddw_end_date = '9999-99-99'
                  group by security_code) t22
             on  t22.security_code=t2.security_code
      left join odata.bond_security_extra t3
             on t1.majorassetcode = trim(t3.security_code)
            and t3.data_date = '${DATA_DATE}'
            and t3.bddw_end_date = '9999-99-99'
      left join(select rat1.security_code,
                   trim(rat2.rating) rating
                from (select max(rating_date) rating_date,
                           security_code
                      from odata.tb_v_security_rating
                     where data_date = '${DATA_DATE}'
                       and bddw_end_date = '9999-99-99'
                     group by security_code) rat1
                inner join odata.tb_v_security_rating rat2
                        on rat1.rating_date = rat2.rating_date
                       and rat1.security_code = rat2.security_code
                       and rat2.data_date = '${DATA_DATE}'
                       and rat2.bddw_end_date = '9999-99-99') t4
             on t1.majorassetcode = t4.security_code
      left join (select   bls.majorassetcode,bls.minorassetcode,
                          max(tvad.accountingcode) as recv_int_subj_no,
                          max(tva.amount)  as  withdraw_int,
                          sum(cast(tvad.amount as decimal(18,2))) as sumd, 
                          sum(cast(tvac.amount as decimal(18,2))) as sumc 
                   from odata.tb_v_balance bls
                   left  join  odata.tb_vs_accentry2 tvad                --取应收利息借方历史数据
                     on bls.alterbalance_id = tvad.bundlecode
                    and tvad.data_date='${DATA_DATE}'
                    and tvad.bddw_end_date='9999-99-99'
                    and tvad.debitcredit = 'D'
                    and tvad.accountingcode like '106%' 
                   left join  odata.tb_vs_accentry2 tvac                --取应收利息贷方历史数据
                     on bls.alterbalance_id = tvac.bundlecode
                    and tvac.data_date='${DATA_DATE}'
                    and tvac.bddw_end_date='9999-99-99'
                    and tvac.debitcredit = 'C'
                    and tvac.accountingcode like '106%' 
                   left  join  odata.tb_vs_accentry2 tva                --取当日计提利息 
                     on bls.alterbalance_id = tva.bundlecode
                    and tva.data_date='${DATA_DATE}'
                    and tva.bddw_end_date='9999-99-99'
                    and tva.settledate= regexp_replace('${DATA_DATE}','-','')  --统计日期
                    and tva.accountingcode like '106%' 
                    and bls.baretradename='WITHDRAWALDEALS'                 
                  where bls.settledate <= regexp_replace('${DATA_DATE}','-','') --统计日期
                    and bls.aspclient_id = '2244' -- 请替换本行部门 ID
                    and bls.buztype = '现券'
                    and bls.majorassetcode <> bls.minorassetcode
                    and bls.assettype in ('交易性金融资产','可供出售金融资产','持有至到期投资','应收款项')
                    and bls.data_date = '${DATA_DATE}'
                    and bls.bddw_end_date = '9999-99-99'
                  group by bls.minorassetcode,bls.majorassetcode
                    ) t
             on t1.majorassetcode = t.majorassetcode
            and t1.minorassetcode=t.minorassetcode
      left join odata.gl_v_gl_subject t5
             on substr(t1.accountingcode,1,6)=substr(t5.gl_code,1,6)
            and substr(t5.gl_code_name,-4)='利息调整'
            and t5.data_date = '${DATA_DATE}'
            and t5.bddw_end_date = '9999-99-99'
      left join odata.gl_v_gl_subject t6
             on substr(t1.accountingcode,1,6)=substr(t6.gl_code,1,6)
            and substr(t6.gl_code_name,-6)='公允价值变动'
            and t6.data_date = '${DATA_DATE}'
            and t6.bddw_end_date = '9999-99-99'