---------------------------------------------------------------------------------------------------------------
--脚本名称：数仓机构表取数逻辑.sql
--功能描述：用于 gdata.dim_g_branch_p
--作    者：高源
--开发日期：2022-07-25
--直属经理：方杰
--修改历史：
--来源表：odata.sym_fm_branch     机构参数信息表 
--目标表： gdata.dim_g_org_p
--          1.高源   2022-07-25    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table gdata.dim_g_branch_p 
select /*+ REPARTITION(1) */
      nvl(a.branch             ,'')                          as   org_id       --机构代码
     ,nvl(a.branch_name        ,'')                          as   org_name     --机构名称
     ,nvl(a.attached_to        ,'')                          as   up_org_id    --上级机构
     ,nvl(a.hierarchy_code     ,'')                          as   org_lvl      --机构层级
     ,nvl(a.branch_type        ,'')                          as   org_type     --机构类型 
     ,'${DATA_DATE}'                                         as   data_date    --数据日期
  from odata.sym_fm_branch a       --机构参数信息表 
  where a.data_date='${DATA_DATE}'
    and a.bddw_end_date='9999-99-99'