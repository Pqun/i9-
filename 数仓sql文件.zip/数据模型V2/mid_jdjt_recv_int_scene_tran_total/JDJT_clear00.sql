insert overwrite table smart.mid_jdjt_yjlx partition(data_date='${DATA_DATE}')
  select
    yjlx.loan_id,
    '',
  sum(case 
        when yjlx.sence in ('006','007','008','052A','062') then nvl(yjlx.amt,0)
        else -nvl(yjlx.amt,0)
       end ) as amt
from smart.mid_jdjt_yjlx yjlx
where yjlx.data_date = '${DATA_DATE}'
  and yjlx.amt<>0
group by yjlx.loan_id 