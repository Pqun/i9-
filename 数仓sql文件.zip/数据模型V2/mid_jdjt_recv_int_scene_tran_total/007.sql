--007 加
insert into dwd.mid_jdjt_recv_int_scene_tran partition(data_date='${DATA_DATE}')

 select /*+ REPARTITION(1) */ 
 t.loan_no
       ,'007'
       ,sum(nvl(t1.yuq_int,0)) as  amt
    from  odata.slur_jd_loan_data_hist t 		   
	inner join odata.slur_jd_loan_data_hist t1 	
			on t.loan_no =  t1.loan_no 
			and t1.data_date = '${DATA_DATE}'
			and t1.bddw_end_date = '9999-99-99'
			and substr(t1.channel_date,1,10) = date_add('${DATA_DATE}',-2)
	
	where t.data_date = '${DATA_DATE}'
		   and t.bddw_end_date = '9999-99-99'
		   and substr(t.channel_date,1,10) = date_add('${DATA_DATE}',-1)
		   and t.yuq_days = 89
		   and exists(
			 select 1 from odata.slur_dzz_compensatory_detail dcd
				where dcd.data_date = '${DATA_DATE}'
				and dcd.bddw_end_date = '9999-99-99'
				and dcd.sl_id = 'JD' 
				and dcd.comps_status = 'S'
				and dcd.channel_date <= regexp_replace(date_add('${DATA_DATE}',-1),'-','')
				and dcd.loan_no =  t.loan_no 			
			)
			group  by   t.loan_no 