--ES070 减
--20230517 新增关联代偿表逻辑
insert into dwd.mid_jdjt_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */ 
      a.loan_no
     ,'ES070'
     ,-sum(nvl(a.int_accrued,0)) as amt
from odata.slur_jd_loan_data_hist a
inner join odata.slur_jd_loan_data_hist b
   on a.loan_no = b.loan_no
  and b.data_date = '${DATA_DATE}'
  and b.bddw_end_date = '9999-99-99'
  and substr(b.channel_date,1,10) = date_add('${DATA_DATE}',-2)
  and b.yuq_days > 88
where a.data_date = '${DATA_DATE}'
  and a.bddw_end_date = '9999-99-99'
  and substr(a.channel_date,1,10) = date_add('${DATA_DATE}',-1)
  and a.yuq_days <= 88
  and exists (
  select 1 from odata.slur_dzz_compensatory_detail c where 
  a.loan_no=c.loan_no
  and c.data_date = '${DATA_DATE}'
  and c.bddw_end_date = '9999-99-99'
  and c.comps_status = 'S'
  and c.prod_type = '110104'
  and c.tran_date <= regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  )
group by a.loan_no