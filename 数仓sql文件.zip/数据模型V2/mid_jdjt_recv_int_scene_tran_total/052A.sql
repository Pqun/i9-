--052A 加
insert into dwd.mid_jdjt_recv_int_scene_tran partition(data_date='${DATA_DATE}')
     select /*+ REPARTITION(1) */ 
             a.loan_no
            ,'052A'
            ,sum(nvl(b.odp_amt,0)-nvl(c.odp_amt,0)) as amt
       from odata.slur_jd_loan_data_hist a
 inner join odata.slur_jd_loan_schedule_hist b
         on a.loan_no = b.loan_no
        and b.data_date = '${DATA_DATE}'
        and b.bddw_end_date = '9999-99-99'
        and substr(b.channel_date,1,10) = date_add('${DATA_DATE}',-1)
 inner join odata.slur_jd_loan_schedule_hist c
         on a.loan_no = c.loan_no
        and b.stage_no = c.stage_no
        and c.data_date = date_add('${DATA_DATE}',-1) --20220517修改
        and c.bddw_end_date = '9999-99-99'
        and substr(c.channel_date,1,10) = date_add('${DATA_DATE}',-2)
      where a.data_date = '${DATA_DATE}'
        and a.bddw_end_date = '9999-99-99'
        and substr(a.channel_date,1,10) = date_add('${DATA_DATE}',-1)
        and substr(a.tran_date,1,10) = '${DATA_DATE}'
        and a.yuq_days >= 89
        and exists (select 1 
                      from odata.slur_dzz_compensatory_detail d 
                     where d.data_date = '${DATA_DATE}'
                       and d.bddw_end_date = '9999-99-99'
                       and d.comps_status = 'S'
                       and d.tran_date <= regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
                       and a.loan_no = d.loan_no)
        and not exists (select 1 
                          from odata.slur_dzz_compensatory_detail d 
                         where d.data_date = '${DATA_DATE}'
                           and d.bddw_end_date = '9999-99-99'
                           and d.comps_status = 'S'
                           and d.tran_date <= regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
                           and a.loan_no = d.loan_no 
                           and d.term_no = b.stage_no)
        group by a.loan_no