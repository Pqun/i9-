--065 短期或中长期正常贷款退货冲销的利息（应计） 减
insert into dwd.mid_jdjt_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */ 
b.loan_no
,'065'
,-sum(nvl(b.rec_int_amt,0))
from odata.slur_acc_writeoff_detail a
inner join odata.slur_jd_loan_receipt_hist b 
on a.loan_no = b.loan_no
and substr(b.channel_date,1,10) = date_add('${DATA_DATE}',-1)
and b.data_date = '${DATA_DATE}'
and b.bddw_end_date = '9999-99-99'
and b.receipt_type='05' --冲销
inner join odata.slur_jd_loan_data_hist c 
on b.loan_no=c.loan_no
and c.data_date = '${DATA_DATE}'
and c.bddw_end_date = '9999-99-99'
and substr(c.channel_date,1,10) = date_add('${DATA_DATE}',-2)
and c.yuq_days < 89
and c.yuq_flag='1'
where a.data_date = '${DATA_DATE}'
and a.bddw_end_date = '9999-99-99'
and a.status='S'
group by b.loan_no