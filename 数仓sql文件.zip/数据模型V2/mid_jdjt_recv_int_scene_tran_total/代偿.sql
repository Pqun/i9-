--代偿发生额
insert into dwd.mid_jdjt_recv_int_scene_tran partition(data_date='${DATA_DATE}')
 select /*+ REPARTITION(1) */ 
 t1.loan_no
        ,'DC'
        ,-sum(nvl(t1.comps_int,0)+nvl(t1.comps_prin_pnlt,0))  as amt		
    from odata.slur_dzz_compensatory_detail t1
	where t1.data_date='${DATA_DATE}'
	  and t1.comps_status = 'S'
      and t1.prod_class = '02'
      and t1.prod_type = '110104'
      and t1.tran_date = regexp_replace('${DATA_DATE}','-','')
	  group by t1.loan_no