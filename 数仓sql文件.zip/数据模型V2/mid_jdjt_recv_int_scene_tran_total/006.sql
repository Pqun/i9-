--006 加
insert overwrite table dwd.mid_jdjt_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */ 
     cct.loan_no
    ,'006'
    ,sum(nvl(jls.int_amt,0)) as amt
from (
    select distinct t.loan_no 
    from odata.slur_dzz_compensatory_detail t 
    where t.data_date = '${DATA_DATE}'
      and t.bddw_end_date = '9999-99-99'
      and t.sl_id = 'JD' 
      and t.comps_status = 'S'
      and t.channel_date <= regexp_replace(date_add('${DATA_DATE}',-2),'-','')
) cct
left join odata.slur_jd_loan_data_hist jld 
   on cct.loan_no = jld.loan_no
  and jld.data_date = '${DATA_DATE}'
  and jld.bddw_end_date = '9999-99-99'
left join odata.slur_jd_loan_schedule_hist jls 
   on jld.loan_no = jls.loan_no
  and jls.data_date = '${DATA_DATE}'
  and jls.bddw_end_date = '9999-99-99'
where substr(jld.channel_date,1,10) = date_add('${DATA_DATE}',-1)
  and substr(jld.tran_date,1,10) = '${DATA_DATE}'
  and jld.channel_date = jls.channel_date 
  and jld.yuq_days > 88
  and jls.cur_accounting_status = '1' 
  and jls.cur_yuq_days = '0'
group by cct.loan_no