--062 加
insert into dwd.mid_jdjt_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */ 
   cct.loan_no
  ,'062'
  ,sum(nvl(bb.odp_accred_ctd,0)) as amt
from (select distinct t.loan_no 
      from odata.slur_dzz_compensatory_detail t
      where t.sl_id = 'JD' 
        and t.comps_status = 'S'
        and t.channel_date <= regexp_replace(date_add('${DATA_DATE}',-2),'-','')
      --and t.tran_date <= regexp_replace(date_add('${DATA_DATE}',-1),'-','')  
      and t.bddw_end_date='9999-99-99'
        and t.data_date=date_add('${DATA_DATE}',-1)
      ) cct 
left join odata.slur_jd_loan_data_hist bb 
   on cct.loan_no =  bb.loan_no 
  and bb.yuq_days >= 89
  and substr(bb.channel_date,1,10) = date_add('${DATA_DATE}',-1)
  and bb.data_date='${DATA_DATE}' 
  and bb.bddw_end_date='9999-99-99'
  and substr(bb.tran_date,1,10) ='${DATA_DATE}'
group by cct.loan_no
union all 
select /*+ REPARTITION(1) */ 
t.loan_no
,'062'
,sum(t.odp_accred_ctd) 
from odata.slur_jd_loan_data_hist t
inner join odata.slur_jd_loan_data_hist t1
on t.loan_no = t1.loan_no
and t1.data_date = '${DATA_DATE}'
and t1.bddw_end_date = '9999-99-99'
and substr(t1.channel_date,1,10) = date_add('${DATA_DATE}',-2)
where 
substr(t.channel_date,1,10) = date_add('${DATA_DATE}',-1)
and t.yuq_days < 89
and t1.yuq_days >=89
and t.data_date = '${DATA_DATE}'
and t.bddw_end_date = '9999-99-99'
and exists(select 1 from odata.slur_acc_writeoff_hist t3 
where t3.loan_no = t.loan_no and t3.prod_type='110104'
and t3.data_date='${DATA_DATE}' and t3.bddw_end_date='9999-99-99')
group by t.loan_no