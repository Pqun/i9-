with tmp as (
 select
   yjlx.bill_no as loan_id ,
   '',
   nvl(yjlx.receiv_int,0) as amt 
 from dwd.mid_jdjt_recv_int_scene_tran_total yjlx
 where yjlx.data_date = date_add('${DATA_DATE}',-1)
  
union all 

select 
 yjlx.bill_no as loan_id ,
 '',
 nvl(yjlx.receiv_int,0) as amt 
from dwd.mid_jdjt_recv_int_scene_tran yjlx
where yjlx.data_date = '${DATA_DATE}' 
)

insert overwrite table dwd.mid_jdjt_recv_int_scene_tran_total partition(data_date='${DATA_DATE}')
select  /*+ REPARTITION(1) */ 
 tmp.loan_id,
 '',
  sum(tmp.amt)
from tmp 
group by tmp.loan_id 