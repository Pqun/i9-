--HX02 减
insert into dwd.mid_jdjt_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */ 
      a.loan_no
     ,'HX02'
     ,-sum(nvl(b.odp_accred_ctd,0)) as amt
from odata.slur_acc_writeoff_hist a
inner join odata.slur_jd_loan_data_hist b
  on  a.loan_no = b.loan_no
  and b.data_date = '${DATA_DATE}'
  and b.bddw_end_date = '9999-99-99'
  and b.yuq_days < 89
  and substr(b.channel_date,1,10) = date_add('${DATA_DATE}',-1)--20220105
where a.data_date = '${DATA_DATE}'
  and a.bddw_end_date = '9999-99-99'
  and a.prod_type = '110104'
group by a.loan_no