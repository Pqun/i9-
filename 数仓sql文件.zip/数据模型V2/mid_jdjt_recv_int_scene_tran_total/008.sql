--008 加
insert into dwd.mid_jdjt_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */ 
     cct.loan_no
    ,'008'
    ,sum(nvl(bb.odp_accrued,0)-nvl(bb.odp_accred_ctd,0)) as amt
from (
    select distinct t.loan_no 
    from odata.slur_dzz_compensatory_detail t 
    where t.data_date = '${DATA_DATE}'
      and t.bddw_end_date = '9999-99-99'
      and t.sl_id = 'JD' 
      and t.comps_status = 'S'
      and t.channel_date <= regexp_replace(date_add('${DATA_DATE}',-2),'-','')
) cct 
left join odata.slur_jd_loan_data_hist bb 
   on cct.loan_no = bb.loan_no 
  and bb.data_date = '${DATA_DATE}'
  and bb.bddw_end_date = '9999-99-99'
  and substr(bb.channel_date,1,10) = date_add('${DATA_DATE}',-1)
  and substr(bb.tran_date,1,10) = '${DATA_DATE}' 
  and bb.yuq_days > 88
where bb.loan_no in (select t.loan_no 
                       from odata.slur_jd_loan_data_hist t 
                      where t.data_date = '${DATA_DATE}'
                        and t.bddw_end_date = '9999-99-99'
                        and substr(t.channel_date,1,10) = date_add('${DATA_DATE}',-2)
                        and t.yuq_days = 88)
group by cct.loan_no