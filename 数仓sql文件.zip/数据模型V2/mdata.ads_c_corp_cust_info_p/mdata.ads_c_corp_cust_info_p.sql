---------------------------------------------------------------------------------------------------------------
--脚本名称：对公客户信息取数逻辑.sql
--功能描述：用于在hive mdata层创建mdata.ads_c_corp_cust_info_p
--作    者：施金才
--开发日期：2020-11-19
--直属经理：程宏明
--修改历史：
--          1.施金才   2020-11-19    新建
--          2.张礼娟   2021-05-07    源表由gdata.ads_c_corp_cust_info_p改为dwd.dwd_c_corp_cust_info_p
---------------------------------------------------------------------------------------------------------------
insert overwrite table mdata.ads_c_corp_cust_info_p partition(data_date='${DATA_DATE}')
select
     acct_mask(cust_id) as cust_id                   
    ,cust_type_code            
    ,cust_subdiv_type          
    ,name_mask(cust_name) as cust_name                 
    ,cust_en_name              
    ,cert_type_code             
    ,cert_no
    ,name_mask(lgl_name) as lgl_name                  
    ,lgl_cert_type             
    ,lgl_cert_no               
    ,cust_crdt_lvl             
    ,cust_crdt_lvl_cont        
    ,create_chan               
    ,tax_id                    
    ,cust_tran_status          
    ,is_inner_cust             
    ,addr_mask(contact_addr) as contact_addr              
    ,contact_addr_code         
    ,total_asset               
    ,opra_income               
    ,opra_status               
    ,source_sys_code           
    ,regist_capital            
    ,regist_capital_ccy        
    ,addr_mask(regist_addr) as regist_addr               
    ,addr_mask(office_addr) as office_addr               
    ,regist_date               
    ,regist_end_date           
    ,regist_update_date        
    ,regist_country_code       
    ,regist_area_code          
    ,opra_scope                
    ,pare_cust_id              
    ,is_listed_flag            
    ,emp_no                    
    ,corp_scale                
    ,investor_econ_type_code   
    ,is_rela_cust_flag         
    ,paid_captial_amt          
    ,create_date               
    ,stock_mkt_type_code       
    ,overseas_flag             
    ,grp_cust_flag             
    ,cust_create_date          
    ,cust_create_org_id        
    ,cust_belong_org_id        
    ,sholder_flag              
    ,sholder_ratio             
    ,cust_magr_id              
    ,indust_type_code          
    ,unif_soc_crdt             
    ,crdt_amt                  
    ,used_amt                  
    ,acct_mask(base_acct_no) as base_acct_no              
    ,base_acct_org_no          
    ,base_acct_org_name        
    ,nat_econ_depar_code       
    ,nat_tax_cert_no           
    ,local_tax_cert_no         
    ,cust_loc_area             
    ,cust_country_code         
    ,rela_cust_type_code       
    ,null as remark1                   
    ,null as remark2                   
    ,null as remark3                   
    ,null as remark4                   
    ,null as remark5                   
from gdata.ads_c_corp_cust_info_p
where data_date='${DATA_DATE}'