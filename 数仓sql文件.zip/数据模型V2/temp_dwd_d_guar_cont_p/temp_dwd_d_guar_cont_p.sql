--2.dq.temp_dwd_d_guar_cont_p
-------------------------------------------------------------------
--脚本名称:temp_dwd_d_guar_cont_p
--功能描述:担保合同信息表
--作    者:邓权
--开发日期:2022-08-21
--直属经理:方杰
--目标表  :dwd.temp_dwd_d_guar_cont_p                  担保物信息表
--数据原表: odata.pawn_pawn_base                       押品主表
--         odata.pawn_pawn_car                        车辆抵押品信息表
--         odata.order_main_loan_order                订单主表
--         odata.order_product_loan_info              产品贷款信息
--         odata.sllv_nl_acct                         线上贷款客户信息表
--         odata.order_contract_sign                  合同签署表
--         odata.order_custom_info                    客户信息表
--         odata.pawn_pawn_house                      房贷抵押品表
--         odata.order_loan_order_house               房抵贷订单表
--         odata.sllv_mb_acct                         账户基本信息表
--         odata.pawn_house_evaluate                  房屋估价信息表
--         odata.order_credit_order_info              授信信息表
--         odata.order_loan_order_car_dealer          车主贷贷款信息表
--         odata.pawn_pawn_machine                    机器抵押品信息表
--         odata.order_coborrower_info                共借人信息表
--         odata.sym_cif_client                       客户信息表
--         odata.sym_cif_client_document              客户证件信息
--         odata.als_guaranty_contract                担保合同信息表 
--         odata.als_cl_occupy                        额度占用关系表
--         odata.als_contract_relative                合同关联表
--         odata.als_business_contract                业务合同信息表
--         odata.als_business_duebill                 业务借据(账户)信息表
--         odata.als_ent_info                         企业基本信息
--         odata.als_customer_address                 客户联系地址信息表
--         odata.als_customer_cert                    客户证件信息表
--修改历史:
--         1、邓权     20220821     新建
--         2、邓权     20230110     新增锡惠贷、变更信贷部分产品号逻辑、变更信贷部分被担保合同取数源
--         3、邓权     20230207     修改信贷部分担保合同金额、担保方式取数逻辑
--         4、邓权     20230323     新增抵质押率字段
--         5、邓权     20230627     调整锡惠贷、锡机贷、车商贷、车主贷、铁甲、孚厘、锡惠贷担保合同号/被担保合同号/担保人名称/担保人证件号/被担保人名称/被担保人证件号逻辑
------------------------------------------------------------------
insert overwrite table dwd.temp_dwd_d_guar_cont_p partition(data_date='${DATA_DATE}') 
--锡车贷、锡机贷 
select 
    /*+ REPARTITION(1) */
nvl(t4.branch,'100000')         as  org_id              --内部机构号 
,nvl(t2.contract_no,'')         as  guar_cont_no        --担保合同号 
,''                             as  guar_cont_name      --担保合同名称    无法获知担保合同名称
,nvl(t7.coborrower_name,'')     as  guartor_name        --担保人名称 
,'101'                          as  guar_cert_type      --担保人证件类别 101身份证    
,nvl(t7.card_no,'')             as  guar_cert_no        --担保人证件号码   
,nvl(t3.contract_no,'')         as  wart_cont_no        --被担保合同号    
,nvl(t8.user_name,'')           as  wart_name           --被担保人姓名    
,'101'                          as  wart_cert_type      --被担保人证件类型  
,nvl(t8.id_card,'')             as  wart_cert_no        --被担保人证件号   
,'02'                           as  tran_type           --交易类型信贷交易  
,t4.prod_type                   as  prod_code           --产品代码  
,'1'                            as  guar_cont_type_code   --担保合同类型代码   一般担保合同
,nvl(t1.status,'')              as  guar_status         --担保合同状态    
,'CNY'                          as  ccy                 --担保币种  无法确定担保合同对应的币种
,nvl(t1.apply_amount,0)         as  guar_amt            --担保金额  无法确定订单主表中申请金额是否为担保金额
,case when t4.prod_type in  ('110115','110116') and t2.loan_id is not null then 'E' --110115锡车贷-消费贷  110116锡车贷-经营贷
      when t4.prod_type in  ('110115','110116') and t2.loan_id is null then 'B99'   --110115锡车贷-消费贷  110116锡车贷-经营贷
      when t4.prod_type in  ('110129','110130') then 'C99'  --锡机贷-上牌车（免征）
      when t4.prod_type in  ('110110','110122') and t5.loan_id is not null and t5.coll_type ='信用' then 'D'  --110110锡机贷-易起投   110122锡机贷-易起投（非免征）
      when t4.prod_type in  ('110110','110122') and t5.loan_id is not null and t5.coll_type ='保证' then 'C99'--110110锡机贷-易起投   110122锡机贷-易起投（非免征）
      when t4.prod_type in  ('110110','110122') and t5.loan_id is null then 'Z'  --110110锡机贷-易起投   110122锡机贷-易起投（非免征）
      else '' end               as  guar_mode
,''                             as  main_guar_flag      --是否主担保
,nvl(substr(t2.sign_time,1,10),'')  as  guar_begin_date     --担保开始日期    无法确认开始日期口径
,nvl(from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as guar_end_date  --担保到期日期 无法确认到期日期口径 
,''                             as  guar_order          --担保顺位
,''                             as  guartor_nat_econ_depar  --担保人国民经济部门
,''                             as  guartor_indst       --担保人行业
,''                             as  guartor_area_code   --担保人地区代码
,''                             as  guartor_corp_scale  --担保人企业规模
--,''                             as  oper_emp_id         --经办人工号
,0                              as  guar_rate           --抵质押率
from odata.order_contract_sign    t2  
left join odata.order_main_loan_order t1
       on t1.loan_id=t2.loan_id 
      and t1.data_date='${DATA_DATE}' 
      and t1.bddw_end_date='9999-99-99' 
left join odata.order_contract_sign t3 
       on t1.loan_id=t3.loan_id 
      and t3.data_date='${DATA_DATE}' 
      and t3.bddw_end_date='9999-99-99' 
      and t3.signer_type=1    --签署人为主借人
      and t3.contract_type=2  --个人借款协议
      and t3.id <> '2161510'  --20220630 重复数据，去掉一条 
inner join odata.sllv_mb_acct t4
       on t1.loan_id=t4.cmisloan_no
      and t4.data_date='${DATA_DATE}'
      and t4.bddw_end_date='9999-99-99' 
      and t4.prod_type in ('110115','110116','110129','1110130','110110','110122')
left join(select
                distinct a.loan_id
               ,if(b.device_type== '0' and c.loan_id is null,'信用','保证') as coll_type 
          from odata.pawn_pawn_base a 
          left join odata.pawn_pawn_machine b 
                 on a.id=b.pawn_id 
                and b.data_date='${DATA_DATE}' 
                and b.bddw_end_date='9999-99-99' 
          left join odata.order_contract_sign c 
                 on a.loan_id=c.loan_id
                and c.data_date='${DATA_DATE}' 
                and c.bddw_end_date= '9999-99-99' 
                and c.contract_type in ('3','4') 
                and c.id <> '2161510'--20220630 重复数据，去掉一条 
          where a.data_date='${DATA_DATE}' 
            and a.bddw_end_date='9999-99-99') t5
        on  t1.loan_id=t5.loan_id
left join odata.order_coborrower_info t7 
       on t1.loan_id=t7.loan_id
      and t7.data_date='${DATA_DATE}'
      and t7.bddw_end_date = '9999-99-99'
      and t7.borrower_type=2 --担保人 
      and t2.sign_id_card = t7.card_no
left join odata.order_custom_info t8 
       on t1.user_id=t8.user_id 
      and t1.loan_id=t8.loan_id 
      and t8.data_date= '${DATA_DATE}'
      and t8.bddw_end_date ='9999-99-99' 
    where t2.data_date='${DATA_DATE}'
      and t2.bddw_end_date='9999-99-99'
      and t2.signer_type=2    --签署人为担保人
      and t2.contract_type=3  --个人担保协议 
      and t2.id <> '2161510'  --20220630 重复数据，去掉一条
union all
--车商贷	  
select 
    /*+ REPARTITION(1) */
nvl(t5.branch,'100000')         as  org_id              --内部机构号 
,nvl(t2.contract_no,'')         as  guar_cont_no        --担保合同号 
,''                             as  guar_cont_name      --担保合同名称    无法获知担保合同名称
,nvl(t82.ch_client_name,'')     as  guartor_name        --担保人名称 
,nvl(t83.document_type, '')     as  guar_cert_type      --担保人证件类别 101身份证    
,nvl(t83.document_id,'')        as  guar_cert_no        --担保人证件号码   
,nvl(t4.contract_no,'')         as  wart_cont_no        --被担保合同号    
,nvl(t82.ch_client_name,'')     as  wart_name           --被担保人姓名    
,nvl(t83.document_type, '')     as  wart_cert_type      --被担保人证件类型  
,nvl(t83.document_id,'')        as  wart_cert_no        --被担保人证件号   
,'02'                           as  tran_type           --交易类型信贷交易  
,t5.prod_type                   as  prod_code           --产品代码  
,'2'                            as  guar_cont_type_code   --担保合同类型代码   一般担保合同
,nvl(t6.status,t61.status)      as  guar_status         --担保合同状态    
,'CNY'                          as  ccy                 --担保币种  无法确定担保合同对应的币种
,nvl(t6.apply_amount,t61.apply_amount)         as  guar_amt            --担保金额  无法确定订单主表中申请金额是否为担保金额
,'A'                            as  guar_mode
,''                             as  main_guar_flag      --是否主担保
,nvl(substr(t2.sign_time,1,10),'')  as  guar_begin_date     --担保开始日期    无法确认开始日期口径
,nvl(from_unixtime(unix_timestamp(t5.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as guar_end_date  --担保到期日期 无法确认到期日期口径 
,''                             as  guar_order          --担保顺位
,''                             as  guartor_nat_econ_depar  --担保人国民经济部门
,''                             as  guartor_indst       --担保人行业
,''                             as  guartor_area_code   --担保人地区代码
,''                             as  guartor_corp_scale  --担保人企业规模
--,''                             as  oper_emp_id         --经办人工号
,0                              as  guar_rate           --抵质押率
from odata.order_contract_sign    t2  
 left join odata.order_main_loan_order t3
   on t3.order_type = '2'  --用信
  and t3.data_date='${DATA_DATE}'
  and t3.bddw_end_date='9999-99-99'
  and t3.loan_time is not null
  and t3.loan_id=t2.loan_id
 left join odata.order_main_credit_order t6
   on t6.loan_id=t3.credit_order_id
  and t6.data_date='${DATA_DATE}'
  and t6.bddw_end_date='9999-99-99'
 left join odata.order_main_loan_order t61
   on t61.loan_id=t3.credit_order_id
  and t61.data_date='${DATA_DATE}'
  and t61.bddw_end_date='9999-99-99'
  and t61.order_type = '1'  --授信
 left join odata.order_main_loan_order t31
   on t31.order_type = '2'  --用信
  and t31.data_date='${DATA_DATE}'
  and t31.bddw_end_date='9999-99-99'
  and t31.loan_time is not null
  and nvl(t6.loan_id,t61.loan_id)=t31.credit_order_id
left join odata.order_contract_sign t4
       on t31.loan_id=t4.loan_id 
      and t4.data_date='${DATA_DATE}' 
      and t4.bddw_end_date='9999-99-99' 
      and t4.signer_type=1    --签署人为主借人
      and t4.contract_type=2  --个人借款协议
      and t4.id <> '2161510'  --20220630 重复数据，去掉一条 
inner join odata.sllv_mb_acct t5
       on t31.loan_id=t5.cmisloan_no
      and t5.data_date='${DATA_DATE}'
      and t5.bddw_end_date='9999-99-99' 
	  and t5.prod_type in ('110120','110121')
left join(select
                distinct a.loan_id
               ,if(b.device_type== '0' and c.loan_id is null,'信用','保证') as coll_type 
          from odata.pawn_pawn_base a 
          left join odata.pawn_pawn_machine b 
                 on a.id=b.pawn_id 
                and b.data_date='${DATA_DATE}' 
                and b.bddw_end_date='9999-99-99' 
          left join odata.order_contract_sign c 
                 on a.loan_id=c.loan_id
                and c.data_date='${DATA_DATE}' 
                and c.bddw_end_date= '9999-99-99' 
                and c.contract_type in ('3','4') 
                and c.id <> '2161510'--20220630 重复数据，去掉一条 
          where a.data_date='${DATA_DATE}' 
            and a.bddw_end_date='9999-99-99') t62
        on  t2.loan_id=t62.loan_id
left join odata.sym_cif_client t82
       on t5.client_no=t82.client_no 
      and t82.data_date= '${DATA_DATE}'
      and t82.bddw_end_date ='9999-99-99' 
left join odata.order_loan_order_car_dealer t9
       on t2.loan_id=t9.loan_id 
      and t9.data_date= '${DATA_DATE}'
      and t9.bddw_end_date ='9999-99-99' 
	  and split(t9.contract_no,',')[2] = t2.contract_no 
left join odata.sym_cif_client_document t83
       on t5.client_no=t83.client_no 
      and t83.data_date= '${DATA_DATE}'
      and t83.bddw_end_date ='9999-99-99' 
    where t2.data_date='${DATA_DATE}'
      and t2.bddw_end_date='9999-99-99'
      and t2.contract_type='29'  --最高额动产质押合同 
      and t2.signer_type = '1'
      and t2.id <> '2161510'  --20220630 重复数据，去掉一条
	  and t9.loan_id is null
union all 
--车商贷	  
select 
    /*+ REPARTITION(1) */
nvl(t5.branch,'100000')         as  org_id              --内部机构号 
,nvl(split(t2.contract_no,',')[2],'') as  guar_cont_no        --担保合同号 
,''                             as  guar_cont_name      --担保合同名称    无法获知担保合同名称
,nvl(t82.ch_client_name,'')     as  guartor_name        --担保人名称 
,nvl(t83.document_type, '')     as  guar_cert_type      --担保人证件类别 101身份证    
,nvl(t83.document_id,'')        as  guar_cert_no        --担保人证件号码   
,nvl(t4.contract_no,'')         as  wart_cont_no        --被担保合同号    
,nvl(t82.ch_client_name,'')     as  wart_name           --被担保人姓名    
,nvl(t83.document_type, '')     as  wart_cert_type      --被担保人证件类型  
,nvl(t83.document_id,'')        as  wart_cert_no        --被担保人证件号   
,'02'                           as  tran_type           --交易类型信贷交易  
,t5.prod_type                   as  prod_code           --产品代码  
,'2'                            as  guar_cont_type_code   --担保合同类型代码   一般担保合同
,nvl(t6.status,t61.status)      as  guar_status         --担保合同状态    
,'CNY'                          as  ccy                 --担保币种  无法确定担保合同对应的币种
,nvl(t6.apply_amount,t61.apply_amount)         as  guar_amt            --担保金额  无法确定订单主表中申请金额是否为担保金额
,'A'                            as  guar_mode
,''                             as  main_guar_flag      --是否主担保
,nvl(from_unixtime(unix_timestamp(t5.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as guar_begin_date     --担保开始日期    无法确认开始日期口径
,nvl(from_unixtime(unix_timestamp(t5.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as guar_end_date  --担保到期日期 无法确认到期日期口径 
,''                             as  guar_order          --担保顺位
,''                             as  guartor_nat_econ_depar  --担保人国民经济部门
,''                             as  guartor_indst       --担保人行业
,''                             as  guartor_area_code   --担保人地区代码
,''                             as  guartor_corp_scale  --担保人企业规模
--,''                             as  oper_emp_id         --经办人工号
,0                              as  guar_rate           --抵质押率
from odata.order_loan_order_car_dealer    t2  
 left join odata.order_main_loan_order t3
   on t3.order_type = '2'  --用信
  and t3.data_date='${DATA_DATE}'
  and t3.bddw_end_date='9999-99-99'
  and t3.loan_time is not null
  and t3.loan_id=t2.loan_id
 left join odata.order_main_credit_order t6
   on t6.loan_id=t3.credit_order_id
  and t6.data_date='${DATA_DATE}'
  and t6.bddw_end_date='9999-99-99'
 left join odata.order_main_loan_order t61
   on t61.loan_id=t3.credit_order_id
  and t61.data_date='${DATA_DATE}'
  and t61.bddw_end_date='9999-99-99'
  and t61.order_type = '1'  --授信
 left join odata.order_main_loan_order t31
   on t31.order_type = '2'  --用信
  and t31.data_date='${DATA_DATE}'
  and t31.bddw_end_date='9999-99-99'
  and t31.loan_time is not null 
  and nvl(t6.loan_id,t61.loan_id)=t31.credit_order_id
left join odata.order_contract_sign t4
       on t31.loan_id=t4.loan_id 
      and t4.data_date='${DATA_DATE}' 
      and t4.bddw_end_date='9999-99-99' 
      and t4.signer_type=1    --签署人为主借人
      and t4.contract_type=2  --个人借款协议
      and t4.id <> '2161510'  --20220630 重复数据，去掉一条 
inner join odata.sllv_mb_acct t5
       on t31.loan_id=t5.cmisloan_no
      and t5.data_date='${DATA_DATE}'
      and t5.bddw_end_date='9999-99-99' 
	  and t5.prod_type in ('110120','110121')
left join(select
                distinct a.loan_id
               ,if(b.device_type== '0' and c.loan_id is null,'信用','保证') as coll_type 
          from odata.pawn_pawn_base a 
          left join odata.pawn_pawn_machine b 
                 on a.id=b.pawn_id 
                and b.data_date='${DATA_DATE}' 
                and b.bddw_end_date='9999-99-99' 
          left join odata.order_contract_sign c 
                 on a.loan_id=c.loan_id
                and c.data_date='${DATA_DATE}' 
                and c.bddw_end_date= '9999-99-99' 
                and c.contract_type in ('3','4') 
                and c.id <> '2161510'--20220630 重复数据，去掉一条 
          where a.data_date='${DATA_DATE}' 
            and a.bddw_end_date='9999-99-99') t62
        on  t2.loan_id=t62.loan_id
left join odata.sym_cif_client t82
       on t5.client_no=t82.client_no 
      and t82.data_date= '${DATA_DATE}'
      and t82.bddw_end_date ='9999-99-99' 
left join odata.sym_cif_client_document t83
       on t5.client_no=t83.client_no 
      and t83.data_date= '${DATA_DATE}'
      and t83.bddw_end_date ='9999-99-99' 
    where t2.data_date='${DATA_DATE}'
      and t2.bddw_end_date='9999-99-99'
      and nvl(split(t2.contract_no,',')[2],'0') <> '0'	  
union all                   
--锡房贷                   
select                  
    /*+ REPARTITION(1) */
nvl(t4.branch,'100000')     as  org_id  --内部机构号     
,nvl(t31.contract_no,'')    as  guar_cont_no    --担保合同号 无法获知担保合同号   
,''                         as  guar_cont_name  --担保合同名称    无法获知担保合同名称  
,nvl(t82.ch_client_name,'') as  guartor_name        --担保人名称 
,nvl(t83.document_type, '') as  guar_cert_type  --担保人证件类别 101身份证        
,nvl(t83.document_id,'')    as  guar_cert_no        --担保人证件号码   
,nvl(t31.contract_no,'')    as  wart_cont_no    --被担保合同号        
,nvl(t82.ch_client_name,'') as  wart_name           --被担保人姓名    
,nvl(t83.document_type, '') as  wart_cert_type  --被担保人证件类型
,nvl(t83.document_id,'')    as  wart_cert_no        --被担保人证件号   
,'02'                       as  tran_type   --交易类型信贷交易
,t4.prod_type               as  prod_code   --产品代码
,'1'                        as  guar_cont_type_code --担保合同类型代码  一般担保合同
,nvl(t1.status,'')          as  guar_status --担保合同状态
,'CNY'                      as  ccy --担保币种
,nvl(t31.actual_loan_amount,0)      as guar_amt --担保金额  无法确定实际贷款金额是否为担保金额
,'B01'                      as  guar_mode_code  --担保方式代码
,''                         as  main_guar_flag  --是否主担保
,nvl(from_unixtime(unix_timestamp(t4.acct_open_date, 'yyyyMMdd'), 'yyyy-MM-dd'),'') as  guar_begin_date  --担保开始日期  
,nvl(from_unixtime(unix_timestamp(t4.maturity_date, 'yyyyMMdd'), 'yyyy-MM-dd'),'') as guar_end_date  --担保结束日期  无法确定担保结束日期
,''                         as  guar_order          --担保顺位
,''                         as  guartor_nat_econ_depar --担保人国民经济部门
,''                         as  guartor_indst--担保人行业
,''                         as  guartor_area_code--担保人地区代码
,''                         as  guartor_corp_scale--担保人企业规模
--,''                             as  oper_emp_id         --经办人工号
,0                          as  guar_rate           --抵质押率
from odata.order_loan_order_house t31 
left join odata.order_main_loan_order t1  
on t1.loan_id =t31.loan_id
and t1.data_date='${DATA_DATE}'
and t1.bddw_end_date='9999-99-99'
inner join odata.sllv_mb_acct t4 
on nvl(t1.receipt_no,t1.loan_id)=t4.cmisloan_no 
and t4.data_date='${DATA_DATE}' 
and t4.bddw_end_date='9999-99-99'
and t4.prod_type = '110108' 
left join odata.sym_cif_client t82
on t4.client_no=t82.client_no 
and t82.data_date= '${DATA_DATE}'
and t82.bddw_end_date ='9999-99-99' 
left join odata.sym_cif_client_document t83
on t4.client_no=t83.client_no 
and t83.data_date= '${DATA_DATE}'
and t83.bddw_end_date ='9999-99-99' 
where t31.data_date='${DATA_DATE}'
and t31.bddw_end_date= '9999-99-99'
and nvl(t31.contract_no,'') <> ''
--and substr(t1.apply_time,1,10)<='${DATA_DATE}' 
--and status in (7,8,9,10)
union all 
--长安新生 
select
    /*+ REPARTITION(1) */
nvl(t4.branch,'100000')     as  org_id  --内部机构号     
,nvl(t3.contract_no,'')     as  guar_cont_no    --担保合同号
,''                         as  auar_cont_name  --担保合同名称 无法获知担保合同名称
,nvl(t8.ch_client_name, '') as  guartor_name  --担保人名称
,nvl(t9.document_type, '')  as  guar_cert_type --担保人证件类别 101身份证
,nvl(t9.document_id, '')    as  guar_cert_no        --担保人证件号码
,nvl(t3.contract_no, '')    as  wart_cont_no        --被担保合同号
,nvl(t8.ch_client_name, '') as  wart_name           --被担保人姓名
,nvl(t9.document_type, '')  as  wart_cert_type      --被担保人证件类型
,nvl(t9.document_id, '')    as  wart_cert_no            --被担保人证件号
,'02'                       as  tran_type           --交易类型信贷交易
,t4.prod_type               as  prod_code           --产品代码
,'1'                        as  guar_cont_type_code --担保合同类型代码 一般担保合同
,nvl(t1.status, '')         as  guar_status         --担保合同状态
,'CNY'                      as  ccy                 --担保币种 无法确定担保合同对应的币种
,nvl(t5.actual_loan_amount,0)   as  guar_amt        --担保金额 无法确定订单主表中申请金额是否为担保金额
,'B99'                      as  guar_mode_code      --担保方式代码
,''                         as  main_guar_flag  --是否主担保
,nvl(substr(t4.acct_open_date,1,10),'')  as  guar_begin_date     --担保开始日期   无法确认开始日期口径
,nvl(substr(t4.maturity_date,1,10),'') as guar_end_date  --担保到期日期   无法确认到期日期口径
,''                         as  guar_order          --担保顺位
,''                         as  guartor_nat_econ_depar  --担保人国民经济部门
,''                         as  guartor_indst       --担保人行业
,''                         as  guartor_area_code   --担保人地区代码
,''                         as  guartor_corp_scale  --担保人企业规模
--,''                             as  oper_emp_id         --经办人工号
,0                          as  guar_rate           --抵质押率
from odata.order_contract_sign t3 
left join odata.order_main_loan_order t1 
on t1.loan_id=t3.loan_id 
and t1.data_date= '${DATA_DATE}'
and t1.bddw_end_date='9999-99-99'
--and substr(t1.apply_time,1,10)<='${DATA_DATE}' 
inner join odata.sllv_nl_acct t4
on t1.receipt_no=t4.cmisloan_no
and t4.data_date='${DATA_DATE}' 
and t4.bddw_end_date='9999-99-99'
and t4.prod_type in ('110118', '110119', '110127')
left join odata.order_product_loan_info t5
on t1.loan_id=t5.loan_id 
and t5.data_date='${DATA_DATE}' 
and t5.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client t8 
on t4.client_no = t8.client_no
and t8.data_date='${DATA_DATE}'
and t8.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client_document t9
on t8.client_no = t9.client_no
and t9.data_date = '${DATA_DATE}'
and t9.bddw_end_date = '9999-99-99'
where t3.signer_type=1    --签署人为主借人
and t3.contract_type=2 --个人贷款协议 
and t3.id <> '2161510' --20220630 重复数据，去掉一条 
and t3. data_date='${DATA_DATE}' 
and t3.bddw_end_date='9999-99-99'  
and t1.product_type='4'
and t1.sub_product_type='7'
union all 
--铁甲
select 
    /*+ REPARTITION(1) */
nvl(t4.branch,'100000')     as  org_id          --内部机构号     
,nvl(t3.contract_no,'')     as  guar_cont_no    --担保合同号     
,''                         as  guar_cont_name  --担保合同名称        无法获知担保合同名称
,nvl(t81.user_name,'')      as  guartor_name    --担保人名称     
,'101'                      as  guar_cert_type  --担保人证件类别 101   身份证 
,nvl(t81.id_card, '')       as  guar_cert_no    --担保人证件号码       
,nvl(t9.contract_no,'')     as  wart_cont_no    --被担保合同号        
,nvl(t8.user_name,'')       as  wart_name       --被担保人姓名        
,'101'                      as  wart_cert_type  --被担保人证件类型      
,nvl(t8.id_card,'')         as  wart_cert_no    --被担保人证件号       
,'02'                       as  tran_type       --交易类型信贷交易      
,t4.prod_type               as  prod_code       --产品代码      
,'1'                        as  guar_cont_type_code --担保合同类型代码  一般担保合同  
,nvl(t1.status,'')          as  guar_status     --担保合同状态        
,'CNY'                      as  ccy             --担保币种      无法确定担保合同对应的币种
,nvl(t5.actual_loan_amount, 0)  as guar_amt --担保金额      无法确定订单主表中申请金额是否为担保金额
,'D'                        as  guar_mode_code  --担保方式代码        
,''                         as  main_guar_flag  --是否主担保
,nvl(from_unixtime(unix_timestamp (t4.acct_open_date, 'yyyyMMdd') , 'yyyy-MM-dd'),'')  as  guar_begin_date  --担保开始日期
,nvl(from_unixtime(unix_timestamp (t4.maturity_date, 'yyyyMMdd') , 'yyyy-MM-dd'),'') as guar_end_date   --担保到期期日期   无法确认到期日期口径
,''                         as  guar_order          --担保顺位
,''                         as  guartor_nat_econ_depar  --担保人国民经济部门
,''                         as  guartor_indst   --担保人行业
,''                         as  guartor_area_code   --担保人地区代码
,''                         as  guartor_corp_scale  --担保人企业规模
--,''                             as  oper_emp_id         --经办人工号
,0                          as  guar_rate           --抵质押率
from odata.order_contract_sign t3  
left join odata.order_main_loan_order t1 
on t1.loan_id=t3.loan_id
and t1.data_date='${DATA_DATE}'
and t1.bddw_end_date='9999-99-99'
inner join odata.sllv_mb_acct t4
on t1.receipt_no=t4.cmisloan_no 
and t4.data_date='${DATA_DATE}' 
and t4.bddw_end_date='9999-99-99' 
and t4.prod_type = '110151'
left join odata.order_product_loan_info t5
on t1.loan_id=t5.loan_id
and t5.data_date= '${DATA_DATE}'
and t5.bddw_end_date ='9999-99-99' 
left join odata.order_custom_info t8 
on t1.user_id=t8.user_id
and t1.loan_id=t8.loan_id 
and t8.data_date='${DATA_DATE}' 
and t8.bddw_end_date ='9999-99-99' 
left join odata.order_custom_info t81 
on t3.sign_id_card =t81.id_card 
and t3.loan_id=t81.loan_id 
and t81.data_date='${DATA_DATE}' 
and t81.bddw_end_date ='9999-99-99' 
left join odata.order_contract_sign t9 
on t1.loan_id=t9.loan_id 
and t9.data_date='${DATA_DATE}' 
and t9.bddw_end_date ='9999-99-99' 
and t9.signer_type=1    --签署人为主借人
and t9.contract_type=2 --个人借款协议
where t3.data_date='${DATA_DATE}'
and t3.bddw_end_date= '9999-99-99' 
and t3.contract_type='4' --担保公司担保协议
and t3.id not in  ('2161510','6829028')  --20220630 重复数据去掉—条，20230217孚厘重复记录剔除
--and substr(t1.apply_time,1,10)<='${DATA_DATE}'
--and status in (7,8,9,10)
and t1.product_type='12'
and t1.sub_product_type='18'
union all
--孚厘
select 
    /*+ REPARTITION(1) */
nvl(t4.branch,'100000')     as  org_id          --内部机构号     
,nvl(t3.contract_no,'')     as  guar_cont_no    --担保合同号     
,''                         as  guar_cont_name  --担保合同名称        无法获知担保合同名称
,nvl(t81.user_name,'')      as  guartor_name    --担保人名称     
,'101'                      as  guar_cert_type  --担保人证件类别 101   身份证 
,nvl(t81.id_card, '')       as  guar_cert_no    --担保人证件号码       
,nvl(t9.contract_no,'')     as  wart_cont_no    --被担保合同号        
,nvl(t8.user_name,'')       as  wart_name       --被担保人姓名        
,'101'                      as  wart_cert_type  --被担保人证件类型      
,nvl(t8.id_card,'')         as  wart_cert_no    --被担保人证件号       
,'02'                       as  tran_type       --交易类型信贷交易      
,t4.prod_type               as  prod_code       --产品代码      
,'1'                        as  guar_cont_type_code --担保合同类型代码  一般担保合同  
,nvl(t1.status,'')          as  guar_status     --担保合同状态        
,'CNY'                      as  ccy             --担保币种      无法确定担保合同对应的币种
,nvl(t5.actual_loan_amount, 0)  as guar_amt --担保金额      无法确定订单主表中申请金额是否为担保金额
,'D'                        as  guar_mode_code  --担保方式代码        
,''                         as  main_guar_flag  --是否主担保
,nvl(from_unixtime(unix_timestamp (t4.acct_open_date, 'yyyyMMdd') , 'yyyy-MM-dd'),'')  as  guar_begin_date  --担保开始日期
,nvl(from_unixtime(unix_timestamp (t4.maturity_date, 'yyyyMMdd') , 'yyyy-MM-dd'),'') as guar_end_date   --担保到期期日期   无法确认到期日期口径
,''                         as  guar_order          --担保顺位
,''                         as  guartor_nat_econ_depar  --担保人国民经济部门
,''                         as  guartor_indst   --担保人行业
,''                         as  guartor_area_code   --担保人地区代码
,''                         as  guartor_corp_scale  --担保人企业规模
--,''                             as  oper_emp_id         --经办人工号
,0                          as  guar_rate           --抵质押率
from odata.order_contract_sign t3  
left join odata.order_main_loan_order t1 
on t1.loan_id=t3.loan_id
and t1.data_date='${DATA_DATE}'
and t1.bddw_end_date='9999-99-99'
inner join odata.sllv_mb_acct t4
on t1.receipt_no=t4.cmisloan_no 
and t4.data_date='${DATA_DATE}' 
and t4.bddw_end_date='9999-99-99' 
and t4.prod_type = '110159'
left join odata.order_product_loan_info t5
on t1.loan_id=t5.loan_id
and t5.data_date= '${DATA_DATE}'
and t5.bddw_end_date ='9999-99-99' 
left join odata.order_custom_info t8 
on t1.user_id=t8.user_id
and t1.loan_id=t8.loan_id 
and t8.data_date='${DATA_DATE}' 
and t8.bddw_end_date ='9999-99-99' 
left join odata.order_custom_info t81 
on t3.sign_id_card =t81.id_card 
and t3.loan_id=t81.loan_id 
and t81.data_date='${DATA_DATE}' 
and t81.bddw_end_date ='9999-99-99' 
left join odata.order_contract_sign t9 
on t1.loan_id=t9.loan_id 
and t9.data_date='${DATA_DATE}' 
and t9.bddw_end_date ='9999-99-99' 
and t9.signer_type=1    --签署人为主借人
and t9.contract_type=2 --个人借款协议
where t3.data_date='${DATA_DATE}'
and t3.bddw_end_date= '9999-99-99' 
and t3.contract_type='4' --担保公司担保协议
and t3.id not in  ('2161510','6829028')  --20220630 重复数据去掉—条，20230217孚厘重复记录剔除
--and substr(t1.apply_time,1,10)<='${DATA_DATE}'
--and status in (7,8,9,10)
and t1.product_type='14'
and t1.sub_product_type='23'
union all
--信贷
select      
    /*+ REPARTITION(1) */
distinct    
'100000'                    as  org_id  --内部机构号
,nvl(t1.serialno,'')        as  guar_cont_no    --担保合同号
,''                         as  guar_cont_name  --担保合同名称
,nvl(t1.guarantorname,'')   as  guartor_name    --担保人名称
,nvl(t1.certtype,'')        as  guartor_cret_type   --担保人证件类型
,nvl(t1.certid,'')          as  guartor_cret_id --担保人证件代码
,nvl(gyl_contract.objectno,t2.serialno) as  be_guar_cont_no --被担保合同号
,nvl(t3.customername,'')    as  be_guartor_name --被担保人
,nvl(t7.certtype,'')        as  be_guartor_cret_type    --担保人证件类型
,nvl(t7.certid,'')          as  be_guartor_cret_id  --担保人证件代码
,'02'                       as  tran_type       --交易类型信贷交易
,nvl(gyl_contract.prod_code,t3.prod_code)   as  prod_code   --产品编号
,nvl(regexp_replace(t1.contracttype,0, ''), '') as guar_cont_type   --担保合同类型（010:—般担保合同，020:最高额担保合同）
,nvl(t1.contractstatus,'')  as  guar_cont_status    --担保状态
,case when  t1.guarantycurrency='01' then 'CNY'     
      else  t1.guarantycurrency end as ccy      --担保合同币种
,round(t1.guarantyvalue,2)  as  guar_cont_amt   --担保合同金额
,nvl(t1.guarantytype,'')    as  guar_mode
,''                         as  main_guar_flag  --是否主担保
,nvl(regexp_replace(t1.signdate, '/','-'), '')  as guar_cont_start_date --担保合同起始日期
,nvl(regexp_replace(t1.enddate, '/','-'), '')   as guar_cont_mature_date --担保合同到期日期
,''                         as  guar_order          --担保顺位
,nvl(t1.certtype, '')       as  guartor_nat_econ_depar  --担保人国民经济部门
,nvl(t4.industrytype, '')   as  guartor_indst --担保人行业
,case when  t1.certtype  like 'Ent%' then t5.city
      when  t1.certtype like 'Ind%' then t6.cnidregcity
      end                   as  guartor_area_code--担保人地区代码
,nvl(t4.scope, '')          as  guartor_corp_scale   --担保人企业规模
--,nvl(t1.inputuserid,'')       as  oper_emp_id         --经办人工号
,nvl(t1.guarantyrate,0)     as  guar_rate           --抵质押率
from odata.als_guaranty_contract t1
left join odata.als_contract_relative t2 
on t1.serialno=t2.objectno
and t2.objecttype= 'GuarantyContract' 
and t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99'
left join
(select  a.relativeserialno                     --原担保合同
        ,b.objectno                             --拆分后的被担保合同(贷款合同)
        ,c.businesssum                          --获批的授信额度
        ,concat_ws(',',collect_set(nvl(e.prod_type,f.product_type))) prod_code
   from odata.als_cl_occupy a
left join odata.als_cl_occupy b
     on a.objectno = b.relativeserialno
    and b.data_date = '${DATA_DATE}'
    and b.bddw_end_date = '9999-99-99'
left join odata.als_business_contract c
     on b.relativeserialno = c.serialno
    and c.data_date = '${DATA_DATE}'
    and c.bddw_end_date = '9999-99-99'
inner join odata.als_business_duebill d
     on d.data_date = '${DATA_DATE}'
    and d.bddw_end_date = '9999-99-99'
    and d.businesstype = '1070010'--供应链金融
    and b.objectno = d.relativeserialno2
left join odata.sym_mb_acct e
     on d.serialno=e.cmisloan_no 
    and e.data_date='${DATA_DATE}' 
    and e.bddw_end_date= '9999-99-99'
    and e.source_module = 'CL'     --对公贷款
    and e.lead_acct_flag = 'N'     --限制非主账户
left join odata.supacct_enterprise_loan_info f --贷款信息表
     on d.serialno = f.iou_no
    and f.data_date='${DATA_DATE}'
    and f.bddw_end_date='9999-99-99'
  where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and b.objectno is not null
group by a.relativeserialno                     --原担保合同
        ,b.objectno                             --拆分后的被担保合同(贷款合同)
        ,c.businesssum                          --获批的授信额度
   -- and a.serialno not in(select serialno
   --                         from odata.als_cl_occupy
   --                        where data_date = '${DATA_DATE}'
   --                          and bddw_end_date = '9999-99-99'
   --                          and serialno between '2022061600001673' and '2022061600002687'
   --                          and relativeserialno = 'BC2022061500000006'
   --                        and serialno not in(select serialno
   --                         from odata.als_cl_occupy
   --                        where data_date = '${DATA_DATE}'
   --                          and bddw_end_date = '9999-99-99'
   --                          and serialno between '2022061600001673' and '2022061600002687'
   --                          and relativeserialno = 'BC2022061500000006'))
  union all
  select distinct  a.relativeserialno  --为拆分前的担保合同
                  ,a.objectno          --贷款合同
                  ,c.businesssum       --获批的授信额度
                  ,concat_ws(',',collect_set(nvl(e.prod_type,f.product_type))) prod_code
             from odata.als_cl_occupy a
        left join odata.als_business_contract c
               on a.objectno = c.serialno
              and c.data_date = '${DATA_DATE}'
              and c.bddw_end_date = '9999-99-99'
       inner join odata.als_business_duebill d
               on d.data_date = '${DATA_DATE}'
              and d.bddw_end_date = '9999-99-99'
              and d.businesstype not in ('1020010','2010') 
              and d.mfareaid = 'Model2' --用信线上化的合同
              and a.objectno = d.relativeserialno2
        left join odata.sym_mb_acct e
               on d.serialno=e.cmisloan_no 
              and e.data_date='${DATA_DATE}' 
              and e.bddw_end_date= '9999-99-99'
              and e.source_module = 'CL'     --对公贷款
              and e.lead_acct_flag = 'N'     --限制非主账户
        left join odata.supacct_enterprise_loan_info f --贷款信息表
               on d.serialno = f.iou_no
              and f.data_date='${DATA_DATE}'
              and f.bddw_end_date='9999-99-99'
            where a.data_date = '${DATA_DATE}'
              and a.bddw_end_date = '9999-99-99'
         group by a.relativeserialno                     --原担保合同
                 ,a.objectno                             --拆分后的被担保合同(贷款合同)
                 ,c.businesssum                          --获批的授信额度
        --     and a.serialno not in(select serialno
        --                             from odata.als_cl_occupy
        --                            where data_date = '${DATA_DATE}'
        --                              and bddw_end_date = '9999-99-99'
        --                              and serialno between '2022061600001673' and '2022061600002687'
        --                              and relativeserialno = 'BC2022061500000006')  
                     ) gyl_contract 
on gyl_contract.relativeserialno = t2.serialno
left join(select  t.serialno
                  ,t.customerid
                  ,t.customername
                  ,t.businesstype 
                  ,concat_ws(',',collect_set(nvl(t2.prod_type,t3.product_type))) prod_code
             from odata.als_business_contract t
        left join odata.als_business_duebill t1
               on t.serialno = t1.relativeserialno2
              and t1.data_date='${DATA_DATE}'
              and t1.bddw_end_date= '9999-99-99'
        left join odata.sym_mb_acct t2
               on t1.serialno=t2.cmisloan_no 
              and t2.data_date='${DATA_DATE}' 
              and t2.bddw_end_date= '9999-99-99'
              and t2.source_module = 'CL'     --对公贷款
              and t2.lead_acct_flag = 'N'     --限制非主账户
        left join odata.supacct_enterprise_loan_info t3 --贷款信息表
               on t1.serialno = t3.iou_no
              and t3.data_date='${DATA_DATE}'
              and t3.bddw_end_date='9999-99-99'
            where t.data_date='${DATA_DATE}'
              and t.bddw_end_date= '9999-99-99' 
         group by t.serialno
                 ,t.customerid
                 ,t.customername
                 ,t.businesstype 
--and balance > 0
--and businesstype not in ('3005','3050020','2010')
)t3
on nvl(gyl_contract.objectno,t2.serialno) = t3.serialno 
left join odata.als_ent_info t4
on guarantorid = t4.customerid 
and t4.data_date='${DATA_DATE}' 
and t4.bddw_end_date='9999-99-99' 
left join (select distinct customerid,city 
             from odata.als_customer_address 
            where addtype='010' 
              and data_date='${DATA_DATE}' 
              and bddw_end_date= '9999-99-99') t5
on t1.guarantorid=t5.customerid 
left join odata.als_customer_cert t6
on t1.guarantorid=t6.customerid 
and t6.customerid not like 'LS%' 
and t6.data_date='${DATA_DATE}' 
and t6.bddw_end_date= '9999-99-99'
left join odata.als_customer_cert t7 
on t3.customerid=t7.customerid 
and t7.data_date='${DATA_DATE}' 
and t7.bddw_end_date = '9999-99-99' 
where t1. data_date='${DATA_DATE}' 
and t1.bddw_end_date= '9999-99-99' 
--and t1.contractstatus <> '010'
union all 
--锡惠贷                   
select 
    /*+ REPARTITION(1) */
nvl(t4.branch,'100000')              as  org_id                  --内部机构号     
,nvl(t3.contract_no,'')              as  guar_cont_no            --担保合同号     
,''                                  as  guar_cont_name          --担保合同名称       
,nvl(t7.coborrower_name,'')          as  guartor_name            --担保人名称     
,'101'                               as  guar_cert_type          --担保人证件类别 101   身份证 
,nvl(t7.card_no, '')                 as  guar_cert_no            --担保人证件号码       
,nvl(t31.contract_no,'')             as  wart_cont_no            --被担保合同号        
,nvl(t8.company_name,'')             as  wart_name               --被担保人姓名        
,'B01'                               as  wart_cert_type          --被担保人证件类型      
,nvl(t8.business_license,'')         as  wart_cert_no            --被担保人证件号       
,'02'                                as  tran_type               --交易类型信贷交易      
,nvl(t4.prod_type,'')                as  prod_code               --产品代码      
,'2'                                 as  guar_cont_type_code     --担保合同类型代码  一般担保合同  
,nvl(t5.status,'')                   as  guar_status             --担保合同状态        
,'CNY'                               as  ccy                     --担保币种      
,nvl(t5.credit_amount, 0)            as  guar_amt                --担保金额      
,case when t7.loan_id  is not null then 'C99'                    
      else 'D' end                   as  guar_mode_code          --担保方式代码        
,''                                  as  main_guar_flag          --是否主担保
,nvl(substr(t5.credit_start_time,1,10),'')   as  guar_begin_date         --担保开始日期
,nvl(substr(t5.credit_end_time,1,10),'')   as  guar_end_date            --担保到期期日期   
,''                                  as  guar_order              --担保顺位
,''                                  as  guartor_nat_econ_depar  --担保人国民经济部门
,''                                  as  guartor_indst           --担保人行业
,nvl(substr(t7.curr_residence_code,-6),'')   as  guartor_area_code       --担保人地区代码
,''                                  as  guartor_corp_scale      --担保人企业规模
--,''                                  as  oper_emp_id           --经办人工号
,0                                   as  guar_rate               --抵质押率
from odata.order_contract_sign t3  
 left join odata.order_main_loan_order t1
   on t1.loan_id=t3.loan_id
  and t1.data_date='${DATA_DATE}'
  and t1.bddw_end_date='9999-99-99'
  and t1.loan_time is not null
  and t1.order_type = '2'  --用信
 left join odata.order_main_credit_order t5
   on t1.credit_order_id=t5.loan_id
  and t5.data_date= '${DATA_DATE}'
  and t5.bddw_end_date ='9999-99-99' 
  --and t5.status = '3'
 left join odata.order_main_loan_order t51
   on t51.order_type = '2'  --用信
  and t51.data_date='${DATA_DATE}'
  and t51.bddw_end_date='9999-99-99'
  and t51.loan_time is not null
  and t5.loan_id=t51.credit_order_id
inner join odata.order_contract_sign t31 
on t51.loan_id=t31.loan_id
and t31.data_date='${DATA_DATE}'
and t31.bddw_end_date= '9999-99-99' 
and t31.signer_type=6    --签署人为法人
and t31.contract_type=41 --人名币流动资金贷款合同
--and t31.status = '1'
and t31.id <> '2161510'  --20220630 重复数据, 去掉—条 
inner join odata.sllv_mb_acct t4
on t51.receipt_no=t4.cmisloan_no 
and t4.data_date='${DATA_DATE}' 
and t4.bddw_end_date='9999-99-99' 
and t4.prod_type = '120111'
left join odata.order_coborrower_info t7 
on t1.credit_order_id=t7.loan_id
and t7.data_date='${DATA_DATE}'
and t7.bddw_end_date ='9999-99-99'
and t7.borrower_type=2 --担保人 
and t3.sign_id_card = t7.card_no
left join odata.order_company_info t8 
on t51.credit_order_id=t8.loan_id
and t8.data_date='${DATA_DATE}' 
and t8.bddw_end_date ='9999-99-99' 
where t3.data_date='${DATA_DATE}'
and t3.bddw_end_date= '9999-99-99' 
--and t3.signer_type=2    --签署人为主借人
and t3.contract_type=44 --最高额保证合同
and t3.id <> '2161510'  --20220630 重复数据, 去掉—条 
and t3.sub_product_type = '25'
--and substr(t1.apply_time,1,10)<='${DATA_DATE}'
--and status in (7,8,9,10)