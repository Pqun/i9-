--2.yangqihao.dwd_d_corp_loan_repayplan_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：dwd_d_corp_loan_repayplan_p.sql行内产品取数
--功能描述：生成每日结果数据并插入hive dwd层dwd.dwd_d_corp_loan_repayplan_p
--作    者：华天顺
--开发日期：2022-08-02
--直属经理：方杰
--来源表  ：odata.sym_mb_acct_schedule_detail 账户计划明细表
--来源表  ：odata.sym_mb_invoice 单据表
--来源表  ：odata.sym_mb_acct 账户基本信息表
--来源表  ：odata.als_business_duebill 业务借据(账户)信息表
--来源表  ：odata.sym_mb_drawdown 贷款发放表
--来源表  ：odata.slur_jcb_repay_plan_final 金城网贷还款计划表
--来源表  ：odata.supacct_enterprise_loan_info 贷款信息表
--来源表  ：odata.slur_jcb_loan_info_final 金城网贷借据信息表
--目标表  ：dwd.dwd_d_corp_loan_repayplan_p 对公贷款还款计划表
--修改历史：
--          1.华天顺   2022-08-02    新建
--          2.华天顺   2022-10-13    新增对公核算还款计划
--          3.杨琦浩   2023-04-06    对公核算取首次用信业务合同
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_corp_loan_repayplan_p partition (data_date='${DATA_DATE}',prod_code)
select /*+ REPARTITION(1) */ 
     nvl(t4.cmisloan_no,'')                                                              as bill_no                   --借据号
    ,nvl(t4.base_acct_no,'')                                                             as acct_no                   --账号
    ,t4.acct_seq_no                                                                      as acct_seq_no               --账户序号
    ,t5.relativeserialno2                                                                as cont_no                   --合同号
    ,nvl(t4.client_no,'')                                                                as cust_id                   --客户号
    ,'${DATA_DATE}'                                                                      as biz_date                  --业务日期
    ,from_unixtime(unix_timestamp(t4.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')            as loan_start_date           --贷款起始日期
    ,from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')             as loan_end_date             --贷款结束日期
    ,nvl(t4.ccy,'')                                                                      as ccy                       --币种
    ,t1.stage_no                                                                         as term_no                   --期次
    ,t1.term_start_date                                                                  as term_start_date           --本期开始日期
    ,t1.term_end_date                                                                    as term_mature_date          --本期到期日期
    ,nvl(t2.grace_period_date,'')                                                        as term_grace_date           --本期宽限到期日
    ,t1.sched_amt_pri                                                                    as matured_prin              --本期应还本金
    ,t1.sched_amt_int                                                                    as matured_int               --本期应还利息
    ,nvl(t3.billed_amt,0)                                                                as matured_pena              --本期应还罚息
     ,nvl(t4.prod_type,'')                                                               as prod_code                 --产品号
from (
             select 
                  a.internal_key
                 ,a.stage_no              as stage_no                                                               --期次
                 ,from_unixtime(unix_timestamp(min(a.start_date),'yyyyMMdd'),'yyyy-MM-dd')      as term_start_date  --期次开始日期
                 ,from_unixtime(unix_timestamp(max(a.end_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_end_date    --期次到期日期
                 ,sum(case when amt_type ='PRI' then a.sched_amt else 0 end) as sched_amt_pri                       --计划本金
                 ,sum(case when amt_type ='INT' then a.sched_amt else 0 end) as sched_amt_int                       --计划利息
                 ,max(pri_outstanding) as pri_outstanding                                                           --剩余未到期本金
             from odata.sym_mb_acct_schedule_detail a
             where data_date = '${DATA_DATE}'
             and bddw_end_date = '9999-99-99'
             group by 
                  a.internal_key
                 ,a.stage_no
                 ,a.start_date
                 ,a.end_date
    ) t1 
                 --取回收的明细信息
left join (
             select 
                  a.internal_key
                 ,a.stage_no  --期次
                 ,min(a.fully_settled)    as fully_settled --是否收回标识(min 取N)
                 ,from_unixtime(unix_timestamp(min(c.start_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_start_date    --期次开始期日
                 ,from_unixtime(unix_timestamp(max(a.grace_period_date),'yyyyMMdd'),'yyyy-MM-dd') as grace_period_date  --期次宽限日
             from odata.sym_mb_invoice a
             left join odata.sym_mb_acct_schedule_detail c
             on c.data_date = '${DATA_DATE}'
             and c.bddw_end_date = '9999-99-99'
             and a.internal_key = c.internal_key
             and a.stage_no = c.stage_no
             and a.amt_type = c.amt_type
             where a.data_date = '${DATA_DATE}'
             and a.bddw_end_date = '9999-99-99'
             and a.amt_type <> 'ODP'
             group by 
                  a.internal_key
                 ,a.stage_no
                 ,c.start_date
    ) t2
     on t1.internal_key = t2.internal_key
    and t1.stage_no = t2.stage_no
    and t1.term_start_date = t2.term_start_date
left join (
             select 
                  internal_key
                 ,stage_no
                 ,sum(billed_amt)  as billed_amt  --可能会有多笔罚息，故按期次进行汇总
                 ,sum(outstanding) as outstanding
             from odata.sym_mb_invoice  --取罚息(罚息在单据表生成，罚息的最后还款日与正常期次的还款日不一致，故在此处单独提取。还款计划明细表中没有罚息记录)
             where data_date = '${DATA_DATE}'
             and bddw_end_date = '9999-99-99'
             and amt_type = 'ODP'
             group by 
                  internal_key
                 ,stage_no
    ) t3
     on t1.internal_key = t3.internal_key
    and t1.stage_no = t3.stage_no
inner join odata.sym_mb_acct t4
     on t4.data_date = '${DATA_DATE}'
    and t4.bddw_end_date = '9999-99-99'
    and from_unixtime(unix_timestamp(t4.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')<='${DATA_DATE}'
    and t4.lead_acct_flag='N'
    and t4.source_module ='CL'
    and t1.internal_key = t4.internal_key
inner join odata.als_business_duebill t5
     on t5.data_date = '${DATA_DATE}'
    and t5.bddw_end_date = '9999-99-99'
    and t4.cmisloan_no=t5.serialno
--剔除发放冲正的借据
left join odata.sym_mb_drawdown t13
     on t1.internal_key = t13.internal_key
    and t13.data_date = '${DATA_DATE}'
    and t13.bddw_end_date = '9999-99-99'
    and t13.reversal = 'Y'  
where 
    t13.internal_key is null --剔除发放冲正的借据
    
union all
--金城
select /*+ REPARTITION(1) */ 
     t3.serialno                                                                           as bill_no              --借据号
    ,t3.serialno                                                                           as acct_no              --账号
    ,''                                                                                    as acct_seq_no          --账户序号
    ,t3.relativeserialno2                                                                  as cont_no              --合同号
    ,t3.customerid                                                                         as cust_id              --客户号
    ,'${DATA_DATE}'                                                                        as biz_date             --业务日期
    ,from_unixtime(unix_timestamp(t4.loan_date,'yyyyMMdd'),'yyyy-MM-dd')                   as loan_start_date      --贷款起始日期
    ,from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')               as loan_end_date        --贷款结束日期
    ,'CNY'                                                                                 as ccy                  --币种
    ,t1.term                                                                               as term_no              --期次
    ,from_unixtime(unix_timestamp(t1.inte_date,'yyyyMMdd'),'yyyy-MM-dd')                   as term_start_date      --本期开始日期
    ,from_unixtime(unix_timestamp(t1.due_date,'yyyyMMdd'),'yyyy-MM-dd')                    as term_mature_date     --本期到期日期
    ,from_unixtime(unix_timestamp(t1.grace_date,'yyyyMMdd'),'yyyy-MM-dd')                  as term_grace_date      --本期宽限到期日
    ,t1.prin_amt                                                                           as matured_prin         --本期应还本金
    ,t1.int_amt                                                                            as matured_int          --本期应还利息
    ,t1.oint_amt                                                                           as matured_pena         --本期应还罚息
    ,'120108'                                                                              as prod_code            --产品号
from odata.slur_jcb_repay_plan_final t1
inner join odata.supacct_enterprise_loan_info t2
       on t2.data_date='${DATA_DATE}'
      and t2.bddw_end_date='9999-99-99'
      and t1.loan_no = t2.partner_loan_no
      and t2.reversal_flag = '00'
left join odata.slur_jcb_loan_info_final t4 
       on t4.data_date='${DATA_DATE}'
      and t4.bddw_end_date='9999-99-99'
      and t1.loan_no=t4.loan_no
      and loan_status<>'03'
left join  odata.als_business_duebill t3
       on t3.data_date='${DATA_DATE}'
      and t3.bddw_end_date='9999-99-99'
      and t2.iou_no = t3.serialno
where t1.data_date = '${DATA_DATE}'
      and t1.bddw_end_date = '9999-99-99'
      and t1.plan_status <> '03'--剔除冲正借据
	  
union all
--对公核算
select /*+ REPARTITION(1) */ 
     nvl(t4.cmisloan_no,'')                                                              as bill_no                   --借据号
    ,nvl(t4.base_acct_no,'')                                                             as acct_no                   --账号
    ,t4.acct_seq_no                                                                      as acct_seq_no               --账户序号
    ,t14.contract_no                                                                as cont_no                   --合同号
    ,nvl(t4.client_no,'')                                                                as cust_id                   --客户号
    ,'${DATA_DATE}'                                                                      as biz_date                  --业务日期
    ,from_unixtime(unix_timestamp(t4.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')            as loan_start_date           --贷款起始日期
    ,from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')             as loan_end_date             --贷款结束日期
    ,nvl(t4.ccy,'')                                                                      as ccy                       --币种
    ,t1.stage_no                                                                         as term_no                   --期次
    ,t1.term_start_date                                                                  as term_start_date           --本期开始日期
    ,t1.term_end_date                                                                    as term_mature_date          --本期到期日期
    ,nvl(date_add(t1.term_end_date,cast(t6.grace_period as int)),'')                                                        as term_grace_date           --本期宽限到期日
    ,t1.sched_amt_pri                                                                    as matured_prin              --本期应还本金
    ,t1.sched_amt_int                                                                    as matured_int               --本期应还利息
    ,nvl(t5.int_accrued+t5.int_adj+t5.int_posted,0)                                   as matured_pena              --本期应还罚息
     ,nvl(t4.prod_type,'')                                                               as prod_code                 --产品号
from (
             select 
                  a.internal_key
                 ,a.stage_no              as stage_no                                                               --期次
                 ,from_unixtime(unix_timestamp(min(a.start_date),'yyyyMMdd'),'yyyy-MM-dd')      as term_start_date  --期次开始日期
                 ,from_unixtime(unix_timestamp(max(a.end_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_end_date    --期次到期日期
                 ,sum(case when amt_type ='PRI' then a.sched_amt else 0 end) as sched_amt_pri                       --计划本金
                 ,sum(case when amt_type ='INT' then a.sched_amt else 0 end) as sched_amt_int                       --计划利息
                 ,max(pri_outstanding) as pri_outstanding                                                           --剩余未到期本金
             from odata.sllv_mb_acct_schedule_detail a
             where data_date = '${DATA_DATE}'
             and bddw_end_date = '9999-99-99'
             group by 
                  a.internal_key
                 ,a.stage_no
                 ,a.start_date
                 ,a.end_date
    ) t1 
inner join odata.sllv_mb_acct t4
     on t4.data_date = '${DATA_DATE}'
    and t4.bddw_end_date = '9999-99-99'
    and t4.prod_type like '120%'
    and t1.internal_key = t4.internal_key
left join odata.sllv_mb_od_int_detail t5
     on t5.data_date = '${DATA_DATE}'
    and t5.bddw_end_date = '9999-99-99'
    and t1.internal_key =  t5.internal_key
    and t1.stage_no = t5.stage_no
left join odata.sllv_mb_agreement_loan t6
     on t6.data_date = '${DATA_DATE}'
    and t6.bddw_end_date = '9999-99-99'
    and t1.internal_key =  t6.internal_key
left join odata.order_main_loan_order t11
       on t4.cmisloan_no = t11.loan_id
      and t11.data_date = '${DATA_DATE}'
      and t11.bddw_end_date = '9999-99-99'
left join(
         select b.credit_order_id,a.contract_no
         from odata.order_contract_sign a
         left join odata.order_main_loan_order b
         on a.loan_id = b.loan_id
         and b.data_date = '${DATA_DATE}'
         and b.bddw_end_date = '9999-99-99'
         and b.status in('7','8') --还款中、已结清（首次用信成功）
         where a.data_date = '${DATA_DATE}'
         and a.bddw_end_date = '9999-99-99'
         and a.sub_product_type = '25'
         and a.signer_type = '6'   -- 企业法人
         and a.contract_type = '41' -- 人民币流动资金贷款合同
         )t14
on t11.credit_order_id = t14.credit_order_id
--剔除发放冲正的借据
left join odata.sllv_mb_drawdown t13
     on t1.internal_key = t13.internal_key
    and t13.data_date = '${DATA_DATE}'
    and t13.bddw_end_date = '9999-99-99'
    and t13.reversal = 'Y'  
where 
    t13.internal_key is null --剔除发放冲正的借据