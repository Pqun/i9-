---------------------------------------------------------------------------------------------------------------
--脚本名称：行业分类维表取数逻辑.sql
--功能描述：用于 gdata.dim_g_indust_class_p 取数
--作    者：高源
--开发日期：2022-07-25
--直属经理：方杰
--修改历史：
--来源表：odata.sym_cif_industry    通用行业代码表
--目标表：gdata.dim_g_indust_class_p
--          1.高源   2022-07-25    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table gdata.dim_g_indust_class_p
select /*+ REPARTITION(1) */
       nvl(a.industry              ,'')       as indust_type    --行业代码
      ,nvl(a.industry_desc         ,'')       as indust_name    --行业名称
      ,nvl(a.parent_industry       ,'')       as up_indust_type --上级行业代码
      ,nvl(a.industry_level        ,'')       as indust_lvl     --行业级别
      ,case when a.detail_ind='Y' then '1'
            when a.detail_ind='N' then '0'  
            else ''  end                      as detail_ind     --是否明细代码
      ,case when a.standard_ind='Y' then '1'
            when a.standard_ind='N' then '0'  
            else ''  end                      as standard_ind   --是否国际代码
      ,'${DATA_DATE}'                         as data_date      --数据日期
  from odata.sym_cif_industry a
  where a.data_date='${DATA_DATE}'
    and a.bddw_end_date='9999-99-99'