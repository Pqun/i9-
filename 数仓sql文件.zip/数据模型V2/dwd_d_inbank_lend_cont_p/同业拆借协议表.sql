--2.gaoyuan.dwd.dwd_d_inbank_lend_cont_p
-------------------------------------------------------------------------------------------------------------
--脚本名称：同业拆借协议表取数逻辑.sql
--功能描述：用于创建 dwd.dwd_d_inbank_lend_cont_p
--作    者：高源
--开发日期：2022-07-27 
--直属经理：方杰
--来源表:
--1.odata.tb_v_balance                   查询当日日终后的资产余额信息 
--2.odata.tb_v_iamdeals                  查询拆借的数据
--3.odata.tb_vs_cptys                    提供交易对手基础信息
--3.odata.tb_v_loandeals                 查询同业存放的数据
--5.odata.tb_vs_payment_iamdeals         查询实际收付确认拆借的数据 
--6.odata.tb_vs_accentry2                提供账务分录(包含手工调账分录)信息
--7.odata.tb_vs_payment_loandeals        查询实际收付确认同业存放的数据
--8.odata.tb_v_bondsdeals                查询现券交易
--9.odata.tb_vs_payment_bondsdeals_all   实际收付确认-现券交易-含衍生
--10.odata.tb_v_security                 查询债券基本资料信息
--11.odata.tb_v_ncd_commission_data      债券发行结果缴款汇总信息
--11.odata.
--目标表：dwd.dwd_d_inbank_lend_cont_p   同业拆借协议表
--修改历史：
--          1.高源   2022-07-27    新建
--          2.于国睿 2023-02-09    新增字段累计价差收益，累计摊销收益，累计利息收益，累计公允价值变动损益
--          3.高源   2023-02-24    新增同业存单业务逻辑，新增资产编号、利息调整金额、利息调整科目、利息收入、利息收入科目字段
--          4.高源   2023-03-23    同业存单业务粒度调整为
--          5.高源   2023-03-23    同业存单业务穿透到交易对手力度
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_inbank_lend_cont_p partition(data_date='${DATA_DATE}')
    select /*+ REPARTITION(1) */
           nvl(t1.ref_number,'')                          as cont_no              --业务协议号
          ,case when t1.buyorsell = 'B' then '1'        
                when t1.buyorsell = 'S' then '2'        
                else ''    
            end                                           as inbank_lend_type     --买卖类型
          ,'CNY'                                          as ccy                  --币种代码
          ,'100000'                                       as org_id               --机构代码 
          ,case when t1.ref_number='I4672-20220624163810' 
                then '20110101'  --此交易号取不到科目，特殊处理
                else tva.accountingcode  
            end                                           as subj_no              --科目号
          ,nvl(t1.cptys_id,'')                            as tran_party_id        --交易对手id
          ,nvl(t1.cptys_name,'')                          as tran_party_desc      --交易对手描述
          ,''                                             as tran_party_type      --交易对手类型
          ,nvl(t1.rating_level,'')                        as tran_party_rating    --交易对手评级        
          ,nvl(from_unixtime(unix_timestamp(string(t1.value_date),'yyyyMMdd'),'yyyy-MM-dd'),'')      as start_date   --开始日期
          ,nvl(from_unixtime(unix_timestamp(string(t1.maturity_date),'yyyyMMdd'),'yyyy-MM-dd'),'')   as mature_date  --到期日期
          ,nvl(t1.repo_rate,0)                            as exec_rate            --执行利率(%)
          ,nvl(t1.amount,0)                               as biz_amt              --业务金额   
          ,case when t1.buyorsell = 'B' then round(nvl(t1.sumc,0)-nvl(t1.sumd,0),2)
                when t1.buyorsell = 'S' then round(nvl(t1.sumd,0)-nvl(t1.sumc,0),2)
            end                                           as recv_int             --应收应付利息    
          ,case when t1.buyorsell = 'B' then '20600401'
                when t1.buyorsell = 'S' then '10600401'
            end                                           as recv_int_subj_no     --应收应付利息科目
          ,'1'                                            as accr_flag            --计息标志
          ,'B99'                                          as int_mode             --计息方式
          ,nvl(from_unixtime(unix_timestamp(string(t1.value_date),'yyyyMMdd'),'yyyy-MM-dd'),'')     as accr_date     --起息日期
          ,'TR99'                                         as pric_benc            --定价基准类型
          ,'2'                                            as int_basis            --计息基础
          ,nvl(tvb.holdposition,0)                        as bal                  --拆借余额   
          ,'RF01'                                         as rate_type            --利率类型
          ,case when tvb.holdposition=0  then from_unixtime(unix_timestamp(string(t7.act_settledate),'yyyyMMdd'),'yyyy-MM-dd')
                else ''  
            end                                           as actual_mature_date   --实际到期日期
          ,nvl(tav.amount,0)                              as withdraw_int         --日计提利息
          ,nvl(cast(t2.priceearning    as decimal(28,10)) ,0)  as total_diff_income  --累计价差收益
          ,nvl(cast(t2.amortizeearning as decimal(28,10)) ,0)  as total_amort_income --累计摊销收益
          ,nvl(cast(t2.interestearning as decimal(28,10)) ,0)  as total_int_income   --累计利息收益
          ,nvl(cast(t2.fairvalueincome as decimal(28,10)) ,0)  as total_fair_value_change  --累计公允价值变动损益
          ,nvl(t1.minorassetcode,'')                           as asset_code         --资产编号
          ,0                                                   as int_adj            --利息调整金额
          ,''                                                  as int_adj_subj_no    --利息调整科目号
          ,nvl(t1.sumcc,0)                                     as int_pl             --利息支出/收入
          ,case when t1.buyorsell = 'B' then '60100301'      --拆入境内同业款项利息支出
                when t1.buyorsell = 'S' then '50100301'      --拆出境内同业款项利息收入
                end                                            as int_pl_subj_no     --利息支出/收入科目
      from (select min(tvb.alterbalance_id) as alterbalance_id   --取最早的交易数据确认交易号
                  ,max(tvb.balance_id)      as balance_id
                  ,tvb.majorassetcode
                  ,tvb.minorassetcode
                  ,tvi.buyorsell            as buyorsell 
                  ,tvc.cptys_id             as cptys_id     
                  ,tvc.cptys_name           as cptys_name 
                  ,tvc.rating_level         as rating_level  
                  ,tvpi.ref_number          as ref_number
                  ,tvpi.value_date          as value_date
                  ,tvpi.maturity_date       as maturity_date
                  ,tvpi.repo_rate           as repo_rate
                  ,tvpi.deal_id             as deal_id
                  ,tvpi.amount              as amount
                  ,sum(tvad.amount)         as sumd
                  ,sum(tvac.amount)         as sumc
                  ,sum(tvcc.amount)         as sumcc
              from odata.tb_v_balance tvb
              left join odata.tb_v_iamdeals tvi
                on tvi.data_date = '${DATA_DATE}'
               and tvi.bddw_end_date= '9999-99-99'
               and tvi.iamdeals_id_grand = substr(tvb.majorassetcode,4)
              left join odata.tb_vs_cptys tvc
                on tvc.key_src = tvi.cptys_id
               and tvc.data_date = '${DATA_DATE}'
               and tvc.bddw_end_date= '9999-99-99'
              left join odata.tb_vs_payment_iamdeals tvpi --实际收付确认拆借的数据
                on tvpi.data_date = '${DATA_DATE}'
               and tvpi.bddw_end_date= '9999-99-99'
               and tvi.deal_id = tvpi.deal_id
               and tvi.deal_tablename = tvpi.deal_tablename
              left join (select bundlecode
                               ,accountingcode
                               ,round(amount,2) as amount
                           from odata.tb_vs_accentry2
                          where data_date='${DATA_DATE}'
                            and bddw_end_date='9999-99-99'
                            and debitcredit = 'C'
                            and accountingcode in('10600401','20600401')
                        ) tvac
                on tvb.alterbalance_id = tvac.bundlecode
              left join (select bundlecode
                               ,accountingcode
                               ,round(amount,2) as amount
                           from odata.tb_vs_accentry2
                          where data_date='${DATA_DATE}'
                            and bddw_end_date='9999-99-99'
                            and debitcredit = 'D'
                            and accountingcode in('10600401','20600401')
                        ) tvad
                on tvb.alterbalance_id = tvad.bundlecode
              left join (select bundlecode
                               ,accountingcode
                               ,round(amount,6) as amount
                           from odata.tb_vs_accentry2
                          where data_date='${DATA_DATE}'
                            and bddw_end_date='9999-99-99'
                            and accountingcode  in ('50100301','60100301')
                            and settledate >= regexp_replace(trunc('${DATA_DATE}','YYYY'),'-','')    --取当年的利息收入
                        ) tvcc
                on tvb.alterbalance_id = tvcc.bundlecode
             where tvb.data_date = '${DATA_DATE}'
               and tvb.bddw_end_date= '9999-99-99'
               and tvb.settledate <= regexp_replace('${DATA_DATE}','-','') --统计日期
               and tvb.aspclient_id = '2244' --请替换本行部门ID
               and tvb.assettype = '拆借'
             group by tvi.buyorsell 
                     ,tvc.cptys_id     
                     ,tvc.cptys_name 
                     ,tvc.rating_level  
                     ,tvpi.ref_number
                     ,tvpi.value_date
                     ,tvpi.maturity_date
                     ,tvpi.repo_rate
                     ,tvpi.deal_id
                     ,tvpi.amount
                     ,tvb.majorassetcode
                     ,tvb.minorassetcode ) t1
      left join odata.tb_vs_accentry2 tva
        on t1.alterbalance_id = tva.bundlecode
       and tva.data_date = '${DATA_DATE}'
       and tva.bddw_end_date= '9999-99-99' 
       and tva.accountingcode like '%011%'
      left join odata.tb_v_balance tvb
        on tvb.data_date = '${DATA_DATE}'
       and tvb.bddw_end_date= '9999-99-99'
       and t1.balance_id = tvb.balance_id
      left join (select * 
                   from (select *
                               ,row_number() over(partition by deal_id order by act_settledate desc) as rn
                           from odata.tb_vs_payment_trsi_iamdeals t7
                          where t7.data_date = '${DATA_DATE}'
                            and t7.bddw_end_date= '9999-99-99') a  
                  where rn=1) t7
        on t7.deal_id = t1.deal_id
       and t7.assettype = '拆借'
      left join (select alterbalance_id
                       ,majorassetcode
                       ,minorassetcode 
                   from odata.tb_v_balance bls
                  where bls.data_date = '${DATA_DATE}'
                    and bls.bddw_end_date = '9999-99-99'
                    and bls.settledate = regexp_replace('${DATA_DATE}','-','') --统计日期
                    and bls.aspclient_id = '2244' --请替换本行部门ID
                    and bls.assettype = '拆借'
                    and bls.baretradename='WITHDRAWALDEALS' ) t
        on t1.majorassetcode = t.majorassetcode
       and t1.minorassetcode=t.minorassetcode
      left join odata.tb_vs_accentry2 tav
        on t.alterbalance_id = tav.bundlecode
       and tav.data_date='${DATA_DATE}'
       and tav.bddw_end_date='9999-99-99' 
       and tav.accountingcode like '%060%'
	  left join (select aspclient_id
                       ,keepfolder_id
                       ,assettype
                       ,majorassetcode
                       ,minorassetcode
	                   ,sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                                 then priceearning
                                 else 0 
                             end)                as priceearning
                       ,sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                                 then amortizeearning
                                 else 0 
                             end)                as amortizeearning
                       ,sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                                 then interestearning
                                 else 0 
                             end)                as interestearning
                       ,sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                                 then fairvalueincome 
                                 else 0 
                             end)                as fairvalueincome
                   from odata.tb_v_alterbalance
                  where data_date ='${DATA_DATE}'
                    and bddw_end_date ='9999-99-99'
                  group by aspclient_id,
                           keepfolder_id,
                           assettype,
                           majorassetcode,
                           minorassetcode
                ) t2
		on t2.aspclient_id = tvb.aspclient_id
       and t2.keepfolder_id = tvb.keepfolder_id
       and t2.assettype = tvb.assettype
       and t2.majorassetcode = tvb.majorassetcode
       and t2.minorassetcode = tvb.minorassetcode
union all
---------------------------------------------同业借贷----------------------------------------
    select  /*+ REPARTITION(1) */
           nvl(t1.ref_number,'')                          as cont_no           --业务协议号
          ,case when t1.buy_or_sell = 'B' then '1'        
                when t1.buy_or_sell = 'S' then '2'        
                else ''    
            end                                           as inbank_lend_type   --买卖类型
          ,'CNY'                                          as ccy                --币种代码
          ,'100000'                                       as org_id             --机构代码  待定
          ,nvl(tva.accountingcode,'')                     as subj_no            --科目号
          ,nvl(t1.cptys_id,'')                            as tran_party_id      --交易对手id
          ,nvl(t1.cptys_name,'')                          as tran_party_desc    --交易对手描述
          ,''                                             as tran_party_type    --交易对手类型
          ,nvl(t1.rating_level,'')                        as tran_party_rating  --交易对手评级        空值待定
          ,nvl(from_unixtime(unix_timestamp(string(t1.value_date),'yyyyMMdd'),'yyyy-MM-dd'),'')      as start_date    --开始日期
          ,nvl(from_unixtime(unix_timestamp(string(t1.maturity_date),'yyyyMMdd'),'yyyy-MM-dd'),'')   as mature_date --到期日期
          ,nvl(t1.trade_rate,0)                           as exec_rate          --执行利率(%)
          ,nvl(t1.amount,0)                               as biz_amt            --业务金额   
          ,round(nvl(t1.sumd,0)-nvl(t1.sumc,0),2)         as recv_int           --应收应付利息    
          ,'10600402'                                     as recv_int_subj_no   --应收应付利息科目
          ,'1'                                            as accr_flag          --计息标志
          ,'B99'                                          as int_mode           --计息方式
          ,nvl(from_unixtime(unix_timestamp(string(t1.value_date),'yyyyMMdd'),'yyyy-MM-dd' ),'')     as accr_date     --起息日期
          ,'TR05'                                         as pric_benc          --定价基准类型
          ,'2'                                            as int_basis          --计息基础
          ,nvl(tvb.holdposition,0)                        as bal                --拆借余额
          ,case when t1.rate_type = 'F' then 'RF01' --固定
                when t1.rate_type = 'O' then 'RF02' --浮动
                else ''
            end                                           as rate_type          --利率类型
          ,case when tvb.holdposition=0 then from_unixtime(unix_timestamp(string(t7.act_settledate),'yyyyMMdd'),'yyyy-MM-dd')
                else '' 
            end                                           as actual_mature_date --实际到期日期
          ,nvl(tav.amount,0)                              as withdraw_int       --日计提利息
          ,nvl(cast(t2.priceearning    as decimal(28,10)) ,0)  as total_diff_income  --累计价差收益
          ,nvl(cast(t2.amortizeearning as decimal(28,10)) ,0)  as total_amort_income --累计摊销收益
          ,nvl(cast(t2.interestearning as decimal(28,10)) ,0)  as total_int_income   --累计利息收益
          ,nvl(cast(t2.fairvalueincome as decimal(28,10)) ,0)  as total_fair_value_change  --累计公允价值变动损益
          ,nvl(t1.minorassetcode,'')                           as asset_code         --资产编号
          ,0                                                   as int_adj            --利息调整金额
          ,''                                                  as int_adj_subj_no    --利息调整科目号
          ,nvl(t1.sumcc,0)                                     as int_pl             --利息支出/收入
          ,'50100302'                                          as int_pl_subj_no     --利息支出/收入科目
      from (select min(tvb.alterbalance_id) as alterbalance_id  --取最早的交易数据确认交易科目号
                  ,max(tvb.balance_id)      as balance_id
                  ,tvb.majorassetcode
                  ,tvb.minorassetcode
                  ,tvl.buy_or_sell          as buy_or_sell 
                  ,tvc.cptys_id             as cptys_id     
                  ,tvc.cptys_name           as cptys_name 
                  ,tvc.rating_level         as rating_level  
                  ,tvpl.ref_number          as ref_number
                  ,tvpl.value_date          as value_date
                  ,tvpl.maturity_date       as maturity_date
                  ,tvpl.trade_rate          as trade_rate
                  ,tvpl.deal_id             as deal_id
                  ,tvpl.amount              as amount
                  ,tvpl.rate_type           as rate_type
                  ,sum(tvad.amount)         as sumd
                  ,sum(tvac.amount)         as sumc
                  ,sum(tvcc.amount)         as sumcc
              from odata.tb_v_balance tvb
              left join odata.tb_v_loandeals tvl
                on tvl.loandeals_id_grand = substr(tvb.majorassetcode,5)
               and tvl.bddw_end_date= '9999-99-99'
               and tvl.data_date = '${DATA_DATE}'
               and tvl.trade_category = '2'
              left join odata.tb_vs_cptys tvc
                on tvc.key_src = tvl.counterparty_seq
               and tvc.data_date = '${DATA_DATE}'
               and tvc.bddw_end_date= '9999-99-99'
              left join odata.tb_vs_payment_loandeals tvpl --实际收付确认同业存放的数据
                on tvpl.data_date = '${DATA_DATE}'
               and tvpl.bddw_end_date= '9999-99-99'
               and tvl.deal_id = tvpl.deal_id
               and tvl.deal_name = tvpl.deal_name
              left join (select bundlecode
                               ,accountingcode
                               ,round(amount,2) as amount
                           from odata.tb_vs_accentry2
                          where data_date='${DATA_DATE}'
                            and bddw_end_date='9999-99-99'
                            and debitcredit = 'C'
                            and accountingcode ='10600402'
                        ) tvac
                on tvb.alterbalance_id = tvac.bundlecode
              left join (select bundlecode
                               ,accountingcode
                               ,round(amount,2) as amount
                           from odata.tb_vs_accentry2
                          where data_date='${DATA_DATE}'
                            and bddw_end_date='9999-99-99'
                            and debitcredit = 'D'
                            and accountingcode='10600402'
                        ) tvad
                on tvb.alterbalance_id = tvad.bundlecode
              left join (select bundlecode
                               ,accountingcode
                               ,round(amount,6) as amount
                           from odata.tb_vs_accentry2
                          where data_date='${DATA_DATE}'
                            and bddw_end_date='9999-99-99'
                            and accountingcode ='50100302'
                            and debitcredit = 'C'
                            and settledate >= regexp_replace(trunc('${DATA_DATE}','YYYY'),'-','')    --取当年的利息收入
                        ) tvcc
                on tvb.alterbalance_id = tvcc.bundlecode
     where tvb.data_date = '${DATA_DATE}'
       and tvb.bddw_end_date= '9999-99-99'
       and tvb.settledate <= regexp_replace('${DATA_DATE}','-','') --统计日期
       and tvb.aspclient_id = '2244' --请替换本行部门ID
       and tvb.assettype = '同业存放'
     group by tvl.buy_or_sell
             ,tvc.cptys_id     
             ,tvc.cptys_name 
             ,tvc.rating_level 
             ,tvpl.ref_number
             ,tvpl.value_date
             ,tvpl.maturity_date
             ,tvpl.trade_rate
             ,tvpl.rate_type 
             ,tvpl.deal_id
             ,tvpl.amount
             ,tvb.majorassetcode
             ,tvb.minorassetcode) t1
      left join odata.tb_vs_accentry2 tva
        on t1.alterbalance_id = tva.bundlecode
       and tva.bddw_end_date= '9999-99-99'
       and tva.data_date = '${DATA_DATE}'
       and tva.accountingcode like '1011%'
      left join odata.tb_v_balance tvb
        on tvb.data_date = '${DATA_DATE}'
       and tvb.bddw_end_date= '9999-99-99'
       and t1.balance_id = tvb.balance_id
      left join (select * 
                   from (select *
                               ,row_number() over(partition by deal_id order by act_settledate desc) as rn
                           from odata.tb_vs_payment_trsi_loandeals t7
                          where t7.data_date = '${DATA_DATE}'
                            and t7.bddw_end_date= '9999-99-99'
                        ) a  
                  where rn=1
                ) t7
        on t7.deal_id = t1.deal_id
       and t7.assettype = '同业存放'
       and t7.buztype = '借出'
      left join (select alterbalance_id
                       ,majorassetcode
                       ,minorassetcode 
                   from odata.tb_v_balance bls
                  where bls.data_date = '${DATA_DATE}'
                    and bls.bddw_end_date = '9999-99-99'
                    and bls.settledate = regexp_replace('${DATA_DATE}','-','') --统计日期
                    and bls.aspclient_id = '2244' --请替换本行部门ID
                    and bls.assettype = '同业存放'
                    and bls.baretradename='WITHDRAWALDEALS'
                ) t
        on t1.majorassetcode = t.majorassetcode
       and t1.minorassetcode=t.minorassetcode
      left join odata.tb_vs_accentry2 tav
        on t.alterbalance_id = tav.bundlecode
       and tav.data_date='${DATA_DATE}'
       and tav.bddw_end_date='9999-99-99' 
       and tav.accountingcode like '106%'
      left join (select aspclient_id
                       ,keepfolder_id
                       ,assettype
                       ,majorassetcode
                       ,minorassetcode
	                   ,sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                                 then priceearning
                                 else 0 
                             end)                as priceearning
                       ,sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                                 then amortizeearning
                                 else 0 
                             end)                as amortizeearning
                       ,sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                                 then interestearning
                                 else 0 
                             end)                as interestearning
                       ,sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                                 then fairvalueincome 
                                 else 0 
                             end)                as fairvalueincome
                   from odata.tb_v_alterbalance
                  where data_date ='${DATA_DATE}'
                    and bddw_end_date ='9999-99-99'
                  group by aspclient_id,
                           keepfolder_id,
                           assettype,
                           majorassetcode,
                           minorassetcode
                ) t2
		on t2.aspclient_id = tvb.aspclient_id
       and t2.keepfolder_id = tvb.keepfolder_id
       and t2.assettype = tvb.assettype
       and t2.majorassetcode = tvb.majorassetcode
       and t2.minorassetcode = tvb.minorassetcode
------------------------------------------------------同业存单----------------------------------------------------
union  all
select /*+ REPARTITION(1) */
           nvl(t31.serial_num,'')                         as cont_no              --业务协议号       --缴款表交易序号
          ,case when t2.buyorsell = 'B' then '1'        
                when t2.buyorsell = 'S' then '2'        
                else ''    
            end                                           as inbank_lend_type     --买卖类型
          ,'CNY'                                          as ccy                  --币种代码
          ,'100000'                                       as org_id               --机构代码 
          ,'20120101'                                     as subj_no              --科目号
          ,nvl(tvc.cptys_id,'')                           as tran_party_id        --交易对手id
          ,nvl(t31.bidder,'')                             as tran_party_desc      --交易对手描述       --中标人名称
          ,''                                             as tran_party_type      --交易对手类型
          ,nvl(tvc.rating_level,'')                       as tran_party_rating    --交易对手评级        
          ,nvl(from_unixtime(unix_timestamp(string(ts.issue_date ),'yyyyMMdd'),'yyyy-MM-dd'),'')     as start_date   --开始日期      
          ,nvl(from_unixtime(unix_timestamp(string(ts.maturity_date),'yyyyMMdd'),'yyyy-MM-dd'),'')   as mature_date  --到期日期
          ,nvl(ts.aution_rate ,0)                         as exec_rate            --执行利率(%)     
          ,nvl(t31.net_commission_amt_cstp*100000000,0)   as biz_amt              --业务金额         
          ,0                                              as recv_int             --应收应付利息    
          ,''                                             as recv_int_subj_no     --应收应付利息科目
          ,'1'                                            as accr_flag            --计息标志        
          ,'B99'                                          as int_mode             --计息方式   
          ,nvl(from_unixtime(unix_timestamp(string(ts.start_coupon_date),'yyyyMMdd'),'yyyy-MM-dd'),'')  as accr_date     --起息日期 
          ,'TR99'                                         as pric_benc            --定价基准类型     
          ,'2'                                            as int_basis            --计息基础     
          ,nvl(b2.holdposition*t31.rate,0)                as bal                  --余额   
          ,'RF01'                                         as rate_type            --利率类型    
          ,''                                             as actual_mature_date   --实际到期日期
          ,nvl(t.withdraw_int*t31.rate,0)                 as withdraw_int         --日计提利息
          ,nvl(cast(ce1.priceearning*t31.rate    as decimal(28,10)) ,0)  as total_diff_income  --累计价差收益
          ,nvl(cast(ce1.amortizeearning*t31.rate as decimal(28,10)) ,0)  as total_amort_income --累计摊销收益
          ,nvl(cast(ce1.interestearning*t31.rate as decimal(28,10)) ,0)  as total_int_income   --累计利息收益
          ,nvl(cast(ce1.fairvalueincome*t31.rate as decimal(28,10)) ,0)  as total_fair_value_change  --累计公允价值变动损益
          ,nvl(b2.majorassetcode,'')                            as asset_code         --资产编号      
          ,nvl(ce1.interestadjust*t31.rate,0)                   as int_adj            --利息调整金额
          ,'20120102'                                           as int_adj_subj_no    --利息调整科目号
          ,nvl(t.sumcc*t31.rate,0)                              as int_pl             --利息支出/收入
          ,'60100501'                                           as int_pl_subj_no     --利息支出/收入科目
  from (select max(bls.balance_id) as balance_id
                      from odata.tb_v_balance bls
                     where bls.settledate <= regexp_replace('${DATA_DATE}','-','') -- 统计日期
                       and bls.aspclient_id = '2244' -- 请替换本行部门 ID
                       and bls.buztype ='债券发行'
                       and bls.assettype  ='债券发行'
                       and bls.data_date = '${DATA_DATE}'
                       and bls.bddw_end_date = '9999-99-99'
                     group by bls.aspclient_id,
                              bls.keepfolder_id,
                              bls.assettype,
                              bls.buztype,
                              bls.majorassetcode,
                              bls.minorassetcode) b1
            inner join odata.tb_v_balance b2
                    on b1.balance_id = b2.balance_id
                   and b2.data_date = '${DATA_DATE}'
                   and b2.bddw_end_date = '9999-99-99'
             left join
                      ( select bd.bondscode,bd.deal_id,t3.net_commission_amt_cstp,t3.serial_num,t3.bidder,bd.cptys_id,
                               t3.net_commission_amt_cstp*100000000/bd.settleamount  as  rate
                          from odata.tb_v_ncd_commission_data t3
                     left join odata.tb_v_bondsdeals bd
                            on bd.bondscode = trim(t3.security_code)
                           and bd.data_date ='${DATA_DATE}'
                           and bd.bddw_end_date = '9999-99-99'
                         where t3.data_date ='${DATA_DATE}'
                           and t3.bddw_end_date = '9999-99-99'
                           and t3.net_commission_amt_cstp is not null        --实际发生缴款的业务
                        ) t31
                    on t31.bondscode = int(b2.minorassetcode)
            inner join odata.tb_vs_payment_bondsdeals_all t2
                    on t31.deal_id = t2.deal_id
                   and t2.data_date = '${DATA_DATE}'
                   and t2.bddw_end_date = '9999-99-99'
   left join (select aspclient_id,
                               keepfolder_id,
                               assettype,
                               majorassetcode,
                               minorassetcode,
                               cast(sum(interestadjust) as decimal(24,6)) interestadjust ,    --利息调整
                               cast(sum(fairvaluealter) as decimal(24,6)) fairvaluealter,     --公允价值变动
                               sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                               then priceearning     else 0 end)  as priceearning,            --价差收益
                               sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                               then amortizeearning  else 0 end)  as amortizeearning,         --摊销收益
                               sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                               then interestearning  else 0 end)  as interestearning,         --利息收益
                               sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                               then fairvalueincome  else 0 end)  as fairvalueincome         --公允价值变动损益
                          from odata.tb_v_alterbalance
                         where data_date ='${DATA_DATE}'
                           and bddw_end_date ='9999-99-99'
                         group by aspclient_id,
                                  keepfolder_id,
                                  assettype,
                                  majorassetcode,
                                  minorassetcode) ce1
                    on b2.aspclient_id = ce1.aspclient_id
                   and b2.keepfolder_id = ce1.keepfolder_id
                   and b2.assettype = ce1.assettype
                   and b2.majorassetcode = ce1.majorassetcode
                   and b2.minorassetcode = ce1.minorassetcode
             left join odata.tb_vs_cptys tvc                --没有交易对手
                    on t31.cptys_id=tvc.key_src
                   and tvc.data_date ='${DATA_DATE}'
                   and tvc.bddw_end_date = '9999-99-99'
             left join odata.tb_v_security ts
                    on b2.majorassetcode = ts.security_code
                   and ts.data_date = '${DATA_DATE}'
                   and ts.bddw_end_date = '9999-99-99'
             left join (select   bls.majorassetcode,bls.minorassetcode,
                                    max(tva.amount)  as  withdraw_int,
                                    sum(cast(tvc.amount as decimal(24,6))) as sumcc
                             from odata.tb_v_balance bls
                             left  join  odata.tb_vs_accentry2 tvc             
                               on bls.alterbalance_id = tvc.bundlecode
                              and tvc.data_date='${DATA_DATE}'
                              and tvc.bddw_end_date='9999-99-99'
                              and tvc.accountingcode  ='60100501'
                              and tvc.debitcredit = 'D'
                              and tvc.settledate>= regexp_replace(trunc('${DATA_DATE}','YYYY'),'-','')    --取当年的利息支出
                             left join  odata.tb_vs_accentry2 tva                --取当日计提利息 
                               on bls.alterbalance_id = tva.bundlecode
                              and tva.data_date='${DATA_DATE}'
                              and tva.bddw_end_date='9999-99-99'
                              and tva.settledate= regexp_replace('${DATA_DATE}','-','')  --统计日期
                              and tva.accountingcode  ='20120102'                        --利息调整科目
                              and bls.baretradename='AMORTIZATIONDEALS'                  --摊销
                            where bls.settledate <= regexp_replace('${DATA_DATE}','-','') --统计日期
                              and bls.aspclient_id = '2244' -- 请替换本行部门 ID
                              and bls.buztype = '债券发行' 
                              and bls.assettype  ='债券发行'
                              and bls.data_date = '${DATA_DATE}'
                              and bls.bddw_end_date = '9999-99-99'
                            group by bls.minorassetcode,bls.majorassetcode
                              ) t
                       on b2.majorassetcode = t.majorassetcode
                      and b2.minorassetcode = t.minorassetcode