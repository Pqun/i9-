---------------------------------------------------------------------------------------------------------------
--脚本名称：dws_loan_indv_loan_repay_sum_p.sql百度张家港取数
--功能描述：生成每日结果数据并插入hive dws层dws.dws_loan_indv_loan_repay_sum_p
--作    者：华天顺
--开发日期：2022-05-06
--直属经理：方杰
--来源表  ：odata.sllv_mb_acct_schedule_detail  --账户计划明细表
--来源表  ：odata.sllv_mb_invoice   --单据表 取回收明细
--来源表  ：odata.sllv_mb_guarantee_receipt
--来源表  ：odata.sllv_mb_acct
--来源表  ：odata.sym_cif_client_document
--来源表  ：odata.ols_loan_cont_info
--来源表  ：odata.order_main_loan_order
--目标表  ：dws.dws_loan_indv_loan_repay_sum_p
--修改历史：
--          1.华天顺   2022-05-06    新建
--          2.华天顺 2022-06-14    新增非应计本金和表外利息字段
--          3.华天顺 2022-10-10    变更表名
--          4.杨琦浩 2023-04-04    修改超过宽限日还清取数逻辑
--          5.邓权   2023-12-16    修改逻辑为宽限期内逾期也计算逾期天数
---------------------------------------------------------------------------------------------------------------
insert overwrite table dws.dws_loan_indv_loan_repay_sum_p partition (data_date='${DATA_DATE}',prod_code='110142')
select /*+ REPARTITION(1) */ 
     t1.loan_id as bill_no                                                     --借据号
    ,'' as acct_no                                                                     --账号
    ,''                                                                                --合同号
    ,t5.crd_cont_no as crd_cont_no                                                                 --授信合同号
    ,t5.cust_id_core as cust_id                                                                     --客户号
    ,t5.cust_name   as cust_name                                                                    --客户姓名
    ,t6.document_type     as cert_type                                                     --证件类型
    ,t6.document_id       as cert_code                                                     --证件代码
    ,t7.contact_tel       as mobile                                                        --联系电话
    ,from_unixtime(unix_timestamp(t1.cur_date,'yyyyMMdd'),'yyyy-MM-dd')          as biz_date                                                      --业务日期
    ,t5.prd_code          as biz_prod_code                                                --业务产品代码
    ,'张家港联合贷'       as prod_name                                                                   --产品名称
    ,'' as biz_type_code                                                               --业务类型编号
    ,'' as biz_type_name                                                               --业务类型名称
    ,from_unixtime(unix_timestamp(t3.start_date,'yyyyMMdd'),'yyyy-MM-dd')       as loan_start_date           --贷款起始日期
    ,from_unixtime(unix_timestamp(t3.end_date,'yyyyMMdd'),'yyyy-MM-dd')         as loan_end_date             --贷款结束日期
    ,from_unixtime(unix_timestamp(t3.clear_date,'yyyyMMdd'),'yyyy-MM-dd')       as loan_clear_date           --贷款结清日
    ,'m'                                    as loan_term_type            --贷款期限类型
    ,t3.total_terms as total_loan_terms                                                  --贷款总期数
    ,'' as ccy                                                                         --币种
    ,'' as rmb_exch                                                                  --对人民币汇率
    ,t1.term_no as term_no                                                                --期次
    ,from_unixtime(unix_timestamp(t1.start_date,'yyyymmdd'),'yyyy-mm-dd') as term_start_date                                                  --本期开始日期
    ,from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd')  as term_mature_date                                                 --本期到期日期
    ,date_add(from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.grace_day as int )) as term_grace_date                              --本期宽限到期日
    ,t3.grace_day  as grace_days
    ,from_unixtime(unix_timestamp(t10.tran_date,'yyyyMMdd'),'yyyy-MM-dd') as repay_date                                                     --实际还款日
    ,t10.cnt as term_repay_cnt                                                 --本期还款次数
    ,case when t1.term_status = '2' then '07'  --未还清 已逾期
          when t1.term_status = '5' and t1.end_date = t1.clear_date then '01' --还款日当天还清
          when t1.term_status = '5' and t1.end_date > t1.clear_date then '04' --还款日前还清
          when t1.term_status = '5' and from_unixtime(unix_timestamp(t1.clear_date,'yyyymmdd'),'yyyy-mm-dd')>date_add(from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.grace_day as int )) then '03' --超过宽限日还清
          when t1.term_status = '5' and t1.end_date < t1.clear_date and from_unixtime(unix_timestamp(t1.clear_date,'yyyymmdd'),'yyyy-mm-dd')<=date_add(from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.grace_day as int )) then '02' --超过还款日，但在宽限期内还清本期
          when t1.term_status = '1' then '06' --未还清，未逾期
    end as term_repay_status                                                                      --还款状态
    ,t1.prin_total/100 as matured_prin                                                                 --本期应还本金
    ,t1.prin_repay/100 as repaid_prin                                                             --本期已还本金
    --,null as                                                                                    --累计应还本金
    --,null as                                                                                    --累计未到期本金
    ,case when t1.term_status='2' 
          then (t1.prin_total-t1.prin_repay)/100
          else 0
      end             as overdue_prin                                                             --本期逾期本金   
    ,t1.int_total/100 as matured_int                                                                   --本期应还利息
    ,t1.int_repay/100 as repaied_int                                                              --本期已还利息
    ,case when t1.term_status='2' 
          then t1.int_bal/100
          else 0
      end as overdue_int                                                               --本期逾期利息    
    ,t1.fund_fee_total/100  as matured_fee                                                              --本期应还担保费  
    ,t1.fund_fee_repay/100 as repaied_fee                                                              --本期已还担保费  
    ,t1.pnlt_int_total/100 as matured_pena                                                               --本期应还罚息
    ,t1.pnlt_int_repay/100  as repaied_pena                                                             --本期已还罚息
    ,0 as matured_compo                                                                           --本期应还复利
    ,0 as repaied_compo                                                                           --本期已还复利
    ,from_unixtime(unix_timestamp(t1.clear_date,'yyyyMMdd'),'yyyy-MM-dd')          as clear_date                                                                  --结清日期
    --,case when t1.term_status = '2' 
    --      then datediff(from_unixtime(unix_timestamp(t1.cur_date,'yyyymmdd'),'yyyy-mm-dd'),from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'))+1
    --   else 0 end            as overdue_days                                                             --逾期天数
    ,case when (t1.prin_total-t1.prin_repay=0 and t1.int_total-t1.int_repay=0 and t1.pnlt_int_total-t1.pnlt_int_repay=0) and    from_unixtime(unix_timestamp(t10.tran_date,'yyyyMMdd'),'yyyy-MM-dd')>from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd')
          then datediff(from_unixtime(unix_timestamp(t10.tran_date,'yyyymmdd'),'yyyy-mm-dd'),from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'))
          when (t1.prin_total-t1.prin_repay>0 or t1.int_total-t1.int_repay>0 or t1.pnlt_int_total-t1.pnlt_int_repay>0) and from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd')<'${DATA_DATE}'
          then datediff('${DATA_DATE}',from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'))
          else 0
      end              as overdue_days                                                            --逾期天数       
    ,nvl(t9.repay_violate_amt,0)               as adv_repay_fee  --提前还款手续费
	,case when t3.cur_ovd_days>90  then t1.prin_total/100-nvl(t1.prin_repay/100,0) else 0 end as non_accru_bal --非应计本金
	,case when t3.cur_ovd_days>90  then t1.int_total/100-nvl(t1.int_repay/100,0) else 0 end as aoff_bal_int  --表外利息
from odata.slur_bdul_repayplan_file_clear   t1 
left join odata.slur_bdul_loan_file_clear t3
on t1.loan_id = t3.loan_id
and t3.data_date = '${DATA_DATE}'
and t3.bddw_end_date = '9999-99-99'
and t3.loan_mode ='01'
inner join  odata.ols_loan_cont_info t5 
on t5.data_date = '${DATA_DATE}'
and t5.bddw_end_date = '9999-99-99'
and t5.cont_status in ('105','106','107','108','109','110')
and t1.loan_id=t5.bill_no
and t5.prd_code='10091004004'
left join odata.sym_cif_client_document t6
on t6.data_date = '${DATA_DATE}'
and t6.bddw_end_date = '9999-99-99'
and t5.cust_id_core = t6.client_no
and t6.pref_flag='Y' 
left join odata.sym_cif_client_contact_tbl t7
on t5.cust_id_core = t7.client_no 
and t7.pref_flag='Y'
and t7.data_date='${DATA_DATE}'
and t7.bddw_end_date='9999-99-99'
left join (select loan_id
                 ,term_no
				 ,max(cur_date) as tran_date 
				 ,count(1) as cnt 
			 from odata.slur_bdul_repay_item_file
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99'
              and loan_mode = '01'
         group by loan_id,term_no) t10
      on t1.loan_id=t10.loan_id
	 and t1.term_no=t10.term_no
left join (select loan_id
                 ,sum(repay_violate_amt) as repay_violate_amt 
             from odata.slur_bdul_repay_file
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99'
              and loan_mode ='01'
            group by loan_id) t9
  on t9.loan_id=t1.loan_id
where t1.data_date = '${DATA_DATE}'
and   t1.bddw_end_date = '9999-99-99'
and   t1.loan_mode ='01'