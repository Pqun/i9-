---------------------------------------------------------------------------------------------------------------
--脚本名称：dws_loan_indv_loan_repay_sum_p.sql小米取数
--功能描述：生成每日结果数据并插入hive dws层dws.dws_loan_indv_loan_repay_sum_p
--作    者：方杰
--开发日期：2021-04-13
--直属经理：方杰
--来源表  ：odata.sllv_mb_acct_schedule_detail  --账户计划明细表
--来源表  ：odata.sllv_mb_invoice   --单据表 取回收明细
--来源表  ：odata.sllv_mb_guarantee_receipt
--来源表  ：odata.sllv_mb_acct
--来源表  ：odata.sym_cif_client_document
--来源表  ：odata.ols_loan_cont_info
--来源表  ：odata.order_main_loan_order
--目标表  ：dws.dws_loan_indv_loan_repay_sum_p
--修改历史：
--          1.方杰   2021-04-13    新建
--          2.华天顺 2022-06-14    新增非应计本金和表外利息字段
--          3.华天顺 2022-10-10    变更表名
--          4.邓权   2023-12-16    修改逻辑为宽限期内逾期也计算逾期天数
--          5.姚威   2024-01-09    修改应还复利，已还复利逻辑
---------------------------------------------------------------------------------------------------------------
insert overwrite table dws.dws_loan_indv_loan_repay_sum_p partition (data_date='${DATA_DATE}',prod_code='110126')
select /*+ REPARTITION(1) */ 
     t1.loan_id as bill_no                                                             --借据号
    ,'' as acct_no                                                                     --账号
    ,''                                                                                --合同号
    ,t5.crd_cont_no as crd_cont_no                                                                 --授信合同号
    ,t5.cust_id_core as cust_id                                                                     --客户号
    ,t5.cust_name   as cust_name                                                                    --客户姓名
    ,t6.document_type     as cert_type                                                     --证件类型
    ,t6.document_id       as cert_code                                                     --证件代码
    ,t7.contact_tel       as mobile                                                        --联系电话
	,from_unixtime(unix_timestamp(t1.cur_date,'yyyyMMdd'),'yyyy-MM-dd')          as biz_date                                                      --业务日期
    ,t5.prd_code          as biz_prod_code                                                --业务产品代码
    ,'小米' as prod_name                                                               --产品名称
    ,'' as biz_type_code                                                               --业务类型编号
    ,'' as biz_type_name                                                               --业务类型名称
    ,from_unixtime(unix_timestamp(t3.start_date,'yyyyMMdd'),'yyyy-MM-dd')       as loan_start_date           --贷款起始日期
    ,from_unixtime(unix_timestamp(t3.end_date,'yyyyMMdd'),'yyyy-MM-dd')         as loan_end_date             --贷款结束日期
    ,from_unixtime(unix_timestamp(t3.clear_date,'yyyyMMdd'),'yyyy-MM-dd')       as loan_clear_date           --贷款结清日
    ,'m'                                    as loan_term_type            --贷款期限类型
    ,t4.term_no as total_loan_terms                                                --贷款总期数
    ,'' as ccy                                                                         --币种
    ,null as rmb_exch                                                                  --对人民币汇率
    ,t1.term_no as term_no                                                            --期次
    ,from_unixtime(unix_timestamp(t1.start_date,'yyyymmdd'),'yyyy-mm-dd') as term_start_date                                                  --本期开始日期
    ,from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd')   as term_mature_date                                                 --本期到期日期
    ,date_add(from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.grace_day as int )) as term_grace_date               --本期宽限到期日
    ,t3.grace_day  as grace_days
    ,from_unixtime(unix_timestamp(t2.receipt_date,'yyyymmdd'),'yyyy-mm-dd') as repay_date                                                     --实际还款日
    ,t2.repay_cnt                 as term_repay_cnt                                         --本期还款次数
    ,case when t8.loan_no is not null then '05'   --代偿
	      when t1.term_status = 2 then '07'  --未还清 已逾期
          when t1.term_status = 5 and t1.end_date = t1.clear_date then '01' --还款日当天还清
          when t1.term_status = 5 and t1.end_date > t1.clear_date then '04' --还款日前还清
          when t1.term_status = 5 and from_unixtime(unix_timestamp(t1.clear_date,'yyyymmdd'),'yyyy-mm-dd')>date_add(from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.grace_day as int )) then '03' --超过宽限日还清
          when t1.term_status = 5 and t1.end_date < t1.clear_date and from_unixtime(unix_timestamp(t1.clear_date,'yyyymmdd'),'yyyy-mm-dd')<=date_add(from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.grace_day as int )) then '02' --超过还款日，但在宽限期内还清本期
          when t1.term_status = 1 then '06' --未还清，未逾期
    end as term_repay_status                                                                      --还款状态
    ,t1.matured_prin/100 as matured_prin                                                              --本期应还本金
    ,t1.repay_prin/100 as repaid_prin                                                                 --本期已还本金
    --,null as                                                                                    --累计应还本金
    --,null as                                                                                    --累计未到期本金
    ,case when t1.term_status = 2 then (t1.matured_prin-t1.repay_prin)/100 else 0 end as overdue_prin   --本期逾期本金  
    ,t1.matured_int/100 as matured_int                                                                --本期应还利息
    ,t1.repay_int/100 as repaied_int                                                                  --本期已还利息
    ,case when t1.term_status = 2 then (t1.matured_int-t1.repay_int)/100 else 0 end as overdue_int      --本期逾期利息    
    ,0 as matured_fee                                                                             --本期应还担保费  小米无担保费
    ,0 as repaied_fee                                                                             --本期已还担保费  小米无担保费
    ,(t1.matured_prin_pena+t1.matured_int_pena)/100 as matured_pena                                     --本期应还罚息
    ,(t1.repay_prin_pena+t1.repay_int_pena)/100 as repaied_pena                                         --本期已还罚息
    ,nvl((t1.matured_int_pena-t1.int_pnlt_reduce_amt)/100,0)  as dourate_amt                            --本期应还复利
    ,nvl(t1.repay_int_pena/100,0 )                            as repaied_compo                          --本期已还复利
    ,from_unixtime(unix_timestamp(t1.clear_date,'yyyymmdd'),'yyyy-mm-dd') as clear_date           --结清日期
    --,t1.overdue_days as overdue_days                                                              --逾期天数
    ,case when (t1.matured_prin-t1.repay_prin=0 and t1.matured_int-t1.repay_int=0 and (t1.matured_prin_pena+t1.matured_int_pena)-(t1.repay_prin_pena+t1.repay_int_pena)=0) and from_unixtime(unix_timestamp(t2.receipt_date,'yyyymmdd'),'yyyy-mm-dd')>from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd')
          then datediff(from_unixtime(unix_timestamp(t2.receipt_date,'yyyymmdd'),'yyyy-mm-dd'),from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'))
          when (t1.matured_prin-t1.repay_prin>0 or t1.matured_int-t1.repay_int>0 or (t1.matured_prin_pena+t1.matured_int_pena)-(t1.repay_prin_pena+t1.repay_int_pena)>0) and from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd')<'${DATA_DATE}'
          then datediff('${DATA_DATE}',from_unixtime(unix_timestamp(t1.end_date,'yyyymmdd'),'yyyy-mm-dd'))
          else 0
      end              as overdue_days                                                            --逾期天数
    ,nvl(t9.pre_pmt_fee_repay/100,0)               as adv_repay_fee  --提前还款手续费
	,case when t3.interesttransferstatus='2'  then t1.matured_prin/100-nvl(t1.repay_prin/100,0) else 0 end as non_accru_bal --非应计本金
	,case when t3.interesttransferstatus='2'  then t1.matured_int/100-nvl(t1.repay_int/100,0) else 0 end as aoff_bal_int  --表外利息
from (select * from (
    select            
         loan_id
        ,term_no
        ,start_date
        ,end_date
        ,clear_date --结清日期
        ,prin_total as matured_prin
        ,int_total_plan as matured_int
        ,prin_repay as repay_prin
        ,int_repay as repay_int
        ,pnlt_int_total as matured_prin_pena       --应还本金罚息
        ,int_pnlt_total as matured_int_pena        --应还利息罚息
        ,pnlt_int_repay as repay_prin_pena         --已还本金罚息
        ,int_pnlt_repay as repay_int_pena          --已还利息罚息
        ,days_ovd as overdue_days                  --逾期天数
        ,int_pnlt_reduce_amt                       --减免利息罚息（复息）发生额
        ,term_status
		,cur_date
        --,sum(matured_prin)over(partition by loan_id,stage_no) as total_prin          --放款本金
        ,rank() over(partition by loan_id order by cur_date desc) as rn
    from odata.slur_xm_term_status_file
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    --and date_add(from_unixtime(unix_timestamp(cur_date,'yyyymmdd'),'yyyy-mm-dd'),1) = '${DATA_DATE}'  --小米文件为T+2
    ) t1   where  rn=1 )t1
left join (select * from (select  loan_id,term_no,row_number() over(partition by loan_id order by cur_date desc,term_no desc) as rn
    from odata.slur_xm_term_status_file
     where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99') a  
    where rn=1) t4
on t1.loan_id = t4.loan_id
left join
    (
    select 
         loan_id
        ,term_no
        ,max(xm_tran_date) as receipt_date  --还款时间
        ,count(1) as repay_cnt --还款笔数
    from odata.slur_xm_repay_item_file
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    group by 
         loan_id
        ,term_no
    ) t2
on t1.loan_id = t2.loan_id
and t1.term_no = t2.term_no
left join odata.slur_xm_loan_file_clear t3
on t1.loan_id = t3.loan_id
and t3.data_date = '${DATA_DATE}'
and t3.bddw_end_date = '9999-99-99'
inner join  odata.ols_loan_cont_info t5 
on t5.data_date = '${DATA_DATE}'
and t5.bddw_end_date = '9999-99-99'
and t1.loan_id=t5.bill_no
and t5.prd_code='10111001001'
and t5.cont_status in ('105','106','107','108','109','110')
left join odata.sym_cif_client_document t6
on t6.data_date = '${DATA_DATE}'
and t6.bddw_end_date = '9999-99-99'
and t5.cust_id_core = t6.client_no
and t6.pref_flag='Y' 
--获取联系电话
left join odata.sym_cif_client_contact_tbl t7
on t5.cust_id_core = t7.client_no 
and t7.pref_flag='Y'
and t7.data_date='${DATA_DATE}'
and t7.bddw_end_date='9999-99-99'
left join odata.slur_dzz_compensatory_detail t8
        on t1.loan_id = t8.loan_no
       and t1.term_no = t8.term_no
       and t8.data_date='${DATA_DATE}'
       and t8.bddw_end_date='9999-99-99'
       and t8.comps_status='S'
       and t8.sl_id = 'XM'
       and t8.prod_class='02'
left join (select loan_id,term_no
                 ,sum(pre_pmt_fee_repay) as pre_pmt_fee_repay 
             from odata.slur_xm_repay_item_file
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99'
            group by loan_id,term_no)t9
on t9.loan_id = t1.loan_id
and t9.term_no = t1.term_no