--2.yangqihao.dws_loan_indv_loan_repay_sum_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：dws_loan_indv_loan_repay_sum_p.sql字节星选取数
--功能描述：生成每日结果数据并插入hive dws层dws.dws_loan_indv_loan_repay_sum_p
--作    者：方杰
--开发日期：2024-04-15
--直属经理：方杰
--来源表  ：odata.sllv_ac_repay_plan
--来源表  ：odata.slur_ac_repayplan_file
--来源表  ：odata.slur_ac_repay_file
--来源表  ：odata.ols_loan_cont_info
--来源表  ：odata.sym_cif_client_document
--来源表  ：odata.sym_cif_client_contact_tbl
--来源表  ：odata.sllv_ac_loan
--目标表  ：dws.dws_loan_indv_loan_repay_sum_p
--修改历史：
--          1.杨琦浩   2024-04-15    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table dws.dws_loan_indv_loan_repay_sum_p partition (data_date='${DATA_DATE}',prod_code='110193')
select /*+ REPARTITION(1) */
     t5.bill_no                                                                      as bill_no --借据号
    ,''                                                                              as acct_no --账号
    ,''                                                                              as cont_no --合同号
    ,t5.crd_cont_no                                                                  as crd_cont_no --授信合同号
    ,t5.cust_id_core                                                                 as cust_id --客户号
    ,t5.cust_name                                                                    as cust_name --客户姓名
    ,t6.document_type                                                                as cert_type --证件类型
    ,t6.document_id                                                                  as cert_code --证件代码
    ,t7.contact_tel                                                                  as mobile --联系电话
    ,substr(t2.biz_date,1,10)                                                        as biz_date --业务日期
    ,t5.prd_code                                                                     as biz_prod_code --业务产品代码
    ,t8.prod_desc                                                                    as prod_name --产品名称
    ,''                                                                              as biz_type_code --业务类型编号
    ,''                                                                              as biz_type_name --业务类型名称
    ,from_unixtime(unix_timestamp(t3.start_date,'yyyyMMdd'),'yyyy-MM-dd')            as loan_start_date --贷款起始日期
    ,from_unixtime(unix_timestamp(t3.end_date,'yyyyMMdd'),'yyyy-MM-dd')              as loan_end_date --贷款结束日期
    ,from_unixtime(unix_timestamp(t3.clear_date,'yyyyMMdd'),'yyyy-MM-dd')            as loan_clear_date --贷款结清日
    ,'m'                                                                             as loan_term_type --贷款期限类型
    ,t3.total_terms                                                                  as total_loan_terms --贷款总期数
    ,t3.ccy                                                                          as ccy --币种
    ,''                                                                              as rmb_exch --对人民币汇率
    ,t1.term_no                                                                      as term_no --期次
    ,from_unixtime(unix_timestamp(t1.start_date,'yyyyMMdd'),'yyyy-MM-dd')            as term_start_date --本期开始日期
    ,from_unixtime(unix_timestamp(t1.end_date,'yyyyMMdd'),'yyyy-MM-dd')              as term_mature_date --本期到期日期
    ,from_unixtime(unix_timestamp(t1.grace_date,'yyyyMMdd'),'yyyy-MM-dd')            as term_grace_date --本期宽限到期日
    ,datediff(from_unixtime(unix_timestamp(t1.grace_date,'yyyyMMdd'),'yyyy-MM-dd'),from_unixtime(unix_timestamp(t1.end_date,'yyyyMMdd'),'yyyy-MM-dd'))
                                                                                     as grace_days --宽限天数
    ,coalesce(from_unixtime(unix_timestamp(t4.receipt_date,'yyyyMMdd'),'yyyy-MM-dd'),t5.loan_clear_date,'') 
                                                                                     as repay_date --实际还款日
    ,t4.term_repay_cnt                                                               as term_repay_cnt --本期还款次数
    ,case when t1.term_status = 'N' and t1.end_date<=t2.biz_date      then '07'  --未还清 已逾期
          when t1.term_status = 'Y' and t1.end_date = t1.clear_date then '01' --还款日当天还清
          when t1.term_status = 'Y' and (t1.end_date > t1.clear_date or from_unixtime(unix_timestamp(t1.end_date,'yyyyMMdd'),'yyyy-MM-dd')>t5.loan_clear_date) then '04' --还款日前还清
          when t1.term_status = 'Y' and t1.clear_date>t1.grace_date then '03' --超过宽限日还清
          when t1.term_status = 'Y' and t1.end_date < t1.clear_date and t1.clear_date <= t1.grace_date then '02' --超过还款日，但在宽限期内还清本期
          when t1.term_status = 'N' and t1.end_date>t2.biz_date then '06' --未还清，未逾期
     end                                                                             as term_repay_status --还款状态
    ,nvl(t1.prin_total,0)                                                            as matured_prin --本期应还本金
    ,nvl(t1.prin_total,0)-nvl(t1.unpaid_prin,0)                                      as repaid_prin --本期已还本金
    ,case when nvl(t1.term_overdue_days,0)<>0 
          then nvl(t1.unpaid_prin,0)
          else 0
     end                                                                             as overdue_prin --本期逾期本金   
    ,nvl(t1.int_total,0)                                                             as matured_int --本期应还利息
    ,nvl(t1.int_total,0)-nvl(t1.unpaid_int,0)-nvl(t1.int_discount,0)                 as repaied_int --本期已还利息 
    ,case when nvl(t1.term_overdue_days,0)<>0 
          then nvl(t1.unpaid_int,0)
          else 0
     end                                                                             as overdue_int --本期逾期利息
    ,0                                                                               as matured_fee --本期应还担保费  
    ,0                                                                               as repaied_fee --本期已还担保费  
    ,nvl(t1.pnlt_int_total,0)                                                        as matured_pena --本期应还罚息
    ,nvl(t1.pnlt_int_total,0)-nvl(t1.unpaid_pnlt_int,0)-nvl(t1.pnlt_int_discount,0)  as repaied_pena --本期已还罚息
    ,nvl(t1.int_pnlt_total,0)                                                        as matured_compo --本期应还复利
    ,nvl(t1.int_pnlt_total,0)-nvl(t1.unpaid_int_pnlt,0)-nvl(t1.int_pnlt_discount,0)  as repaied_compo --本期已还复利
    ,nvl(t1.clear_date,'')                                                           as clear_date --结清日期
    ,nvl(t1.term_overdue_days,0)                                                     as overdue_days --逾期天数
    ,nvl(t1.fee_reapy,0)                                                             as adv_repay_fee  --提前还款手续费
    ,case when t3.accounting_status='FYJ' then nvl(t1.unpaid_prin,0) else 0 end      as non_accru_bal --非应计本金
    ,case when t3.accounting_status='FYJ' then nvl(t1.unpaid_int,0)-nvl(t1.int_discount,0) else 0 end 
                                                                                     as off_bal_int  --表外利息
from odata.sllv_ac_repay_plan   t1 
left join
    (
        select    loan_id
                  ,term_no
                  ,max(channel_date) as biz_date
        from odata.slur_ac_repayplan_file
        where data_date='${DATA_DATE}'
        and bddw_end_date='9999-99-99'
        group by loan_id,term_no
        ) t2
on  t1.loan_id = t2.loan_id
and t1.term_no = t2.term_no
left join (
           select loan_id
                  ,term_no
                  ,max(receipt_date) as receipt_date
                  ,count(1) as term_repay_cnt
           from odata.slur_ac_repay_file
           where data_date='${DATA_DATE}'
           and bddw_end_date='9999-99-99'
           group by loan_id
                    ,term_no
          ) t4
on  t1.loan_id = t4.loan_id
and t1.term_no = t4.term_no
left join odata.sllv_ac_loan t3
on t1.loan_id = t3.loan_id
and t3.data_date = '${DATA_DATE}'
and t3.bddw_end_date = '9999-99-99'
inner join  odata.ols_loan_cont_info t5 
on t5.data_date = '${DATA_DATE}'
and t5.bddw_end_date = '9999-99-99'
and t5.cont_status in ('105','106','107','108','109','110')
and t1.loan_id=t5.app_no
left join odata.sym_cif_client_document t6
on t6.data_date = '${DATA_DATE}'
and t6.bddw_end_date = '9999-99-99'
and t5.cust_id_core = t6.client_no
and t6.pref_flag='Y' 
left join odata.sym_cif_client_contact_tbl t7
on t5.cust_id_core = t7.client_no 
and t7.pref_flag='Y'
and t7.data_date='${DATA_DATE}'
and t7.bddw_end_date='9999-99-99'
left join odata.sym_mb_prod_type t8
on t3.prod_type=t8.prod_type
and t8.data_date='${DATA_DATE}'
and t8.bddw_end_date='9999-99-99'
where t1.data_date = '${DATA_DATE}'
and   t1.bddw_end_date = '9999-99-99'