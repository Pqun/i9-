--2.hts.dws_loan_indv_loan_repay_sum_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：dws_loan_indv_loan_repay_sum_p.sql行内产品取数
--功能描述：生成每日结果数据并插入hive dws层dws.dws_loan_indv_loan_repay_sum_p
--作    者：方杰
--开发日期：2021-04-13
--直属经理：方杰
--来源表  ：odata.sllv_mb_acct_schedule_detail  --账户计划明细表
--来源表  ：odata.sllv_mb_invoice   --单据表 取回收明细
--来源表  ：odata.sllv_mb_guarantee_receipt
--来源表  ：odata.sllv_mb_acct
--来源表  ：odata.sym_cif_client_document
--来源表  ：odata.ols_loan_cont_info
--来源表  ：odata.order_main_loan_order
--目标表  ：dws.dws_loan_indv_loan_repay_sum_p
--修改历史：
--          1.方杰   2021-04-13    新建
--          2.华天顺 2021-09-15    联合贷补充提前整笔结清,单期结清的期数
--          3.华天顺 2021-12-30    得物还款状态，逾期天数逻辑变更
--          4.华天顺 2022-01-13    洋钱罐联合带授信合同号改为从信贷取
--          5.华天顺 2022-05-18    得物逾期本金、逾期利息取数逻辑变更
--          6.华天顺 2022-06-09    借据结清时无需使已还等于应还
--          7.华天顺 2022-06-14    新增非应计本金和表外利息字段
--          8.华天顺 2022-10-10    应还罚息取数逻辑改为从罚息计提表取，表名变更
--          9.华天顺 2022-11-02    锡锡贷手工调整数据特殊处理
--          10.华天顺 2022-11-16   得物逾期本金和利息改为从出单表取
--          11.华天顺 2022-11-29   部分提前还款回收本金取数逻辑调整
--          12.华天顺 2023-01-10   行内产品取罚息时限制int_class='ODP'
--          13.杨琦浩 2023-03-09   联合贷金额改成行内金额
--          14.姚威   2024-01-09   修改应还复利，已还复利逻辑
---------------------------------------------------------------------------------------------------------------
insert overwrite table dws.dws_loan_indv_loan_repay_sum_p partition (data_date='${DATA_DATE}',prod_code)
select  
	 nvl(t4.cmisloan_no,'') as bill_no                                                     --借据号
    ,nvl(t4.base_acct_no,'') as acct_no                                                    --账号
    ,''                                                                                    --合同号
    ,nvl(t7.credit_order_id,t6.crd_cont_no) as crd_cont_no                                 --授信合同号
    ,nvl(t4.client_no,'') as cust_id                                                       --客户号
    ,t9.client_short      as cust_name                                                     --客户姓名
    ,t5.document_type     as cert_type                                                     --证件类型
    ,t5.document_id       as cert_code                                                     --证件代码
    ,t10.contact_tel      as mobile                                                        --联系电话
    ,'${DATA_DATE}'       as biz_date                                                      --业务日期
    ,nvl(concat('jts0',t7.sub_product_type),t6.prd_code)       as biz_prod_code            --业务产品号
    ,t12.prd_name         as prod_name                                                                       --产品名称
    ,'' as biz_type_code                                                                   --业务类型编号
    ,'' as biz_type_name                                                                   --业务类型名称
    ,from_unixtime(unix_timestamp(t4.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')       as loan_start_date           --贷款起始日期
    ,case when t4.prod_type='110140' then concat(substr(from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),1,8),10)
          else from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')
      end                                                                           as loan_end_date             --贷款结束日期
    ,from_unixtime(unix_timestamp(t4.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd')      as loan_clear_date           --贷款结清日
    ,case when t4.term is not null 
          then 'm'   
          when substr(t6.loan_term,-2) <> '00'
          then 'd'
          else  'm'
      end                                                                           as loan_term_type            --贷款期限类型
    ,nvl(t4.term,case when substr(t6.loan_term,-2) <> '00' then substr(t6.loan_term,-2)
                  when substr(t6.loan_term,-2)  = '00' and substr(t6.loan_term,1,2) = '00' then substr(t6.loan_term,3,2)
                  when substr(t6.loan_term,-4)  = '0000' then cast(substr(t6.loan_term,1,2)as int )*12 end) as total_loan_terms                                                                --贷款总期数
    ,nvl(t4.ccy,'') as ccy                                                                  --币种
    ,null as rmb_exch                                                                      --对人民币汇率
    ,t1.stage_no as term_no                                                                --期次
    ,case when t4.prod_type='110140' and t1.stage_no<>'1' then concat(substr(t1.term_start_date,1,8),10)
          else t1.term_start_date end as term_start_date                                                  --本期开始日期
    ,case when t4.prod_type='110140' then concat(substr(t1.term_end_date,1,8),10)
          else t1.term_end_date end as term_mature_date                                                  --本期到期日期
    ,case when t4.prod_type='110140' then concat(substr(t1.term_end_date,1,8),10)
          else t2.grace_period_date end  as term_grace_date                                               --本期宽限到期日
    ,case when t4.prod_type='110140' then '0'
          else t12.overdue_frace_period end as grace_days                         --宽限天数
    ,t2.receipt_date as repay_date                                                         --实际还款日
    ,t11.repay_cnt               as term_repay_cnt                                         --本期还款次数
    ,case when t2.daichang_flag = '1' then '05' 
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date = concat(substr(t1.term_end_date,1,8),10) then '01'
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date > concat(substr(t1.term_end_date,1,8),10) and t2.receipt_date <= t2.grace_period_date then '02'
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date > t2.grace_period_date then '03'
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date < concat(substr(t1.term_end_date,1,8),10) then '04'
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='N' and '${DATA_DATE}' < concat(substr(t1.term_end_date,1,8),10) then '06'
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='N' and '${DATA_DATE}' >= concat(substr(t1.term_end_date,1,8),10)  then '07'
      when t4.prod_type='110140' and t2.internal_key is null and t4.acct_close_date is not null and e.internal_key is not null then '05'
      when t4.prod_type='110140' and t2.internal_key is null and t4.acct_close_date is not null then '04'
      when t4.prod_type='110140' and t2.internal_key is null then '06'
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' < concat(substr(t1.term_end_date,1,8),10) then '06'
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' >= concat(substr(t1.term_end_date,1,8),10)  then '07'
      when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date = t1.term_end_date then '01'
      when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date > t1.term_end_date and t2.receipt_date <= t2.grace_period_date then '02'
      when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date > t2.grace_period_date then '03'
      when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='Y' and t2.receipt_date < t1.term_end_date then '04'
      when t2.internal_key is not null and t2.receipt_date is null and t2.fully_settled ='Y' then '01'
      when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled ='N' then '07'
      when t2.internal_key is null and t4.acct_close_date is not null and e.internal_key is not null then '05'
      when t2.internal_key is null and t4.acct_close_date is not null then '04'
      when t2.internal_key is null then '06'
      when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' < t1.term_end_date then '06'
      when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' >= t1.term_end_date  then '07'
      else '06' end                                           as term_repay_status             --还款状态
    ,t1.sched_amt_pri as matured_prin                                                        --本期应还本金
    ,nvl(t2.rec_amt_pri,0) as repaid_prin                                                    --本期已还本金
    --,null                                                                                  --累计应还本金
    --,pri_outstanding as                                                                    --累计未到期本金
    ,case when t4.prod_type='110140' and '${DATA_DATE}' >= concat(substr(t1.term_end_date,1,8),10) then t2.overdue_pri
	  when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' >= t1.term_end_date then t1.sched_amt_pri
      when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' < t1.term_end_date then 0
      when t2.internal_key is not null and t2.receipt_date is not null and t2.receipt_date > t1.term_end_date then t1.sched_amt_pri-nvl(t2.rec_amt_pri,0)
      when t2.internal_key is null then null --未关联上，期次还未开始，直接置空值
      else 0  end  as  overdue_prin                                                          --本期逾期本金
    ,t1.sched_amt_int as matured_int                                                       --本期应还利息
    ,t2.rec_amt_int           as  repaid_int                                               --本期已还利息
    ,case when t4.prod_type='110140' and '${DATA_DATE}' >= concat(substr(t1.term_end_date,1,8),10) then t2.overdue_int
	  when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' >= t1.term_end_date then t1.sched_amt_int
      when t2.internal_key is not null and t2.receipt_date is null and '${DATA_DATE}' < t1.term_end_date then 0
      when t2.internal_key is not null and t2.receipt_date is not null and t2.receipt_date > t1.term_end_date then t1.sched_amt_int-nvl(t2.rec_amt_int,0)
      when t2.internal_key is null then null --未关联上，期次还未开始，直接置空值
      else 0  end as overdue_int                                                           --本期逾期利息
    ,t1.sched_amt_fee as matured_fee                                                       --本期应还担保费
    ,t2.rec_amt_fee as repaid_fee                                                          --本期已还担保费
    ,nvl(t14.matured_pena,0)                         as matured_pena                                      --本期应还罚息
    ,nvl(t3.repaid_pena,0)                           as repaid_pena                                       --本期已还罚息
    ,case when t4.prod_type='110159' and t1.sched_amt_pri<>0  then 0 
	      else nvl(t14.dourate_amt , 0)          end as matured_compo                                     --本期应还复利
    ,case when t4.prod_type='110159' and t1.sched_amt_pri<>0  then 0         
	      else nvl(t3.repaid_compo , 0)          end as repaid_compo                                      --本期已还复利
    ,case when t2.fully_settled ='Y' then t2.receipt_date
      when t4.acct_close_date is not null then from_unixtime(unix_timestamp(t4.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd')
	  when t2.internal_key is not null and t2.receipt_date is null and t2.fully_settled ='Y' then t1.term_end_date
      else null end  as term_clear_date                                                    --本期还清日期
    ,case 
	  when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled = 'Y' and t2.receipt_date = concat(substr(t1.term_end_date,1,8),10) then 0
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled = 'Y' then if(datediff(t2.receipt_date,concat(substr(t1.term_end_date,1,8),10))<0,0,datediff(t2.receipt_date,concat(substr(t1.term_end_date,1,8),10)))
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled = 'N' then if(datediff('${DATA_DATE}',concat(substr(t1.term_end_date,1,8),10))<0,0,datediff('${DATA_DATE}',concat(substr(t1.term_end_date,1,8),10))+1)
      when t4.prod_type='110140' and t2.internal_key is not null and t2.receipt_date is null then if(datediff('${DATA_DATE}',concat(substr(t1.term_end_date,1,8),10))<0,0,datediff('${DATA_DATE}',concat(substr(t1.term_end_date,1,8),10))+1)
	  when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled = 'Y' and t2.receipt_date = t1.term_end_date then 0
      when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled = 'Y' then if(datediff(t2.receipt_date,t1.term_end_date)<0,0,datediff(t2.receipt_date,t1.term_end_date))
      when t2.internal_key is not null and t2.receipt_date is null and t2.fully_settled ='Y' then 0
      when t2.internal_key is not null and t2.receipt_date is not null and t2.fully_settled = 'N' then if(datediff('${DATA_DATE}',t1.term_end_date)<0,0,datediff('${DATA_DATE}',t1.term_end_date)+1)
      when t2.internal_key is not null and t2.receipt_date is null then if(datediff('${DATA_DATE}',t1.term_end_date)<0,0,datediff('${DATA_DATE}',t1.term_end_date)+1)
      when t2.internal_key is null then 0  --未关联上，期次还未开始，直接置空值
      end                                                      as overdue_days              --逾期天数
	 ,nvl(a4.orig_fee_amt,0)                                    as adv_repay_fee --提前还款手续费
	 ,case when t4.accounting_status='FYJ' then nvl(t2.non_accru_bal,0) else 0 end  as  non_accru_bal --非应计本金
	 ,case when t4.accounting_status='FYJ' then nvl(t2.aoff_bal_int,0)+nvl(t3.outstanding,0) else 0 end                        as aoff_bal_int  --表外利息
     ,nvl(t4.prod_type,'') as prod_code                                                     --产品号
from (
    select 
         a.internal_key
        ,a.stage_no              as stage_no                                                               --期次
        ,from_unixtime(unix_timestamp(min(a.start_date),'yyyyMMdd'),'yyyy-MM-dd')      as term_start_date  --期次开始日期
        ,from_unixtime(unix_timestamp(max(a.end_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_end_date    --期次到期日期
        ,sum(case when amt_type ='PRI' then a.sched_amt else 0 end) as sched_amt_pri                       --计划本金
        ,sum(case when amt_type ='INT' then a.sched_amt else 0 end) as sched_amt_int                       --计划利息
        ,sum(case when amt_type ='FEE' then a.sched_amt else 0 end) as sched_amt_fee                       --计划费用
        ,max(pri_outstanding) as pri_outstanding                                                           --剩余未到期本金
    from odata.sllv_mb_acct_schedule_detail a --账户计划明细表
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    group by 
         a.internal_key
        ,a.stage_no
        ,a.start_date
        ,a.end_date
    ) t1 
                 --取回收的明细信息
left join (
    select 
         a.internal_key
        ,a.stage_no  --期次
        ,min(a.fully_settled)    as fully_settled --是否收回标识(min 取N)
        ,from_unixtime(unix_timestamp(min(nvl(c.start_date,e.start_date)),'yyyyMMdd'),'yyyy-MM-dd')        as term_start_date    --期次开始期日
        ,from_unixtime(unix_timestamp(max(a.grace_period_date),'yyyyMMdd'),'yyyy-MM-dd') as grace_period_date  --期次宽限日
        ,sum(case when a.amt_type = 'PRI' then b.rec_amt else 0 end) as rec_amt_pri                            --回收本金
        ,sum(case when a.amt_type = 'INT' then b.rec_amt else 0 end) as rec_amt_int                            --回收利息
        ,sum(case when a.amt_type = 'FEE' then b.rec_amt else 0 end) as rec_amt_fee                            --回收费用(担保费）
		,sum(case when a.amt_type = 'PRI' then a.outstanding else 0 end) as non_accru_bal                          --非应计本金
		,sum(case when a.amt_type = 'INT'  then a.outstanding else 0 end) as aoff_bal_int                          --非应计本金
        ,max(substr(b.receipt_date,1,10)) as receipt_date                                                      --回收日期
        ,max(case when d.receipt_no is not null then '1' else 0  end) as daichang_flag
		,max(b.receipt_no)  as receipt_no
        ,sum(case when a.amt_type = 'PRI' then a.outstanding else 0 end) as overdue_pri                            --逾期本金
        ,sum(case when a.amt_type = 'INT' then a.outstanding else 0 end) as overdue_int                            --逾期利息
    from odata.sllv_mb_invoice a
    left join odata.sllv_mb_receipt_detail b
    on b.data_date = '${DATA_DATE}'
    and b.bddw_end_date = '9999-99-99'
    and a.invoice_tran_no = b.invoice_tran_no
    and a.internal_key = b.acct_internal_key
    and a.stage_no = b.stage_no
    and a.amt_type = b.amt_type
    left join odata.sllv_mb_acct_schedule_detail c
    on c.data_date = '${DATA_DATE}'
    and c.bddw_end_date = '9999-99-99'
    and a.internal_key = c.internal_key
    and a.stage_no = c.stage_no
    and a.amt_type = c.amt_type
    left join odata.sllv_mb_guarantee_receipt d --取代偿的期次
    on d.data_date = '${DATA_DATE}'
    and d.bddw_end_date = '9999-99-99'
    and b.receipt_no =  d.receipt_no
	left join odata.sllv_mb_acct_schedule_detail e
    on e.data_date = '${DATA_DATE}'
    and e.bddw_end_date = '9999-99-99'
    and a.internal_key = e.internal_key
    and a.stage_no = e.stage_no
	and e.amt_type='INT'
    where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and a.amt_type <> 'ODP'
    group by 
         a.internal_key
        ,a.stage_no
        ,nvl(c.start_date,e.start_date)
    ) t2
on t1.internal_key = t2.internal_key
and t1.stage_no = t2.stage_no
and t1.term_start_date = t2.term_start_date
left join (
    select 
         internal_key
        ,stage_no
        ,sum(case when amt_type = 'ODP' then billed_amt - outstanding else 0 end)  as repaid_pena  --可能会有多笔罚息，故按期次进行汇总
        ,sum(case when amt_type = 'ODI' then billed_amt - outstanding else 0 end)  as repaid_compo  --本期已还复利
		,sum(outstanding) as outstanding
    from odata.sllv_mb_invoice  --单据表取罚息(罚息在单据表生成，罚息的最后还款日与正常期次的还款日不一致，故在此处单独提取。还款计划明细表中没有罚息记录)
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    and amt_type in ('ODP','ODI')
    group by 
         internal_key
        ,stage_no
    ) t3
on t1.internal_key = t3.internal_key
and t1.stage_no = t3.stage_no
inner join odata.sllv_mb_acct t4  --账户基本信息表
on t4.data_date = '${DATA_DATE}'
and t4.bddw_end_date = '9999-99-99'
and t4.prod_type not like '120%'
and from_unixtime(unix_timestamp(t4.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')<='${DATA_DATE}'
and t1.internal_key = t4.internal_key
--获取客户身份证信息
left join odata.sym_cif_client_document t5
on t5.data_date = '${DATA_DATE}'
and t5.bddw_end_date = '9999-99-99'
and t4.client_no = t5.client_no
and t5.pref_flag='Y' 
--取网贷产品的授信合同号(度小满、债转、京东、小米除外)
left join odata.ols_loan_cont_info t6    
on t6.data_date = '${DATA_DATE}'
and t6.bddw_end_date = '9999-99-99'
--and t6.prd_code <>'10021001001'
and t4.cmisloan_no = t6.bill_no
and t6.cont_status<>'104' --已作废
--车商贷,医美，得物，锡锡贷有单独的授信订单，取授信合同号
left join(
    select 
         nvl(a.credit_order_id,a.loan_id) as credit_order_id
        ,a.sub_product_type
        ,a.loan_id 
    from odata.order_main_loan_order a
    where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and a.status in ('7','8','9','10','11')
    and a.order_type = '2'
    ) t7
on t4.cmisloan_no = t7.loan_id
left join(
    select 
         a.acct_internal_key as internal_key
        ,a.stage_no
        ,sum(case when a.amt_type = 'PRI' then a.rec_amt else 0 end) as rec_amt_pri
        ,sum(case when a.amt_type = 'INT' then a.rec_amt else 0 end) as rec_amt_int
        ,sum(case when a.amt_type = 'FEE' then a.rec_amt else 0 end) as rec_amt_fee
    from odata.sllv_mb_receipt_detail a
    left join odata.sllv_mb_acct_schedule_detail b
    on a.acct_internal_key =  b.internal_key
    and a.stage_no =  b.stage_no
    and a.amt_type = b.amt_type
    and b.data_date = '${DATA_DATE}'
    and b.bddw_end_date = '9999-99-99'
    where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and regexp_replace(substr(a.receipt_date,1,10),'-','')<= b.end_date
    group by 
         a.acct_internal_key
        ,a.stage_no
    ) t8
on t2.receipt_no = t8.internal_key
and t1.stage_no = t8.stage_no
--获取客户姓名
left join odata.sym_cif_client t9
on t4.client_no=t9.client_no
and t9.data_date='${DATA_DATE}'
and t9.bddw_end_date='9999-99-99'
--获取联系电话
left join odata.sym_cif_client_contact_tbl t10
on t4.client_no = t10.client_no 
and t10.pref_flag='Y'
and t10.data_date='${DATA_DATE}'
and t10.bddw_end_date='9999-99-99'
--获取每期还款次数
left join (
     select acct_internal_key
              ,stage_no
              ,count(*) as repay_cnt
              from (
          select 
               acct_internal_key
              ,stage_no
              ,substr(receipt_date,1,10)
          from odata.sllv_mb_receipt_detail  --单笔还款分本金和利息多条数据，暂时按还款日期汇总
          where data_date = '${DATA_DATE}'
          and bddw_end_date = '9999-99-99'
          group by 
               acct_internal_key
              ,stage_no
              ,substr(receipt_date,1,10)) a
              group by 
               acct_internal_key
              ,stage_no) t11
on  t1.internal_key = t11.acct_internal_key
and t1.stage_no = t11.stage_no
left join odata.ols_loan_prd_info  t12
on t6.prd_code=t12.loan_no
and t12.data_date = '${DATA_DATE}'
and t12.bddw_end_date = '9999-99-99'
--剔除发放冲正的借据
left join odata.sllv_mb_drawdown t13
on t1.internal_key = t13.internal_key
and t13.data_date = '${DATA_DATE}'
and t13.bddw_end_date = '9999-99-99'
and t13.reversal = 'Y'  
left join(select  receipt_no
                 ,orig_fee_amt as orig_fee_amt
            from odata.sllv_mb_serv_charge a2 
           where a2.data_date='${DATA_DATE}' 
             and a2.bddw_end_date='9999-99-99'
			 and a2.fee_type = 'D005') a4
  on t2.receipt_no =a4.receipt_no
left join odata.sllv_mb_guarantee_receipt e --取代偿的期次
on e.data_date = '${DATA_DATE}'
and e.bddw_end_date = '9999-99-99'
and e.guarec_type='B'
and t1.internal_key =  e.internal_key
left join (select internal_key
                   ,stage_no
				   ,sum(case when int_class='ODP' then (int_posted+int_adj+int_accrued) else null end) as matured_pena--应还罚息
				   ,sum(case when int_class='ODI' then (int_posted+int_adj+int_accrued) else null end) as dourate_amt--应还复利
           from odata.sllv_mb_od_int_detail    --线上贷款罚息复利明细表
			     where data_date = '${DATA_DATE}'
                   and bddw_end_date = '9999-99-99'
		      group by internal_key,stage_no) t14
on t1.internal_key =  t14.internal_key
and t1.stage_no = t14.stage_no 
where 
    t13.internal_key is null --剔除发放冲正的借据

union all 

--长安新生
select 
	 t3.cmisloan_no as bill_no                                                     --借据号
    ,'' as acct_no                                                                     --账号
    ,''                                                                                --合同号
    ,nvl(t16.crd_cont_no,t3.cmisloan_no) as crd_cont_no                                                                 --授信合同号
    ,t4.client_no as cust_id                                                                     --客户号
    ,t9.client_short      as cust_name                                                     --客户姓名
    ,t4.document_type     as cert_type                                                     --证件类型
    ,t4.document_id       as cert_code                                                     --证件代码
    ,t10.contact_tel      as mobile                                                        --联系电话
    ,'${DATA_DATE}'       as biz_date                                                      --业务日期
    ,nvl(t16.prd_code,'jts07')                                              as biz_prod_code            --业务产品号
    ,'' as prod_name                                                                   --产品名称
    ,'' as biz_type_code                                                               --业务类型编号
    ,'' as biz_type_name                                                               --业务类型名称
    ,substr(t3.acct_open_date,1,10)         as loan_start_date           --贷款起始日期
    ,substr(t3.maturity_date,1,10)          as loan_end_date             --贷款结束日期
    ,substr(t3.acct_close_date,1,10)        as loan_clear_date           --贷款结清日
    ,'m'                                    as loan_term_type            --贷款期限类型
    ,t3.term as total_loan_terms                                         --贷款总期数
    ,'' as ccy                                                                         --币种
    ,null as rmb_exch                                                                  --对人民币汇率
    ,t1.stage_no as term_no                                                            --期次
    ,t1.term_start_date as term_start_date                                                  --本期开始日期
    ,t1.term_end_date as term_mature_date                                                  --本期到期日期
    ,t1.grace_period_date as term_grace_date                              --本期宽限到期日
    ,datediff(t1.grace_period_date,t1.term_end_date)  as grace_days
    ,t1.receipt_date as repay_date                                                     --实际还款日
    ,''               as term_repay_cnt                                         --本期还款次数
    ,case when t1.are_int_flag is not null and t1.receipt_date is not null and t1.are_int_flag = 'Y' and t1.receipt_date = t1.term_end_date then '01'
      when t1.are_int_flag is not null and t1.receipt_date is not null and t1.are_int_flag = 'Y' and t1.receipt_date > t1.term_end_date and t1.receipt_date <= t1.grace_period_date then '02'
      when t1.are_int_flag is not null and t1.receipt_date is not null and t1.are_int_flag = 'Y' and t1.receipt_date > t1.grace_period_date then '03'
      when t1.are_int_flag is not null and t1.receipt_date is not null and t1.are_int_flag = 'Y' and t1.receipt_date < t1.term_end_date then '04'
      when t1.are_int_flag is not null and t1.receipt_date is not null and t1.are_int_flag = 'N' then '07'
      when 1 = 2 then '05'
      when t1.are_int_flag is null and t3.acct_close_date is not null then '04'
      when t1.are_int_flag is null then '06'
      when t1.are_int_flag is not null and t1.receipt_date is null then '07'
      else '06' end as term_repay_status                                                                      --还款状态
    ,t1.sched_amt_pri as matured_prin                                                                 --本期应还本金
    ,nvl(t5.rec_amt_pri,0) as repaid_prin                                                             --本期已还本金
    --,null as                                                                                    --累计应还本金
    --,null as                                                                                    --累计未到期本金
    ,case when t1.are_int_flag is not null and t1.receipt_date is null then t1.sched_amt_pri
      when t1.are_int_flag is not null and t1.receipt_date > t1.term_end_date then t1.sched_amt_pri-t5.rec_amt_pri
      when t1.are_int_flag is null then null --未关联上，期次还未开始，直接置空值
      else 0  end as overdue_prin                                                             --本期逾期本金   
    ,t1.sched_amt_int as matured_int                                                                   --本期应还利息
    ,t5.rec_amt_int as repaied_int                                                              --本期已还利息
    ,case when t1.are_int_flag is not null and t1.receipt_date is null then t1.sched_amt_int
      when t1.are_int_flag is not null and t1.receipt_date > t1.term_end_date then t1.sched_amt_int-t5.rec_amt_int
      when t1.are_int_flag is null then null --未关联上，期次还未开始，直接置空值
      else 0  end  as overdue_int                                                               --本期逾期利息    
    ,t1.sched_amt_fee  as matured_fee                                                              --本期应还担保费  
    ,t5.rec_amt_fee as repaied_fee                                                              --本期已还担保费  
    ,nvl(t14.int_accrued+t14.int_adj+t14.int_posted,0) as matured_pena                           --本期应还罚息
    ,t2.billed_amt-t2.outstanding  as repaied_pena                                              --本期已还罚息
    ,0   as matured_compo                                             --本期应还复利
    ,0   as repaid_compo                                              --本期已还复利
    ,case when t1.are_int_flag = 'Y' then t1.receipt_date
      when t3.acct_close_date is not null then substr(t3.acct_close_date,1,10)
      else null end as clear_date                                                                  --结清日期
    ,if(t1.are_int_flag is null,0,nvl(t1.actual_yq_days,0)) as overdue_days                                                              --逾期天数
    ,nvl(a4.partner_fee_amt,0)                   as adv_repay_fee     --提前还款手续费
	 ,case when t3.accounting_status='FYJ' then nvl(t1.non_accru_bal,0) else 0 end  as  non_accru_bal --非应计本金
	 ,case when t3.accounting_status='FYJ' then nvl(t1.aoff_bal_int,0)+nvl(t2.outstanding,0) else 0 end                        as aoff_bal_int  --表外利息
    ,t3.prod_type as prod_code                                                                   --产品号
from(select internal_key,
            cast(stage_no as int)                  as stage_no,
            min(case when is_invoice = 'Y' then nvl(fully_settled,'N') else null end) as are_int_flag,
            substr(min(start_date),1,10)           as term_start_date,
            substr(max(end_date),1,10)             as term_end_date,
            substr(max(grace_period_date),1,10)    as grace_period_date,
            substr(max(paid_date),1,10)            as receipt_date,
            max(actual_yq_days)       as actual_yq_days,
            sum(case when amt_type = 'PRI' then nvl(sched_amt,0)-nvl(partner_amt,0) else 0 end) as sched_amt_pri,
            sum(case when amt_type = 'INT' then nvl(sched_amt,0)-nvl(partner_amt,0) else 0 end) as sched_amt_int,
            sum(case when amt_type = 'FEE' then nvl(sched_amt,0)-nvl(partner_amt,0) else 0 end) as sched_amt_fee,
            sum(case when amt_type = 'PRI' then nvl(outstanding,0)-nvl(partner_outstanding,0) else 0 end) as non_accru_bal,
            sum(case when amt_type = 'INT' then nvl(outstanding,0)-nvl(partner_outstanding,0) else 0 end) as aoff_bal_int
     from odata.sllv_nl_acct_schedule_detail
    where data_date = '${DATA_DATE}'
      and bddw_end_date = '9999-99-99'
      and amt_type <> 'ODP'
 group by internal_key,stage_no)t1
left join(select internal_key,
                 stage_no,
                 sum(nvl(billed_amt,0)-nvl(partner_amt,0))  as billed_amt,
                 sum(nvl(outstanding,0)-nvl(partner_outstanding,0)) as outstanding
            from odata.sllv_nl_acct_schedule_detail
            where data_date = '${DATA_DATE}'
            and bddw_end_date = '9999-99-99'
            and amt_type = 'ODP'
            group by internal_key,
                     stage_no)t2
       on t1.internal_key = t2.internal_key
      and t1.stage_no = t2.stage_no
left join odata.sllv_nl_acct t3
       on t3.data_date = '${DATA_DATE}'
      and t3.bddw_end_date = '9999-99-99'
      and t1.internal_key = t3.internal_key
left join odata.sym_cif_client_document t4
       on t4.data_date = '${DATA_DATE}'
      and t4.bddw_end_date = '9999-99-99'
      and t3.client_no = t4.client_no
      and t4.pref_flag='Y' 
left join(select internal_key,
                 stage_no,
                 sum(case when amt_type = 'INT' then nvl(rec_amt,0)-nvl(partner_rec_amt,0) else 0 end) as rec_amt_int,
                 sum(case when amt_type = 'PRI' then nvl(rec_amt,0)-nvl(partner_rec_amt,0) else 0 end) as rec_amt_pri,
                 sum(case when amt_type = 'FEE' then nvl(rec_amt,0)-nvl(partner_rec_amt,0) else 0 end) as rec_amt_fee,
                 substr(max(due_date),1,10) as receipt_date,
				 max(a.receipt_no)  as receipt_no
            from odata.sllv_nl_receipt_detail a
           where a.data_date = '${DATA_DATE}'
             and a.bddw_end_date = '9999-99-99'
           group by internal_key,stage_no)t5
       on t1.internal_key = t5.internal_key
      and t1.stage_no = t5.stage_no
left join odata.ols_loan_cont_info t16    
on t16.data_date = '${DATA_DATE}'
and t16.bddw_end_date = '9999-99-99'
and t3.cmisloan_no=t16.bill_no
--获取客户姓名
left join odata.sym_cif_client t9
on t3.client_no=t9.client_no
and t9.data_date='${DATA_DATE}'
and t9.bddw_end_date='9999-99-99'
--获取联系电话
left join odata.sym_cif_client_contact_tbl t10
on t3.client_no = t10.client_no 
and t10.pref_flag='Y'
and t10.data_date='${DATA_DATE}'
and t10.bddw_end_date='9999-99-99'
--获取每期还款次数
left join (
     select internal_key
              ,stage_no
              ,count(*) as repay_cnt
              from (
          select 
               internal_key
              ,stage_no
              ,substr(due_date,1,10)
          from odata.sllv_nl_receipt_detail  --单笔还款分本金和利息多条数据，暂时按还款日期汇总
          where data_date = '${DATA_DATE}'
          and bddw_end_date = '9999-99-99'
          group by 
               internal_key
              ,stage_no
              ,substr(due_date,1,10)) a
              group by 
               internal_key
              ,stage_no) t11
on  t1.internal_key = t11.internal_key
and t1.stage_no = t11.stage_no
left join  odata.sllv_nl_drawdown t6
    on t6.data_date = '${DATA_DATE}'
      and t6.bddw_end_date = '9999-99-99'
      and t6.reversal = 'Y'
      and t1.internal_key = t6.internal_key
left join(select  receipt_no
                 ,nvl(partner_fee_amt,0) as partner_fee_amt
            from odata.sllv_nl_serv_charge a2 
           where a2.data_date='${DATA_DATE}' 
             and a2.bddw_end_date='9999-99-99'
			 and a2.fee_type = 'D005'
)a4
on t5.receipt_no =a4.receipt_no
left join odata.sllv_nl_od_int_detail t14
on t14.data_date = '${DATA_DATE}'
and t14.bddw_end_date = '9999-99-99'
and t14.int_class='ODP'
and t1.internal_key =  t14.internal_key
and t1.stage_no = t14.stage_no
where t6.internal_key is null

union all
select  
	 e.cmisloan_no as bill_no                  --借据号
    ,'' as acct_no                             --账号
    ,''                                        --合同号
    ,nvl(t16.crd_cont_no,e.cmisloan_no) as crd_cont_no              --授信合同号
    ,e.client_no as cust_id                    --客户号
    ,t9.client_short      as cust_name         --客户姓名
    ,t4.document_type     as cert_type                                                     --证件类型
    ,t4.document_id       as cert_code                                                     --证件代码
    ,t10.contact_tel      as mobile                                                        --联系电话
    ,'${DATA_DATE}'       as biz_date                                                      --业务日期
    ,nvl(t16.prd_code,'jts07')                                              as biz_prod_code            --业务产品号
    ,'' as prod_name                                                                   --产品名称
    ,'' as biz_type_code                                                               --业务类型编号
    ,'' as biz_type_name                                                               --业务类型名称
    ,substr(e.acct_open_date,1,10)         as loan_start_date           --贷款起始日期
    ,substr(e.maturity_date,1,10)          as loan_end_date             --贷款结束日期
    ,substr(e.acct_close_date,1,10)        as loan_clear_date           --贷款结清日
    ,'m'                                    as loan_term_type            --贷款期限类型
    ,e.term as total_loan_terms                                         --贷款总期数
    ,'' as ccy                                                                         --币种
    ,null as rmb_exch                                                                  --对人民币汇率
    ,a.stage_no as term_no                     --期次
    ,nvl(a.term_start_date,b.term_start_date) --本期开始日期
    ,nvl(a.term_end_date,b.term_end_date)  as term_mature_date      --本期到期日期
    ,'' as term_grace_date                              --本期宽限到期日
    ,'' as grace_days                        --宽限天数
    ,c.receipt_date as repay_date             --实际还款日
    ,''               as term_repay_cnt                                         --本期还款次数
    ,'04' as term_repay_status --还款状态
    ,a.sched_amt_pri as  matured_prin         --本期应还本金     
    ,a.sched_amt_pri as repaid_prin             --本期已还本金
    ,null          as overdue_prin            --本期逾期本金
    ,a.sched_amt_int as  matured_int          --本期应还利息
    ,a.sched_amt_int  as  repaied_int         --本期已还利息
    ,null   as overdue_int                    --本期逾期利息
    ,a.sched_amt_fee  as  matured_fee         --本期应还担保费
    ,a.sched_amt_fee   as repaied_fee           --本期已还担保费 
    ,null as matured_pena                     --本期应还罚息
    ,null as repaied_pena                     --本期已还罚息
    ,0      as matured_compo                                       --本期应还复利
    ,0      as repaid_compo                                        --本期已还复利
    ,c.receipt_date                 as clear_date                                               --结清日期  
    ,0                              as overdue_days                                             --逾期天数
    ,nvl(a4.partner_fee_amt,0)      as adv_repay_fee                                            --提前还款手续费
	,0  as  non_accru_bal --非应计本金
	,0  as aoff_bal_int  --表外利息
    ,e.prod_type                    as prod_code                                                --产品类别
     from  (select internal_key
                   ,cast(stage_no as int)                  as stage_no
                   ,substr(max(due_date),1,10)            as receipt_date
                   ,sum(case when amt_type = 'PRI' then nvl(billed_amt,0)-nvl(partner_amt,0) else 0 end) as sched_amt_pri
                   ,sum(case when amt_type = 'INT' then nvl(billed_amt,0)-nvl(partner_amt,0) else 0 end) as sched_amt_int
                   ,sum(case when amt_type = 'FEE' then nvl(billed_amt,0)-nvl(partner_amt,0) else 0 end) as sched_amt_fee
                   ,from_unixtime(unix_timestamp(min(start_date),'yyyyMMdd'),'yyyy-MM-dd') as term_start_date
                   ,from_unixtime(unix_timestamp(min(end_date),'yyyyMMdd'),'yyyy-MM-dd') as term_end_date
     from odata.sllv_nl_noschedule_invoice
    where data_date = '${DATA_DATE}'
      and bddw_end_date = '9999-99-99'
 group by internal_key,stage_no)  a   --涉及提前还款的借据
 left join (select receipt_no
                 ,internal_key 
                 ,stage_no
                 ,substr(max(due_date),1,10) as receipt_date
     from odata.sllv_nl_receipt_detail
    where data_date = '${DATA_DATE}'
      and bddw_end_date = '9999-99-99'
      and sched_flag='N'
      group by receipt_no,internal_key,stage_no )c
      on a.internal_key=c.internal_key
      and a.stage_no=c.stage_no    --获取还款编号
 inner join (select internal_key,receipt_no  
     from odata.sllv_nl_receipt  
    where data_date = '${DATA_DATE}'
      and bddw_end_date = '9999-99-99'
      and receipt_type in ('PO','ER')
 group by  internal_key,receipt_no)d
on c.internal_key=d.internal_key
and c.receipt_no=d.receipt_no    --取整笔提前结清的借据
 left join odata.sllv_nl_acct e
       on e.data_date = '${DATA_DATE}'
      and e.bddw_end_date = '9999-99-99'
      and a.internal_key = e.internal_key
left join odata.ols_loan_cont_info t16    
on t16.data_date = '${DATA_DATE}'
and t16.bddw_end_date = '9999-99-99'
and e.cmisloan_no=t16.bill_no
left join odata.sym_cif_client t9
on e.client_no=t9.client_no
and t9.data_date='${DATA_DATE}'
and t9.bddw_end_date='9999-99-99'
left join odata.sym_cif_client_document t4
       on t4.data_date = '${DATA_DATE}'
      and t4.bddw_end_date = '9999-99-99'
      and e.client_no = t4.client_no
      and t4.pref_flag='Y' 
left join odata.sym_cif_client_contact_tbl t10
on e.client_no = t10.client_no 
and t10.pref_flag='Y'
and t10.data_date='${DATA_DATE}'
and t10.bddw_end_date='9999-99-99'
 left join (select internal_key,stage_no
                  ,max(substr(start_date,1,10)) as term_start_date
                  ,max(substr(end_date,1,10)) as term_end_date
                  ,substr(max(grace_period_date),1,10)    as grace_period_date
              from odata.sllv_nl_acct_schedule_detail_amend
             where data_date = '${DATA_DATE}'
               and bddw_end_date = '9999-99-99'
          group by internal_key,stage_no) b  --取原始开始结束日期
 on a.internal_key=b.internal_key
and a.stage_no=b.stage_no
left join  odata.sllv_nl_drawdown f
    on f.data_date = '${DATA_DATE}'
      and f.bddw_end_date = '9999-99-99'
      and f.reversal = 'Y'
      and a.internal_key = f.internal_key
left join(select  receipt_no
                 ,nvl(partner_fee_amt,0) as partner_fee_amt
            from odata.sllv_nl_serv_charge a2 
           where a2.data_date='${DATA_DATE}' 
             and a2.bddw_end_date='9999-99-99'
			 and a2.fee_type = 'D005'
)a4
on c.receipt_no =a4.receipt_no
where f.internal_key is null  --剔除冲正借据