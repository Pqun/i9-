---------------------------------------------------------------------------------------------------------------
--脚本名称：dws_loan_indv_loan_repay_sum_p.sql京东金条取数
--功能描述：生成每日结果数据并插入hive dws层dws.dws_loan_indv_loan_repay_sum_p
--作    者：方杰
--开发日期：2021-04-13
--直属经理：方杰
--来源表  ：odata.sllv_mb_acct_schedule_detail  --账户计划明细表
--来源表  ：odata.sllv_mb_invoice   --单据表 取回收明细
--来源表  ：odata.sllv_mb_guarantee_receipt
--来源表  ：odata.sllv_mb_acct
--来源表  ：odata.sym_cif_client_document
--来源表  ：odata.ols_loan_cont_info
--来源表  ：odata.order_main_loan_order
--目标表  ：dws.dws_loan_indv_loan_repay_sum_p
--修改历史：
--          1.方杰   2021-04-13    新建
--          2.华天顺 2022-06-14    新增非应计本金和表外利息字段
--          3.华天顺 2022-10-10    变更表名
---------------------------------------------------------------------------------------------------------------
insert overwrite table dws.dws_loan_indv_loan_repay_sum_p partition (data_date='${DATA_DATE}',prod_code='110104')
select 
     t1.loan_no as bill_no                                                             --借据号
    ,'' as acct_no                                                                     --账号
    ,''                                                                                --合同号
    ,t5.crd_cont_no as crd_cont_no                                                                 --授信合同号
    ,t5.cust_id_core as cust_id                                                                     --客户号
    ,t5.cust_name   as cust_name                                                                    --客户姓名
    ,t6.document_type     as cert_type                                                     --证件类型
    ,t6.document_id       as cert_code                                                     --证件代码
    ,t7.contact_tel       as mobile                                                        --联系电话
    ,from_unixtime(unix_timestamp(t1.busi_date,'yyyyMMdd'),'yyyy-MM-dd')         as biz_date                                                      --业务日期
    ,t5.prd_code          as biz_prod_code                                                --业务产品代码
    ,'京东金条' as prod_name                                                           --产品名称
    ,'' as biz_type_code                                                               --业务类型编号
    ,'' as biz_type_name                                                               --业务类型名称
    ,from_unixtime(unix_timestamp(t3.open_date,'yyyyMMdd'),'yyyy-MM-dd')       as loan_start_date           --贷款起始日期
    ,from_unixtime(unix_timestamp(t3.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')   as loan_end_date             --贷款结束日期
    ,case when t3.accouting_status='3' 
          then t5.loan_clear_date  
          else null
      end                                                 as loan_clear_date           --贷款结清日
    ,'m'                                    as loan_term_type                          --贷款期限类型
    ,t1.stage as total_loan_terms                                                      --贷款总期数
    ,'' as ccy                                                                         --币种
    ,null as rmb_exch                                                                  --对人民币汇率
    ,t1.stage_no as term_no                                                            --期次
    ,null as term_start_date                                                           --本期开始日期  京东只有到期时间，开始时间暂定为到期日期的上月
    ,from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd') as term_mature_date                                               --本期到期日期
    ,date_add(from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.yuq_grace_day as int)) as term_grace_date                              --本期宽限到期日
    ,t3.yuq_grace_day as grace_days                                                    --本期宽限日
    ,t2.receipt_date as repay_date                                                     --实际还款日
    ,t2.repay_cnt                 as term_repay_cnt                                         --本期还款次数
    ,case when t8.loan_no is not null then '05'   --代偿
	      when (t1.pri_amt+nvl(t2.repay_prin,0)-nvl(t2.repay_prin,0)=0 and nvl(t2.repay_int,0)+t1.int_amt-nvl(t2.repay_int,0)=0 and nvl(t2.repay_pena,0)+t1.odp_amt-nvl(t2.repay_pena,0)=0)  and from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd') = t2.receipt_date 
          then '01' --还款日当天还清
          when (t1.pri_amt+nvl(t2.repay_prin,0)-nvl(t2.repay_prin,0)=0 and nvl(t2.repay_int,0)+t1.int_amt-nvl(t2.repay_int,0)=0 and nvl(t2.repay_pena,0)+t1.odp_amt-nvl(t2.repay_pena,0)=0)  and from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd') > t2.receipt_date
          then '04' --还款日前还清
          when (t1.pri_amt+nvl(t2.repay_prin,0)-nvl(t2.repay_prin,0)=0 and nvl(t2.repay_int,0)+t1.int_amt-nvl(t2.repay_int,0)=0 and nvl(t2.repay_pena,0)+t1.odp_amt-nvl(t2.repay_pena,0)=0)  and t2.receipt_date>date_add(from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.yuq_grace_day as int ))
          then '03' -- --超过宽限日还清
          when (t1.pri_amt+nvl(t2.repay_prin,0)-nvl(t2.repay_prin,0)=0 and nvl(t2.repay_int,0)+t1.int_amt-nvl(t2.repay_int,0)=0 and nvl(t2.repay_pena,0)+t1.odp_amt-nvl(t2.repay_pena,0)=0) and from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd') < t2.receipt_date and t2.receipt_date<=date_add(from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.yuq_grace_day as int ))
          then '02' --超过还款日，但在宽限期内还清本期
          when (t4.stage+t1.stage_no<>t1.stage  or t4.stage is null) and from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd')>from_unixtime(unix_timestamp(t1.busi_date,'yyyymmdd'),'yyyy-mm-dd')
          then '06' --未还清，未逾期
          when (t4.stage+t1.stage_no<>t1.stage  or t4.stage is null) and from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd')<=from_unixtime(unix_timestamp(t1.busi_date,'yyyymmdd'),'yyyy-mm-dd')
          then '07'  --未还清 已逾期
      end   as term_repay_status                                                           --还款状态
    ,t1.pri_amt+nvl(t2.repay_prin,0)        as matured_prin                                                              --本期应还本金
    ,nvl(t2.repay_prin,0) as repaid_prin                                                                 --本期已还本金
    --,null as                                                                                    --累计应还本金
    --,null as                                                                                    --累计未到期本金
    ,case when t1.cur_accounting_status='1'
          then t1.pri_amt
          else 0
      end                                                                                        --本期逾期本金
    ,nvl(t2.repay_int,0)+t1.int_amt             as matured_int                                                                --本期应还利息
    ,nvl(t2.repay_int,0) as repaied_int                                                                  --本期已还利息
    ,case when t1.cur_accounting_status='1'
          then t1.int_amt
          else 0
      end                --本期逾期利息
    ,0 as matured_fee                                                                             --本期应还担保费  京东金条无担保费
    ,0 as repaied_fee                                                                             --本期已还担保费  京东金条无担保费
    ,nvl(t2.repay_pena,0)+t1.odp_amt          as matured_pena                                                              --本期应还罚息
    ,nvl(t2.repay_pena,0) as repaied_pena                                                                --本期已还罚息
    ,0 as matured_compo                                                                           --本期应还复利
    ,0 as repaied_compo                                                                           --本期已还复利
    ,case when (t4.matured_prin-t2.repay_prin=0 and t4.matured_int-t2.repay_int=0 and t4.matured_pena-t2.repay_pena=0)
          then t2.receipt_date
          else null 
      end  as clear_date                                                                          --结清日期
    ,case when (t4.matured_prin-t2.repay_prin=0 and t4.matured_int-t2.repay_int=0 and t4.matured_pena-t2.repay_pena=0) and t2.receipt_date>from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd')
          then datediff(t2.receipt_date,from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd'))
          when (t4.matured_prin-t2.repay_prin<>0 or t4.matured_int-t2.repay_int<>0 or t4.matured_pena-t2.repay_pena<>0 or t4.stage is null) and t1.pri_end_date<t1.busi_date
          then datediff(from_unixtime(unix_timestamp(t1.busi_date,'yyyymmdd'),'yyyy-mm-dd'),from_unixtime(unix_timestamp(t1.pri_end_date,'yyyymmdd'),'yyyy-mm-dd'))
          else 0
      end              as overdue_days                                                            --逾期天数
    ,nvl(t2.rec_bocd,0)        as adv_repay_fee  --提前还款手续费
	,case when t3.yuq_flag='1' and t3.yuq_days>=89  then t1.pri_amt else 0 end as non_accru_bal --非应计本金
	,case when t3.yuq_flag='1' and t3.yuq_days>=89  then t1.int_amt else 0 end as aoff_bal_int  --表外利息
from odata.slur_jd_loan_schedule_hist_clear t1 
left join
    (
    select 
         loan_no
        ,stage_no
        ,sum(rec_pri_amt) as repay_prin
        ,sum(rec_int_amt) as repay_int
        ,sum(rec_odp_amt) as repay_pena
		,sum(rec_bocd)    as rec_bocd
        ,max(receipt_date) as receipt_date
        ,count(1) as repay_cnt
    from odata.slur_jd_loan_receipt_hist 
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    group by 
         loan_no
        ,stage_no
    ) t2
on t1.loan_no = t2.loan_no
and t1.stage_no = t2.stage_no
left join (
    select * from 
     (
    select 
         loan_no
        ,stage_no
        ,receipt_pri_amt as matured_prin
        ,receipt_int_amt as matured_int
        ,receipt_odp_amt as matured_pena
        ,stage    --未还期数
        ,row_number() over(partition by loan_no,stage_no order by busi_date desc) as rn
    from odata.slur_jd_loan_receipt_hist 
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    ) a 
    where a.rn=1  )t4
on t1.loan_no = t4.loan_no
and t1.stage_no = t4.stage_no
left join odata.slur_jd_loan_data_hist_clear t3 
on t1.loan_no = t3.loan_no
and t3.data_date = '${DATA_DATE}'
and t3.bddw_end_date = '9999-99-99'
inner join  odata.ols_loan_cont_info t5 
on t5.data_date = '${DATA_DATE}'
and t5.bddw_end_date = '9999-99-99'
and t5.cont_status in ('105','106','107','108','109','110')
and t1.loan_no=t5.bill_no
and t5.prd_code='10011001003'
left join odata.sym_cif_client_document t6
on t6.data_date = '${DATA_DATE}'
and t6.bddw_end_date = '9999-99-99'
and t5.cust_id_core = t6.client_no
and t6.pref_flag='Y' 
left join odata.sym_cif_client_contact_tbl t7
on t5.cust_id_core = t7.client_no 
and t7.pref_flag='Y'
and t7.data_date='${DATA_DATE}'
and t7.bddw_end_date='9999-99-99'
left join odata.slur_dzz_compensatory_detail t8
        on t1.loan_no = t8.loan_no
       and t1.stage_no = t8.term_no
       and t8.data_date='${DATA_DATE}'
       and t8.bddw_end_date='9999-99-99'
       and t8.comps_status='S'
       and t8.sl_id = 'JD'
       and t8.prod_class='02'
where t1.data_date = '${DATA_DATE}'
and t1.bddw_end_date = '9999-99-99'
