---------------------------------------------------------------------------------------------------------------
--脚本名称：dws_loan_indv_loan_repay_sum_p.sql锡望贷取数
--功能描述：生成每日结果数据并插入hive dws层dws.dws_loan_indv_loan_repay_sum_p
--作    者：方杰
--开发日期：2021-04-13
--直属经理：方杰
--来源表  ：odata.sllv_mb_acct_schedule_detail  --账户计划明细表
--来源表  ：odata.sllv_mb_invoice   --单据表 取回收明细
--来源表  ：odata.sllv_mb_guarantee_receipt
--来源表  ：odata.sllv_mb_acct
--来源表  ：odata.sym_cif_client_document
--来源表  ：odata.ols_loan_cont_info
--来源表  ：odata.order_main_loan_order
--目标表  ：dws.dws_loan_indv_loan_repay_sum_p
--修改历史：
--          1.王胜杰   2021-12-10    新建
--          2.华天顺 2022-06-14    新增非应计本金和表外利息字段
--          3.华天顺 2022-10-10    变更表名
---------------------------------------------------------------------------------------------------------------
insert overwrite table dws.dws_loan_indv_loan_repay_sum_p partition (data_date='${DATA_DATE}',prod_code)
select 
      t1.loan_id                         as bill_no           --借据号
     ,''                           as acct_no           --账号
     ,t2.contract_no                           as cont_no           --合同号
     ,t2.credit_apply_no          as crd_cont_no       --授信合同号
     ,t4.client_no                         as cust_id           --客户号
     ,t3.user_name                         as cust_name         --客户姓名
     ,t4.document_type                         as cert_type         --证件类型
     ,t4.document_id                         as cert_code         --证件代码
     ,t5.contact_tel                         as mobile            --联系电话
     ,date_add('${DATA_DATE}',-1)                 as biz_date          --业务日期
     ,'jts013'                         as biz_prod_code     --业务产品代码
     ,'大额锡望贷经营贷款'                         as prod_name         --产品名称
     ,''                         as biz_type_code     --业务类型编号
     ,''                         as biz_type_name     --业务类型名称
     ,from_unixtime(unix_timestamp(t6.dd_start_date,'yyyyMMdd'),'yyyy-MM-dd')                          as loan_start_date   --贷款起始日期
     ,from_unixtime(unix_timestamp(t6.dd_end_date,'yyyyMMdd'),'yyyy-MM-dd')                         as loan_end_date     --贷款结束日期
     ,nvl(from_unixtime(unix_timestamp(t6.clear_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                         as loan_clear_date   --贷款结清日期
     ,'m'                         as loan_term_type    --贷款期限类型
     ,t6.periods                         as total_loan_terms  --贷款总期数
     ,'CNY'                         as ccy               --币种
     ,''                         as rmb_exch          --对人民币汇率
     ,t1.period                         as term_no           --期次
     ,from_unixtime(unix_timestamp(t1.start_date,'yyyyMMdd'),'yyyy-MM-dd')                         as term_start_date   --本期开始日期
     ,from_unixtime(unix_timestamp(t1.repay_date,'yyyyMMdd'),'yyyy-MM-dd')                         as term_mature_date  --本期到期日期
     ,date_add(from_unixtime(unix_timestamp(t1.repay_date,'yyyyMMdd'),'yyyy-MM-dd'),cast(t2.grace_day as int))                         as term_grace_date   --本期宽限到期日
     ,t2.grace_day                         as grace_days        --宽限天数
     ,from_unixtime(unix_timestamp(t7.repay_date,'yyyyMMdd'),'yyyy-MM-dd')                         as repay_date        --实际还款日
     ,t7.rn                       as term_repay_cnt    --本期还款次数
     ,case when t1.status = '3' then '07'  --未还清 已逾期
           when t1.status = '2' and t1.repay_date = t7.repay_date then '01' --还款日当天还清
           when t1.status = '2' and t1.repay_date > nvl(t7.repay_date,t6.clear_date)  then '04' --还款日前还清
           when t1.status = '2' and t1.repay_date < nvl(t7.repay_date,t6.clear_date) then '03' --超过宽限日还清
           when t1.status = '1'  then '06' --未还清，未逾期
    end as term_repay_status                                                                      --还款状态
     ,t1.prin_amt                         as matured_prin      --本期应还本金
     ,t1.paid_prin_amt                         as repaid_prin       --本期已还本金
     ,case when t1.status='3' then t1.prin_amt else 0 end                         as overdue_prin      --本期逾期本金
     ,t1.int_amt                         as matured_int       --本期应还利息
     ,t1.paid_int_amt                         as repaid_int        --本期已还利息
     ,case when t1.status='3' then t1.int_amt else 0 end                         as overdue_int       --本期逾期利息
     ,t1.gurantee_fee_amt                         as matured_fee       --本期应还担保费
     ,t1.repay_gurantee_fee_amt                   as repaid_fee        --本期已还担保费
     ,t1.odp_amt                         as matured_pena      --本期应还罚息
     ,t1.paid_odp_amt                         as repaid_pena       --本期已还罚息
     ,t1.odi_amt                         as matured_compo     --本期应还复利
     ,t1.paid_odi_amt                         as repaid_compo      --本期已还复利
     ,case when t7.repay_date is not null and t1.status = '2' then from_unixtime(unix_timestamp(t7.repay_date,'yyyyMMdd'),'yyyy-MM-dd')
           when t1.status = '2' then nvl(from_unixtime(unix_timestamp(t6.clear_date,'yyyyMMdd'),'yyyy-MM-dd'),'')
       end                        as term_clear_date   --本期还清日期
     ,case when t1.status = '3' 
           then datediff(from_unixtime(unix_timestamp(t1.repay_date,'yyyymmdd'),'yyyy-mm-dd'),date_add('${DATA_DATE}',-1))
           else 0
       end                                  as overdue_days      --逾期天数
     ,0                    as adv_repay_fee --提前还款手续费
	,case when t6.loan_status='3'  then t1.prin_amt-nvl(t1.paid_prin_amt,0) else 0 end as non_accru_bal --非应计本金
	,case when t6.loan_status='3'  then t1.int_amt-nvl(t1.paid_int_amt,0) else 0 end as aoff_bal_int  --表外利息
     ,t1.prod_type
from odata.slur_acc_repay_plan   t1 
--取合同号
left join  odata.slur_acc_loan_detail t2
on t1.loan_id=t2.loan_id
and t2.data_date='${DATA_DATE}'
and t2.bddw_end_date='9999-99-99'
--取客户姓名
left join odata.order_custom_info t3
on t1.loan_id=t3.loan_id
and t3.data_date='${DATA_DATE}'
and t3.bddw_end_date='9999-99-99'
--取客户号、证件号
left join odata.sym_cif_client_document t4
on t4.data_date='${DATA_DATE}'
and t4.bddw_end_date='9999-99-99'
and t3.id_card=t4.document_id
and t4.document_type='101'
--获取联系电话
left join odata.sym_cif_client_contact_tbl t5
on t4.client_no = t5.client_no 
and t5.pref_flag='Y'
and t5.data_date='${DATA_DATE}'
and t5.bddw_end_date='9999-99-99'
--获取业务类型编号
left join odata.slur_acc_duebill_info t6
on t1.loan_id=t6.loan_id
and t6.data_date='${DATA_DATE}'
and t6.bddw_end_date='9999-99-99'
--取实际还款日
left join (select  loan_id,period,max(repay_date) as repay_date,count(1) as rn  from odata.slur_acc_repay_detail
                    where data_date='${DATA_DATE}'
                      and bddw_end_date='9999-99-99'
                      group by loan_id,period) t7
on t1.loan_id=t7.loan_id
and t1.period=t7.period
where t1.data_date='${DATA_DATE}'
and t1.bddw_end_date='9999-99-99'