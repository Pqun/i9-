---------------------------------------------------------------------------------------------------------------
--脚本名称：dws_loan_indv_loan_repay_sum_p.sql度小满取数
--功能描述：生成每日结果数据并插入hive dws层dws.dws_loan_indv_loan_repay_sum_p
--作    者：方杰
--开发日期：2021-04-13
--直属经理：方杰
--来源表  ：odata.sllv_mb_acct_schedule_detail  --账户计划明细表
--来源表  ：odata.sllv_mb_invoice   --单据表 取回收明细
--来源表  ：odata.sllv_mb_guarantee_receipt
--来源表  ：odata.sllv_mb_acct
--来源表  ：odata.sym_cif_client_document
--来源表  ：odata.ols_loan_cont_info
--来源表  ：odata.order_main_loan_order
--目标表  ：dws.dws_loan_indv_loan_repay_sum_p
--修改历史：
--          1.方杰   2021-04-13    新建
--          2.华天顺 2022-06-14    新增非应计本金和表外利息字段
--          3.华天顺 2022-10-10    变更表名
--          4.杨琦浩 2024-02-22    slur_dxm_repayplan_file改为slur_dxm_repayplan_file_np取数
---------------------------------------------------------------------------------------------------------------
insert overwrite table dws.dws_loan_indv_loan_repay_sum_p partition (data_date='${DATA_DATE}',prod_code='110114')
select 
     t1.loan_no as bill_no                                                     --借据号
    ,'' as acct_no                                                                     --账号
    ,''                                                                                --合同号
    ,t5.crd_cont_no as crd_cont_no                                                                 --授信合同号
    ,t5.cust_id_core as cust_id                                                                     --客户号
    ,t5.cust_name   as cust_name                                                                    --客户姓名
    ,t6.document_type     as cert_type                                                     --证件类型
    ,t6.document_id       as cert_code                                                     --证件代码
    ,t7.contact_tel       as mobile                                                        --联系电话
    ,from_unixtime(unix_timestamp(t1.biz_date,'yyyyMMdd'),'yyyy-MM-dd')          as biz_date                                                      --业务日期
    ,t5.prd_code          as biz_prod_code                                                --业务产品代码
    ,'度小满' as prod_name                                                                   --产品名称
    ,'' as biz_type_code                                                               --业务类型编号
    ,'' as biz_type_name                                                               --业务类型名称
    ,from_unixtime(unix_timestamp(t3.loan_start_date,'yyyyMMdd'),'yyyy-MM-dd')       as loan_start_date           --贷款起始日期
    ,from_unixtime(unix_timestamp(t3.loan_end_date,'yyyyMMdd'),'yyyy-MM-dd')         as loan_end_date             --贷款结束日期
    ,from_unixtime(unix_timestamp(t3.clear_date,'yyyyMMdd'),'yyyy-MM-dd')       as loan_clear_date           --贷款结清日
    ,'m'                                    as loan_term_type            --贷款期限类型
    ,t3.loan_term as total_loan_terms                                                  --贷款总期数
    ,'' as ccy                                                                         --币种
    ,null as rmb_exch                                                                  --对人民币汇率
    ,t1.term as term_no                                                                --期次
    ,from_unixtime(unix_timestamp(t1.begin_date,'yyyymmdd'),'yyyy-mm-dd') as term_start_date                                                  --本期开始日期
    ,from_unixtime(unix_timestamp(t1.stmt_date,'yyyymmdd'),'yyyy-mm-dd')  as term_mature_date                                                 --本期到期日期
    ,date_add(from_unixtime(unix_timestamp(t1.stmt_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.grace_day as int )) as term_grace_date                              --本期宽限到期日
    ,t3.grace_day  as grace_days
    ,'' as repay_date                                                     --实际还款日
    ,'' as term_repay_cnt                                                 --本期还款次数
    ,case when t8.loan_no is not null then '05'   --代偿
	      when (t1.principal_paid<>t1.principal or t1.interest<>t1.interest_paid or t1.pay_guar_amt<>t1.service_repay)  and  t3.compensatory_status='1' then '05'
          when t1.status = 'N' and t1.stmt_date<=t1.biz_date      then '07'  --未还清 已逾期
          when t1.status = 'Y' and t1.stmt_date = t2.repay_date then '01' --还款日当天还清
          when t1.status = 'Y' and t1.stmt_date > t2.repay_date then '04' --还款日前还清
          when t1.status = 'Y' and from_unixtime(unix_timestamp(t2.repay_date,'yyyymmdd'),'yyyy-mm-dd')>date_add(from_unixtime(unix_timestamp(t1.stmt_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.grace_day as int )) then '03' --超过宽限日还清
          when t1.status = 'Y' and t1.stmt_date < t2.repay_date and from_unixtime(unix_timestamp(t2.repay_date,'yyyymmdd'),'yyyy-mm-dd')<=date_add(from_unixtime(unix_timestamp(t1.stmt_date,'yyyymmdd'),'yyyy-mm-dd'),cast(t3.grace_day as int )) then '02' --超过还款日，但在宽限期内还清本期
          when t1.status = 'N' and t1.stmt_date>t1.biz_date  then '06' --未还清，未逾期
    end as term_repay_status                                                                      --还款状态
    ,t1.principal as matured_prin                                                                 --本期应还本金
    ,t1.principal_paid as repaid_prin                                                             --本期已还本金
    --,null as                                                                                    --累计应还本金
    --,null as                                                                                    --累计未到期本金
    ,t1.principal_due as overdue_prin                                                             --本期逾期本金   
    ,t1.interest as matured_int                                                                   --本期应还利息
    ,t1.interest_paid as repaied_int                                                              --本期已还利息
    ,t1.interest_due as overdue_int                                                               --本期逾期利息    
    ,t1.pay_guar_amt  as matured_fee                                                              --本期应还担保费  
    ,t1.service_repay as repaied_fee                                                              --本期已还担保费  
    ,t1.penalty_due as matured_pena                                                               --本期应还罚息
    ,t1.penalty_paid  as repaied_pena                                                             --本期已还罚息
    ,0 as matured_compo                                                                           --本期应还复利
    ,0 as repaied_compo                                                                           --本期已还复利
    ,case when (t1.principal_paid<>t1.principal or t1.interest<>t1.interest_paid or t1.pay_guar_amt<>t1.service_repay)  and  t3.compensatory_status='1' 
          then from_unixtime(unix_timestamp(t1.biz_date,'yyyyMMdd'),'yyyy-MM-dd')
          when t1.status='Y'  
          then from_unixtime(unix_timestamp(t2.repay_date,'yyyymmdd'),'yyyy-mm-dd') 
          else null
      end          as clear_date                                                                  --结清日期
    ,case when t1.status = 'Y' and t1.stmt_date<t2.repay_date
          then datediff(from_unixtime(unix_timestamp(t2.repay_date,'yyyymmdd'),'yyyy-mm-dd'),from_unixtime(unix_timestamp(t1.stmt_date,'yyyymmdd'),'yyyy-mm-dd'))
          when t1.status = 'N' and t1.stmt_date<t1.biz_date
          then datediff(from_unixtime(unix_timestamp(t1.biz_date,'yyyymmdd'),'yyyy-mm-dd'),from_unixtime(unix_timestamp(t1.stmt_date,'yyyymmdd'),'yyyy-mm-dd')) 
       else 0 end            as overdue_days                                                             --逾期天数
    ,nvl(t9.repay_violate_amt,0)               as adv_repay_fee  --提前还款手续费
	,case when t3.overdue_days>90  then t1.principal-nvl(t1.principal_paid,0) else 0 end as non_accru_bal --非应计本金
	,case when t3.overdue_days>90  then t1.interest-nvl(t1.interest_paid,0) else 0 end as aoff_bal_int  --表外利息
from odata.slur_dxm_repayplan_file_clear   t1 
left join
    (
        select    loan_no
                  ,term
                  ,min(biz_date) as repay_date
        from odata.slur_dxm_repayplan_file_np
        where status = 'Y'
        group by loan_no,term
        ) t2
on  t1.loan_no = t2.loan_no
and t1.term = t2.term
left join odata.slur_dxm_loan_file_clear t3
on t1.loan_no = t3.loan_no
and t3.data_date = '${DATA_DATE}'
and t3.bddw_end_date = '9999-99-99'
inner join  odata.ols_loan_cont_info t5 
on t5.data_date = '${DATA_DATE}'
and t5.bddw_end_date = '9999-99-99'
and t5.cont_status in ('105','106','107','108','109','110')
and t1.loan_no=t5.bill_no
and t5.prd_code='10091001001'
left join odata.sym_cif_client_document t6
on t6.data_date = '${DATA_DATE}'
and t6.bddw_end_date = '9999-99-99'
and t5.cust_id_core = t6.client_no
and t6.pref_flag='Y' 
left join odata.sym_cif_client_contact_tbl t7
on t5.cust_id_core = t7.client_no 
and t7.pref_flag='Y'
and t7.data_date='${DATA_DATE}'
and t7.bddw_end_date='9999-99-99'
left join odata.slur_dzz_compensatory_detail t8
        on t1.loan_no = t8.loan_no
       and t1.term = t8.term_no
       and t8.data_date='${DATA_DATE}'
       and t8.bddw_end_date='9999-99-99'
       and t8.comps_status='S'
       and t8.sl_id = 'DXM'
       and t8.prod_class='02'
left join (select loan_no,term_no
                 ,sum(repay_violate_amt) as repay_violate_amt 
             from odata.slur_dxm_repay_file
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99'
            group by loan_no,term_no) t9
  on t9.loan_no=t1.loan_no
  and t9.term_no = t1.term
where t1.data_date = '${DATA_DATE}'
and   t1.bddw_end_date = '9999-99-99'