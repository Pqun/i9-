---------------------------------------------------------------------------------------------------------------
--脚本名称：二三类户他行卡绑定流水表.sql
--作    者：张礼娟
--开发日期：2022-11-11
--直属经理：程宏明
--来源表  ：odata.sym_mb_acct            账户基本信息表
--目标表  ：dwd.dwd_e_acct_bind_p
--修改历史：
--          1.张礼娟   2022-11-11    新建
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_acct_bind_p 
select /*+ REPARTITION(1) */
    a3.seq_no as seq_no	--流水号
    ,a3.tran_seq_no as tran_seq_no	--交易流水号
    ,a1.base_acct_no as acct_no	--账号
    ,a1.client_no as cust_id	--客户号
    ,a2.settle_base_acct_no as new_card_no	--新绑定卡号
    ,a3.old_settle_base_acct_no as old_card_no	--原卡号
    ,a3.create_time as create_time	--绑定时间
    ,a4.ip as ip_value	--IP
    ,a4.mac_value as mac_value	--MAC   
    ,a3.option_type as oper_type	--操作类型    
    ,a2.settle_branch as fin_org_code	--开户银行金融机构编码   
    ,a2.settle_bank_name as fin_org_nm	--开户银行名称
    ,a2.settle_bank_flag as bank_in_out	--行内外标志 O-行外  I-行内
    ,'${DATA_DATE}' as data_date	    
from odata.sym_mb_acct a1
left join odata.sym_mb_acct_settle a2
on a1.internal_key = a2.internal_key
and a2.data_date = '${DATA_DATE}'
and a2.bddw_end_date = '9999-99-99'
left join odata.bp_bp_bind_acct_hist a3
on a2.settle_base_acct_no = a3.settle_base_acct_no
and a3.data_date = '${DATA_DATE}'
and a3.bddw_end_date = '9999-99-99'
left join 
(
    select source_ref_no,imei_value,ip,mac_value
    from odata.bp_cm_tran_comm 
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    and service_code='MBSD_BP_EA' 
    and message_type='1200' 
    and message_code='0208'  --0208三方换绑卡
    and ret_code='000000'
    union all
    select source_ref_no,imei_value,ip,mac_value 
    from odata.bp_cm_tran_comm 
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    and service_code='MBSD_BP_UM' 
    and message_type='1200' 
    and message_code='0108' --0108手机银行换绑卡
    and ret_code='000000'
) a4 
on a3.tran_seq_no=a4.source_ref_no
where a1.data_date = '${DATA_DATE}' 
and a1.bddw_end_date = '9999-99-99'
and a1.source_module ='RB'
and a1.acct_class in ('2','3')
and a1.acct_real_flag = 'Y' --实账户
and a1.ccy = 'CNY'