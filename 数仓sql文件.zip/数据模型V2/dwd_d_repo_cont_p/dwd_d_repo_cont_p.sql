--2.gaoyuan.dwd.dwd_d_repo_cont_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：存量债券返售、回购信息.sql
--功能描述：生成每日结果数据并插入hive dwd层 dwd_d_repo_cont_p 分区表
--作    者：华天顺
--开发日期：2022-08-05
--直属经理：方杰
--来源表  ：odata.tb_v_balance                --查询当日日终后的资产余额信息
--来源表  ：odata.tb_v_ldrepodeals            --查询质押式回购的数据
--来源表  ：odata.tb_vs_cptys                 --提供交易对手基础信息
--来源表  ：odata.tb_vs_cptyattsmap           --提供交易对手分类对应信息
--来源表  ：odata.nbms_cpes_quote_contract    --对话报价协议表
--来源表  ：odata.nbms_cpes_quote_details     --对话报价明细表
--来源表  ：odata.nbms_bms_provision          --计提主表
--来源表  ：odata.nbms_dpc_draft_info         --票据票面信息表
--来源表  ：odata.nbms_cpes_quote_due         --对话报价到期表
--来源表  ：odata.nbms_bms_customer_info      --客户信息表
--目标表  ：dwd.dwd_d_repo_cont_p      --回购业务协议表
--修改历史：
--          1.华天顺   2022-08-05    新建
--          2.高源     2022-11-14    新增回购天数、实际终止日期
--          3.高源     2022-11-25    新新增日计提利息
--          4.高源     2022-12-14    票据回购利息调整字段逻辑调整
--          5.高源     2022-12-19    新增应收利息、应收利息科目字段逻辑
--          6.高源     2023-01-06    交易对手逻辑调整
--          7.高源     2023-02-06    新增首期结算金额、累计价差收益、累计摊销收益、累计利息收益、累计公允价值变动损益字段
--          8.高源     2023-02-16    新增保证金和抵质押品价值
--          9.高源     2023-07-10    债券回购业务新增成交编号字段
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_repo_cont_p partition(data_date = '${DATA_DATE}')  
--债券回购
 select  /*+ REPARTITION(1) */
     t1.serial_number                                   as cont_no             --回购业务协议号
    ,t1.bondscode                                       as repo_asset_code     --回购资产编号
    ,t1.repo_id                                         as repo_name           --回购名称
    ,case when t1.buztype = '逆回购' then '1' --买入返售
          when t1.buztype = '正回购' then '2' --卖出回购
          else ''  end                                  as bull_sell_type      --买卖类型
    ,'2'                                                as repo_asset_type     --回购资产类型
    ,'1'                                                as repo_mode           --回购方式
    ,'CNY'                                              as ccy                 --币种代码
    ,'100000'                                           as org_id              --机构代码
    ,case when t1.buztype = '逆回购' then '10200301' --质押式买入返售证券
          when t1.buztype = '正回购' then '20200301' --质押式卖出回购证券
          else ''    end                                as subj_no             --科目号
    ,t1.cptys_id                                        as tran_party_id       --交易对手id
    ,coalesce(t1.master_short_cname,t1.cptys_name ,'')  as tran_party_name     --交易对手名称
    ,nvl(t1.commonatts_id,'')                           as tran_party_type     --交易对手类型
    ,from_unixtime(unix_timestamp(t1.value_date,'yyyyMMdd'),'yyyy-MM-dd')    as start_date         --开始日期
    ,from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd') as mature_date        --到期日期
    ,t1.realrate                                        as exec_rate           --执行利率(%)
    ,t1.repo_rate                                       as repo_rate           --质押比例
    ,t1.holdposition                                    as biz_amt             --业务金额
    ,0                                                  as int_adj             --利息调整
    ,''                                                 as int_adj_subj_no     --利息调整科目
    ,0                                                  as fair_value_adj_amt  --公允价值变动金额
    ,''                                                 as fair_value_adj_subj --公允价值变动科目
    ,''                                                 as accr_flag           --计息标志
    ,'B99'                                              as int_mode            --计息方式
    ,from_unixtime(unix_timestamp(t1.value_date,'yyyyMMdd'),'yyyy-MM-dd')    as accr_date           --起息日期
    ,'TR99'                                             as pric_benc           --定价基准类型
    ,t1.repo_days                                       as repo_days           --回购天数
    ,case when t1.holdposition = 0 then from_unixtime(unix_timestamp(t1.settledate,'yyyyMMdd'),'yyyy-MM-dd')
          else '' end                                   as actual_mature_date     --实际终止日期
    ,nvl(t.withdraw_int,0)                              as withdraw_int           --日计提利息
    ,case when t1.buztype = '逆回购' then nvl(t.sumd,0)-nvl(t.sumc,0)
          when t1.buztype = '正回购' then nvl(t.sumc,0)-nvl(t.sumd,0)  
          else 0   end                                  as recv_int           --应收应付利息 
    ,case when t1.buztype = '逆回购' then '10600605' --应收利息-应收质押式买入返售证券
          when t1.buztype = '正回购' then '20600503' --应付利息-应付质押式卖出回购证券
          else ''  end                                  as recv_int_subj_no            --应收应付利息科目
    ,nvl(t1.amount             ,0)                      as settle_amt                  --首期结算金额
    ,nvl(t1.priceearning       ,0)                      as total_diff_income           --累计价差收益
    ,nvl(t1.amortizeearning    ,0)                      as total_amort_income          --累计摊销收益
    ,nvl(t1.interestearning    ,0)                      as total_int_income            --累计利息收益
    ,nvl(t1.fairvalueincome    ,0)                      as total_fair_value_change     --累计公允价值变动损益
    ,nvl(t1.repo_face_amt      ,0)                      as repo_face_amt               --保证金和抵质押品价值
    ,nvl(t1.ref_number        ,'')                      as ref_no                      --成交编号             --2023-07-10新增字段
	,''                                                 as oper_emp_id                 --经办人   (split(t1.dn_dealer,'\\(')[0],split(t1.note,'>')[0])经办人名称
    ,''                                                 as approver                    --审批人     --2023-11-16   新增字段
 from(select cp.cptys_id         --交易对手ID
            --,vi.cptys_short_name
            ,cp.cptys_name
            ,cp.master_short_cname
            ,vi.counterparty_type
            ,b2.holdposition     --持有仓位(余额)
            ,b2.realrate         --实际利率
            --,b2.interestcost    --利息成本
            ,cast(b2.settledate as string) as settledate
            --,vi.sec_face_amt
            ,vi.amount
            --,vi.maturity_amount
            ,vi.serial_number     --成交号
            ,vi.ref_number
            ,vi.bondscode
            ,vi.repo_rate
            ,vi.repo_id
            ,vi.repo_days
			,vi.dn_dealer
			,vi.note
            ,cast(vi.value_date    as string) as value_date   --起息日
            ,cast(vi.maturity_date as string) as maturity_date --到期日
            ,t3.repo_face_amt
            ,b2.buztype
            ,b2.majorassetcode
            ,b2.minorassetcode
            --,b3.start_coupon_date
            ,b4.commonatts_id
            ,cast(ce1.priceearning     as decimal(28,10)) as priceearning
            ,cast(ce1.amortizeearning  as decimal(28,10)) as amortizeearning
            ,cast(ce1.interestearning  as decimal(28,10)) as interestearning
            ,cast(ce1.fairvalueincome  as decimal(28,10)) as fairvalueincome
   from(select max(bls.balance_id) as balance_id
              from odata.tb_v_balance bls
             where bls.data_date = '${DATA_DATE}'
               and bls.bddw_end_date = '9999-99-99'
               and bls.settledate <= regexp_replace('${DATA_DATE}','-','') --统计日期
               and bls.aspclient_id = '2244' --请替换本行部门ID
               and bls.assettype = '质押式回购'
          group by bls.aspclient_id,
                   bls.keepfolder_id,
                   bls.assettype,
                   bls.buztype,
                   bls.majorassetcode,
                   bls.minorassetcode)b1
inner join odata.tb_v_balance b2
        on b1.balance_id = b2.balance_id
       and b2.data_date = '${DATA_DATE}'
       and b2.bddw_end_date = '9999-99-99'
inner join odata.tb_v_ldrepodeals vi   --债券
        on vi.deal_id = substr(b2.majorassetcode,4)
       and vi.data_date = '${DATA_DATE}'
       and vi.bddw_end_date = '9999-99-99'
      left join odata.tb_vs_payment_ldrepodeals  t3
        on vi.serial_number = t3.serial_number
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
 left join(select aspclient_id,
                  keepfolder_id,
                  assettype,
                  majorassetcode,
                  minorassetcode,
                  sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                           then priceearning    else 0 end)  as priceearning,
                  sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                           then amortizeearning else 0 end)  as amortizeearning,
                  sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                           then interestearning else 0 end)  as interestearning,
                  sum(case when baretradename in('AMORTIZATIONDEALS','WITHDRAWALDEALS','ESTIMATIONDEALS','BONDSDEALS') 
                           then fairvalueincome else 0 end)  as fairvalueincome
             from odata.tb_v_alterbalance                                         --查询当日资产变动信息
            where data_date ='${DATA_DATE}'
              and bddw_end_date ='9999-99-99'
            group by aspclient_id,                                               --所属部门ID
                     keepfolder_id,                                              --账户ID
                     assettype,                                                  --资产类别
                     majorassetcode,                                             --主资产代码
                     minorassetcode)ce1                                          --次资产代码
        on b2.aspclient_id = ce1.aspclient_id                                    
       and b2.keepfolder_id = ce1.keepfolder_id                                 
       and b2.assettype = ce1.assettype                                          
       and b2.majorassetcode = ce1.majorassetcode                                
       and b2.minorassetcode = ce1.minorassetcode      
 left join odata.tb_vs_cptys cp
        on vi.cptys_id = cp.key_src
       and cp.data_date = '${DATA_DATE}'
       and cp.bddw_end_date = '9999-99-99'
 left join odata.tb_v_security b3
        on vi.bondscode = b3.security_code
       and b3.data_date = '${DATA_DATE}'
       and b3.bddw_end_date = '9999-99-99'
 left join odata.tb_vs_cptyattsmap b4
        on cp.cptys_id = b4.cptys_id
       and b4.data_date = '${DATA_DATE}'
       and b4.bddw_end_date = '9999-99-99'
      )t1
 left join
        ( select   bls.majorassetcode,bls.minorassetcode,
                          max(tva.amount)  as  withdraw_int,
                          sum(cast(tvad.amount as decimal(18,2))) as sumd, 
                          sum(cast(tvac.amount as decimal(18,2))) as sumc 
                   from odata.tb_v_balance bls
                   left  join  odata.tb_vs_accentry2 tvad                --取应收利息借方历史数据
                     on bls.alterbalance_id = tvad.bundlecode
                    and tvad.data_date='${DATA_DATE}'
                    and tvad.bddw_end_date='9999-99-99'
                    and tvad.debitcredit = 'D'
                    and tvad.accountingcode like '%0600%' 
                   left join  odata.tb_vs_accentry2 tvac                --取应收利息贷方历史数据
                     on bls.alterbalance_id = tvac.bundlecode
                    and tvac.data_date='${DATA_DATE}'
                    and tvac.bddw_end_date='9999-99-99'
                    and tvac.debitcredit = 'C'
                    and tvac.accountingcode like '%0600%' 
                   left  join  odata.tb_vs_accentry2 tva                --取当日计提利息 
                     on bls.alterbalance_id = tva.bundlecode
                    and tva.data_date='${DATA_DATE}'
                    and tva.bddw_end_date='9999-99-99'
                    and tva.settledate= regexp_replace('${DATA_DATE}','-','')  --统计日期
                    and tva.accountingcode like '%0600%' 
                    and bls.baretradename='WITHDRAWALDEALS'                 
                  where bls.settledate <= regexp_replace('${DATA_DATE}','-','') --统计日期
                    and bls.aspclient_id = '2244' -- 请替换本行部门 ID
                    and bls.assettype  = '质押式回购'
                    and bls.data_date = '${DATA_DATE}'
                    and bls.bddw_end_date = '9999-99-99'
                  group by bls.minorassetcode,bls.majorassetcode
         ) t
        on t1.majorassetcode = t.majorassetcode
       and t1.minorassetcode = t.minorassetcode
union all
--回购交易票据
 select   /*+ REPARTITION(1) */
    a.contract_no                                          as cont_no              --回购业务协议号
   ,''                                                     as repo_asset_code      --回购资产编号
   ,''                                                     as repo_name            --回购名称
   ,case when a.trade_direct = 'CRD01' then '1'  --买入返售
         when a.trade_direct = 'CRD02' then '2'  --卖出回购
         end                                               as bull_sell_type       --买卖类型
   ,'1'                                                    as repo_asset_type      --回购资产类型
   ,case when a.busi_type = 'BT02'
         then '1'
         when a.busi_type = 'BT03'
         then '2'
      end                                                  as repo_mode            --回购方式
   ,'CNY'                                                  as ccy                  --币种代码
   ,'100000'                                               as org_id               --机构代码
   ,case when a.trade_direct = 'CRD01' and a.busi_type = 'BT02' then '10200201'  --质押式买入返售票据-面值
         when a.trade_direct = 'CRD01' and a.busi_type = 'BT03' then '10200203'  --买断式买入返售票据-面值
         when a.trade_direct = 'CRD02' then '20200201'  --卖出回购票据-面值
         end                                               as subj_no              --科目号
   ,nvl(a.cust_no    ,'')                                  as tran_party_id        --交易对手id
   ,coalesce(c.cust_name,a.cust_name  ,'')                 as tran_party_name      --交易对手名称
   ,''                                                     as tran_party_type      --交易对手类型
   ,from_unixtime(unix_timestamp(a.apply_date,'yyyyMMdd'),'yyyy-MM-dd')      as start_date         --开始日期
   ,from_unixtime(unix_timestamp(a.due_settle_date,'yyyyMMdd'),'yyyy-MM-dd') as mature_date        --到期日期
   ,a.rate*100                                             as exec_rate            --执行利率(%)
   ,100                                                    as repo_rate            --质押比例
   ,case when b.org_cpes_quote_contract_id is not NULL then 0
         else nvl(t3.amount,0)  end                        as biz_amt              --业务金额
   ,case when b.org_cpes_quote_contract_id is not NULL then 0
         else nvl(-t3.rema_interest,0) end                 as int_adj              --利息调整
   ,case when a.trade_direct = 'CRD01' and a.busi_type = 'BT02' then '10200202'  
         when a.trade_direct = 'CRD01' and a.busi_type = 'BT03' then '10200204'  
         when a.trade_direct = 'CRD02' then '20200202'  
         end                                               as int_adj_subj_no      --利息调整科目
   ,0                                                      as fair_value_adj_amt   --公允价值变动金额
   ,''                                                     as fair_value_adj_subj  --公允价值变动科目
   ,''                                                     as accr_flag            --计息标志
   ,'B99'                                                  as int_mode             --计息方式
   ,from_unixtime(unix_timestamp(a.apply_date,'yyyyMMdd'),'yyyy-MM-dd')      as accr_date            --起息日期
   ,'TR99'                                                 as pric_benc            --定价基准类型
   ,a.tenor_days                                           as repo_days            --回购天数
   ,case when b.org_cpes_quote_contract_id is not null then from_unixtime(unix_timestamp(a.due_settle_date,'yyyyMMdd'),'yyyy-MM-dd')
         else '' end                                       as actual_mature_date   --实际终止日期
   ,nvl(t3.ever_pro_amount      ,0)                        as withdraw_int         --日计提利息
   ,0                                                      as recv_int             --应收应付利息 
   ,case when a.trade_direct = 'CRD01' and a.busi_type = 'BT02' then '10600603'  
         when a.trade_direct = 'CRD01' and a.busi_type = 'BT03' then '10600604'  
         when a.trade_direct = 'CRD02' then '20600502'  
         end                                               as recv_int_subj_no         --应收应付利息科目
   ,0                                                      as settle_amt               --首期结算金额
   ,0                                                      as total_diff_income        --累计价差收益
   ,0                                                      as total_amort_income       --累计摊销收益
   ,0                                                      as total_int_income         --累计利息收益
   ,0                                                      as total_fair_value_chang   --累计公允价值变动损益
   ,0                                                      as repo_face_amt            --保证金和抵质押品价值
   ,''                                                     as ref_no                   --成交编号             --2023-07-10新增字段
   ,nvl(a.created_by , '')                                 as oper_emp_id	           --经办人               -- 20231116update
   ,nvl(tbl.assign_id, '')                                 as approver	 	           --审批人               -- 20231116update
 from odata.nbms_cpes_quote_contract a
 left join ( select  
                    contract_id
                   ,sum(draft_amount)  as amount
                   ,sum(rema_interest) as rema_interest
                   ,max(remit_date) as remit_date
                   ,sum(ever_pro_amount)  as  ever_pro_amount
               from 
                  (
                     select a.contract_id,
                            c.draft_amount,
                            c.remit_date,
                            b.ever_pro_amount,
                            b.rema_interest
                        from odata.nbms_cpes_quote_details a
                        left join odata.nbms_bms_provision b 
                          on a.draft_id=b.draft_id 
                         and a.id=b.detail_id
                         and b.data_date='${DATA_DATE}' 
                         and b.bddw_end_date='9999-99-99'
                        left join odata.nbms_dpc_draft_info c 
                          on a.draft_id=c.id 
                         and c.data_date='${DATA_DATE}' 
                         and c.bddw_end_date='9999-99-99'
                       where a.data_date='${DATA_DATE}' 
                         and a.bddw_end_date='9999-99-99' 
                         and b.jiti_type in (3,4,5,6) 
                   ) t2
              group by contract_id    ) t3 
        on t3.contract_id = a.id
  left join
    (select * from
         (select  task_name, task_flag, assign_id, name2, row_number() over(partition by name2 order by create_time desc  ) rn
            from  odata.flowsharp_tbl_repeat_task        --流程表
           where data_date='${DATA_DATE}' 
 	         and bddw_end_date='9999-99-99'
			 and task_flag='2'         --审批状态           --待确认数据
			 ) a 
 	 where a.rn=1) tbl
   on a.contract_no=tbl.name2   
 left join odata.nbms_cpes_quote_due b
        on a.id = b.org_cpes_quote_contract_id 
       and b.account_status = '02'
       and b.data_date='${DATA_DATE}' 
       and b.bddw_end_date='9999-99-99'
 left join odata.nbms_bms_customer_info c
        on c.data_date = '${DATA_DATE}'
       and c.bddw_end_date = '9999-99-99'
       and a.cust_no = c.cust_no
       and c.cust_type='2'
     where a.data_date = '${DATA_DATE}'
       and a.bddw_end_date = '9999-99-99'
       and a.account_status = '02'
       and a.busi_type in ('BT02','BT03')