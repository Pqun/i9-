--2.gaoyuan.dwd.dwd_d_corp_credit_cont_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：对公授信合同表取数逻辑.sql
--功能描述：用于创建 dwd.dwd_d_corp_credit_cont_p
--作    者：高源
--开发日期：2022-09-02
--直属经理：方杰
--来源表 :odata.als_business_contract                     业务合同信息表 
--来源表 :odata.als_business_apply                        业务申请信息表
--来源表 :odata.als_business_duebill                      业务借据信息表
--来源表 :odata.sym_mb_acct                               账户基本信息表
--来源表 :odata.supacct_enterprise_loan_info              贷款信息表 
--来源表 :odata.sym_mb_prod_type                          产品类型定义表 
--来源表 :odata.als_business_approve                      业务批准信息表 
--来源表 :odata.order_main_loan_order                     订单主表
--来源表 :odata.order_main_credit_order                   授信信息表
--来源表 :odata.order_custom_info                         客户信息表
--来源表 :odata.order_order_audit_operation_log           订单审核操作日志记录表
--来源表 :odata.sllv_mb_acct                              账户基本信息表
--来源表 :odata.sso_upms_user                             历史流程实例表
--来源表 :odata.supentry_scp_grant_credit_apply           授信申请表
--来源表 :odata.supentry_scp_increase_grant_credit_apply  提额申请表
--来源表 :odata.uquam_ps_product_limit                    个人产品额度表
--来源表 :odata.uquam_ps_product_limit_change             个人产品总额度变更表
--来源表 :odata.uquam_channel_limit                       渠道额度表
--目标表：dwd.dwd_d_corp_credit_cont_p   对公授信合同表
--修改历史：
--          1.高源    2022-09-02    新建
--          2.高源    2023-02-10    新增授信业务种类、授信主体种类、经办人工号
--          3.于国睿  2023-02-09    新增锡惠贷授信逻辑
--          4.高源    2023-03-03    锡惠贷授信客户逻辑调整
--          5.高源    2023-05-15    新增项目id字段
--          6.高源    2023-05-15    项目id字段逻辑调整
--          7.高源    2023-08-15    锡惠贷企业融授信额度、开始日期、结束日期调整为优先取额度中心 
--          8.高源    2023-08-31    新增已用额度字段，审批人、经办人工号逻辑调整
--          9.高源    2023-09-13    供应链群组额度逻辑调整，取额度中心最新的渠道额度
--          10.高源   2023-10-13    授信主体种类字段逻辑调整
--          11.杨琦浩 2023-11-30    新增绿色贷款标识
--          12.杨琦浩 2023-12-28    授信主体种类新增集团客户授信，锡惠贷对公产品审批人逻辑调整
--          13.杨琦浩  2024-03-20   新增锡享贷产品
--          14.姚威    2024-05-14   新增孚厘企业贷
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_corp_credit_cont_p partition(data_date = '${DATA_DATE}')
    select /*+ REPARTITION(1) */
           nvl(t.serialno,'')                              as  credit_cont_no      --授信合同编号
          ,'02'                                            as  cust_type           --客户类型
          ,nvl(t.customerid,'')                            as  cust_id             --客户号
          ,nvl(t.customername,'')                          as  cust_name           --客户姓名
          ,nvl(t3.prod_desc,'')                            as  prod_name           --产品名称
          ,'003'                                           as  credit_app_status   --授信申请状态
          ,case when t.status ='EFFECTIVE' then '103'
                when t.status ='INEFFECTIVE' then '106'
                else '104'  
            end                                            as  credit_cont_status  --授信合同状态  进入合同表的数据都为审批通过
          ,case when t.cycleflag =1 then 1
                when t.cycleflag =2 then 0 
                else '' 
            end                                            as  cycle_flag          --循环标识
          ,nvl(if(t.businesscurrency='01','CNY',''),'CNY') as  ccy                 --币种
          ,coalesce(tu.total_limit,t.businesssum,0)        as  credit_limit        --授信额度
          ,nvl(t.termmonth,'')                             as  credit_terms        --授信期限
          ,'M'                                             as  credit_term_type    --授信期限类型
          ,nvl(regexp_replace(t.putoutdate,'/','-'),'')    as  credit_start_date   --授信起始日期
          ,nvl(regexp_replace(t.maturity,'/','-'),'')      as  credit_mature_date  --授信到期日期
          ,nvl(if(t.status='EFFECTIVE','01','02'),'')      as  credit_status       --授信状态
          ,case when t.businesstype in ('3005','3050010') then nvl(regexp_replace(t2.occurdate,'/','-'),'')   
                when t.businesstype in ('3006010','3050020') then nvl(regexp_replace(t.occurdate,'/','-'),'')
                else ''  
            end                                            as  credit_app_date     --申请日期
          ,coalesce(tf2.userid,t42.username     ,'')       as  approver   --审批人
          ,''                                              as  approve_opinion     --审批意见
          ,nvl(t3.prod_type,'')                            as  prod_code           --产品编号
          ,nvl(t4.typename,'')                             as  credit_biz_type     --授信业务种类
          ,case when t7.customertype like '01%' and t.businesstype in ('3006010','3005' ) then '单一法人授信'
                when t7.customertype like '03%' and t.businesstype in ('3006010','3005' ) then '个人客户授信'
                when t.businesstype='3050030' then '集团客户授信'                  --20231228 update yqh
                  when t.businesstype  in('3050010','3050020') then '供应链融资'
                else ''
            end                                            as  credit_cust_type    --授信主体种类        --20231013update
          ,coalesce(tf1.userid,t16.cust_manager_id,'')     as  oper_emp_id         --经办人工号        
          ,coalesce(spa.project_id ,sra.project_id,spi.project_id,sri.project_id,'')        as  project_id          --项目ID
          ,nvl(t.balance   ,0)                             as  used_limit          --已用额度      
          ,case when t2.greenloan='1' then '1'
                else '0' end                               as  green_loan_flag     --绿色贷款标识
      from odata.als_business_contract t     --业务合同信息表
     --left join odata.als_org_info t1 --机构信息 
     --on t.putoutorgid = t1.orgid 
     --and t1.data_date = '${DATA_DATE}' 
     --and t1.bddw_end_date = '9999-99-99'
      left join odata.uquam_channel_limit tu   --渠道额度表     
        on t.channelserialno = tu.channel_code
       and tu.data_date = '${DATA_DATE}' 
       and tu.bddw_end_date = '9999-99-99'  
      left join odata.als_business_approve t1 --业务批准信息表      --(只有综合授信额度信息，还有少量历史单笔单批)
        on t.relativeserialno = t1.serialno
       and t1.data_date = '${DATA_DATE}' 
       and t1.bddw_end_date = '9999-99-99' 
      left join odata.als_business_apply t2 --业务申请信息表 
        on t1.relativeserialno = t2.serialno
       and t2.data_date = '${DATA_DATE}' 
       and t2.bddw_end_date = '9999-99-99' 
      left join (select  * from  
                     ( select   *,row_number()over(partition by objectno order by serialno desc) rn     --信贷取最新的经办经理  
                        from odata.als_flow_task         --流程任务表  
                      where data_date = '${DATA_DATE}' 
                        and bddw_end_date = '9999-99-99' 
                        and objecttype = 'CreditApply' --授信申请  
                        and phaseno = '0010'           --经办客户经理 
                       ) t 
                  where  t.rn=1   )  tf1
        on t2.serialno =tf1.objectno
      left join  (select  * from  
                         ( select  *,row_number()over(partition by objectno order by serialno desc) rn     --信贷取最新的授信审批人员     
                           from odata.als_flow_task         --流程任务表  
                         where  data_date = '${DATA_DATE}' 
                           and  bddw_end_date = '9999-99-99' 
                           and  objecttype = 'CreditApply' --授信申请  
                           and  phaseno = '0050'           --授信审批岗  
                         ) t   
                    where  t.rn=1   )  tf2
       on t2.serialno =tf2.objectno
     left join (select  * from   
                    ( select  *,row_number()over(partition by apply_no order by create_time  desc ,operate_task desc) rn     --供应链取最后一笔为审批人员     
                      from odata.suprisk_credit_apply_status_record         
                     where data_date = '${DATA_DATE}' 
                       and bddw_end_date = '9999-99-99' 
                       and operate_result not in ('00','01','02','03','04')             --剔除非人工审批
                    ) t 
                 where  t.rn=1 ) t41
         on t41.apply_no =regexp_replace(t.artificialno,'L','')
      left join odata.sso_upms_user t42                --审批人员工号
        on t41.operator=t42.user_id 
       and t42.data_date='${DATA_DATE}' 
       and t42.bddw_end_date='9999-99-99'    
      left join  odata.supentry_scp_grant_credit_apply  spa
        on regexp_replace(t.artificialno,'L','')  = spa.apply_no
       and spa.data_date = '${DATA_DATE}' 
       and spa.bddw_end_date = '9999-99-99' 
       left join  odata.suprisk_credit_apply_info  sra
        on regexp_replace(t.artificialno,'L','')= sra.apply_no
       and sra.data_date = '${DATA_DATE}' 
       and sra.bddw_end_date = '9999-99-99'       
      left join  odata.supentry_scp_increase_grant_credit_apply  spi
        on t.artificialno = spi.apply_no
       and spi.data_date = '${DATA_DATE}' 
       and spi.bddw_end_date = '9999-99-99' 
      left join  odata.suprisk_increase_credit_apply_info  sri  
        on t.artificialno = sri.apply_no
       and sri.data_date = '${DATA_DATE}' 
       and sri.bddw_end_date = '9999-99-99'   
      left join odata.suppimp_scp_project_info  t16  --金融项目表
       on coalesce(spa.project_id ,sra.project_id,spi.project_id,sri.project_id,'') =t16.project_id
      and t16.data_date='${DATA_DATE}'
      and t16.bddw_end_date = '9999-99-99'
      left join (select p.relativeserialno
                       ,concat_ws(',',collect_set(p.prod_type)) prod_type
                       ,concat_ws(',',collect_set(p.prod_desc)) prod_desc 
                   from (select nvl(a.relativeserialno,a.artificialno) as relativeserialno
                               ,a.serialno
                               ,nvl(a4.product_type,a2.prod_type)  as  prod_type
                               ,a3.prod_desc
                               ,row_number() over(partition by a.relativeserialno,a.artificialno order by a3.prod_desc) rn  
                           from odata.als_business_contract a--取贷款合同号  --业务合同信息表
                           left join odata.als_business_duebill a1           --业务借据信息表
                             on a.serialno=a1.relativeserialno2
                            and a1.data_date='${DATA_DATE}'
                            and a1.bddw_end_date ='9999-99-99'
                           left join odata.sym_mb_acct a2           
                             on a1.serialno=a2.cmisloan_no
                            and a2.data_date='${DATA_DATE}'
                            and a2.bddw_end_date='9999-99-99'
                            and a2.lead_acct_flag='N'           --仅取借据
                           left join odata.supacct_enterprise_loan_info a4
                             on a1.serialno = a4.iou_no
                            and a4.data_date='${DATA_DATE}'
                            and a4.bddw_end_date='9999-99-99'
                            and a4.reversal_flag = '00'             --正常部分
                           left join odata.sym_mb_prod_type a3
                             on nvl(a4.product_type,a2.prod_type)=a3.prod_type
                            and a3.data_date='${DATA_DATE}'
                            and a3.bddw_end_date='9999-99-99'
                          where a.data_date='${DATA_DATE}'
                            and a.bddw_end_date='9999-99-99'
                            and a.status='EFFECTIVE'              
                            and substr(a.businesstype,1,1) <>'3') p    --业务合同表 
                  group by p.relativeserialno) t3
        on regexp_replace(nvl(t.relativeserialno,t.artificialno),'授','借') =regexp_replace(t3.relativeserialno,'授','借') 
      left join odata.als_business_type t4
        on t.businesstype = t4.typeno
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
      left join odata.als_group_info t5  --供应链额度客户号
        on t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
       and t5.groupid=t.customerid
       and t.applytype ='GroupCreditApply'
      left join odata.sym_cif_client t6  
        on t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
       and t6.client_no = nvl(t5.keymembercustomerid,t.customerid)
      left join odata.als_customer_info t7   --客户信息表
        on t6.client_no = t7.customerid
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'       
     where t.data_date='${DATA_DATE}'
       and t.bddw_end_date='9999-99-99'
       and substr(t.businesstype,1,1) ='3'--取授信类合同
union  all 
---------------------------------------------锡惠贷、锡享贷授信、孚厘----------------------------------------------------------------
     select  /*+ REPARTITION(1) */
             nvl(t1.loan_id,'')                       as     credit_cont_no       --授信合同号
            ,'02'                                     as     cust_type            --客户类型
            ,nvl(t3.client_no,'')                     as     cust_id              --客户号
            ,nvl(t4.ch_client_name,'')                as     cust_name            --客户姓名
            --,'锡惠贷-企业融'                          as     prod_name            --产品名称
            ,nvl(t15.prod_desc,'')                    as     prod_name            --产品名称
            ,case when t1.status in (1,2,7)   --申请中，审批中
                  then '001'
                  when t1.status in (3,5)   --授信成功，授信失效
                  then '003'
                  when t1.status in (4,6)        --审批失败 
                  then '002'
                  else ''
              end                                     as     credit_app_status    --授信申请状态
            ,case when t1.status in (3,5) and (t12.effective_status = 2 or t12.credit_order_no is null)  --20220815 update 从额度中心判断额度失效
                 then '104'
                 when t1.status in (1,2,7)   --申请中，审批中
                 then '101'
                 when t12.effective_status in (1,3)   --生效、冻结
                 then '103'
                 when t1.status in (4,6)
                 then '102'
                 else ''                                
              end                                     as     credit_cont_status   --授信合同状态            
            ,case when t1.sub_product_type='45' then '0' else '1'      
			     end                                  as     cycle_flag           --循环标识   
            ,'CNY'                                    as     ccy                  --币种
            ,coalesce(t12.total_limit,t1.credit_amount,0)   as     credit_limit         --授信额度          --update 20230902
            ,case when t1.sub_product_type='45' then datediff(substr(t12.limit_end_time,1,10),substr(t12.limit_begin_time,1,10))
             else coalesce(cast(round(months_between(substr(t12.limit_end_time,1,10),substr(t12.limit_begin_time,1,10)),0) as int),t1.credit_period,'')         
              end                                         as     credit_terms         --授信期限
            , case when t1.sub_product_type='45' then 'D' 
			        else 'M'    
                    end 				               as     credit_term_type     --授信期限类型
            ,coalesce(substr(t12.limit_begin_time,1,10),substr(t1.credit_start_time,1,10),'')      as     credit_start_date    --授信起始日期    --update 20230902
            ,coalesce(substr(t12.limit_end_time,1,10),substr(t1.credit_end_time,1,10),'')          as     credit_mature_date   --授信到期日期     --update 20230902      
            ,case when t1.status in (3,5) and (t12.effective_status = 2 or t12.credit_order_no is null)  
                  then '02'
                  when t12.effective_status in (1,3) 
                  then '01' --有效
                  else ''
              end                                     as     credit_status        --授信状态              
            ,substr(t1.apply_time,1,10)               as     app_date             --申请日期              
            --,nvl(t7.username    ,'')                  as     approver             --审批人                  --update 20230902
            ,nvl(p.username,'')             	      as     approver             --审批人
            --,nvl(t6.process_result,'')                as     approve_opinion      --审批意见(得物，颐而信授信订单在日志表里无审批流程)
            ,case when p.full_msg='PUSH' then '通过'
                  when p.full_msg='ROLLBACK' then '回退'
                  when p.full_msg='BACK' then '退回'
                  when p.full_msg='REFUSE' then '不通过'
                  when p.full_msg='CANCEL' then '取消'
                  when p.full_msg='REVOKE' then '撤销'
                  else '' end                         as     approve_opinion      --审批意见
            --,'120111'                                 as     prod_code            --产品编号 
            ,nvl(t3.prod_type,'')                     as     prod_code            --产品编号 
            ,'综合额度授信'                           as     credit_biz_type      --授信业务种类
            --,'单一法人授信'                           as     credit_cust_type     --授信主体种类
            ,case when t1.sub_product_type in('25','44','45') --锡惠贷、锡享贷-厚沃企业-孚厘
                 then '单一法人授信'
                 when t1.sub_product_type in('42') --锡享贷-找钢
                 then '供应链融资'
            end                                       as     credit_cust_type     --授信主体种类
            ,case when t1.sub_product_type='45' then 'xs0347'	
                  else nvl(t8.username,'') 
                  end 				                  as     oper_emp_id          --经办人工号             --update 20230902 
            ,''                                       as     project_id           --项目ID
            ,nvl(t12.used_limit,0)                    as     used_limit           --已用额度           
            ,'0'                                      as     green_loan_flag      --绿色贷款标识
      from odata.order_main_credit_order t1
      left join odata.uquam_ps_product_limit t12          --update 20230902
        on t12.credit_order_no = t1.loan_id
       and t12.data_date='${DATA_DATE}'
       and t12.bddw_end_date='9999-99-99'
     --left join(select row_number()over(partition by credit_order_no order by create_time desc)rn,
     --            limit_type,
     --            credit_order_no,
     --            target_total_limit,
     --            limit_begin_time,
     --            limit_end_time
     --       from odata.uquam_ps_product_limit_change  
     --      where data_date='${DATA_DATE}'
     --              and bddw_end_date ='9999-99-99') t13  --update 20230815
     --   on t1.loan_id = t13.credit_order_no 
     --  and t13.rn = 1  
      left join (select  credit_order_id
                        ,min(loan_id)  as loan_id
                   from odata.order_main_loan_order
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and order_type = 2
                   -- and sub_product_type in(12,14,15,16,17,18,19,21,22,24)
                    and status in (7,8,15)
                  group by credit_order_id
                ) t2 --取授信下第一笔有效借据用于关联核算取核心客户号及产品号
        on t1.loan_id = t2.credit_order_id
      left join odata.sllv_mb_acct t3
        on t2.loan_id = t3.cmisloan_no
       and t3.data_date='${DATA_DATE}'
       and t3.bddw_end_date='9999-99-99'
      left join odata.sym_cif_client t4        
        on t3.client_no=t4.client_no 
       and t4.data_date='${DATA_DATE}' 
       and t4.bddw_end_date='9999-99-99'
      left join odata.sym_mb_prod_type t15
       on t3.prod_type=t15.prod_type
       and t15.data_date = '${DATA_DATE}' 
       and t15.bddw_end_date = '9999-99-99'
--      left join (select  loan_id
--                        ,processor
--                        ,case when process_result = 1  then '通过'
--                              when process_result = 2  then '回退'
--                              when process_result = -1 then '拒绝'
--                              when process_result = -2 then '取消'
--                          end     as process_result
--                        ,row_number() over(partition by loan_id order by process_time desc) as seq 
--                   from odata.order_order_audit_operation_log 
--                  where data_date='${DATA_DATE}' 
--                    and bddw_end_date='9999-99-99'
--                    and sub_product_type ='25'             --产品子类型为锡惠贷企业融
--                    and process_node is not null
--                ) t6
--        on t1.loan_id=t6.loan_id  
--       and t6.seq=1
--      left join odata.sso_upms_user t7 
--        on t6.processor=t7.user_id 
--       and t7.data_date='${DATA_DATE}' 
--       and t7.bddw_end_date='9999-99-99'
      left join 
       (select  t8.business_key_,t13.username,t13.user_id,t10.full_msg  
                  from 
              (
               select a.business_key_
                      ,b.proc_inst_id_
                      ,b.assignee_ 
                      ,b.id_
                      ,row_number() over(partition by b.proc_inst_id_ order by b.end_time_ desc) as rn
               from odata.work_act_hi_procinst a 
               left join odata.work_act_hi_taskinst b 
               on a.proc_inst_id_ = b.proc_inst_id_
               and b.data_date='${DATA_DATE}'
               and b.bddw_end_date='9999-99-99'
               where a.data_date='${DATA_DATE}' 
               and a.bddw_end_date='9999-99-99'
               and b.task_def_key_ in  ('XHD_RISK_TRIAL'           --授信初审岗
                                        ,'XHD_CREDIT_RECHECK'      --授信复审岗
                                        ,'XHD_CREDIT_FINAL_TRIAL'  --授信终审岗
										,'CREDIT_RISK_FIRST_TRIAL' --孚厘授信初审岗码值
										,'CREDIT_RISK_RECHECK')    --孚厘授信复审岗码值
               ) t8
     left join (
               select task_id_
                      ,get_json_object(full_msg_,'$.auditResult') as full_msg
               from odata.work_act_hi_comment where data_date='${DATA_DATE}'
               and bddw_end_date='9999-99-99'
               and type_='comment'
               and get_json_object(full_msg_,'$.auditResult') in ('PUSH','ROLLBACK','BACK','REFUSE','CANCEL','REVOKE')
               ) t10
       on t8.id_=t10.task_id_
 left join (select t11.username,t11.user_id
                        from odata.sso_upms_user t11
     inner join odata.oa_hrmresource t12  
       on t11.username = t12.workcode
                        and t12.data_date = '${DATA_DATE}' 
                        and t12.bddw_end_date = '9999-99-99'
                        where t11.data_date = '${DATA_DATE}' 
                        and t11.bddw_end_date = '9999-99-99'
                        and t11.locked = 0  --0正常 1锁定
                                          ) t13
       on t8.assignee_ = t13.user_id
                         where t8.rn=1
                         ) p
        on t1.loan_id=p.business_key_
      left join odata.sso_upms_user t8             
        on t1.xsbank_salesman=t8.user_id 
       and t8.data_date='${DATA_DATE}' 
       and t8.bddw_end_date='9999-99-99'
     where t1.data_date='${DATA_DATE}'
       and t1.bddw_end_date='9999-99-99'
       and t1.sub_product_type in('25','42','44','45') --锡惠贷产品、锡享贷产品子分类、孚厘企业经营贷
       and substr(t1.apply_time,1,10) <= '${DATA_DATE}'