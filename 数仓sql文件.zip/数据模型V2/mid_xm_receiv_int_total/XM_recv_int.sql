insert overwrite table dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select 
nvl(t3.loan_id,'')
,''
,sum(
case when t3.interesttransferstatus='1' then (nvl(t3.int_bal,0)+nvl(t3.ovd_int_bal,0)+nvl(t3.pnlt_int_bal,0))/100
else 0 end
) as amt
from odata.slur_xm_loan_file_clear t3 
where t3.data_date='${DATA_DATE}'
and t3.bddw_end_date='9999-99-99'
group by nvl(t3.loan_id,'')
--union all 
-- XM026 减 减免利息发生额
--select loan_id
--       ,'XM026' as sence
--       ,sum(nvl(int_reduce_amt,0)/100) as amt
--from odata.slur_xm_term_status_file
--where data_date ='${DATA_DATE}' 
--and bddw_end_date ='9999-99-99'
--and int_reduce_amt > 0
--and channel_date=regexp_replace(date_add('${DATA_DATE}',-1),'-','')
--group by loan_id