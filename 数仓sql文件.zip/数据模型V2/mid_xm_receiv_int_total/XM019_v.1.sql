--XM019
insert overwrite table dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}')
             select 
                  w.loan_id     as loan_no,
                  'XM019'       as sence,
                  sum(nvl(w.int_bal,0)/100) + sum(nvl(w.ovd_int_bal,0)/100) int_bal
             from odata.slur_xm_loan_file_clear w
             inner join odata.slur_xm_loan_file_clear d
               on w.loan_id = d.loan_id
               and d.channel_date =  regexp_replace(date_add('${DATA_DATE}',-2),'-','')
               and d.data_date = date_add('${DATA_DATE}',-1)
               and d.interesttransferstatus = '1'
               and d.bddw_end_date='9999-99-99'
             where  w.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
               and w.loan_form = '2' 
               and w.interesttransferstatus = '2' 
               and w.data_date = '${DATA_DATE}'
               and w.bddw_end_date='9999-99-99'
             group by w.loan_id 
         
             union all
        
          select  
                w.loan_id     as loan_no,
                'XM019'       as sence,
                -1*sum(nvl(w.int_bal,0)/100) + -1*sum(nvl(w.ovd_int_bal,0)/100) int_bal 
          from odata.slur_xm_loan_file_clear w
          inner join odata.slur_xm_loan_file_clear d
            on w.loan_id = d.loan_id 
            and d.channel_date =  regexp_replace(date_add('${DATA_DATE}',-2),'-','')
            and d.interesttransferstatus = '1'
            and d.bddw_end_date='9999-99-99'
            and d.data_date=date_add('${DATA_DATE}',-1)
          where w.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
            and w.loan_form = '2' 
            and w.interesttransferstatus = '2'
            and w.bddw_end_date='9999-99-99'
            and w.data_date = '${DATA_DATE}'
            and exists (select 1
                        from odata.slur_dzz_compensatory_detail f
                        where f.data_date = '${DATA_DATE}'
                          and f.bddw_end_date='9999-99-99'
						  and f.comps_status = 'S'
						  and f.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                          and w.loan_id = f.loan_no)
          group by w.loan_id 
