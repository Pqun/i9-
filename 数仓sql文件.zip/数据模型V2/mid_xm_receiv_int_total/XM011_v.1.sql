--XM011
insert into dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}') 		 
              select 
                 w.loan_id,
                 'XM011' as sence,
                 sum(w.int_repay/100)-sum(d.int_repay/100) int_amt 
               from odata.slur_xm_loan_file_clear w 
               inner join odata.slur_xm_loan_file_clear d 
                 on w.loan_id = d.loan_id 
                 and d.data_date=date_add('${DATA_DATE}',-1) 
                 and d.bddw_end_date='9999-99-99'
                 and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
                 and d.interesttransferstatus = '1'
               where w.channel_date =  regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
                 and w.data_date='${DATA_DATE}' 
                 and w.bddw_end_date='9999-99-99' 
               group by w.loan_id
               
          union all 
             select w.loan_id,
                    'XM011' as sence,
                    sum(nvl(w.int_today,0)/100) int_today 
               from odata.slur_xm_loan_file_clear w
              where w.cur_date = w.start_date
                and w.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
                and w.int_today > 0
                and w.data_date='${DATA_DATE}' 
                and w.bddw_end_date='9999-99-99'
           group by w.loan_id
          union all 
             select aa.loan_id,
                    'XM011' as sence,
                    sum(int_amt) 
              from (     select a.loan_id,
                                -1*sum(d.int_amt/100) int_amt 
                           from odata.slur_xm_loan_file_clear a
                     inner join odata.slur_xm_loan_file_clear b
                             on a.loan_id = b.loan_id
                            and b.data_date=date_add('${DATA_DATE}',-1) 
                            and b.bddw_end_date='9999-99-99'
                            and b.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
                            and b.interesttransferstatus  <> '2'
                     inner join odata.slur_xm_repay_item_file d
                             on a.loan_id = d.loan_id
                            and d.data_date='${DATA_DATE}' 
                            and d.bddw_end_date='9999-99-99'
                            and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                          where a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
                            and a.data_date='${DATA_DATE}' 
                            and a.bddw_end_date='9999-99-99'
                            and exists (select 1 from odata.slur_dzz_compensatory_detail c where c.loan_no = d.loan_id and c.comps_status = 'S' and c.data_date = '${DATA_DATE}' and c.term_no = d.term_no and c.channel_date <regexp_replace(date_add('${DATA_DATE}',-1),'-','') )
                       group by a.loan_id      
                      union all  
                         select a.loan_id,
                                sum(nvl(d.int_amt,0)/100) int_amt 
                           from odata.slur_xm_loan_file_clear a 
                     inner join odata.slur_xm_loan_file_clear b
                             on a.loan_id = b.loan_id
                            and b.data_date=date_add('${DATA_DATE}',-1) 
                            and b.bddw_end_date='9999-99-99'
                            and b.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
                            and b.interesttransferstatus = '2'
                     inner join odata.slur_xm_repay_item_file d
                             on a.loan_id = d.loan_id
                            and d.data_date='${DATA_DATE}' 
                            and d.bddw_end_date='9999-99-99'
                            and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                          where a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
                            and a.data_date='${DATA_DATE}' 
                            and a.bddw_end_date='9999-99-99'
                            and exists (select 1 from odata.slur_dzz_compensatory_detail c where c.loan_no = d.loan_id and c.comps_status = 'S' and c.data_date = '${DATA_DATE}' and c.channel_date <regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
                            and not exists (select 1 from odata.slur_dzz_compensatory_detail c where c.loan_no = d.loan_id and c.comps_status = 'S' and c.data_date = '${DATA_DATE}' and c.term_no = d.term_no and c.channel_date <regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
                       group by a.loan_id  
                          )  aa
                   group by aa.loan_id  
