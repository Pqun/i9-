--XM013
insert into dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}') 
              select 
                 w.loan_id  as loan_no,
                 'XM013' as sence,
                 sum(w.pnlt_int_repay/100)-sum(d.pnlt_int_repay/100) as pnlt_int_amt 
               from odata.slur_xm_loan_file_clear w 
               inner join odata.slur_xm_loan_file_clear d 
                 on w.loan_id = d.loan_id 
                and d.data_date=date_add('${DATA_DATE}',-1) 
                and d.bddw_end_date='9999-99-99'
                and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
                and d.interesttransferstatus = '1'
              where w.channel_date =  regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
                and w.data_date='${DATA_DATE}' 
                and w.bddw_end_date='9999-99-99' 
           group by w.loan_id
          union all 
             select aa.loan_no,
                    'XM013' as sence,
                    sum(PNLT_INT_AMT) as PNLT_INT_AMT
              from (     select a.loan_id  as loan_no,
                                -1*SUM(D.PNLT_INT_AMT/100) PNLT_INT_AMT
                           from odata.slur_xm_loan_file_clear a
                     inner join odata.slur_xm_loan_file_clear b
                             on a.loan_id = b.loan_id
                            and b.data_date=date_add('${DATA_DATE}',-1) 
                            and b.bddw_end_date='9999-99-99'
                            and b.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
                            and b.interesttransferstatus  <> '2'
                     inner join odata.slur_xm_repay_item_file d
                             on a.loan_id = d.loan_id
                            and d.data_date='${DATA_DATE}' 
                            and d.bddw_end_date='9999-99-99'
                            and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                          where a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
                            and a.data_date='${DATA_DATE}' 
                            and a.bddw_end_date='9999-99-99'
                            and exists (select 1 from odata.slur_dzz_compensatory_detail c where c.data_date='${DATA_DATE}' and c.bddw_end_date='9999-99-99' and c.loan_no = d.loan_id and c.comps_status = 'S' and c.term_no = d.term_no and c.channel_date <regexp_replace(date_add('${DATA_DATE}',-1),'-','') )
                       group by a.loan_id      
                      union all  
                         select a.loan_id,
                                SUM(D.PNLT_INT_AMT/100) PNLT_INT_AMT
                           from odata.slur_xm_loan_file_clear a 
                     inner join odata.slur_xm_loan_file_clear b
                             on a.loan_id = b.loan_id
                            and b.data_date=date_add('${DATA_DATE}',-1) 
                            and b.bddw_end_date='9999-99-99'
                            and b.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
                            and b.interesttransferstatus = '2'
                     inner join odata.slur_xm_repay_item_file d
                             on a.loan_id = d.loan_id
                            and d.data_date='${DATA_DATE}' 
                            and d.bddw_end_date='9999-99-99'
                            and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                          where a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
                            and a.data_date='${DATA_DATE}' 
                            and a.bddw_end_date='9999-99-99'
                            and exists (select 1 from odata.slur_dzz_compensatory_detail c where c.data_date='${DATA_DATE}' and c.bddw_end_date='9999-99-99' and c.loan_no = d.loan_id and c.comps_status = 'S' and c.comps_status = 'S' and c.channel_date <regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
                            and not exists (select 1 from odata.slur_dzz_compensatory_detail c where c.data_date='${DATA_DATE}' and c.bddw_end_date='9999-99-99' and c.loan_no = d.loan_id and c.comps_status = 'S' and c.term_no = d.term_no and c.channel_date <regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
                       group by a.loan_id  
                          )  aa
                   group by aa.loan_no 
