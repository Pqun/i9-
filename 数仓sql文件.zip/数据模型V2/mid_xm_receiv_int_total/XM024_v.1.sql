--XM024 罚息表外转表内
insert into dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}') 
select t1.loan_id
       ,'XM024'
       ,sum(nvl(t1.pnlt_int_bal, 0))/100
  from odata.slur_xm_loan_file_clear t1
  inner join odata.slur_xm_loan_file_clear t2
    on t1.loan_id = t2.loan_id
    and t2.data_date = date_add('${DATA_DATE}',-1)
    and t2.bddw_end_date = '9999-99-99'
    and t2.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
    and t2.interesttransferstatus = '2'
  where t1.data_date='${DATA_DATE}'
    and t1.bddw_end_date = '9999-99-99'
    and t1.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
    and t1.interesttransferstatus = '1'
    and not exists (select 1
                      from odata.slur_dzz_compensatory_detail dcd
                      where dcd.data_date='${DATA_DATE}'
                        and dcd.bddw_end_date = '9999-99-99'
		                and dcd.loan_no = t1.loan_id
                        and dcd.prod_type = '110126'
                        and dcd.comps_status = 'S'
                        and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
    and not exists (select 1
                      from odata.slur_acc_writeoff_hist awh
                      where awh.data_date='${DATA_DATE}'
                        and awh.bddw_end_date = '9999-99-99'
					    and awh.loan_no = t1.loan_id
                        and awh.tran_date <= regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
	group by t1.loan_id 	