--XM023
insert into dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}')
     select 
            w.loan_id              as loan_no,
            'XM023'                as sence,
            sum(nvl(w.int_bal,0)/100) as amt
       from odata.slur_xm_loan_file_clear w
 inner join odata.slur_xm_loan_file_clear d
         on w.loan_id = d.loan_id
        and d.data_date = date_add('${DATA_DATE}',-1)
        and d.bddw_end_date = '9999-99-99'
        and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
        and d.interesttransferstatus = '2'
      where w.data_date = '${DATA_DATE}'
        and w.bddw_end_date = '9999-99-99'
        and w.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
        and w.interesttransferstatus = '1'
        and not exists (select 1  
                          from odata.slur_acc_writeoff_hist aw 
                         where aw.data_date = '${DATA_DATE}' 
                           and aw.bddw_end_date = '9999-99-99'
						   and aw.loan_no = w.loan_id)
        and  not exists (select 1
                           from odata.slur_dzz_compensatory_detail dc 
                          where dc.data_date = '${DATA_DATE}' 
                            and dc.bddw_end_date = '9999-99-99'
							and dc.comps_status = 'S' 
                            and dc.channel_date <= regexp_replace(date_add('${DATA_DATE}',-1),'-','')
			                and dc.loan_no = w.loan_id)
   group by w.loan_id
