-- XM026 减 减免利息发生额
insert into dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}') 
select loan_id
       ,'XM026' as sence
       ,sum(nvl(int_reduce_amt,0)/100)
from odata.slur_xm_term_status_file
where data_date ='${DATA_DATE}' 
and bddw_end_date ='9999-99-99'
and int_reduce_amt > 0
and channel_date=regexp_replace(date_add('${DATA_DATE}',-1),'-','')
group by loan_id