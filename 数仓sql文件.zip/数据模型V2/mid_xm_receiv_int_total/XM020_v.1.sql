--XM020 罚息表内转表外
insert into dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}') 				 
    select w.loan_id                         as loan_no,
	       'XM020'                           as sence,
	       sum(nvl(w.pnlt_int_bal, 0) / 100) as pnlt_int_bal
      from odata.slur_xm_loan_file_clear w
inner join odata.slur_xm_loan_file_clear d
        on w.loan_id = d.loan_id
	   and d.data_date = date_add('${DATA_DATE}',-1)
       and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
       and d.interesttransferstatus = '1'
     where w.data_date = '${DATA_DATE}'
	   and w.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
       and w.loan_form = '2'
       and w.interesttransferstatus = '2'
       and not exists (select 1
                         from odata.slur_dzz_compensatory_detail dc
                        where dc.data_date = '${DATA_DATE}'
						  and dc.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                          and dc.comps_status = 'S'
						  and dc.loan_no = w.loan_id)
       and not exists (select 1
                         from odata.slur_acc_writeoff_hist awh
                        where awh.data_date = '${DATA_DATE}'
	                      and awh.prod_type = '110126' 
					      and substr(awh.tran_date,1,10) <= '${DATA_DATE}'
					      and awh.loan_no = w.loan_id)
       group by w.loan_id
