--XM003
insert into dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}') 
              select
                w.loan_id,
                'XM003',
                sum(w.int_today+int_total)/100
              from odata.slur_xm_loan_file_clear w
              where w.data_date = '${DATA_DATE}'
                and w.bddw_end_date = '9999-99-99'
                and w.cur_date = w.start_date
                and w.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
              group by w.loan_id 

union all

      select
        w.loan_id,
        'XM003',
        sum(w.int_total - d.int_total)/100
      from odata.slur_xm_loan_file_clear w
      inner join odata.slur_xm_loan_file_clear d 
        on w.loan_id = d.loan_id 
        and d.data_date = date_add('${DATA_DATE}',-1)
        and d.bddw_end_date = '9999-99-99'
        and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
        and d.interesttransferstatus = '1'
      where w.data_date = '${DATA_DATE}'
        and w.bddw_end_date = '9999-99-99'
        and w.channel_date =  regexp_replace(date_add('${DATA_DATE}',-1),'-','')
        group by w.loan_id 

union all 

      select
        a.loan_id,
        'XM003',
        sum(a.int_total - b.int_total) / 100  
      from odata.slur_xm_loan_file_clear a
      inner join odata.slur_xm_loan_file_clear b
        on a.loan_id = b.loan_id
        and b.data_date = date_add('${DATA_DATE}',-1)
        and b.bddw_end_date = '9999-99-99'
        and b.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
        and b.interesttransferstatus = '2'
        where a.data_date = '${DATA_DATE}'
          and a.channel_date =  regexp_replace(date_add('${DATA_DATE}',-1),'-','')
          and a.loan_id in (select dc.loan_no
                              from odata.slur_dzz_compensatory_detail dc
                             where dc.data_date = date_add('${DATA_DATE}',-1)
                               and dc.bddw_end_date = '9999-99-99'
                               and dc.prod_type = '110126'
                               and dc.comps_status = 'S'
                               and dc.channel_date <= regexp_replace(date_add('${DATA_DATE}',-2),'-',''))
       group by a.loan_id
	   