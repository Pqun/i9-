insert overwrite table dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}')
  select /*+ REPARTITION(1) */ 
    yjlx.bill_no,
    '',
  sum(case 
        when yjlx.scene in ('XM003','XM005','XM023','XM024','XM24_01','XM23_01') then yjlx.receiv_int
        else -yjlx.receiv_int 
       end ) as amt
from dwd.mid_xm_recv_int_scene_tran yjlx
where yjlx.data_date = '${DATA_DATE}'
  and yjlx.receiv_int<>0
group by yjlx.bill_no 