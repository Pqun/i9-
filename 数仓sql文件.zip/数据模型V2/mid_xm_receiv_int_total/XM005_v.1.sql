--XM005
insert into dwd.mid_xm_recv_int_scene_tran partition(data_date='${DATA_DATE}') 		 
    select  w.loan_id    as loan_no,
            'XM005'      as sence,	 
            sum(nvl(w.pnlt_int_total,0) - nvl(d.pnlt_int_total,0))/100 pnlt_int_total  
      from  odata.slur_xm_loan_file_clear w
inner join  odata.slur_xm_loan_file_clear d 
        on  w.loan_id = d.loan_id 
       and  d.data_date=date_add('${DATA_DATE}',-1) 
       and  d.bddw_end_date='9999-99-99'
       and  d.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
       and  d.interesttransferstatus = '1'
     where  w.channel_date =  regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
       and  w.loan_form = '2' 
       and  w.data_date='${DATA_DATE}' 
       and  w.bddw_end_date='9999-99-99' 
  group by  w.loan_id 

     union all 
     
    select  dc.loan_no   as loan_no,
            'XM005'      as sence,	
            sum(nvl(xl.pnlt_int_total,0)/100-nvl(xll.pnlt_int_total,0)/100)  as pnlt_int_total1
      from (select 
	      distinct loan_no  --排除同一借据号代偿多个期次的问题，只需取一个借据号即可
		      from odata.slur_dzz_compensatory_detail 
	         where data_date = date_add('${DATA_DATE}',-1) 
		       and bddw_end_date = '9999-99-99'
			   and prod_type = '110126'
			   and comps_status = 'S'
			   and channel_date <= regexp_replace(date_add('${DATA_DATE}',-2),'-','')) dc 
      inner join odata.slur_xm_loan_file_clear xl
        on  dc.loan_no = xl.loan_id 
       and  xl.data_date='${DATA_DATE}' 
       and  xl.bddw_end_date='9999-99-99'
       and  xl.channel_date =  regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
       and  xl.loan_form ='2'
inner join  odata.slur_xm_loan_file_clear xll
        on  xl.loan_id = xll.loan_id
       and  xll.data_date=date_add('${DATA_DATE}',-1) 
       and  xll.bddw_end_date='9999-99-99'
       and  xll.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
       and  xll.interesttransferstatus = '2'
  group by  dc.loan_no

  union all
    select  dc.loan_no   as loan_no,
            'XM005'      as sence,	 
            -sum(nvl(t.pnlt_int_total,0)/100-nvl(tt.pnlt_int_total,0)/100)  as  pnlt_int_total2
      from  odata.slur_dzz_compensatory_detail dc 
inner join  odata.slur_xm_term_status_file_clear t
        on  dc.loan_no = t.loan_id 
       and  dc.term_no = t.term_no
       and  t.data_date='${DATA_DATE}' 
       and  t.bddw_end_date='9999-99-99'
       and  t.channel_date =  regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
inner join  odata.slur_xm_term_status_file_clear tt
        on  t.loan_id = tt.loan_id
       and  t.term_no =tt.term_no
       and  tt.data_date=date_add('${DATA_DATE}',-1) 
       and  tt.bddw_end_date='9999-99-99'
       and  tt.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
     where  dc.channel_date <=  regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
       and  dc.data_date=date_add('${DATA_DATE}',-1) 
       and  dc.bddw_end_date='9999-99-99'
       and  dc.sl_id = 'XM'  
	   and  dc.comps_status = 'S'
  group by  dc.loan_no
