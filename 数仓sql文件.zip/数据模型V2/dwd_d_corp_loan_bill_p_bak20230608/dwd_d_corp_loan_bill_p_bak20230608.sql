--2.yangqihao.dwd_d_corp_loan_bill_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：非同业对公贷款借据信息表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive dwd层dwd.dwd_d_corp_loan_bill_p
--作    者：杨琦浩
--开发日期：2022-07-06
--直属经理：方杰
--来源表  ：odata.sym_mb_acct 账户基本信息表
--来源表  ：odata.sym_cif_client_type  客户类型
--来源表  ：odata.sym_mb_prod_type  产品类型定义表
--来源表  ：odata.sym_gl_prod_accounting 产品科目表
--来源表  ：odata.gl_gl_item_bal 科目余额表(日)
--来源表  ：odata.als_business_duebill 业务借据(账户)信息表
--来源表  ：odata.als_business_contract 业务合同信息表
--来源表  ：gdata.dim_g_partner_mapping_p 合作方mapping维表
--来源表  ：odata.als_user_info 用户基本信息
--来源表  ：odata.sym_mb_acct_balance 账户余额表
--来源表  ：odata.sym_mb_acct_int_detail 利息明细表
--来源表  ：odata.odata.sym_mb_invoice  单据表
--来源表  ：odata.als_ent_info 企业基本信息
--来源表  ：smart.js_201_dbwxx 担保物信息表
--来源表  ：adm.ods_code_mapping 源系统接口与ADM目标表参数对应表
--来源表  ：odata.sym_mb_agreement_loan 贷款签约表
--来源表  ：odata.slur_jcb_loan_info_final 金城网贷借据信息表
--来源表  ：odata.supacct_enterprise_loan_info 贷款信息表
--来源表  ：odata.slur_jcb_repay_plan_final 金城网贷还款计划表
--来源表  ：odata.slur_jcb_account_entry 金城网贷分录明细表
--来源表  ：odata.slur_jcb_loan 金城放款明细表
--来源表  ：odata.sym_mb_amend 业务信息变更操作记录
--来源表  ：odata.ols_loan_cont_info 支用合同信息表
--来源表  ：odata.acct_loan_category 贷款五级分类
--来源表  ：odata.plm_loan_info_detail 贷款信息详情
--目标表  ：dwd.dwd_d_corp_loan_bill_p
--修改历史：
--          1.杨琦浩   2022-07-06    新建
--          2.杨琦浩   2022-08-02    新增逾期本金、逾期利息字段
--          3.杨琦浩   2022-08-10    金城应收利息新增科目
--          4.邓权     2022-08-16    新增展期日期字段
--          5.华天顺   2022-08-22    新增本金和利息逾期日期字段
--          6.华天顺   2022-08-25    新增产品代码字段
--          7.杨琦浩   2022-09-20    新增是否银团贷款字段
--          8.杨琦浩   2022-09-28    修改对公贷款逾期本金、利息逻辑，锡惠贷担保方式逻辑
--          9.杨琦浩   2022-10-11    修改贷款用途、贷款用途明细分类、锡惠贷贷款合同号字段取数逻辑
--          10.杨琦浩  2022-10-18    新增放款账号、还款账号字段
--          11.杨琦浩  2022-11-01    修改金城应收未收利息取数逻辑
--          12.杨琦浩  2022-11-14    新增信贷业务类型字段
--          13.杨琦浩  2022-12-05    新增现转标志、核算状态字段
--          14.杨琦浩  2022-12-28    锡惠贷修改五级分类取数逻辑
--          15.杨琦浩  2023-01-11    修改实际利率取数逻辑
--          16.杨琦浩  2023-02-03    金城逾期利息修改为应还利息-优惠利息金额-实还利息、新增供应链归属字段
--          17.杨琦浩  2023-02-16    修改核心、供应链执行利率取数逻辑    
--          18.杨琦浩  2023-02-20    新增授信合同编号字段    
--          19.杨琦浩  2023-03-06    剔除失效授信合同以及新增其他担保方式字段
--          20.杨琦浩  2023-03-24    拆分供应链支付方式，修改信贷及供应链还款方式、还款频率取数逻辑
--          21.杨琦浩  2023-04-10    修复businesstype为Null取不到数据、信贷借据发放日期大于当前日期问题
--          22.杨琦浩  2023-04-04    金城逾期利息日期逻辑调整
--          23.杨琦浩  2023-04-17    金城贷款业务细类逻辑调整
--          25.杨琦浩  2023-05-17    新增项目ID字段
--          26.杨琦浩  2023-05-24    修复信贷借据表内利息转表外时应收利息有误问题
--          27.杨琦浩  2023-06-07    修改核心、锡惠贷对公逾期本金、逾期利息及逾期日期取数逻辑
--------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_corp_loan_bill_p_bak20230608 partition(data_date = '${DATA_DATE}')
select /*+ REPARTITION(1) */
nvl(a.cmisloan_no,'') as bill_no --借据号
,nvl(c.prod_desc,'') as prod_name --产品名称
,nvl(a.base_acct_no,'') as acct_no --账号
,nvl(a.acct_seq_no,'') as acct_seq_no --账户序列号
,'01' as accting_cacl_mode --会计核算方式 01 表内 02 表外
,nvl(d.gl_code_a,'') as subj_no --本金余额明细科目号
,nvl(e.gl_name,'') as subj_name --本金余额明细科目名称
,nvl(a.client_no,'') as cust_id --客户号
,nvl(a.acct_name,'') as cust_name --客户名称
--,nvl(f.businesssum,0) as credit_limit --授信额度
,nvl(h.businesssum,0) as credit_limit --授信额度
,nvl(a.sched_mode,'') as repay_mode --还款方式
,nvl(regexp_replace(h.putoutdate,'/','-'),'') as loan_grant_date --贷款发放日期
,'00:00:00' as loan_grant_time --贷款发放时间
,nvl(g.serialno,'') as loan_cont_no --贷款合同号
,'' as fin_supp_mode --贷款财政扶持方式
--,case when h.serialno='BD2020121600000001' then 'D'
--      when o.bdbhtbm is not null then 'B'
--      else nvl(s.t_code,'') end as loan_guar_mode --贷款担保方式
,nvl(g.vouchtype,'') as loan_guar_mode --贷款担保方式
,'企业经营贷款' as loan_purp --贷款用途 1：企业经营贷款
,'TR05' as pric_benc --定价基准
,nvl(g.status,'') as loan_cont_status --贷款合同状态
,nvl(regexp_replace(h.putoutdate,'/','-'),'') as loan_start_date --借据起始日期
,nvl(regexp_replace(h.maturity,'/','-'),'') as loan_mature_date --借据到期日期
,nvl(from_unixtime(unix_timestamp(a.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as loan_close_date --借据关闭日期/借据实际到期日
--,nvl(f.businesssum,0) as loan_amt --放款金额
,nvl(h.businesssum,0) as loan_amt --放款金额
,nvl(h.actualtermmonth,0) as total_loan_terms --放款总期数
,nvl(case when a.acct_status = 'C' then h.actualtermmonth else a.cur_stage_no end,0) as curr_term_no --当前期次
,case when g.ratetype='01' then 'RF02' else 'RF01' end as rate_type --利率类型
,nvl(v.real_rate,0) as real_rate --实际利率/执行利率
--,coalesce(h.executeyearrate,g.executeyearrate,0) as real_rate --实际利率/执行利率
--,nvl(g.executeyearrate,0) as real_rate --实际利率/执行利率
,nvl(a.partner_id,'') as partner_id --合作方编码
,nvl(i.fp_partner_name,'') as partner_name --合作方名称
,case when h.businesstype='1070010' then '02'
      when h.mfareaid='Model2' then '02' --线上
      else '01' end as sub_channel_type --渠道类型 01 柜台
,case when g.thirdpartyzip3 = '1' then 0.0493*100 else 1*100 end as invest_ratio --出资比例
,nvl(a.ccy,'') as ccy --币种
,case when a.acct_status = 'C' then from_unixtime(unix_timestamp(a.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd') else '' end as clear_date --结清日期
,nvl(case when h.classifyresult='01' then 'FQ01'
          when h.classifyResult='02' then 'FQ02'
          when h.classifyResult='03' then 'FQ03'
          when h.classifyResult='04' then 'FQ04'
          when h.classifyResult='05' then 'FQ05' 
          end,'')           as five_risk_level  --五级分类
--,case when (h.businesstype ='1070010' or (h.businesstype='1010010' and h.mfareaid='Model2')) then 
--      case when u.pay_type='01' then 1 --自主支付
--           when u.pay_type='02' then 2 --受托支付
--           when u.pay_type='03' then 3 --二次受托
--      else '' 
--      end
-- else case when g.paymentmode='010' then 1 
--      else 2 
--      end
-- end as payment_mode --支付方式
,case when g.paymentmode='010' then 1 else 2 end as payment_mode --支付方式
,nvl(j.username,'') as credit_tlr_name --信贷员姓名
,nvl(h.operateuserid,'') as credit_tlr_id --信贷员员工号
,nvl(h.ictype,'') as int_mode --计息方式
--,nvl(h.paycyc,'') as repay_freq --还款频率
,case when a.sched_mode='1' then '01' --sched_mode='1'等额本息
      when a.sched_mode='2' then '01' --sched_mode='2'等额本金
      when a.sched_mode='3' then '05' --sched_mode='3'一次还本付息
      when a.sched_mode='4' then '06' --sched_mode='4'按频率付息、一次还本
      when a.sched_mode='5' then '07' --sched_mode='5'按频率付息、任意本金
 else '' end repay_freq --还款频率
,nvl(k.amt_bal,0) as bal --余额
,case when a.accounting_status <> 'FYJ' then nvl(l.int_accrued,0) + nvl(l.int_adj,0) + nvl(l.int_posted_ctd,0)+nvl(m.outstanding,0)
      else 0 end as recv_int --应收未收利息
,nvl(d.gl_code_int_rec,'') as recv_int_subj_no --应收未收利息科目
,0 as int_adj --利息调整
,'' as int_adj_subj_no --利息调整科目
,nvl(t2.term_end_date,'') as int_overdue_date --利息拖欠日期
,'SYM' as source_system --来源系统
,nvl(g.direction,'') as loan_indust_type  --贷款投向行业
,nvl(case when a.acct_status = 'C' then 1 else 0 end,'') as is_setted --是否结清
,nvl(regexp_replace(h.putoutdate,'/','-'),'') as accting_date --记账日期
,'' as int_basis --计息基础
,nvl(n.industrytype,'') as cust_indust_type  --客户所属行业
,nvl(q.t_code,'') as loan_biz_detail --贷款业务细类
,nvl(g.purpose,'') as loan_purp_detail --贷款用途明细分类
,nvl(yq.pri_outstanding,0) as overdue_prin --逾期本金
,nvl(yq.int_outstanding,0) as overdue_int --逾期利息
,nvl(z.defer_mature_date,'') as defer_mature_date --展期日期
,nvl(t1.term_end_date,'') as pri_overdue_date --本金逾期日
,nvl(a.prod_type,'')              as prod_code        --产品代码
,nvl(a.branch,'')      as org_id --机构号
,case when a.prod_type='120105' then '1' else '0' end as is_syndicate_loan --是否银团贷款
,coalesce(t.loanaccountno,u.loan_account_no,'') as loan_acct_no --放款账号
,coalesce(u.repay_account_no,h.paybackaccount,'') as repay_acct_no --还款账号
,nvl(h.businesstype,'') as als_biz_type --信贷业务类型
,'02' as cash_tran_flag --现转标志 01 现 02 转
,nvl(a.accounting_status,'') as accting_status --核算状态
,nvl(h.gccustomerid,'') as supply_chn_belong --供应链归属
,nvl(w.relativeserialno,'') as credit_cont_no --授信合同编号
,nvl(g.vouchflag,'') as loan_sub_guar_mode --其他担保方式
,nvl(u.project_id,'') as project_id --项目ID
from (select * from odata.sym_mb_acct --账户基本信息表
      where data_date='${DATA_DATE}'
      and bddw_end_date='9999-99-99'
      and source_module = 'CL'     --贷款
      and lead_acct_flag = 'N'
      and from_unixtime(unix_timestamp(acct_open_date,'yyyyMMdd'),'yyyy-MM-dd') <= '${DATA_DATE}'
      ) a     --限制非主账户
inner join odata.sym_cif_client_type b --客户类型
      on a.client_type = b.client_type
      and b.data_date='${DATA_DATE}'
      and b.bddw_end_date='9999-99-99'
      and b.is_individual = 'N' --对公
left join odata.sym_mb_prod_type c --产品类型定义表
      on a.prod_type=c.prod_type
      and c.data_date='${DATA_DATE}'
      and c.bddw_end_date='9999-99-99'
left join odata.sym_gl_prod_accounting d --产品科目表
      on a.prod_type = d.prod_type
      and d.data_date='${DATA_DATE}'
      and d.bddw_end_date='9999-99-99'
      and d.accounting_status = 'ZHC'    --科目号
left join odata.gl_gl_item_bal e --科目余额表(日)
      on d.gl_code_a=e.gl_code
      and e.data_date='${DATA_DATE}'
      and e.bddw_end_date='9999-99-99'
      and e.gl_data_date='${DATA_DATE}'
      and org_code='000000'
--left join
--(
--select serialno,relativeserialno2,sum(businesssum) as businesssum
--       from odata.als_business_duebill --业务借据(账户)信息表
--       where data_date='${DATA_DATE}'
--       and bddw_end_date='9999-99-99'
--       and nvl(businesstype,'') not in ('1020010','2010') --剔除贴现
--       group by serialno,relativeserialno2
--)f
--on a.cmisloan_no=f.serialno
left join odata.als_business_duebill h --业务借据(账户)信息表
     on a.cmisloan_no=h.serialno
     and h.data_date='${DATA_DATE}'
     and h.bddw_end_date='9999-99-99'
     and nvl(h.businesstype,'') not in ('1020010','2010') --剔除贴现
left join odata.als_business_contract g --业务合同信息表
     on h.relativeserialno2=g.serialno
     and g.data_date='${DATA_DATE}'
     and g.bddw_end_date='9999-99-99'
     --and g.businesstype like '30%'
left join gdata.dim_g_partner_mapping_p i --合作方mapping维表
     on a.partner_id=i.fp_partner_id
left join odata.als_user_info j --用户基本信息
     on h.operateuserid=j.userid
     and j.data_date='${DATA_DATE}'
     and j.bddw_end_date='9999-99-99'
left join 
(
select internal_key,
           sum(case when amt_type = 'BAL'  then total_amount_prev else 0 end) amt_bal   --发放余额
           --sum(case when amt_type = 'PRD'  then total_amount_prev else 0 end) amt_prd,   --逾期本金
           --sum(case when amt_type = 'INTP' then total_amount_prev else 0 end) amt_intp,  --逾期利息
           --sum(case when amt_type = 'ODPP' then total_amount_prev else 0 end) amt_odpp,  --逾期罚息
           --sum(case when amt_type = 'ODIP' then total_amount_prev else 0 end) amt_odip,  --逾期复利
           --sum(case when amt_type = 'OSL'  then total_amount_prev else 0 end) amt_osl    --未到期余额
           from odata.sym_mb_acct_balance --账户余额表
           where data_date = '${DATA_DATE}'
           and bddw_end_date = '9999-99-99'
           group by internal_key
) k
on a.internal_key=k.internal_key
left join 
(select internal_key,sum(int_accrued) int_accrued
        ,sum(int_adj) int_adj
        ,sum(int_posted_ctd) int_posted_ctd  
        from odata.sym_mb_acct_int_detail --利息明细表
        where data_date = '${DATA_DATE}'
        and bddw_end_date='9999-99-99' 
        and nvl(int_class,'') not like 'ODI%'
        group by internal_key
) l
on a.internal_key=l.internal_key
left join 
(
  select  internal_key
                     ,sum(outstanding) as outstanding
               from  odata.sym_mb_invoice  --单据表
              where  data_date='${DATA_DATE}'
                and  bddw_end_date='9999-99-99'
                and  amt_type<>'PRI'
                and  nvl(amt_type,'') not like 'ODI%'
                and  outstanding<>0
                and  fully_settled = 'N'
                and  due_date <= regexp_replace('${DATA_DATE}','-','')
           group by  internal_key
)m 
on a.internal_key=m.internal_key
left join odata.als_ent_info n --企业基本信息
      on a.client_no = n.customerid
      and n.data_date = '${DATA_DATE}'
      and n.bddw_end_date = '9999-99-99'
--left join (select bdbhtbm,bdbrmc from smart.js_201_dbwxx --担保物信息表
--           where data_date = '${DATA_DATE}'
--           and dbwlb in ('C02','C04')
--          group by bdbhtbm,bdbrmc) o
--       on g.serialno = o.bdbhtbm
--left join 
--(
--select  internal_key
--        ,prod_type as business_sub_type
--         from odata.sym_mb_acct --账户基本信息表
--         where data_date='${DATA_DATE}'
--         and bddw_end_date='9999-99-99'
--         and source_module = 'CL'     --对公贷款
--         and lead_acct_flag = 'N'
--) p
--on a.internal_key=p.internal_key
left join adm.ods_code_mapping q --源系统接口与ADM目标表参数对应表
on a.prod_type=q.s_code
and q.convert_id='6' --6 贷款业务细类
--left join adm.ods_code_mapping s --源系统接口与ADM目标表参数对应表
--on g.vouchtype=s.s_code
--and s.convert_id='8' --8 子担保方式
--left join odata.sym_mb_agreement_loan r --贷款签约表
--on a.internal_key=r.internal_key
--and r.data_date = '${DATA_DATE}'
--and r.bddw_end_date = '9999-99-99'
left join 
(
select amend_key
       ,from_unixtime(unix_timestamp(min(substr(before_val,18,8)),'yyyyMMdd'),'yyyy-MM-dd') origin_mature_date  --原始到期日
       ,from_unixtime(unix_timestamp(max(substr(after_val,18,8)),'yyyyMMdd'),'yyyy-MM-dd') defer_mature_date   --展期日期
       from odata.sym_mb_amend  --业务信息变更操作记录
       where data_date = '${DATA_DATE}' 
       and bddw_end_date = '9999-99-99' 
       and amend_type = 'MATE'
       group by amend_key
) z 
on a.internal_key = z.amend_key
left join (select internal_key
                 ,min(from_unixtime(unix_timestamp(due_date,'yyyyMMdd'),'yyyy-MM-dd')) as term_end_date
             from odata.sym_mb_invoice
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99'
              and amt_type = 'PRI'
              --and fully_settled = 'N'
              and outstanding > 0
              and due_date < regexp_replace('${DATA_DATE}','-','')
            group by internal_key) t1
  on a.internal_key = t1.internal_key
left join (select internal_key
                 ,min(from_unixtime(unix_timestamp(due_date,'yyyyMMdd'),'yyyy-MM-dd')) as term_end_date
             from odata.sym_mb_invoice
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99'
              and amt_type in ( 'INT','ODP')
              --and fully_settled = 'N'
              and outstanding > 0
              and due_date < regexp_replace('${DATA_DATE}','-','')
            group by internal_key) t2
  on a.internal_key = t2.internal_key
left join (
        select
	          ce.internal_key
             ,sum(case when ce.amt_type ='PRI' then ce.outstanding when ce.amt_type in ('INT','ODP') then 0 end) as pri_outstanding  --逾期本金
             ,sum(case when ce.amt_type ='PRI' then 0 when ce.amt_type in ('INT','ODP') then ce.outstanding end) as int_outstanding  --逾期利息
        from odata.sym_mb_invoice  ce
        where ce.data_date='${DATA_DATE}' 
          and ce.bddw_end_date='9999-99-99'
          and ce.outstanding >0
          and ce.due_date < regexp_replace('${DATA_DATE}','-','')
        group by ce.internal_key
) yq 
on a.internal_key = yq.internal_key 
left join odata.als_business_putout t
on h.relativeserialno1=t.serialno
and t.data_date='${DATA_DATE}'
and t.bddw_end_date='9999-99-99'
left join odata.supacct_enterprise_loan_info u
on h.serialno=u.iou_no
and u.data_date='${DATA_DATE}'
and u.bddw_end_date='9999-99-99'
left join odata.sym_mb_acct_int_detail v 
on a.internal_key=v.internal_key
and v.data_date='${DATA_DATE}'
and v.bddw_end_date='9999-99-99'
and v.int_class='INT'
left join odata.als_cl_occupy w 
on  g.serialno=w.objectno
and w.data_date='${DATA_DATE}'
and w.bddw_end_date='9999-99-99'
and w.objecttype='BusinessContract'
and nvl(w.remark,'') <> 'INVALID'
union all --金城
select /*+ REPARTITION(1) */
nvl(b.serialno,'') as bill_no --借据号
,nvl(c.prod_desc,'') as prod_name --产品名称
,nvl(a.loan_account_no,'') as acct_no --账号
,nvl(a.loan_acct_seq_no,'') as acct_seq_no --账户序列号
,'01' as accting_cacl_mode --会计核算方式 01 表内 02 表外
,'10410101' as subj_no --本金余额明细科目号
,'单位流动资金贷款-成本' as subj_name --本金余额明细科目名称
,nvl(a.cust_id,'') as cust_id --客户号
,nvl(a.cust_name,'') as cust_name --客户名称
,nvl(a.loan_amt,0) as credit_limit --授信额度
,nvl(a.repay_mode,'') as repay_mode --还款方式
,nvl(from_unixtime(unix_timestamp(a.loan_time,'yyyyMMddHHmmss'),'yyyy-MM-dd'),'') as loan_grant_date --贷款发放日期
,nvl(from_unixtime(unix_timestamp(a.loan_time,'yyyyMMddHHmmss'),'HH:mm:ss'),'') loan_grant_time --贷款发放时间
,nvl(d.serialno,'') as loan_cont_no --贷款合同号
,'' as fin_supp_mode --贷款财政扶持方式
,nvl(d.vouchtype,'') as loan_guar_mode --贷款担保方式
--,case when b.serialno='BD2020121600000001' then 'D'
--         when j.bdbhtbm is not null then 'B'
--         else nvl(k.t_code,'') end as loan_guar_mode --贷款担保方式
,'企业经营贷款' as loan_purp --贷款用途 1：企业经营贷款
,'TR05' as pric_benc --定价基准
,nvl(d.status,'') as loan_cont_status --贷款合同状态
,nvl(from_unixtime(unix_timestamp(a.loan_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as loan_start_date --借据起始日期
,nvl(from_unixtime(unix_timestamp(a.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as loan_mature_date --借据到期日期
,nvl(from_unixtime(unix_timestamp(a.real_maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as loan_close_date --借据关闭日期/借据实际到期日
,nvl(a.loan_amt,0) as loan_amt --放款金额
,nvl(a.term,0) as total_loan_terms --放款总期数
,nvl(case when a.settle_date is null then e.term else a.term end,0) as curr_term_no --当前期次
,'RF01' as rate_type --利率类型
,nvl(a.real_rate,0) as real_rate --实际利率/执行利率
--,coalesce(b.executeyearrate,d.executeyearrate,0) as real_rate --实际利率/执行利率
--,nvl(b.executeyearrate,0) as real_rate --实际利率/执行利率
,nvl(a.platform_id,'') as partner_id --合作方编码
,nvl(a.platform_name,'') as partner_name --合作方名称
,case when b.businesstype='1070010' then '02'
      when b.mfareaid='Model2' then '02'
      else '01' end as sub_channel_type --渠道类型
,case when d.thirdpartyzip3 = '1' then 0.0493*100 else 1*100 end as invest_ratio --出资比例
,nvl(a.currency,'') as ccy --币种
,nvl(from_unixtime(unix_timestamp(a.settle_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as clear_date --结清日期
,case when b.classifyresult='01' then 'FQ01'
      when b.classifyResult='02' then 'FQ02'
      when b.classifyResult='03' then 'FQ03'
      when b.classifyResult='04' then 'FQ04'
      when b.classifyResult='05' then 'FQ05'
      else '' end as five_risk_level --贷款5级分类
,case when a.pay_type='01' then 1 --自主支付
     when a.pay_type='02' then 2 --受托支付
     when a.pay_type='03' then 3 --二次受托
     else '' end as payment_mode --支付方式
,nvl(f.username,'') as credit_tlr_name --信贷员姓名
,nvl(b.operateuserid,'') as credit_tlr_id --信贷员员工号
,nvl(b.ictype,'') as int_mode --计息方式
,case when a.repay_frequency='1' then '01'
      when a.repay_frequency='2' then '02'
      when a.repay_frequency='3' then '05'
      when a.repay_frequency='4' then '03'
      when a.repay_frequency='5' then '04'
      else '07' end as repay_freq --还款频率
,nvl(a.loan_bal,0) as bal --余额
,nvl(g.int_amt,0) as recv_int --应收未收利息
,'10600801' as recv_int_subj_no  --应收未收利息科目
,0 as int_adj --利息调整
,'' as int_adj_subj_no --利息调整科目
,nvl(m.due_date_int,'') as int_overdue_date --利息拖欠日期
,'SLUR' as source_system --来源系统
,nvl(case when d.direction='C' then h.industrytype else d.direction end,'') as loan_indust_type --贷款投向行业
,case when a.settle_date is null then 0 else 1 end as is_setted --是否结清
,nvl(date_add(regexp_replace(b.putoutdate,'/','-'),1),'') as accting_date --记账日期
,'' as int_basis --计息基础
,nvl(h.industrytype,'') as cust_indust_type  --客户所属行业
,'B2' as loan_biz_detail --贷款业务细类
--,'B9' as loan_biz_detail --贷款业务细类
,'经营贷款' as loan_purp_detail --贷款用途明细分类
,case when a.loan_status='02' then 0 else nvl(l.overdue_prin,0) end as overdue_prin --逾期本金 --02 结清
--,nvl(l.overdue_prin,0) as overdue_prin --逾期本金
,case when a.loan_status='02' then 0 else nvl(l.overdue_int,0)+nvl(l.overdue_pena,0) end as overdue_int --逾期利息 --02 结清
--,nvl(l.overdue_int,0) as overdue_int --逾期利息
,'' as defer_mature_date --展期日期
,nvl(m.due_date_pri,'') as pri_overdue_date --本金逾期日
,'120108'              as prod_code        --产品代码
,'100000'   as org_id --机构号
,'0' as is_syndicate_loan --是否银团贷款
,nvl(a.loan_account_no,'') as loan_acct_no --放款账号
,nvl(a.repay_account_no,'') as repay_acct_no --还款账号
,nvl(b.businesstype,'') as als_biz_type --信贷业务类型
,'02' as cash_tran_flag --现转标志 01 现 02 转
,'' as accting_status --核算状态
,nvl(b.gccustomerid,'') as supply_chn_belong --供应链归属
,nvl(n.relativeserialno,'') as credit_cont_no --授信合同编号
,nvl(d.vouchflag,'') as loan_sub_guar_mode --其他担保方式
,nvl(a.project_id,'') as project_id --项目ID
from 
(
select t1.loan_no 
       ,t1.loan_bal
       ,t1.over_due_date
       ,t1.loan_status 
       ,t1.loan_amt
       ,t1.contract_no
       ,t1.loan_time
       ,t1.lpr_int_rate_type
       ,t1.loan_date
       ,t1.maturity_date
       ,t1.real_maturity_date
       ,t1.term
       ,t1.currency
       ,t1.settle_date
       ,t1.int_rate*10000 as int_rate
       ,t1.repay_frequency
       ,t2.iou_no 
       ,t2.loan_account_no
       ,t2.loan_acct_seq_no
       ,t2.repay_mode
       ,t2.product_type
       ,t2.cust_id
       ,t2.cust_name
       ,t2.loan_amount
       ,t2.pay_type
       ,t2.platform_id
       ,t2.platform_name
       ,t2.repay_account_no
       ,t2.year_interest_rate*100 as real_rate
       ,t2.project_id
       from 
odata.slur_jcb_loan_info_final t1 --金城网贷借据信息表
left join odata.supacct_enterprise_loan_info t2 --贷款信息表
     on t1.loan_no = t2.partner_loan_no
     and t2.data_date='${DATA_DATE}'
     and t2.bddw_end_date='9999-99-99'
     where t1.data_date='${DATA_DATE}'
     and t1.bddw_end_date='9999-99-99'
     and t1.loan_status<>'03' --冲销
) a
left join odata.als_business_duebill b --业务借据(账户)信息表
     on a.iou_no = b.serialno
     and b.data_date='${DATA_DATE}'
     and b.bddw_end_date='9999-99-99' 
left join odata.sym_mb_prod_type c --产品类型定义表
     on a.product_type=c.prod_type
     and c.data_date='${DATA_DATE}'
     and c.bddw_end_date='9999-99-99'
left join odata.als_business_contract d --业务合同信息表
     on b.relativeserialno2 = d.serialno
     and d.data_date = '${DATA_DATE}'
       and d.bddw_end_date = '9999-99-99'
left join
(
select 
loan_no 
,min(term) as term from 
odata.slur_jcb_repay_plan_final  --金城网贷还款计划表
where ('${DATA_DATE}' between from_unixtime(unix_timestamp(inte_date,'yyyyMMdd'),'yyyy-MM-dd') 
                        and from_unixtime(unix_timestamp(due_date,'yyyyMMdd'),'yyyy-MM-dd'))
and data_date='${DATA_DATE}'
and bddw_end_date='9999-99-99'
group by loan_no
) e 
on a.loan_no=e.loan_no
left join odata.als_user_info f --用户基本信息
     on b.operateuserid=f.userid
     and f.data_date='${DATA_DATE}'
     and f.bddw_end_date='9999-99-99'     
left join
(      select  loan_no
               ,sum((case when trans_code ='2'  and bal_direction = 'D' then nvl(amt,0) else 0 end) --2、利息计提类：正常计提 逾期计提 表外计提 --D：借（收）
                -(case when trans_code ='4'  and bal_direction = 'C' then nvl(amt,0) else 0 end) --4、还款类：正常还款 逾期还款 非应计还款  --C:贷（付）
                -(case when trans_code ='3'  and bal_direction = 'D' then nvl(amt,0) else 0 end)) as int_amt --3、形态转移类
       from odata.slur_jcb_account_entry --金城网贷分录明细表
           where data_date='${DATA_DATE}'
           and bddw_end_date = '9999-99-99'
           and code in ('CAL1140040106','CAL1140060106','CALOT9006030106') --科目编号
       group by loan_no
) g 
on a.loan_no=g.loan_no
left join odata.als_ent_info h --企业基本信息
     on h.data_date='${DATA_DATE}'
     and h.bddw_end_date='9999-99-99'
       and a.cust_id=h.customerid
--left join odata.slur_jcb_loan   i --金城放款明细表
--     on a.loan_no=i.loan_no
--     and i.data_date='${DATA_DATE}'
--     and i.bddw_end_date='9999-99-99'
--left join (select bdbhtbm,bdbrmc from smart.js_201_dbwxx --担保物信息表
--           where data_date = '${DATA_DATE}'
--           and dbwlb in ('C02','C04')
--           group by bdbhtbm,bdbrmc) j
--on d.serialno = j.bdbhtbm
--left join adm.ods_code_mapping k --源系统接口与ADM目标表参数对应表
--on d.vouchtype=k.s_code
--and k.convert_id='8' --8 子担保方式
left join 
(
select loan_no
       ,sum(case when prin_amt-paid_prin_amt>0 and due_date < regexp_replace('${DATA_DATE}','-','') then prin_amt-paid_prin_amt end) as overdue_prin
       ,sum(case when int_amt-dis_int_amt-paid_int_amt>0 and due_date < regexp_replace('${DATA_DATE}','-','') then int_amt-dis_int_amt-paid_int_amt end) as overdue_int
       ,sum(case when oint_amt-paid_oint_amt>0 and due_date < regexp_replace('${DATA_DATE}','-','') then oint_amt-paid_oint_amt end) as overdue_pena 
       from odata.slur_jcb_repay_plan_final ----金城网贷还款计划表
       where data_date='${DATA_DATE}'
       and bddw_end_date='9999-99-99'
       --and plan_status='04' --逾期
       group by loan_no
) l 
on a.loan_no=l.loan_no
left join 
(
select 
loan_no
,min(case when prin_amt-paid_prin_amt>0
     then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) as due_date_pri  --逾期本金日期
,min(case when (int_amt-dis_int_amt-paid_int_amt>0 or oint_amt-paid_oint_amt>0)
     then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) as due_date_int  --逾期利息日期
from odata.slur_jcb_repay_plan_final  --金城网贷还款计划表
where data_date = '${DATA_DATE}'
and bddw_end_date = '9999-99-99'
--and plan_status='04'           数据有问题 --04:逾期
and due_date< regexp_replace('${DATA_DATE}','-','')
group by loan_no
) m
on a.loan_no=m.loan_no
left join odata.als_cl_occupy n
on  d.serialno=n.objectno
and n.data_date='${DATA_DATE}'
and n.bddw_end_date='9999-99-99'
and n.objecttype='BusinessContract'
and nvl(n.remark,'') <> 'INVALID'
union all
-- 锡惠贷
select   /*+ REPARTITION(1) */
                     nvl(t1.cmisloan_no,'')                                       as bill_no            --借据号
                    ,nvl(t2.prod_desc,'')                                         as prod_name          --产品名称
                    ,nvl(t1.base_acct_no,'')                                      as acct_no            --账号
                    ,''                                                           as acct_seq_no        --账户序列号
                    ,'01'                                                         as accting_cacl_mode  --会计核算方式
                    ,nvl(t3.gl_code_a,'')                                         as subj_no            --本金余额明细科目号
                    ,nvl(t4.gl_code_name,'')                                      as subj_name          --本金余额明细科目名称
                    ,nvl(t1.client_no,'')                                         as cust_id            --客户号
                    ,nvl(t5.client_short,'')                                      as cust_name          --客户名称
                    ,nvl(t7.credit_amount,0)                                      as credit_limit       --授信额度
                    ,nvl(t9.repay_type,'')                                        as repay_mode         --还款方式
                    ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as loan_grant_date --贷款发放日期
                    ,'00:00:00'                                                   as loan_grant_time    --贷款发放时间
                    ,nvl(t8.contract_no,'')                                       as loan_cont_no       --贷款合同号
                    ,''                                                           as fin_supp_mode      --贷款财政扶持方式
                    ,case  when t18.loan_id  is null  then '005'
                           when t18.loan_id  is not null then '010'
                           else ''   end                                          as loan_guar_mode     --贷款担保方式
                    ,case when t9.loan_need_type = '1' then '企业经营性贷款'
                          when t9.loan_need_type = '2' then '个人消费贷款'
                          when t9.loan_need_type = '3' then '个人经营性贷款'
                          else nvl(t9.loan_need_type,'')
                          end                                                     as loan_purp          --贷款用途
                    ,'TR05'                                                       as pric_benc          --定价基准
                    ,''                                                           as loan_cont_status   --贷款合同状态
                    ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                                as loan_start_date    --借据起始日期
                    ,nvl(from_unixtime(unix_timestamp(t1.ori_maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                             as loan_mature_date   --借据到期日期
                    ,nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                       as loan_close_date    --借据关闭日期/借据实际到期日
                    ,nvl(t9.actual_loan_amount,0)                                 as loan_amt           --放款金额
                    ,nvl(t1.term,0)                                               as total_loan_terms   --放款总期数
                    ,nvl(t1.cur_stage_no,'')                                      as curr_term_no       --当前期次
                    ,'RF01'                                                       as rate_type          --利率类型
                    ,nvl(t10.real_rate,0)                                         as real_rate          --实际利率/执行利率
                    ,nvl(t1.partner_id,'')                                        as partner_id         --合作方编码
                    ,''                                                           as partner_name       --合作方名称
                    ,''                                                           as sub_channel_type   --渠道类型
                    ,'100'                                                        as invest_ratio       --出资比例
                    ,'CNY'                                                        as ccy                --币种
                    ,nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                        as clear_date         --结清日期
                    ,coalesce(dh_five.manual_five_class,cate_five.five_category,five.five_cate,'FQ01' ) as five_risk_level    --贷款5级分类
                    ,nvl(t9.payment_mode,'')                                      as payment_mode       --支付方式  
                    ,nvl(t6.xsbank_salesman,'')                                   as credit_tlr_name    --信贷员姓名
                    ,nvl(t11.realname,'')                                         as credit_tlr_id      --信贷员员工号
                    ,case t10.cycle_freq
                       when 'T1' then 'B99'
                       when 'M1' then 'B01'
                       when 'M3' then 'B02'
                       else ''
                         end                                                      as int_mode           --计息方式
                    --,nvl(t10.cycle_freq,'')                                       as repay_freq         --还款频率
                    ,case when t1.sched_mode='1' then '01'
                          when t1.sched_mode='2' then '01'
                          when t1.sched_mode='3' then '05'
                          when t1.sched_mode='4' then '06'
                          when t1.sched_mode='5' then '07'
                     else '' end repay_freq --还款频率
                    ,nvl(t12.total_amount_prev,0)                                 as bal                --余额
                    ,case when t1.accounting_status in ('ZHC','YUQ') then nvl(t77.int_accrued_sum,0) + nvl(t77.int_adj_sum,0) + nvl(t78.outstanding_sum,0) 
                          else 0 
                      end                                                         as recv_int           --应收未收利息
                    ,nvl(t3.gl_code_int_rec,'')                                   as recv_int_subj_no   --应收未收利息科目
                    ,0                                                            as int_adj            --利息调整
                    ,''                                                           as int_adj_subj_no    --利息调整科目
                    ,nvl(t16.term_end_date,'')                                    as int_overdue_date   --利息拖欠日期
                    ,'SLLV'                                                       as source_system      --来源系统
                    ,nvl(substr(t14.industry_involved,-5),'')         as loan_indust_type   --贷款投向行业
                    ,case when t1.acct_status = 'C' then 1 else 0 end             as is_setted          --是否结清
                    ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                                 as accting_date       --记账日期
                    ,''                                                           as int_basis          --计息基础
                    ,nvl(substr(t14.industry_involved,-5),'')         as cust_indust_type   --客户所属行业
                    ,'B2'                                                         as loan_biz_detail    --贷款业务细类
                    ,case when t9.loan_need_type in (1,3) then '经营贷款' else '其他' end   as loan_purp_detail   --贷款用途明细分类
                    ,nvl(t17.pri_outstanding,0)                                   as overdue_prin       --逾期本金
                    ,nvl(t17.int_outstanding,0)+nvl(t19.odp_outstanding,0)        as overdue_int        --逾期利息
                    ,''                                                           as defer_mature_date  --展期到期日
                    ,nvl(t15.term_end_date,'')                                    as pri_overdue_date   --本金逾期日
                    ,nvl(t1.prod_type,'')                                         as prod_code          --产品编码
                    ,'100000'                                                     as org_id             --机构号
                    ,'0'                                                          as is_syndicate_loan --是否银团贷款
                    ,''                                                           as loan_acct_no --放款账号
                    ,''                                                           as repay_acct_no --还款账号
                    ,'1010'                                                       as als_biz_type --信贷业务类型
                    ,'02'                                                         as cash_tran_flag --现转标志 01 现 02 转
                    ,nvl(t1.accounting_status,'')                                 as accting_status --核算状态
                    ,''                                                           as supply_chn_belong --供应链归属
                    ,nvl(t6.credit_order_id,'')                                   as credit_cont_no --授信合同编号
                    ,''                                                           as loan_sub_guar_mode --其他担保方式
                    ,''                                                           as project_id --项目ID
              from  odata.sllv_mb_acct t1
         left join  odata.sym_mb_prod_type t2
                on  t1.prod_type = t2.prod_type
               and  t2.data_date = '${DATA_DATE}'
               and  t2.bddw_end_date = '9999-99-99'
         left join  odata.sym_gl_prod_accounting t3 --产品科目表
                on  t1.prod_type = t3.prod_type
               and  t3.data_date='${DATA_DATE}'
               and  t3.bddw_end_date='9999-99-99'
               and  t3.accounting_status = 'ZHC'    
         left join  odata.gl_v_gl_subject t4 
                on  t3.gl_code_a = t4.gl_code
               and  t4.data_date='${DATA_DATE}'
               and  t4.bddw_end_date='9999-99-99' 
         left join  odata.sym_cif_client t5
                on  t1.client_no = t5.client_no
               and  t5.data_date='${DATA_DATE}'
               and  t5.bddw_end_date='9999-99-99' 
         left join  odata.order_main_loan_order t6
                on  t1.cmisloan_no = t6.loan_id
               and  t6.data_date='${DATA_DATE}'
               and  t6.bddw_end_date='9999-99-99' 
               and  t6.order_type = '2' --借款订单
               and  t6.sub_product_type = '25' --锡惠贷产品子分类
         left join  odata.order_main_credit_order t7
                on  t6.credit_order_id = t7.loan_id
               and  t7.data_date='${DATA_DATE}'
               and  t7.bddw_end_date='9999-99-99' 
               and  t7.sub_product_type = '25' --锡惠贷产品子分类
               and  t7.status = '3' --授信成功
--取授信合同下对应的借款合同               
         left join 
                    (
                    select b.credit_order_id,a.contract_no
                    from odata.order_contract_sign a
                    inner join odata.order_main_loan_order b
                    on a.loan_id = b.loan_id
                    and b.data_date = '${DATA_DATE}'
                    and b.bddw_end_date = '9999-99-99'
                    and b.status in('7','8') --还款中、已结清（首次用信成功）
                    where a.data_date = '${DATA_DATE}'
                    and a.bddw_end_date = '9999-99-99'
                    and a.sub_product_type = '25' --锡惠贷产品子分类
                    and a.signer_type = '6'   -- 企业法人
                    and a.contract_type = '41' -- 人民币流动资金贷款合同
                    )  t8             
                on t6.credit_order_id=t8.credit_order_id
         left join  odata.order_product_loan_info t9
                on  t1.cmisloan_no = t9.loan_id
               and  t9.data_date = '${DATA_DATE}'
               and  t9.bddw_end_date = '9999-99-99'
         left join  odata.sllv_mb_acct_int_detail t10
                on  t1.internal_key = t10.internal_key
               and  t10.int_class = 'INT'
               and  t10.data_date = '${DATA_DATE}'
               and  t10.bddw_end_date = '9999-99-99'
         left join  odata.sso_upms_user t11
                on  t6.xsbank_salesman=t11.user_id 
               and  t11.data_date='${DATA_DATE}' 
               and  t11.bddw_end_date='9999-99-99'
         left join  odata.sllv_mb_acct_balance t12
                on  t1.internal_key = t12.internal_key
               and  t12.data_date = '${DATA_DATE}'
               and  t12.bddw_end_date = '9999-99-99'
               and  t12.amt_type = 'BAL'
         --left join  odata.sym_gl_prod_accounting t13
         --       on  t1.prod_type = t13.prod_type 
         --      and  t13.accounting_status = 'ZHC' 
         --      and  t13.data_date = '${DATA_DATE}'
         --      and t13.bddw_end_date = '9999-99-99'
         left join  odata.order_company_info t14
                on  t6.credit_order_id = t14.loan_id
               and  t14.data_date = '${DATA_DATE}'
               and  t14.bddw_end_date = '9999-99-99'
         left join
                   (
                         select
                                 internal_key
                                ,sum(int_accrued) as int_accrued_sum
                                ,sum(int_adj) as int_adj_sum
                                ,sum(int_posted) as int_posted_sum
                          from  odata.sllv_mb_acct_int_detail
                         where  int_class in ('INT','ODP') 
                           and  data_date='${DATA_DATE}' 
                           and  bddw_end_date='9999-99-99'
                      group by  internal_key
                    )t77 
                on  t1.internal_key = t77.internal_key
         left join
                   (
                         select
                                 internal_key
                                ,sum(outstanding) as outstanding_sum
                          from  odata.sllv_mb_invoice
                         where  amt_type in ('INT','ODP') 
                           and  data_date='${DATA_DATE}' 
                           and  bddw_end_date='9999-99-99'
                      group by  internal_key
                   ) t78  
                on  t1.internal_key = t78.internal_key
         left join 
                    (
                         select 
                                 internal_key
                                ,min(from_unixtime(unix_timestamp(due_date,'yyyyMMdd'),'yyyy-MM-dd')) as term_end_date
                          from  odata.sllv_mb_invoice
                         where  data_date = '${DATA_DATE}'
                           and  bddw_end_date = '9999-99-99'
                           and  amt_type = 'PRI'
                           --and  fully_settled = 'N'
                           and outstanding>0
                           and  due_date < regexp_replace('${DATA_DATE}','-','')
                      group by  internal_key
                     ) t15
                on  t1.internal_key = t15.internal_key
         left join  
                    (
                         select 
                                 internal_key
                                ,min(from_unixtime(unix_timestamp(due_date,'yyyyMMdd'),'yyyy-MM-dd')) as term_end_date
                          from  odata.sllv_mb_invoice
                         where  data_date = '${DATA_DATE}'
                           and  bddw_end_date = '9999-99-99'
                           and  amt_type = 'INT'
                           --and  fully_settled = 'N'
                           and outstanding>0
                           and  due_date < regexp_replace('${DATA_DATE}','-','')
                      group by  internal_key
                     ) t16
                on  t1.internal_key = t16.internal_key
         left join 
                    (
                     select
                             ce.internal_key
                            ,sum(case when ce.amt_type ='PRI' then ce.outstanding when ce.amt_type in ('INT','ODP') then 0 end) as pri_outstanding  --逾期本金
                            ,sum(case when ce.amt_type ='PRI' then 0 when ce.amt_type in ('INT','ODP') then ce.outstanding end) as int_outstanding  --逾期利息
                      from  odata.sllv_mb_invoice  ce
                     where  ce.data_date='${DATA_DATE}' 
                       and  ce.bddw_end_date='9999-99-99'
                       and  ce.outstanding >0
                       and  ce.due_date < regexp_replace('${DATA_DATE}','-','')
                  group by  ce.internal_key
                    ) t17
                on  t1.internal_key = t17.internal_key
         left join 
                   (
                   select loan_id 
                   from  odata.order_coborrower_info  
                   where  data_date = '${DATA_DATE}'
                   and  bddw_end_date = '9999-99-99'
	                 and  borrower_type='2'                     --有担保人
	                 group by loan_id
                   ) t18
              on t6.credit_order_id=t18.loan_id    
         left join 
                   (
                    select
                    od.internal_key
                    ,sum(nvl(od.int_accrued,0)+nvl(od.int_adj,0)) as odp_outstanding  --逾期罚息
                    from odata.sllv_mb_od_int_detail  od
                    where od.data_date='${DATA_DATE}' 
                      and od.bddw_end_date='9999-99-99'
                      and od.int_class='ODP'
                    group by od.internal_key
                   )t19
         on t1.internal_key=t19.internal_key 
----五级分类----              
        left join 
         (
           select  
		        bill_no
			   ,case when five_cate ='1' then 'FQ01' 
                     when five_cate ='2' then 'FQ02' 
                     when five_cate ='3' then 'FQ03' 
                     when five_cate ='4' then 'FQ04' 
                     when five_cate ='5' then 'FQ05' 
                     end as five_cate 
			   ,repay_type
            from odata.ols_loan_cont_info  --支用合同信息表
           where data_date='${DATA_DATE}' 
             and bddw_end_date='9999-99-99' 
             and cont_status in ('105','106','107','108','109','110')  --105已放款 106已结清 107逾期 108核销 109终止 110关闭
         ) five 
   on t1.cmisloan_no=five.bill_no
 left join odata.acct_loan_category cate_five --贷款五级分类
   on trim(t1.cmisloan_no) = trim(cate_five.loan_id)
  and cate_five.data_date = '${DATA_DATE}'
  and cate_five.bddw_end_date = '9999-99-99'
 left join
         (
		  select 
		       loan_id
              ,prod_type
              ,case when manual_five_class = '正常'  then  'FQ01'
                    when manual_five_class = '关注'  then  'FQ02'
                    when manual_five_class = '次级'  then  'FQ03'
                    when manual_five_class = '可疑'  then  'FQ04'
                    when manual_five_class = '损失'  then  'FQ05'
                    end as manual_five_class
           from odata.plm_loan_info_detail --贷款信息详情
          where data_date = '${DATA_DATE}'
            and bddw_end_date = '9999-99-99'
            and manual_term_validity_date >= '${DATA_DATE}'
		  ) dh_five  
   on t1.cmisloan_no = dh_five.loan_id         
             where  t1.data_date = '${DATA_DATE}'
               and  t1.bddw_end_date = '9999-99-99'
               and  t1.prod_type = '120111'