--2.ygr.dwd_d_indv_credit_cont_p
--脚本名称：dwd_d_indv_credit_cont_p.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2022-08-25
--直属经理：方杰
--来源表  :odata.order_main_loan_order            订单主表
--来源表  :odata.order_credit_order_info          授信信息表
--来源表  :odata.order_custom_info                客户信息表
--来源表  :odata.order_order_audit_operation_log  订单审核操作日志记录表
--来源表  :odata.sllv_mb_acct                     账户基本信息表
--来源表  :odata.sym_cif_client                   客户信息表
--来源表  :odata.sym_cif_client_document          客户证件信息
--来源表  :odata.sso_upms_user                    历史流程实例表
--目标表  :dwd.dwd_d_indv_credit_cont_p   
--修改历史：
--          1.于国睿   2022-08-25    新建 
--          2.于国睿   2023-07-11    授信额度，授信申请状态，授信合同状态，授信起始日，授信到期日，授信期限改从额度中心获取
--          3.于国睿   2023-07-20    得物颐尔信欢太产品号写死
--          4.于国睿   2023-09-12    新增已用额度，经办人，审批人字段逻辑
--          5.于国睿   2023-09-19    审批人经办人只保留我行员工
--          6.于国睿   2023-10-31    新增字段渠道编号
--          7.于国睿   2023-12-15    授信额度逻辑新增从额度变更表获取，车商贷授信起始日到期日新增获取逻辑
---------------------------------------------------------------------------------------------------------------
--颐尔信,得物,欢太,车商贷
insert overwrite table dwd.dwd_d_indv_credit_cont_p partition(data_date='${DATA_DATE}',prod_code)
    select /*+ REPARTITION(1) */
          ''                                        as credit_app_no          --授信申请号
          ,coalesce(t1.loan_id,'')                  as credit_cont_no         --授信合同编号
          ,'01'                                     as cust_type              --客户类型
          ,nvl(t4.client_no,'')                     as cust_id                --客户号
          ,nvl(t5.client_short,'')                  as cust_name              --客户姓名
          ,case when t1.sub_product_type = 10 then '颐尔信'
                when t1.sub_product_type = 11 then '得物'
                when t1.sub_product_type = 20 then '欢太'
                else nvl(t12.prod_desc,'')          
            end                                     as prod_name              --产品名称
          ,nvl(t1.product_type,'')                  as biz_prod_code          --源业务系统产品名称
          ,nvl(t1.sub_product_type,'')              as biz_sub_prod_code      --源业务系统子产品号
          ,nvl(t6.document_type,'')                 as cert_type              --证件类型
          ,coalesce(t6.document_id,'')              as cert_no                --证件号码
          ,case when t1.status in (1,2,19)       
                then '001'  --申请中，审批中
                when t1.status in (4,5,6,7,8,9,13,14,15,16,17,18)     
                then '003'  --审批成功
                when t1.status in (11,12)         
                then '002'  --审批失败 
                else ''
            end                                     as credit_app_status      --授信申请状态
          ,case when t1.status in (1,2,14) 
                then '101'  --合同未签订
                when t1.status in (11,12) 
                then '102'  --审批作废
                when t10.effective_status in (1,3)
                then '103'  --额度生效
                when t1.status in (4,5,6,7,8,9,13,15,16,17,18) and (t10.effective_status = 2 or t10.credit_order_no is null)
                then '104'  --额度失效
                else ''
            end                                     as credit_cont_status     --授信合同状态 --update 20230711
          ,case when t10.limit_type = 1 then '0' --单次
                when t10.limit_type = 2 then '1' --循环
                when t1.product_model = 1 then '0'
                when t1.product_model = 2 then '1'
                else ''
            end                                     as cycle_flag             --循环标识
          ,'CNY'                                    as ccy                    --币种
          ,coalesce(t10.total_limit,t17.target_total_limit,0)             as credit_limit           --授信额度 --update 20231215 yuguorui
          ,nvl(round(months_between(substr(t10.limit_end_time,1,10),substr(t10.limit_begin_time,1,10)),0),'')   as credit_terms --授信期限--update 20230711
          ,'M'                                      as credit_term_type       --授信期限类型
          ,coalesce(substr(t10.limit_begin_time,1,10),t18.credit_start_time,'') as credit_start_date      --授信起始日期 --update 20231215 yuguorui
          ,coalesce(substr(t10.limit_end_time,1,10),t18.credit_end_time,'')   as credit_mature_date     --授信到期日期 --update 20231215 yuguorui
          ,case when t1.status in (4,5,6,7,8,9,13,15,16,17,18) and (t10.effective_status = 2 or t10.credit_order_no is null)  
                then '02'
                when t10.effective_status in (1,3) 
                then '01' --有效
                else ''
            end                                     as credit_status          --授信状态 --update 20230711
          ,nvl(substr(t1.apply_time,1,10),'')       as credit_app_date        --申请日期
          ,coalesce(t15.username,t14.username,'')   as approver               --审批人  update 20230912 yuguorui east报送新增逻辑
          ,''                                       as approve_opinion        --审批意见
          ,'2'                                      as loan_biz_class         --业务分类
          ,nvl(t1.apply_no,'')                      as third_party_app_no     --第三方申请流水号
          ,nvl(t9.loan_rate*100,0)                  as loan_rate              --贷款年利率(年%)
          ,''                                       as credit_manage_status   --授信处理状态
          ,''                                       as ip 
          ,''                                       as device_id
          ,''                                       as project_id             --项目ID
          ,nvl(t10.used_limit,0)                    as used_limit             --已用额度 update 20230912 yuguorui east报送新增字段
          ,nvl(t16.username,'')                     as oper_emp_id            --经办人  update 20230912 yuguorui east报送新增逻辑
          ,nvl(t1.channel_code,'')                     as credit_channel_id    --渠道编号  update 20231031 yuguorui 新增字段
          ,case when t1.sub_product_type = 10 then '110134' --颐尔信
                when t1.sub_product_type = 11 then '110140' --得物
                when t1.sub_product_type = 20 then '110155' --欢太
                else nvl(t11.prod_type,'2')         
            end                                     as prod_code 
      from odata.order_main_loan_order t1
      left join (select  credit_order_id
                        ,max(loan_id)  as loan_id
                   from odata.order_main_loan_order
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and order_type = 2 
                    and status in (7,8,15)
                    and sub_product_type in (6,10,11,20)
                  group by credit_order_id) t2
        on t1.loan_id = t2.credit_order_id 
      left join odata.uc_um_participant_user t4
        on t4.user_id = t1.user_id
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99' 
      left join odata.sym_cif_client t5
        on t5.client_no = t4.client_no
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
      left join odata.sym_cif_client_document t6
        on t4.client_no = t6.client_no
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
      left join odata.order_product_loan_info t9
        on t2.loan_id = t9.loan_id   
       and t9.data_date = '${DATA_DATE}' 
       and t9.bddw_end_date = '9999-99-99'
      left join odata.uquam_ps_product_limit t10 --update 20230711
        on t10.credit_order_no = t1.loan_id
       and t10.data_date='${DATA_DATE}'
       and t10.bddw_end_date='9999-99-99' 
      left join odata.sllv_mb_acct t11
        on t2.loan_id = t11.cmisloan_no
       and t11.data_date = '${DATA_DATE}' 
       and t11.bddw_end_date = '9999-99-99'
      left join odata.sym_mb_prod_type t12
        on t11.prod_type = t12.prod_type
       and t12.data_date = '${DATA_DATE}' 
       and t12.bddw_end_date = '9999-99-99'
      left join (select  loan_id
                        ,processor
                        ,case when process_result = 1  then '通过'
                              when process_result = 2  then '回退'
                              when process_result = -1 then '拒绝'
                              when process_result = -2 then '取消'
                          end     as process_result
                        ,row_number() over(partition by loan_id order by process_time desc) as seq 
                   from odata.order_order_audit_operation_log 
                  where data_date='${DATA_DATE}' 
                    and bddw_end_date='9999-99-99'
                ) t13
        on t1.loan_id = t13.loan_id  
       and t13.seq = 1
      left join (select t1.username,t1.user_id
                   from odata.sso_upms_user t1
                  inner join odata.oa_hrmresource t2  --update 20230919 yuguorui 获取我行员工
                     on t1.username = t2.workcode
                    and t2.data_date = '${DATA_DATE}' 
                    and t2.bddw_end_date = '9999-99-99'
                  where t1.data_date = '${DATA_DATE}' 
                    and t1.bddw_end_date = '9999-99-99'
                    and t1.locked = 0  --0正常 1锁定
                ) t14 
        on t13.processor = t14.user_id 
      left join (select t1.username,t1.user_id
                   from odata.sso_upms_user t1
                  inner join odata.oa_hrmresource t2  --update 20230919 yuguorui 获取我行员工
                     on t1.username = t2.workcode
                    and t2.data_date = '${DATA_DATE}' 
                    and t2.bddw_end_date = '9999-99-99'
                  where t1.data_date = '${DATA_DATE}' 
                    and t1.bddw_end_date = '9999-99-99'
                    and t1.locked = 0  --0正常 1锁定
                ) t15 --update 20230912 yuguorui 获取审批人工号
        on t1.curr_operator = t15.user_id 
      left join (select t1.username,t1.user_id
                   from odata.sso_upms_user t1
                  inner join odata.oa_hrmresource t2  --update 20230919 yuguorui 获取我行员工
                     on t1.username = t2.workcode
                    and t2.data_date = '${DATA_DATE}' 
                    and t2.bddw_end_date = '9999-99-99'
                  where t1.data_date = '${DATA_DATE}' 
                    and t1.bddw_end_date = '9999-99-99'
                    and t1.locked = 0  --0正常 1锁定
                ) t16 
        on t1.xsbank_salesman = t16.user_id --update 20230912 yuguorui 获取经办人工号
      left join (select credit_order_no 
                       ,target_total_limit
                       ,row_number() over(partition by credit_order_no order by create_time desc) as rn
                   from odata.uquam_ps_product_limit_change   --update 20231215 yuguorui
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                ) t17
        on t17.credit_order_no = t1.loan_id
       and t17.rn = 1
      left join odata.order_credit_order_info t18  --update 20231215 yuguorui
        on t1.loan_id = t18.loan_id
       and t18.data_date = '${DATA_DATE}'
       and t18.bddw_end_date = '9999-99-99'  
     where t1.data_date = '${DATA_DATE}' 
       and t1.bddw_end_date = '9999-99-99'  
       and t1.order_type = 1 
       and t1.sub_product_type in (6,10,11,20)
      
