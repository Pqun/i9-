---------------------------------------------------------------------------------------------------------------
--脚本名称：个人授信合同表特色业务.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2022-09-07
--直属经理：方杰
--来源表  :odata.order_main_loan_order            订单主表
--         odata.order_order_audit_operation_log  订单审核操作日志记录表
--         odata.sso_upms_user                    历史流程实例表
--         odata.uc_um_participant_user
--         odata.sllv_mb_acct
--         odata.order_audit_result_info
--         odata.order_product_loan_info
--修改历史：
--          1.于国睿   2022-09-07    新建  
---------------------------------------------------------------------------------------------------------------
--孚厘
insert overwrite table dwd.dwd_d_indv_credit_cont_p partition(data_date='${DATA_DATE}',prod_code)

    select ''                                       as credit_app_no          --授信申请号
	      ,nvl(t1.loan_id,'')                       as credit_cont_no         --授信合同编号
          ,'01'                                     as cust_type              --客户类型
          ,nvl(t2.client_no,'')                     as cust_id                --客户号
          ,nvl(t3.client_short,'')                  as cust_name              --客户姓名
          ,nvl(t5.prod_desc,'')                     as prod_name              --产品名称
          ,nvl(t1.product_type,'')                  as biz_prod_code          --源业务系统产品名称
          ,nvl(t1.sub_product_type,'')              as biz_sub_prod_code      --源业务系统子产品号
          ,nvl(t7.document_type,'')                 as cert_type              --证件类型
          ,coalesce(t7.document_id,'')              as cert_no                --证件号码
          ,case when t1.process_result in('拒绝','取消')       
                then '002' 
                when t1.process_result = '通过' 
				and t1.process_node in ('CREDIT_DECISIONS') 
				then '003' 
				else '001' 
			end                                     as credit_app_status      --授信申请状态
          ,''                                       as credit_cont_status     --授信合同状态
          ,case when t6.product_model = 1 then '0'
                when t6.product_model = 2 then '1'
				else ''
            end                       				as cycle_flag             --循环标识
          ,'CNY'                                    as ccy                    --币种
          ,nvl(t8.audit_amount,0)                   as credit_limit           --授信额度
          ,nvl(t8.audit_period,0)                   as credit_terms           --授信期限
          ,'M'                                      as credit_term_type       --授信期限类型
          ,nvl(from_unixtime(unix_timestamp(t4.acct_open_date,'yyyymmdd'),'yyyy-mm-dd'),'')   as credit_start_date      --授信起始日期
          ,nvl(from_unixtime(unix_timestamp(t4.maturity_date,'yyyymmdd'),'yyyy-mm-dd'),'')    as credit_mature_date     --授信到期日期
          ,case when t4.acct_status != 'C' then '01' 
		        else '02' 
			end                                     as credit_status          --授信状态
          ,nvl(substr(t9.static_time,1,10),'')      as credit_app_date        --申请日期
          ,nvl(t10.realname,'')                     as approver               --审批人
          ,nvl(t1.process_result,'')                as approve_opinion        --审批意见
		  ,'2'                                      as loan_biz_class         --业务分类
          ,nvl(t6.apply_no,'')                      as third_party_app_no     --第三方申请流水号
          ,nvl(t11.loan_rate*100,0)                 as loan_rate              --贷款年利率(年%)
          ,''                                       as credit_manage_status   --授信处理状态
		  ,''                                       as ip 
          ,''                                       as device_id
		  ,''                                       as project_id
		  ,t4.prod_type                             as prod_code
      from (select loan_id,
	               processor,
				   process_node,
				   user_id,
				   product_type,
				   sub_product_type,
                   case when process_result=1 then '通过'
                        when process_result=2 then '回退'
                        when process_result=-1 then '拒绝'
                        when process_result=-2 then '取消' 
				    end   as process_result,
                   row_number() over(partition by loan_id order by process_time desc) as seq 
              from odata.order_order_audit_operation_log 
             where data_date='${DATA_DATE}' 
			   and bddw_end_date='9999-99-99' 
			   and sub_product_type = 23 ) t1
      left join odata.uc_um_participant_user t2
	    on t2.user_id = t1.user_id
	   and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99' 
	  left join odata.sym_cif_client t3
	    on t3.client_no = t2.client_no
	   and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
	  left join odata.sllv_mb_acct t4
	    on t1.loan_id = t4.cmisloan_no
	   and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
	  left join odata.sym_mb_prod_type t5
	    on t4.prod_type = t5.prod_type
	   and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
	  left join odata.order_main_loan_order t6
	    on t1.loan_id = t6.loan_id
	   and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
	  left join odata.sym_cif_client_document t7
        on t2.client_no = t7.client_no
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
	  left join (select loan_id         --授信借据号
                       ,audit_amount    --审批贷款金额
					   ,audit_period    --审批贷款期限  
                       ,row_number() over (partition by loan_id order by create_time desc) as rn           --订单排序
                   from odata.order_audit_result_info --审批结果信息录入
                  where data_date = '${DATA_DATE}'
                    and bddw_end_date = '9999-99-99'
                    and process_node in ('CREDIT_DECISIONS')) t8
		on t1.loan_id = t8.loan_id
	   and t8.rn = 1 
	  left join (select min(node_create_time) as static_time --授信申请时间
                       ,loan_id               as loan_id     --授信借据号
                   from odata.order_order_audit_operation_log --订单审核操作日志记录表
                  where data_date = '${DATA_DATE}'
                    and bddw_end_date = '9999-99-99'
                    and process_node in ('NODE_START')
                  group by loan_id) t9
		on t1.loan_id = t9.loan_id
	  left outer join odata.sso_upms_user t10
        on t1.processor=t10.user_id 
	   and t10.data_date='${DATA_DATE}' 
	   and t10.bddw_end_date='9999-99-99'
	  left join odata.order_product_loan_info t11 
	    on t1.loan_id = t11.loan_id   
	   and t11.data_date = '${DATA_DATE}' 
	   and t11.bddw_end_date = '9999-99-99'
	 where t1.seq = 1
	  