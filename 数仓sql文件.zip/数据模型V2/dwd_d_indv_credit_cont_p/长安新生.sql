---------------------------------------------------------------------------------------------------------------
--脚本名称：dwd_d_indv_credit_cont_p.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2022-08-25
--直属经理：方杰
--来源表  :
--来源表  :
--来源表  :
--来源表  :
--来源表  :
--来源表  :
--来源表  :
--来源表  :
--修改历史：
--          1.于国睿   2022-08-25    新建  
---------------------------------------------------------------------------------------------------------------
--长安新生
insert overwrite table dwd.dwd_d_indv_credit_cont_p partition(data_date='${DATA_DATE}',prod_code)

    select ''                                       as credit_app_no          --授信合同编号
	      ,coalesce(t1.loan_id,'')                  as credit_cont_no         --授信合同编号
          ,'01'                                     as cust_type              --客户类型
          ,nvl(t4.client_no,'')                     as cust_id                --客户号
          ,nvl(t5.client_short,'')                  as cust_name              --客户姓名
          ,nvl(t9.prod_desc,'')                     as prod_name              --产品名称
          ,nvl(t1.product_type,'')                  as biz_prod_code          --源业务系统产品名称
          ,nvl(t1.sub_product_type,'')              as biz_sub_prod_code      --源业务系统子产品号
          ,nvl(t6.document_type,'')                 as cert_type              --证件类型
          ,coalesce(t6.document_id,'')              as cert_no                --证件号码
          ,case when t1.status in (1,2)       
                then '001'  --申请中，审批中
                when t1.status in (4,5,7,8,13,14,15)     
                then '003'  --审批成功
                when t1.status in (11,12)         
                then '002'  --审批失败 
                else ''
            end                                     as credit_app_status      --授信申请状态
          ,case when t1.status in (1,2,11,12,14,15) 
		        then '101'  --合同未签订
                when t1.status in (11,15) 
				then '102'  --审批作废
                when t1.status in (4,5,7,13) 
				then '103'  --额度生效
                when t1.status = 8 
				then '104'  --额度失效
                else ''
		    end                                     as credit_cont_status     --授信合同状态
          ,'0'                                    	as cycle_flag             --循环标识
          ,'CNY'                                    as ccy                    --币种
          ,nvl(t3.actual_loan_amount,0)             as credit_limit           --授信额度
          ,nvl(t3.actual_loan_period,'')            as credit_terms           --授信期限
          ,'M'                                      as credit_term_type       --授信期限类型
          ,nvl(t2.acct_open_date,'')                as credit_start_date      --授信起始日期
          ,nvl(t2.maturity_date,'')                 as credit_mature_date     --授信到期日期
          ,case when t2.acct_status != 'C'  
		        then '01' 
				when t2.acct_status = 'C' then '02'
                else ''				
		    end                                     as credit_status          --授信状态
          ,nvl(substr(t1.apply_time,1,10),'')       as credit_app_date        --申请日期
          ,''                                       as approver               --审批人
          ,''                                       as approve_opinion        --审批意见
		  ,'2'                                      as loan_biz_class         --业务分类
          ,nvl(t1.apply_no,'')                      as third_party_app_no     --第三方申请流水号
          ,nvl(t3.loan_rate*100,0)                  as loan_rate              --贷款年利率(年%)
          ,''                                       as credit_manage_status   --授信处理状态
		  ,''                                       as ip 
          ,''                                       as device_id
		  ,''                                       as project_id
		  ,t2.prod_type                             as prod_code 
      from odata.order_main_loan_order t1
      left join odata.sllv_nl_acct t2
	    on t1.receipt_no = t2.cmisloan_no
       and t2.data_date='${DATA_DATE}' 
       and t2.bddw_end_date='9999-99-99'
      left join odata.order_product_loan_info t3
        on t1.loan_id = trim(t3.loan_id)
       and t3.data_date='${DATA_DATE}' 
       and t3.bddw_end_date='9999-99-99'
	  left join odata.uc_um_participant_user t4
	    on t4.user_id = t1.user_id
	   and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99' 
	  left join odata.sym_cif_client t5
	    on t5.client_no = t4.client_no
	   and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
	  left join odata.sym_cif_client_document t6
        on t4.client_no = t6.client_no
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
	  left join odata.sym_mb_prod_type t9
	    on t2.prod_type = t9.prod_type   
	   and t9.data_date = '${DATA_DATE}' 
	   and t9.bddw_end_date = '9999-99-99'
     where t1.data_date = '${DATA_DATE}' 
       and t1.bddw_end_date = '9999-99-99'  
       and t1.order_type = 2
       and t1.product_type = 4 
       and t1.sub_product_type = 7
      
