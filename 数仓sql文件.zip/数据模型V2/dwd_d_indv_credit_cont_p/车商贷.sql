---------------------------------------------------------------------------------------------------------------
--脚本名称：个人授信合同表车商贷.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2022-08-29
--直属经理：方杰
--来源表  :odata.order_main_loan_order            订单主表
--来源表  :odata.order_credit_order_info          授信信息表
--来源表  :odata.order_custom_info                客户信息表
--来源表  :odata.order_order_audit_operation_log  订单审核操作日志记录表
--来源表  :odata.sso_upms_user                    历史流程实例表
--修改历史：
--          1.于国睿   2022-08-29    新建  
---------------------------------------------------------------------------------------------------------------
--车商贷
insert overwrite table dwd.dwd_d_indv_credit_cont_p partition(data_date='${DATA_DATE}',prod_code)

    select ''                                       as credit_app_no          --授信合同编号
          ,coalesce(t1.loan_id,'')                  as credit_cont_no         --授信合同编号
          ,'01'                                     as cust_type              --客户类型
          ,nvl(t4.client_no,'')                     as cust_id                --客户号
          ,nvl(t5.user_name,'')                     as cust_name              --客户姓名
          ,'车商贷'                                 as prod_name              --产品名称
          ,nvl(t1.product_type,'')                  as biz_prod_code          --源业务系统产品名称
          ,nvl(t1.sub_product_type,'')              as biz_sub_prod_code      --源业务系统子产品号
          ,nvl(t6.document_type,'')                 as cert_type              --证件类型
          ,coalesce(t6.document_id,t5.id_card,'')   as cert_no                --证件号码
          ,case when t1.status in (1,2)       
                then '001'  --申请中，审批中
                when t1.status in (4,5,7,8,13,14,15)     
                then '003'  --审批成功
                when t1.status in (11,12)         
                then '002'  --审批失败 
                else ''
            end                                     as credit_app_status      --授信申请状态
          ,case when t1.status in (1,2,11,12,14) 
		        then '101'  --合同未签订
                when t1.status in (11,15) 
				then '102'  --审批作废
                when t1.status in (4,5,7,13,15) 
				then '103'  --额度生效
                when t1.status = 8 
				then '104'  --额度失效
                else ''
		    end                                     as credit_cont_status     --授信合同状态
          ,'0'                                      as cycle_flag             --循环标识
          ,'CNY'                                    as ccy                    --币种
          ,nvl(t3.credit_line,0)                    as credit_limit           --授信额度
          ,nvl(round(months_between(t3.credit_end_time,t3.credit_start_time),0),'')     as credit_terms           --授信期限
          ,'M'                                      as credit_term_type       --授信期限类型
          ,nvl(t3.credit_start_time,'')             as credit_start_date      --授信起始日期
          ,nvl(t3.credit_end_time,'')               as credit_mature_date     --授信到期日期
          ,case when t3.credit_status=1
                then '01'
				when t3.credit_status=2
                then '02' 
				else ''
			end                                     as credit_status          --授信状态
          ,nvl(t1.apply_time,'')                    as credit_app_date        --申请日期
          ,nvl(t8.realname,'')                      as approver               --审批人
          ,nvl(t7.process_result,'')                as approve_opinion        --审批意见
		  ,'2'                                      as loan_biz_class         --业务分类
          ,''                                       as third_party_app_no     --第三方申请流水号
          ,nvl(t10.loan_rate*100,0)                 as loan_rate              --贷款年利率(年%)
          ,''                                       as credit_manage_status   --授信处理状态
		  ,''                                       as ip 
          ,''                                       as device_id
		  ,''                                       as project_id
		  ,t9.prod_type                             as prod_code
      from odata.order_main_loan_order t1
      left join (select  credit_order_id
                        ,min(loan_id)  as loan_id
                   from odata.order_main_loan_order
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and order_type = 2
                    and product_type = 5  
                    and sub_product_type = 6 
                    and status in (7,8,15)
                  group by credit_order_id) t2
	    on t1.loan_id = t2.credit_order_id
      left join odata.order_credit_order_info t3      
        on t1.loan_id = t3.loan_id 
       and t3.data_date = '${DATA_DATE}' 
       and t3.bddw_end_date = '9999-99-99' 
	  left join odata.uc_um_participant_user t4
	    on t4.user_id = t1.user_id
	   and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99' 
	  left join odata.order_custom_info t5
        on t1.loan_id = t5.loan_id
       and t5.data_date = '${DATA_DATE}' 
       and t5.bddw_end_date = '9999-99-99'
	  left join odata.sym_cif_client_document t6
        on t4.client_no = t6.client_no
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
      left join(select loan_id,
	                   processor,
                       case when process_result=1 then '通过'
                            when process_result=2 then '回退'
                            when process_result=-1 then '拒绝'
                            when process_result=-2 then '取消' 
					    end   as process_result,
                       row_number() over(partition by loan_id order by process_time desc) as seq 
                  from odata.order_order_audit_operation_log 
                 where data_date='${DATA_DATE}' 
				   and bddw_end_date='9999-99-99' ) t7
        on t1.loan_id = t7.loan_id  
	   and t7.seq = 1
      left join odata.sso_upms_user t8 
	    on t7.processor = t8.user_id 
	   and t8.data_date = '${DATA_DATE}' 
	   and t8.bddw_end_date = '9999-99-99'
	  left join odata.sllv_mb_acct t9
        on t9.cmisloan_no = t2.loan_id	
       and t9.data_date = '${DATA_DATE}' 
       and t9.bddw_end_date = '9999-99-99'		
	  left join odata.order_product_loan_info t10 
	    on t2.loan_id = t10.loan_id   
	   and t10.data_date = '${DATA_DATE}' 
	   and t10.bddw_end_date = '9999-99-99'
     where t1.data_date = '${DATA_DATE}' 
       and t1.bddw_end_date = '9999-99-99'  
       and t1.order_type = 1
       and t1.product_type = 5  
       and t1.sub_product_type = 6 
