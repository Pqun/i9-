--2.ygr.个人授信合同表-网贷
--脚本名称：授信合同表dwd.dwd_d_indv_credit_cont_p取数逻辑.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_indv_credit_cont_p分区表
--作    者：于国睿
--开发日期：2021-11-20
--直属经理：方杰
--来源表:odata.ols_crd_app_info                 授信申请表
--来源表:odata.ols_crd_un_app_info              联合贷授信申请表
--来源表:odata.ols_crd_un_jd_app_info           京东金条授信申请表
--来源表:odata.ols_loan_prd_info                贷款产品信息表
--来源表:odata.ols_crd_cont_info                授信合同信息表
--来源表:odata.ols_admin_sm_user                系统用户表
--目标表:dwd.dwd_d_indv_credit_cont_p
--修改历史：
--          1.于国睿   2021-11-20    新建
--          2.于国睿   2022-12-19    增加伊春联合贷产品
--          3.于国睿   2023-03-08    优先取ols_crd_cont_info的客户号
--          4.于国睿   2023-05-17    授信到期日改成直取
--          5.于国睿   2023-06-14    新增小赢张家港联合贷和微财数科助贷产品
--          6.于国睿   2023-09-12    新增字段已用额度，经办人，授信状态逻辑改从额度中心获取
--          7.于国睿   2023-10-31    新增字段渠道编号
--          8.于国睿   2023-11-09    新增乐云小贷，宁波通商联合贷产品
--          9.姚威     2023-11-16    修改授信期限，授信期限类型逻辑
--         10.姚威     2023-02-01    新增小赢通商联合贷，小赢兰州联合贷
--         11.姚威     2024-04-11    新增拍拍联合融担模式消费贷
--         12.姚威     2024-05-14    新增字节星选  
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_indv_credit_cont_p partition(data_date='${DATA_DATE}',prod_code)
--行内网贷
     select  /*+ REPARTITION(1) */
	         nvl(t1.app_no,'')           as credit_app_no        --授信申请号
            ,nvl(t1.crd_cont_no,'')      as credit_cont_no       --授信合同号
            ,'01'                        as cust_type            --客户类型
            ,coalesce(t3.cust_id_core,t1.cust_id_core,t10.client_no,'')     
			                             as cust_id              --客户号
            ,nvl(t1.cust_name,'')        as cust_name            --客户姓名
            ,case when t1.prd_code='10071001001' and t5.crd_cont_no is not null 
			      then '洋钱罐联合贷'
				  when t1.prd_code='10071001001' and t7.crd_cont_no is not null 
			      then '张家港联合贷二期'
				  when t1.prd_code='10071001001' and t8.crd_cont_no is not null 
			      then '伊春联合贷'
				  when t1.prd_code='10061001001' and t9.crd_cont_no is not null 
				  then '小赢张家港联合贷'
				  when t1.prd_code='10071001001' and t13.crd_cont_no is not null 
			      then '宁波通商联合贷'
				  when t1.prd_code='10211001001' and t12.crd_cont_no is not null 
			      then '乐云小贷联合贷'
                  when t1.prd_code='10061001001' and t14.crd_cont_no is not null 
			      then '小赢通商联合贷'
                  when t1.prd_code='10061001001' and t15.crd_cont_no is not null 
			      then '小赢兰州联合贷'
				  else nvl(t2.prd_name,'')
              end       				 as prod_name            --产品名称
            ,nvl(t1.prd_code,'')         as biz_prod_code        --源业务系统产品号
            ,''                          as biz_sub_prod_code    --源业务系统子产品号(网贷无)
            ,nvl(t1.cert_type,'')        as cert_type            --证件类型
            ,nvl(t1.cert_code,'')        as cert_no              --证件号码
            ,nvl(t1.app_status,'')       as credit_app_status    --授信申请状态
            ,nvl(t3.cont_status,'')      as credit_cont_status   --授信合同状态
            ,case when t1.cycle_flag='Y'  
                  then '1'
                  when t1.cycle_flag='N'  
                  then '0'  
                  else ''
              end                        as     cycle_flag       --循环标识   
            ,'CNY'                       as     ccy              --币种
            ,coalesce(t11.total_limit,t3.crd_amt,0)           
			                             as     credit_limit     --授信额度
            ,case when cast(substr(t1.app_term,3,2) as int) >0 
			      and cast(substr(t1.app_term,5,2) as int) =0 
				  then (cast(substr(t1.app_term,3,2) as int)  + cast(substr(t1.app_term,1,2) as int)*12)
	              when cast(substr(t1.app_term,1,2) as int) >0 
				  and cast(substr(t1.app_term,3,2) as int) =0 and cast(substr(t1.app_term,5,2) as int) =0 
				  then cast(substr(t1.app_term,1,2) as int)
	              else '' 
				  end                       as credit_terms         --授信期限
            ,case when cast(substr(t1.app_term,3,2) as int) >0 
			      and cast(substr(t1.app_term,5,2) as int) =0 
			      then 'M'
	              when cast(substr(t1.app_term,1,2) as int) >0 
				  and cast(substr(t1.app_term,3,2) as int) =0 and cast(substr(t1.app_term,5,2) as int) =0 
				  then 'Y'
	              else '' 
				  end                    as     credit_term_type     --授信期限类型
            ,coalesce(substr(t11.limit_begin_time,1,10),t3.crd_start_date,t1.input_date,'')   
			                             as     credit_start_date    --授信起始日期
            ,coalesce(substr(t11.limit_end_time,1,10),t3.crd_end_date,'')     
			                             as     credit_mature_date   --授信到期日期
            ,case when t11.effective_status = 2   
                  then '02'
                  when t11.effective_status in (1,3) 
                  then '01' --有效
                  else ''
              end  
			                             as     credit_status        --授信状态 update 20230912 yuguorui
            ,nvl(t1.app_date,'')         as     app_date             --申请日期
            ,''                          as     approver             --审批人  --网贷均为决策审批，无人工审核
            ,''                          as     approve_opinion      --审批意见
            ,'1'                         as     loan_biz_class       --业务分类 
            ,nvl(t1.tp_no,'')            as     third_party_app_no   --第三方流水号
            ,nvl(t3.appr_year_rate,0)    as     loan_rate            --贷款年利率
            ,nvl(t1.manage_status,'')    as     credit_manage_status --处理状态
			,nvl(t6.af_ip_address,'')    as     ip 
            ,''                          as     device_id            --设备ID
			,''                          as     project_id           --项目ID
			,nvl(t11.used_limit,0)       as     used_limit           --已用额度 update 20230912 yuguorui east报送新增字段
			,''                          as     oper_emp_id          --经办人  --网贷均为决策审批，无人工审核
            ,nvl(t1.channel_type,'')       as     credit_channel_id  --渠道编号  update 20231031 yuguorui 新增字段
            ,case when t1.prd_code='10011001003' then '110104'
                  when t1.prd_code='10151001001' then '110139'
                  when t1.prd_code='10101001001' then '110117'  
                  when t1.prd_code='10091004003' then '110132'
                  when t1.prd_code='10091001001' then '110114'
                  when t1.prd_code='10091004002' then '110128'
                  when t1.prd_code='10121001001' then '110131'
                  when t1.prd_code='10031001001' then '110106'
                  when t1.prd_code='10131001001' then '110133'
                  when t1.prd_code='10051001001' then '110109'
                  when t1.prd_code='10081001001' then '110111'
                  when t1.prd_code='10111001001' then '110126'
                  when t1.prd_code='10071001001' and t5.crd_cont_no is null 
				                                 and t7.crd_cont_no is null 
												 and t8.crd_cont_no is null 
												 and t13.crd_cont_no is null then '110113' 
				  when t1.prd_code='10071001001' and t5.crd_cont_no is not null then '110135'
                  when t1.prd_code='10071001001' and t7.crd_cont_no is not null then '110169'
                  when t1.prd_code='10071001001' and t8.crd_cont_no is not null then '110174'
				  when t1.prd_code='10071001001' and t13.crd_cont_no is not null then '110182'
                  when t1.prd_code='10181001001' then '110148'
                  when t1.prd_code='10171001001' then '110147'  
                  when t1.prd_code='10161001001' then '110141'  
                  when t1.prd_code in ('10091004','10091004007') then '110145'
                  when t1.prd_code='10091004004' then '110142'
                  when t1.prd_code='10051001002' then '110149'
				  when t1.prd_code='10061001002' then '110164'
				  when t1.prd_code='10191001001' then '110167'
				  when t1.prd_code='10061001001' and t9.crd_cont_no is not null then '110176'
				  when t1.prd_code='10201001001' then '110177'
				  when t1.prd_code='10211001001' and t12.crd_cont_no is not null then '110181'
                  when t1.prd_code='10061001001' and t14.financial_id ='NBTS'then '110185' 
                  when t1.prd_code='10061001001' and t15.financial_id ='LANZ'then '110186'
                  when t1.prd_code='10061001001' then '110112'
				  when t1.prd_code='10171001002' then '110190'
              end                        as prod_code                --产品编号 --有空，核心产品划分较细，未走到放款获取不到产品号
       from odata.ols_crd_app_info t1
       left join odata.ols_loan_prd_info t2
         on t1.prd_code=t2.loan_no
        and t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
       left join odata.ols_crd_cont_info t3
         on t1.crd_cont_no=t3.crd_cont_no
        and t3.data_date='${DATA_DATE}'
        and t3.bddw_end_date='9999-99-99'
       left join odata.ols_admin_sm_user  t4
         on case when t3.prd_code='10151001001' then 'xs0094'
                 when t3.biz_manager_id='xs0179' and '${DATA_DATE}'>='2021-07-09' then 'xs0251'
                 else t3.biz_manager_id 
             end = t4.login_code
        and t4.data_date='${DATA_DATE}' 
        and t4.bddw_end_date='9999-99-99'
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10071001001'     
                     and financial_id = 'DXAL'       --洋钱罐大兴安岭 
					 ) t5
		 on t1.crd_cont_no = t5.crd_cont_no
	   left join odata.ols_rat_decision_dcl_address t6
         on t3.app_no = t6.business_no
        and t6.data_date = '${DATA_DATE}' 
        and t6.bddw_end_date = '9999-99-99'
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10071001001'     
                     and financial_id = 'ZJG'       --张家港联合贷二期
					 ) t7
		 on t1.crd_cont_no = t7.crd_cont_no
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10071001001'     
                     and financial_id = 'yichun'       --伊春联合贷
					 ) t8
		 on t1.crd_cont_no = t8.crd_cont_no
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10061001001'     
                     and financial_id = 'ZJG'       --小赢张家港联合贷
					 ) t9
		 on t1.crd_cont_no = t9.crd_cont_no
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10211001001'     
                     and financial_id = 'LYXD'       --乐云小贷联合贷
					 ) t12  --update yuguorui 20231109 
		 on t1.crd_cont_no = t12.crd_cont_no
	   left join (select crd_cont_no
                    from odata.ols_asset_loan_cont_info
                   where data_date='${DATA_DATE}'
                     and bddw_end_date='9999-99-99'
                     and prd_code = '10071001001'     
                     and financial_id = 'NBTS'       --宁波通商联合贷
					 ) t13  --update yuguorui 20231109 
		 on t1.crd_cont_no = t13.crd_cont_no
       left join (select financial_id,crd_cont_no
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code = '10061001001'     
                    and financial_id = 'NBTS'       --小赢通商联合贷
				) t14   
		on t1.crd_cont_no = t14.crd_cont_no
       left join (select financial_id,crd_cont_no
                   from odata.ols_asset_loan_cont_info
                  where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and prd_code = '10061001001'     
                    and financial_id = 'LANZ'       --小赢兰州联合贷
				) t15   
		on t1.crd_cont_no = t15.crd_cont_no
	   left join odata.sym_cif_client_document t10
         on t1.cert_code = t10.document_id
        and t10.pref_flag = 'Y'   --是否首选地址
        and t10.data_date = '${DATA_DATE}'
        and t10.bddw_end_date = '9999-99-99'
	   left join odata.uquam_ps_product_limit t11 --update 20230912 yuguorui
	     on t1.crd_cont_no = t11.credit_order_no
		and t11.data_date = '${DATA_DATE}'
        and t11.bddw_end_date = '9999-99-99'
      where t1.data_date = '${DATA_DATE}' 
        and t1.bddw_end_date='9999-99-99' 
        and substr(t1.input_time,1,10)<='${DATA_DATE}'
        and t1.prd_code <> '10021001001' --剔除迁移前的锡锡贷自营数据
     union all
--行外网贷
     select  /*+ REPARTITION(1) */
	         nvl(t1.app_no,'')           as credit_app_no        --授信申请号
            ,nvl(t1.crd_cont_no,'')      as credit_cont_no       --授信合同号
            ,'01'                        as cust_type            --客户类型
            ,coalesce(t3.cust_id_core,t1.cust_id_core,t7.client_no,'')     
			                             as cust_id              --客户号
            ,nvl(t1.cust_name,'')        as cust_name            --客户姓名
            ,nvl(t2.prd_name,'')		 as prod_name            --产品名称
            ,nvl(t1.prd_code,'')         as biz_prod_code        --源业务系统产品号
            ,''                          as biz_sub_prod_code    --源业务系统子产品号(网贷无)
            ,nvl(t1.cert_type,'')        as cert_type            --证件类型
            ,nvl(t1.cert_code,'')        as cert_no              --证件号码
            ,nvl(t1.app_status,'')       as credit_app_status    --授信申请状态
            ,nvl(t3.cont_status,'')      as credit_cont_status   --授信合同状态
            ,case when t1.cycle_flag='Y'  
                  then '1'
                  when t1.cycle_flag='N'  
                  then '0'  
                  else ''
              end                        as cycle_flag           --循环标识   
            ,'CNY'                       as ccy                  --币种
            ,coalesce(t8.total_limit,t3.crd_amt,0)           
			                             as credit_limit         --授信额度
            ,case when cast(substr(t1.app_term,3,2) as int) >0 
			      and cast(substr(t1.app_term,5,2) as int) =0 
				  then (cast(substr(t1.app_term,3,2) as int)  + cast(substr(t1.app_term,1,2) as int)*12)
	              when cast(substr(t1.app_term,1,2) as int) >0 
				  and cast(substr(t1.app_term,3,2) as int) =0 and cast(substr(t1.app_term,5,2) as int) =0 
				  then cast(substr(t1.app_term,1,2) as int)
	              else '' 
				  end                     as credit_terms          --授信期限
            ,case when cast(substr(t1.app_term,3,2) as int) >0 
			      and cast(substr(t1.app_term,5,2) as int) =0 
			      then 'M'
	              when cast(substr(t1.app_term,1,2) as int) >0 
				  and cast(substr(t1.app_term,3,2) as int) =0 and cast(substr(t1.app_term,5,2) as int) =0 
				  then 'Y'
	              else '' 
				  end                    as     credit_term_type     --授信期限类型
            ,coalesce(substr(t8.limit_begin_time,1,10),t3.crd_start_date,t1.input_date,'')   
			                             as     credit_start_date--授信起始日期
            ,coalesce(substr(t8.limit_end_time,1,10),t3.crd_end_date,'')     
			                             as credit_mature_date   --授信到期日期
            ,case when t8.effective_status = 2   
                  then '02'
                  when t8.effective_status in (1,3) 
                  then '01' --有效
                  else ''
              end                        as credit_status        --授信状态 update 20230912 yuguorui 
            ,nvl(t1.app_date,'')         as app_date             --申请日期
            ,''                          as approver             --审批人  --网贷均为决策审批，无人工审核
            ,''                          as approve_opinion      --审批意见
            ,'1'                         as loan_biz_class       --业务分类 
            ,nvl(t1.tp_no,'')            as third_party_app_no   --第三方流水号
            ,nvl(t3.appr_year_rate,0)    as loan_rate            --贷款年利率
            ,nvl(t1.manage_status,'')    as credit_manage_status --处理状态
			,nvl(t6.af_ip_address,'')    as ip 
            ,''                          as device_id            --设备ID
			,''                          as project_id           --项目ID
			,nvl(t8.used_limit,0)        as used_limit           --已用额度 update 20230912 yuguorui east报送新增字段
			,''                          as oper_emp_id          --经办人  --网贷均为决策审批，无人工审核
            ,nvl(t1.channel_type,'')     as credit_channel_code  --渠道编号  update 20231031 yuguorui 新增字段
            ,case when t1.prd_code='10011001003' then '110104'
                  when t1.prd_code='10151001001' then '110139'
                  when t1.prd_code='10101001001' then '110117'  
                  when t1.prd_code='10091004003' then '110132'
                  when t1.prd_code='10091001001' then '110114'
                  when t1.prd_code='10091004002' then '110128'
                  when t1.prd_code='10121001001' then '110131'
                  when t1.prd_code='10031001001' then '110106'
                  when t1.prd_code='10131001001' then '110133'
                  when t1.prd_code='10051001001' then '110109'
                  when t1.prd_code='10081001001' then '110111'
                  when t1.prd_code='10111001001' then '110126'
                  when t1.prd_code='10061001001' then '110112'	  
                  when t1.prd_code='10181001001' then '110148'
                  when t1.prd_code='10171001001' then '110147'  
                  when t1.prd_code='10161001001' then '110141'  
                  when t1.prd_code in('10091004','10091004007','10091004006','10091004005') then '110145'
                  when t1.prd_code='10091004004' then '110142'
                  when t1.prd_code='10051001002' then '110149'
				  when t1.prd_code='10061001002' then '110164'
				  when t1.prd_code='10091001002' then '110162'
				  when t1.prd_code='10191001001' then '110167'
			      when t1.prd_code='10221001001' then '110193'--字节
              end                        as prod_code                --产品编号 --有空，核心产品划分较细，未走到放款获取不到产品号
       from odata.ols_crd_un_app_info t1
       left join odata.ols_loan_prd_info t2
         on t1.prd_code=t2.loan_no
        and t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
       left join odata.ols_crd_cont_info t3
         on t1.crd_cont_no=t3.crd_cont_no
        and t3.data_date='${DATA_DATE}'
        and t3.bddw_end_date='9999-99-99'
       left join odata.ols_admin_sm_user  t4
         on case when t3.prd_code='10151001001' then 'xs0094'
                 when t3.biz_manager_id='xs0179' and '${DATA_DATE}'>='2021-07-09' then 'xs0251'
                 else t3.biz_manager_id 
             end = t4.login_code
        and t4.data_date='${DATA_DATE}' 
        and t4.bddw_end_date='9999-99-99'
	   left join odata.ols_rat_decision_dcl_address t6
         on t3.app_no = t6.business_no
        and t6.data_date = '${DATA_DATE}' 
        and t6.bddw_end_date = '9999-99-99'
	   left join odata.sym_cif_client_document t7
         on t1.cert_code = t7.document_id
        and t7.pref_flag = 'Y'   --是否首选地址
        and t7.data_date = '${DATA_DATE}'
        and t7.bddw_end_date = '9999-99-99'
	   left join odata.uquam_ps_product_limit t8  --update 20230912 yuguorui
	     on t1.crd_cont_no = t8.credit_order_no
		and t8.data_date = '${DATA_DATE}'
        and t8.bddw_end_date = '9999-99-99'
      where t1.data_date = '${DATA_DATE}' 
        and t1.bddw_end_date='9999-99-99' 
        and substr(t1.input_time,1,10)<='${DATA_DATE}'
        and t1.prd_code <> '10021001001' --剔除迁移前的锡锡贷自营数据
	 union all
--京东金条
     select  /*+ REPARTITION(1) */
	         nvl(t1.app_no,'')           as credit_app_no        --授信申请号
            ,nvl(t1.crd_cont_no,'')      as credit_cont_no       --授信合同号
            ,'01'                        as cust_type            --客户类型
            ,coalesce(t3.cust_id_core,t1.cust_id_core,t8.client_no,'')     
			                             as cust_id              --客户号
            ,nvl(t1.user_name,'')        as cust_name            --客户姓名
            ,nvl(t2.prd_name,'')		 as prod_name            --产品名称
            ,nvl(t1.prd_code,'')         as biz_prod_code        --源业务系统产品号
            ,''                          as biz_sub_prod_code    --源业务系统子产品号(网贷无)
            ,nvl(t1.cert_type,'')        as cert_type            --证件类型
            ,nvl(t1.cert_no,'')          as cert_no              --证件号码
            ,nvl(t1.app_status,'')       as credit_app_status    --授信申请状态
            ,nvl(t3.cont_status,'')      as credit_cont_status   --授信合同状态
            ,case when t1.cycle_flag='Y'  
                  then '1'
                  when t1.cycle_flag='N'  
                  then '0'  
                  else ''
              end                        as     cycle_flag           --循环标识   
            ,'CNY'                       as     ccy                  --币种
            ,coalesce(t7.total_limit,t3.crd_amt,0)           
			                             as     credit_limit         --授信额度
            ,case when cast(substr(t1.app_term,3,2) as int) >0 
			      and cast(substr(t1.app_term,5,2) as int) =0 
				  then (cast(substr(t1.app_term,3,2) as int)  + cast(substr(t1.app_term,1,2) as int)*12)
	              when cast(substr(t1.app_term,1,2) as int) >0 
				  and cast(substr(t1.app_term,3,2) as int) =0 and cast(substr(t1.app_term,5,2) as int) =0 
				  then cast(substr(t1.app_term,1,2) as int)
	              else '' 
				  end                       as credit_terms          --授信期限
            ,case when cast(substr(t1.app_term,3,2) as int) >0 
			      and cast(substr(t1.app_term,5,2) as int) =0 
			      then 'M'
	              when cast(substr(t1.app_term,1,2) as int) >0 
				  and cast(substr(t1.app_term,3,2) as int) =0 and cast(substr(t1.app_term,5,2) as int) =0 
				  then 'Y'
	              else '' 
				  end                    as     credit_term_type     --授信期限类型
            ,coalesce(substr(t7.limit_begin_time,1,10),t3.crd_start_date,t1.input_date,'')   
			                             as     credit_start_date    --授信起始日期
            ,coalesce(substr(t7.limit_end_time,1,10),t3.crd_end_date,'')  
                                         as     credit_mature_date   --授信到期日期
            ,case when t7.effective_status = 2   
                  then '02'
                  when t7.effective_status in (1,3) 
                  then '01' --有效
                  else ''
              end                        as     credit_status        --授信状态 update 20230912 yuguorui
            ,nvl(t1.app_date,'')         as     app_date             --申请日期
            ,''                          as     approver             --审批人  
            ,''                          as     approve_opinion      --审批意见
            ,'1'                         as     loan_biz_class       --业务分类 
            ,''                          as     third_party_app_no   --第三方流水号
            ,nvl(t3.appr_year_rate,0)    as     loan_rate            --贷款年利率
            ,nvl(t1.manage_status,'')    as     credit_manage_status --处理状态
			,nvl(t6.af_ip_address,'')    as     ip 
            ,''                          as     device_id            --设备ID
			,''                          as     project_id           --项目ID
			,nvl(t7.used_limit,0)        as     used_limit           --已用额度 update 20230912 yuguorui east报送新增字段
			,''                          as     oper_emp_id          --经办人  --网贷均为决策审批，无人工审核
            ,nvl(t1.channel_type,'')     as     credit_channel_code  --渠道编号  update 20231031 yuguorui 新增字段
            ,'110104'                    as     prod_code            --产品编号 
       from odata.ols_crd_un_jd_app_info t1
       left join odata.ols_loan_prd_info t2
         on t1.prd_code=t2.loan_no
        and t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
       left join odata.ols_crd_cont_info t3
         on t1.crd_cont_no=t3.crd_cont_no
        and t3.data_date='${DATA_DATE}'
        and t3.bddw_end_date='9999-99-99'
       --left join odata.ols_admin_sm_user  t4
       --  on case when t3.prd_code='10151001001' then 'xs0094'
       --          when t3.biz_manager_id='xs0179' and '${DATA_DATE}'>='2021-07-09' then 'xs0251'
       --          else t3.biz_manager_id 
       --      end = t4.login_code
       -- and t4.data_date='${DATA_DATE}' 
       -- and t4.bddw_end_date='9999-99-99'
	   left join odata.ols_rat_decision_dcl_address t6
         on t3.app_no = t6.business_no
        and t6.data_date = '${DATA_DATE}' 
        and t6.bddw_end_date = '9999-99-99'
	   left join odata.uquam_ps_product_limit t7  --update 20230912 yuguorui
	     on t1.crd_cont_no = t7.credit_order_no
		and t7.data_date = '${DATA_DATE}'
        and t7.bddw_end_date = '9999-99-99'
	   left join odata.sym_cif_client_document t8
         on t1.cert_no = t8.document_id
        and t8.pref_flag = 'Y'   --是否首选地址
        and t8.data_date = '${DATA_DATE}'
        and t8.bddw_end_date = '9999-99-99'
      where t1.data_date = '${DATA_DATE}' 
        and t1.bddw_end_date='9999-99-99' 
        and substr(t1.input_time,1,10)<='${DATA_DATE}'
		and t1.business_type = 'JT'
        and t1.prd_code <> '10021001001' --剔除迁移前的锡锡贷自营数据
		--目前网贷产品：
        --            '110104'	--个人消费贷款-京东金条
		--	         ,'110106'	--霖梓贷
        --           ,'110109'	--还享借
        --           ,'110111'	--小花钱包
        --           ,'110112'	--小赢易贷
        --           ,'110113'	--洋钱罐借款
        --           ,'110114'	--有钱花贷款
        --           ,'110117'	--人品贷
        --           ,'110126'	--小米消费贷款
        --           ,'110128'	--度小满债转贷款
        --           ,'110131'	--即有钱
        --           ,'110132'	--百度虚拟卡贷款
        --           ,'110133'	--你我贷
        --           ,'110135'	--洋钱罐联合贷
        --           ,'110139'	--萨摩耶助贷
        --           ,'110141'	--万达标准助贷
        --           ,'110142'	--张家港联合贷
        --           ,'110145'	--百度周转贷
        --           ,'110147'	--拍拍贷标准助贷
        --           ,'110148'	--时光分期标准助贷
        --           ,'110149'	--数禾标准助贷
        --           ,'110164'	--小赢经营贷
        --           ,'110169'  --张家港联合贷二期
        --           ,'110174'  --伊春联合贷
		--           ,'110167'  --维信金科助贷
		--           ,'110162'  --百度满意贷兜底
		--           ,'110176'  --小赢张家港联合贷
		--           ,'110177'  --微财数科助贷
		--           ,'110190'  --拍拍联合融担模式消费贷