--2.yangqihao.dim_g_basis_rate_prod_p
-------------------------------------------------------------------
--脚本名称:dim_g_basis_rate_prod_p
--功能描述:基准利率明细表
--作    者:杨琦浩
--开发日期:2023-06-21
--直属经理:方杰
--目标表  :gdata.dim_g_basis_rate_prod_p 
--来源表：odata.sym_irl_basis_rate        基准利率信息表
--来源表：odata.sym_irl_prod_int          产品利率信息表
--来源表：odata.sym_irl_int_rate          利率税率信息表
--来源表：odata.sym_irl_int_matrix        利率税率阶梯表
--来源表：odata.sym_irl_int_basis         基准利率类型表     
--修改历史:
--         1、杨琦浩     2023-06-21     新建
-------------------------------------------------------------------
insert overwrite table gdata.dim_g_basis_rate_prod_p partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
nvl(b.int_basis,'')
,nvl(c.int_basis_desc,'')
,'CNY'
,nvl(b.int_basis_rate,0)
,nvl(a.prod_type,'')
,nvl(a.period_freq,'')
,nvl(substr(a.period_freq,1,1),'')
,from_unixtime(unix_timestamp(b.effect_date,'yyyyMMdd'),'yyyy-MM-dd')
from (select * from odata.sym_irl_basis_rate a
                  where a.data_date='${DATA_DATE}'
                  and a.bddw_end_date='9999-99-99' )b
left join   (select a.int_type,
                       c.int_basis,
                       a.prod_type,
                       b.irl_seq_no,
                       d.int_basis_desc,
                       --b.effect_date,
                       c.period_freq,
                       b.effect_date 
                  from  odata.sym_irl_prod_int a
                  left join odata.sym_irl_int_rate b
                  on a.int_type = b.int_type
                  and b.data_date='${DATA_DATE}'
                  and b.bddw_end_date='9999-99-99'
                  left join odata.sym_irl_int_matrix c
                  on b.irl_seq_no = c.irl_seq_no
                  and c.data_date='${DATA_DATE}'
                  and c.bddw_end_date='9999-99-99' 
                  left join odata.sym_irl_int_basis d
                  on d.int_basis=c.int_basis
                  and d.data_date='${DATA_DATE}'
                  and d.bddw_end_date='9999-99-99'
                 where a.data_date='${DATA_DATE}'
                  and a.bddw_end_date='9999-99-99'
                  and a.event_type = 'OPEN') a
 on a.int_basis = b.int_basis
 and a.EFFECT_DATE=b.EFFECT_DATE
left join odata.sym_irl_int_basis c 
on b.int_basis=c.int_basis
and c.data_date='${DATA_DATE}'
and c.bddw_end_date='9999-99-99' 