--2.zhanglijuan.dwd_d_depo_cont_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：存款账户表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive dwd层dwd.dwd_d_depo_cont_p
--作    者：张礼娟
--开发日期：2021-03-11
--直属经理：方杰
--来源表  ：odata.sym_mb_acct 账户基本信息表
--来源表  ：odata.sym_fm_channel 渠道类型  无
--来源表  ：odata.sym_mb_prod_type 产品类型定义表
--来源表  ：odata.sym_mb_acct_balance 账户余额表
--来源表  ：odata.sym_mb_acct_int_detail 利息明细表
--来源表  ：odata.sym_mb_agreement 合同/协议信息表
--来源表  ：odata.sym_mb_agreement_accord 协定协议登记簿表
--来源表  ：odata.sym_cif_client 客户信息表
--来源表  ：odata.sym_gl_prod_accounting 产品科目表
--来源表  ：odata.sym_mb_acct_sec_balance  账户其他余额表 wu
--来源表  ：odata.sym_mb_tda_hist 定期交易历史表 无
--来源表  ：odata.fp_fp_acct_info 理财账户表
--来源表  ：odata.fp_ec_platform 平台信息表 无
--目标表  ：dwd.dwd_d_depo_cont_p
--修改历史：
--          1.张礼娟   2021-03-11    新建
--          2.张礼娟   2021-03-15    修改sym_mb_acct_balance关联条件，由a9.amt_type = 'bal' 改为 a9.amt_type = 'BAL' 
--          3.于国睿   2021-04-25    新增关联odata.sym_gl_prod_accounting表，从该表取科目代码和科目名称
--                                   新增关联odata.sym_mb_agreement表，从该表取新增字段存款产品类别
--          4.于国睿   2021-04-26    新增odata.sym_mb_acct表条件source_module = 'GL'，去掉条件acct_real_flag = 'Y'
--          5.方杰     2021-05-12    修改关联获取科目号，科目名称代码
--          6.张礼娟   2021-05-28    修改biz_type为prod_code,新增合作方名称、渠道名称、子产品编码、子产品名称、产品名称、remark1 remark2 remark3 remark4 remark5
--          7.华天顺   2021-06-08    新增实际账户类别用于区分1类户、2类户
--          8.于国睿   2021-06-16    修改存款产品类型逻辑
--          9.华天顺   2021-06-21    新增产品类别字段
--          10.方杰    2021-06-24    协定存款拆分两笔，一笔活期，一笔协定
--          11.华天顺  2021-07-02    合作方标识，渠道类型优先取互金的逻辑修改
--          12.张礼娟  2021-07-07    因表sym_mb_prod_type抽数慢，导致prod_name经常为空，故使用表sym_mb_prod_type的上一日数据date_sub('${DATA_DATE}',1)进行关联取数
--          13.张礼娟  2021-09-14    修改子产品编码、子产品名称取数逻辑，增加存单部分逻辑
--          14.杨琦浩  2022-06-20    增加冻结余额字段
--          15.邓权    2022-07-29    增加字段是否可以提前支取、计息基础
--          16.张礼娟  2022-10-27    
-- 修改 pri_acct_flag 是否主账户 码值Y N 转化为 1 0
-- 修改 all_depo_flag	通存标志 码值Y N 转化为 1 0
-- 修改 all_draw_flag	通兑标志 码值Y N 转化为 1 0
-- 修改 auto_depo_flag	自动转存标志 码值Y N 转化为 1 0
-- 修改 get_advanced_flag	是否可以提前支取 码值Y N 转化为 1 0
-- org 机构代码 变更字段英文名为 org_id
-- co_id 合作方标识 变更字段英文名为 partner_id
-- co_name 合作方名称 变更字段英文名为 partner_name
-- chan_type 渠道类型 变更字段英文名为 channel_type
-- chan_name 渠道名称 变更字段英文名为 channel_name
-- rate 执行利率 变更字段英文名为 exec_rate
-- get_advanced_flag	中文名由“是否提取支取”修改为“是否提前支取” 
-- get_advanced_amt	中文名由“提取支取金额”修改为“提前支取金额” 
--          16.张礼娟  2022-11-22 新增source_module 源模块字段，计息基础码值标准化；修改科目代码取数逻辑，因存放同业科目代码为空
--          17.华天顺  2022-12-07 新增基准利率类型字段
--          18.张礼娟  2023-02-20 新增开户柜员、最近交易日期
--          19.方杰    2023-10-31 修改440805，440801，440820，440821，440823余额，去除绝对值逻辑
--          20.彭群    2023-11-14 （1）新增提前支取标识
--                                （2）open_amt字段逻辑调整
--			21.彭群	   2023-11-28   新增起息日
--          22.姚威      2023-12-15   新增计息标识
--			23.彭群	   2024-02-23	合作人名称字段逻辑修改
--			24.彭群    2024-04-25  表sym_mb_prod_type取值时间由前一天改为当天
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_depo_cont_p partition(data_date='${DATA_DATE}')
select 
    /*+ REPARTITION(1) */
     a1.internal_key                                                           as cont_no --协议号
    ,a1.base_acct_no                                                           as acct_no --账号
    --协定存款拆分存款序列号
    ,coalesce(t3.seq_no,a1.acct_seq_no)                                        as acct_seq_no --账户序列号
    ,a1.card_no                                                                as bank_card_no --卡号
    ,a1.branch                                                                 as org_id --机构代码
    ,a1.client_no                                                              as cust_id --客户号
    ,a1.client_type                                                            as cust_type --客户类型
    ,a1.prod_type                                                              as prod_code --产品号
    ,a5.prod_desc                                                              as prod_name --产品名称                    
    ,a4.prod_type                                                              as sub_prod_code --子产品号
    ,a4.prod_name                                                              as sub_prod_name --子产品名称
    ,a1.ccy                                                                    as ccy --币种
    ,from_unixtime(unix_timestamp(a1.acct_open_date,'yyyymmdd'),'yyyy-mm-dd')  as acct_open_date --开户日期
    ,from_unixtime(unix_timestamp(a1.maturity_date,'yyyymmdd'),'yyyy-mm-dd')   as mature_date --到期日期
    ,from_unixtime(unix_timestamp(a1.acct_close_date,'yyyymmdd'),'yyyy-mm-dd') as acct_close_date --关闭日期
    ,a1.acct_status                                                            as acct_status --账户状态
    ,a1.acct_name                                                              as acct_name --账户名称
    ,a1.acct_nature                                                            as acct_prop --账户属性
    ,case when a1.lead_acct_flag='Y' then '1' 
        when a1.lead_acct_flag='N' then '0' 
        else '' end                                                            as pri_acct_flag --是否主账户
    ,a1.term                                                                   as term --存期
    ,a1.term_type                                                              as term_type --存期类型
    ,nvl(a4.platform_id,a1.partner_id)                                         as partner_id --合作方标识
    ,coalesce(r.platform_name,q.platform_name,'')                              as partner_name --合作方名称    				--updata20240204    pengqun
    ,nvl(a4.source_type,a1.source_type)                                        as channel_type --渠道类型
    ,a3.channel_desc                                                           as channel_name --渠道名称 
    ,nvl(a1.acct_real_flag,'')                                                 as acct_real_flag --账户虚实标志
    ,a1.acct_class                                                             as acct_lvl --账户类别
    ,a1.acct_type                                                              as acct_type --账户类型
    ,case when a1.all_dep_ind='Y' then '1' 
        when a1.all_dep_ind='N' then '0' 
        else '' end                                                            as all_depo_flag --通存标志
    ,case when a1.all_dra_ind='Y' then '1' 
        when a1.all_dra_ind='N' then '0' 
        else '' end                                                            as all_draw_flag --通兑标志
    ,a1.apply_branch                                                           as app_org --申请机构
    ,a1.home_branch                                                            as belong_org --归属机构
    ,case when a1.auto_renew_rollover='Y' then '1' 
        when a1.auto_renew_rollover='N' then '0' 
        else '' end                                                            as auto_depo_flag --自动转存标志
    --拆分协定存款余额
    ,case when t3.near_amt is null then 
    	(case when a1.prod_type in ('440805','440801','440820','440821','440823') then -1*a9.total_amount_prev  
    	     else abs(a9.total_amount_prev) end)  --５类内部户产品取消取绝对值逻辑            
    when t3.near_amt is not null and t3.near_amt <> 0 and abs(a9.total_amount_prev)>nvl(t3.near_amt,0)
    then abs(a9.total_amount_prev)-nvl(t3.near_amt,0)
    when t3.near_amt is not null and t3.near_amt = 0 and abs(a9.total_amount_prev) > t3.new_near_amt
    then t3.new_near_amt
    when t3.near_amt is not null and t3.near_amt = 0 and abs(a9.total_amount_prev) <= t3.new_near_amt
    then abs(a9.total_amount_prev) 
    when t3.near_amt is not null and t3.near_amt <> 0 and abs(a9.total_amount_prev)<nvl(t3.near_amt,0)
    then 0 end                                                                as bal --余额
    ,coalesce(a17.gl_code,a14.gl_code_l,a15.gl_code_l,a16.gl_code_l)                       as subj_no --科目代码
    ,case when coalesce(a14.gl_code_l,a15.gl_code_l,a16.gl_code_l) is not null then '负债科目' end as subj_name --科目名称
    --拆分协定存款利率
    ,case when t3.near_amt is null then 
	(case when a10.real_rate=0 then '0' else cast(a10.real_rate as string) end)           
    when t3.near_amt is not null and t3.near_amt <> 0 then cast(t3.real_rate as string)   
    when t3.near_amt is not null and t3.near_amt = 0  then cast(t3.real_rate as string) end    as exec_rate --执行利率
    ,nvl(g.principal_amt,0)                                                         as open_amt --开户金额       --update20131114 pengqun调整
    ,''                                                                      as marg_acct_flag --保证金账户标志
    ,''                                                                      as cash_type --钞汇类型
    ,'部分缴存'                                                                as depo_reserv_mode --缴存准备金方式
    ,case when a1.prod_type = '220101' and a12.base_acct_no is null then 'D011' --单位活期存款
    when a1.prod_type = '220101' and a12.base_acct_no is not null and t3.agreement_id is not null and t3.near_amt<>0 then 'D052' --协定户存款
    when a1.prod_type = '220101' and a12.base_acct_no is not null and t3.agreement_id is not null and t3.near_amt=0 then 'D051' --结算户存款
    when a1.prod_type = '220201' then 'D012' --单位定期存款
    when a1.prod_type in ('230203','220203') then 'D04' --协议存款
    when a1.prod_type in ('210101','210102') then 'D013' --个人活期存款
    when a1.prod_type = '210201' then 'D0141' --个人定期整存整取存款
    when a1.prod_type in ('210202','210203','210205') then 'D0149' --其他定期储蓄存款
    when a1.prod_type = '210301' then 'D02' --个人定活两便存款
    when a1.prod_type in ('220401','210401') then 'D031' --一天通知存款
    when a1.prod_type in ('220402','210402') then 'D032' --七天通知存款
    when coalesce(a14.gl_code_l,a15.gl_code_l,a16.gl_code_l) in ('20320201','20320202')   then 'D069'
    when coalesce(a14.gl_code_l,a15.gl_code_l,a16.gl_code_l) in ('20300203','20300289') then 'D0141'
    when coalesce(a14.gl_code_l,a15.gl_code_l,a16.gl_code_l)='20300301' and a1.term='7' then 'D032'
    when coalesce(a14.gl_code_l,a15.gl_code_l,a16.gl_code_l)='20300301' and a1.term='1' then 'D031'
    when coalesce(a14.gl_code_l,a15.gl_code_l,a16.gl_code_l)='20310201' then 'D012'
    when a1.prod_type is not null then 'D99' --其他存款
    else a1.prod_type end                                                       as depo_type --存款产品类别                                                                       
    ,case when a6.acct_class is not null then a6.acct_class
    when a1.base_acct_no like '121%' then '1' end                         as real_acct_lvl          --实际账户类别
    ,a5.prod_class                                                              as prod_class             --产品类别
    ,nvl(a7.total_amount,0)                                                     as blocked_bal            --冻结余额
    ,case when a8.wdrawn_amt >0 then '1' else '0' end                           as get_advanced_flag      --是否提前支取
    ,case when a10.month_basis='30' and a10.year_basis='360' then '1'
          when a10.month_basis='ACT' and a10.year_basis='360' then '2'
          when a10.month_basis='ACT' and a10.year_basis='ACT' then '3'
          when a10.month_basis='30' and a10.year_basis='365' then '4'
          when a10.month_basis='30' and a10.year_basis='ACT' then '5'
          when a10.month_basis='ACT' and a10.year_basis='365' then '6'
    else '7' end as int_basis              --计息基础
    --,case when nvl(concat(a10.month_basis,'/',a10.year_basis),'/') <>'/' then concat(a10.month_basis,'/',a10.year_basis) else '' end as int_basis              --计息基础
    ,nvl(a8.wdrawn_amt,0)                                                       as get_advanced_amt       --提前支取金额
    ,a1.source_module as source_module
	,nvl(f.int_basis,'')                                                                as int_basis_type    --基准利率类型
    ,nvl(a1.user_id,'')     as open_ltr	--开户柜员
    ,nvl(from_unixtime(unix_timestamp(a1.last_tran_date,'yyyymmdd'),'yyyy-mm-dd'),'')            as last_tran_date	   --上次交易日期
    ,nvl(case when  p.attr_value = 'Y' then '1'  --1代表可提前支出，0代表不可提前支出
     else '0' end,'')                                                                            as adv_draw_flag	    --提前支出标识  --update 20231114 pengqun 调整 
	,concat(SUBSTRING(a1.effect_date,1,4),
	'-',SUBSTRING(a1.effect_date,5,2),'-',
	SUBSTRING(a1.effect_date,7,2)) 	                                                             as  accr_date 		
    --起息日        --updata 202311128 pengqun 新增字段
    ,case when d1.internal_key is not null and nvl(d1.int_ind,'Y')='Y' then '1'
          when d.internal_key is not null and nvl(d.int_ind,'')='Y' then '1'
          when d.internal_key is not null and nvl(d.int_ind,'')='N' then '0'
          else '' end                       as accr_flag           --新增计息标识
from odata.sym_mb_acct a1
left join odata.sym_fm_channel a3
on a1.source_type=a3.channel
and a3.data_date='${DATA_DATE}'
and a3.bddw_end_date='9999-99-99'  
left join odata.sym_mb_prod_type a5
on a1.prod_type=a5.prod_type
and a5.data_date='${DATA_DATE}'                     --updatapengqun 20240425调整日期取值
and a5.bddw_end_date='9999-99-99'    
left join odata.sym_mb_acct_balance a9
on a1.internal_key = a9.internal_key
and a9.amt_type = 'BAL' 
and a9.data_date='${DATA_DATE}'
and a9.bddw_end_date='9999-99-99' 
left join odata.sym_mb_acct_int_detail a10
on a1.internal_key = a10.internal_key
and a10.data_date='${DATA_DATE}'
and a10.bddw_end_date='9999-99-99'
and a10.int_class = 'INT'
left join odata.sym_mb_agreement a12
on a1.base_acct_no = a12.base_acct_no
and a12.data_date='${DATA_DATE}' 
and a12.bddw_end_date='9999-99-99' 
and a12.agreement_type = 'ACC' 
and a12.agreement_status = 'A'
left join 
(
    select t1.*,t2.near_amt as new_near_amt 
    from odata.sym_mb_agreement_accord t1
    left join odata.sym_mb_agreement_accord t2
    on t1.agreement_id=t2.agreement_id
    and t2.data_date='${DATA_DATE}'
    and t2.bddw_end_date='9999-99-99'
    and t2.near_amt>0
    where t1.data_date='${DATA_DATE}'
    and t1.bddw_end_date='9999-99-99'
) t3
on a12.agreement_id = t3.agreement_id
left join odata.sym_cif_client a13
on a1.client_no=a13.client_no
and a13.data_date='${DATA_DATE}'
and a13.bddw_end_date='9999-99-99'
--获取科目号、科目名称
left join odata.sym_gl_prod_accounting a14
on a1.prod_type = a14.prod_type
and a1.accounting_status = a14.accounting_status
and a13.category_type = a14.tran_category
and a14.data_date='${DATA_DATE}'
and a14.bddw_end_date='9999-99-99'
left join odata.sym_gl_prod_accounting a15
on a1.prod_type = a15.prod_type
and a1.accounting_status = a15.accounting_status
and a15.tran_category = 'ALL'
and a15.data_date='${DATA_DATE}'
and a15.bddw_end_date='9999-99-99'
left join odata.sym_gl_prod_accounting a16
on a1.prod_type = a16.prod_type
and a16.tran_category = 'ALL'
and a16.accounting_status = 'ALL'
and a16.data_date='${DATA_DATE}'
and a16.bddw_end_date='9999-99-99'
left join odata.sym_mb_acct_attach a17
on a1.internal_key = a17.internal_key
and a17.data_date = '${DATA_DATE}'
and a17.bddw_end_date = '9999-99-99'
left join --获取子产品编码、子产品名称
(
    select
    a1.internal_key
    ,a1.base_acct_no
    ,a1.card_no
    ,a1.acct_seq_no
    ,a2.prod_type
    ,a2.prod_name
    ,a2.source_type
    ,a2.platform_id
    from odata.sym_mb_acct a1 
    inner join 
    (
        select 
        b1.internal_key
        ,b1.base_acct_no
        ,b1.card_no
        ,b2.acct_seq_no
        ,b2.prod_type
        ,b2.prod_name
        ,b2.source_type
        ,b2.platform_id
        from odata.sym_mb_acct b1
        inner join odata.fp_fp_acct_info b2
        on b1.card_no = b2.base_acct_no   --关联条件
        and b2.data_date='${DATA_DATE}'
        and b2.bddw_end_date='9999-99-99'    
        where b1.client_type='01' --个人客户
        and b1.acct_type='A' --账户类型：AIO账户，此账户才有卡号
        and b1.data_date='${DATA_DATE}'
        and b1.bddw_end_date='9999-99-99'
    )a2
    on a1.base_acct_no = a2.base_acct_no 
    and a1.acct_seq_no = a2.acct_seq_no 
    where a1.data_date='${DATA_DATE}'
    and a1.bddw_end_date='9999-99-99' 
    union all
    select
    b1.internal_key
    ,b1.base_acct_no
    ,b1.card_no
    ,b1.acct_seq_no
    ,b2.prod_type
    ,b2.prod_name
    ,b2.source_type
    ,b2.platform_id
    from odata.sym_mb_acct b1
    inner join odata.fp_fp_acct_info b2 
    on b1.base_acct_no = b2.base_acct_no 
    and b1.acct_seq_no = b2.acct_seq_no 
    and b2.data_date='${DATA_DATE}'
    and b2.bddw_end_date='9999-99-99'   
    where b1.client_type='01'
    and b1.data_date='${DATA_DATE}'
    and b1.bddw_end_date='9999-99-99'
)a4
on a1.internal_key=a4.internal_key
left join odata.sym_mb_acct a6
on a1.base_acct_no=a6.base_acct_no
and a6.acct_type='C'
and a6.data_date='${DATA_DATE}'
and a6.bddw_end_date='9999-99-99' 
left join odata.sym_mb_acct_sec_balance a7
on a1.internal_key=a7.internal_key
and a7.data_date='${DATA_DATE}' 
and a7.bddw_end_date='9999-99-99'
left join 
(
    select 
    internal_key         as internal_key
    ,sum(nvl(wdrawn_amt,0))     as wdrawn_amt
    from odata.sym_mb_tda_hist 
    where data_date='${DATA_DATE}' 
    and bddw_end_date='9999-99-99'
    and movt_status in ('P','F')--P:部分提前支取  F：全部提前支取
    and substr(acct_movt_date,1,10) ='${DATA_DATE}' 
    group by internal_key
)	a8 
on a1.internal_key = a8.internal_key 
 left join odata.sym_mb_acct_int_detail d 
  on a1.internal_key=d.internal_key
  and d.data_date = '${DATA_DATE}'
  and d.bddw_end_date='9999-99-99'
  and d.int_class = 'INT'--正常计息
 left join odata.sym_mb_acct_int_detail d1--update yw 20231215 添加关联获取计息方式
on a1.internal_key =d1.internal_key 
and d1.data_date = '${DATA_DATE}'
and d1.bddw_end_date ='9999-99-99'
and d1.int_class='PDUE'  --逾期利息
left join  odata.sym_mb_agreement h  --取协定存款利率类型
     on h.data_date='${DATA_DATE}'
     and h.bddw_end_date='9999-99-99'
     and h.agreement_type = 'ACC' 
     and h.agreement_status = 'A'
     and a1.base_acct_no=h.base_acct_no
     and coalesce(t3.seq_no,a1.acct_seq_no)='0'
 left join odata.sym_mb_agreement_accord i 
 on i.data_date='${DATA_DATE}'
and i.bddw_end_date='9999-99-99'
and h.agreement_id=i.agreement_id
and i.near_amt>0
 left join odata.sym_irl_int_rate e 
 on nvl(i.int_type,d.int_type) = e.int_type
 and e.data_date = '${DATA_DATE}'
 and e.bddw_end_date = '9999-99-99'
 and regexp_replace(a1.acct_open_date,'-','')>=e.effect_date
 and regexp_replace(a1.acct_open_date,'-','')<=e.end_date 
 left join odata.sym_irl_int_matrix f 
 on e.irl_seq_no = f.irl_seq_no
 and nvl(concat(a1.term_type,a1.term),'') = nvl(f.period_freq,'')
 and f.int_basis is not null
 and f.data_date = '${DATA_DATE}'
 and f.bddw_end_date = '9999-99-99'
 left join odata.sym_mb_tda_hist g
  on a1.internal_key = g.internal_key
  and g.movt_status = 'A' --开户存入
  and g.data_date = '${DATA_DATE}'
  and g.bddw_end_date = '9999-99-99'
left join odata.sym_mb_prod_define p
on a1.prod_type = p.prod_type
and p.attr_key='PRE_WITHDRAW_FLAG'
and p.data_date='${DATA_DATE}'
and p.bddw_end_date='9999-99-99'
left join odata.fp_ec_platform r									--add20240204    pengqun
on nvl(a4.platform_id,a1.partner_id) = r.platform_id			
and r.data_date='${DATA_DATE}'
and r.bddw_end_date='9999-99-99'
left join odata.uc_ec_platform q
on nvl(a4.platform_id,a1.partner_id) = q.platform_id				--add20240204    pengqun
and q.data_date='${DATA_DATE}'
and q.bddw_end_date='9999-99-99'
where a1.data_date='${DATA_DATE}'
and a1.bddw_end_date='9999-99-99'
and a1.source_module in ('RB','GL')
