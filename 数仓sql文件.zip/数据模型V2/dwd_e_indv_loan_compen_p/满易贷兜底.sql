--2.yqh.dwd_e_indv_loan_compen_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：个人贷款代偿表取数逻辑.sql
--功能描述：生成每日结果数据并插入 dwd.dwd_e_indv_loan_compen_p
--作    者：杨琦浩
--开发日期：2023-04-20
--直属经理：方杰
--来源表  ：
--1.odata.slur_dzz_compensatory_detail 文件类代偿明细表
--2.odata.ols_loan_cont_info 支用合同信息表
--3.odata.slur_bddd_repayplan_file_clear 百度满易贷贷款还款计划表

--目标表  ：dwd.dwd_e_indv_loan_compen_p
--修改历史：
--          1.杨琦浩   2023-04-20    百度满易贷代偿拆分  
--          2.姚威     2024-04-11    新增核算回收号字段
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_indv_loan_compen_p partition(DATA_DATE='${DATA_DATE}',prod_code)
select /*+ REPARTITION(1) */
nvl(a.tran_date,'') as compen_date --代偿日期
,case when a.prod_type='110128' then concat('ZZ',a.loan_no) else a.loan_no end --借据号
,nvl(a.reference,'') as receipt_no --回收号
,nvl(b.prd_code,'') biz_prod_code --主产品号
,'' as biz_sub_prod_code --产品子类
,case when a.term_no='0' then 'B' else 'A' end as compen_type --代偿类型 A:当期代偿 B:整笔代偿
,nvl(a.term_no,'') as compen_term_no --代偿期次
,case when a.term_no='0' then coalesce(m.stmt_date,'')
      else coalesce(from_unixtime(unix_timestamp(substr(l.stmt_date,1,10),'yyyy-MM-dd'),'yyyyMMdd'),'') end as term_mature_date --当期还款日
,nvl(a.comps_total,0) as compen_total_amt --代偿总金额
,nvl(a.comps_prin,0) as compen_prin --代偿本金
,nvl(a.comps_int,0) as compen_int --代偿利息 
,nvl(a.comps_prin_pnlt,0) as compen_pena --代偿罚息
,nvl(a.comps_int_pnlt,0) as compen_compo --代偿复利
,case when a.comps_status='S' then 0
      when a.comps_status in ('F','A') then 1 
      when a.comps_status='N' then 2
      else '' end as compen_status --代偿状态 S:成功 F:失败 A:保证金账户余额不足 N:未处理
,'' as sym_receipt_no--核算回收号
,nvl(a.prod_type,'') as prod_code --产品编号
from odata.slur_dzz_compensatory_detail a --文件类代偿明细表
left join odata.ols_loan_cont_info b --支用合同信息表
on (case when a.prod_type='110128' then concat('ZZ',a.loan_no) else a.loan_no end) =b.bill_no --代偿表百度债转借据号缺少ZZ
and b.data_date='${DATA_DATE}'
and b.bddw_end_date='9999-99-99'
left join odata.slur_bddd_repayplan_file_clear l --百度满易贷贷款还款计划表
on a.loan_no=l.loan_no
and a.term_no=l.term
and l.data_date='${DATA_DATE}'
and l.bddw_end_date='9999-99-99'
-----------百度虚拟卡、百度周转贷、百度债转发生整笔代偿时取最大期次的结束日期-----------
left join (
select loan_no
       ,max(from_unixtime(unix_timestamp(substr(stmt_date,1,10),'yyyy-MM-dd'),'yyyyMMdd')) as stmt_date
       from odata.slur_bddd_repayplan_file_clear --百度满易贷贷款还款计划表
       where data_date='${DATA_DATE}'
       and bddw_end_date='9999-99-99'
       group by loan_no
) m
on a.loan_no=m.loan_no
where a.data_date='${DATA_DATE}'
and a.bddw_end_date='9999-99-99'
and a.prod_type='110162'