--2.yqh.dwd_e_indv_loan_compen_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：个人贷款代偿表取数逻辑.sql
--功能描述：生成每日结果数据并插入 dwd.dwd_e_indv_loan_compen_p
--作    者：杨琦浩
--开发日期：2022-01-11
--直属经理：程宏明
--来源表  ：
--1.odata.slur_sl_receipt_table 合作贷回收表
--2.odata.sllv_mb_guarantee_receipt 账户代偿回收信息表
--3.odata.sllv_mb_receipt 线上贷款回收表
--4.odata.sllv_mb_receipt_detail 线上贷款回收明细表
--5.odata.sllv_mb_invoice 单据表
--6.odata.ols_loan_cont_info 支用合同信息表
--7.odata.slur_dzz_compensatory_detail 文件类代偿明细表
--8.odata.slur_bdvc_repayplan_file_clear 百度虚拟卡贷款还款计划表
--9.odata.slur_bdzz_repayplan_file_clear 百度周转贷贷款还款计划表
--10.odata.slur_dxm_repayplan_file_clear 度小满贷款还款计划表
--11.odata.slur_dzz_repayplan_file_clear 百度债转贷款还款计划表
--12.odata.slur_jd_loan_schedule_hist_clear 京东贷款还款计划表
--13.odata.slur_xm_term_status_file_clear 小米日初期次信息表

--目标表  ：dwd.dwd_e_indv_loan_compen_p
--修改历史：
--          1.杨琦浩   2022-01-11    新建
--          2.杨琦浩   2022-10-20    新增行外产品代偿
--          3.杨琦浩   2022-12-12    修复锡锡贷代偿金额翻倍问题
--          4.杨琦浩   2023-01-10    增加手动代偿取数逻辑
--          5.杨琦浩   2023-04-20    拆分行内代偿
--          6.杨琦浩   2023-10-20    增加联合贷产品
--          7.姚威     2024-04-11    新增核算回收号字段
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_indv_loan_compen_p partition(DATA_DATE='${DATA_DATE}',prod_code)
select /*+ REPARTITION(1) */ 
nvl(a.receipt_date,'') as compen_date, --代偿日期
nvl(a.cmisloan_no,'') as bill_no, --借据号
nvl(a.reference,'') as receipt_no, --回收号
nvl(f.prd_code,'') as biz_prod_code, --主产品号
'' as biz_sub_prod_code, --产品子类
nvl(a.receipt_type,'') as compen_type, --代偿类型
coalesce(d.stage_no,h.stage_no,'') as compen_term_no, --代偿期次
coalesce(e.due_date,i.due_date,j.due_date,'') as term_mature_date, --当期还款日
coalesce(d.compen_total_amt,h.compen_total_amt,0) as compen_total_amt, --代偿总金额
coalesce(d.compen_prin,h.compen_prin,0) as compen_prin, --代偿本金
coalesce(d.compen_int,h.compen_int,0) as compen_int, --代偿利息
coalesce(d.compen_pena,h.compen_pena,0) as compen_pena, --代偿罚息
coalesce(d.compen_compo,h.compen_compo,0) as compen_compo, --代偿复利
nvl(case a.REC_STATUS when  'F' then 1  when 'S' then 0 end ,'') as compen_status, --代偿状态
coalesce(d.receipt_no,h.receipt_no,'') as sym_receipt_no,--回收号
nvl(substr(a.extend_column1,1,6),'') as prod_code --产品编号
from odata.slur_sl_receipt_table a --合作贷回收表
left join odata.sllv_mb_guarantee_receipt  b --账户代偿回收信息表
on a.receipt_date = b.receipt_date
and a.cmisloan_no = b.cmisloan_no
and b.data_date = '${DATA_DATE}'
and b.bddw_end_date = '9999-99-99'
left join 
(
select acct_internal_key
       ,receipt_no
       ,stage_no
       ,nvl(sum(nvl(rec_amt,0)),0) as compen_total_amt
       ,nvl(sum(if(amt_type = 'PRI',rec_amt,0)),0) as compen_prin
       ,nvl(sum(if(amt_type = 'INT',rec_amt,0)),0) as compen_int
       ,nvl(sum(if(amt_type = 'ODP',rec_amt,0)),0) as compen_pena
       ,nvl(sum(if(amt_type = 'ODI',rec_amt,0)),0) as compen_compo
       from odata.sllv_mb_receipt_detail --线上贷款回收明细表
       where data_date = '${DATA_DATE}'
       and bddw_end_date = '9999-99-99'
       group by acct_internal_key
                ,receipt_no
                ,stage_no
) d 
on b.receipt_no = d.receipt_no
and cast(d.stage_no as int)= case when (a.extend_column2 is not null and a.extend_column2 > 0) --当期代偿出现多期次
                                  then cast (a.extend_column2 as int)
                             else cast (d.stage_no as int) end
left join (select internal_key,stage_no,min(due_date) as due_date from odata.sllv_mb_invoice
where data_date = '${DATA_DATE}'
and bddw_end_date = '9999-99-99'
group by internal_key,stage_no) e --单据表
on d.acct_internal_key = e.internal_key
and d.stage_no = e.stage_no
left join odata.ols_loan_cont_info f --网贷支用合同信息表
on a.cmisloan_no = f.bill_no
and f.data_date = '${DATA_DATE}'
and f.bddw_end_date = '9999-99-99'
left join odata.sllv_nl_guarantee_receipt  g --账户代偿回收信息表
on a.receipt_date = g.receipt_date
and a.cmisloan_no = g.cmisloan_no
and g.data_date = '${DATA_DATE}'
and g.bddw_end_date = '9999-99-99'
left join 
(
select internal_key
       ,receipt_no
       ,stage_no
       ,nvl(sum(nvl(rec_amt,0)),0) as compen_total_amt
       ,nvl(sum(if(amt_type = 'PRI',rec_amt-partner_rec_amt,0)),0) as compen_prin
       ,nvl(sum(if(amt_type = 'INT',rec_amt-partner_rec_amt,0)),0) as compen_int
       ,nvl(sum(if(amt_type = 'ODP',rec_amt-partner_rec_amt,0)),0) as compen_pena
       ,nvl(sum(if(amt_type = 'ODI',rec_amt-partner_rec_amt,0)),0) as compen_compo
       from odata.sllv_nl_receipt_detail --线上贷款回收明细表
       where data_date = '${DATA_DATE}'
       and bddw_end_date = '9999-99-99'
       group by internal_key
                ,receipt_no
                ,stage_no
) h 
on g.receipt_no = h.receipt_no
and cast(h.stage_no as int)= case when (a.extend_column2 is not null and a.extend_column2 > 0) 
                                  then cast (a.extend_column2 as int)
                             else cast (h.stage_no as int) end
left join (
          select internal_key
                 ,stage_no
                 ,regexp_replace(substr(min(due_date),1,10),'-','') as due_date
          from odata.sllv_nl_acct_schedule_detail
          where data_date = '${DATA_DATE}'
          and bddw_end_date = '9999-99-99'
          group by internal_key
                   ,stage_no
          ) i 
on h.internal_key = i.internal_key
and h.stage_no = i.stage_no
left join (
          select internal_key
                 ,stage_no
                 ,regexp_replace(substr(min(due_date),1,10),'-','') as due_date
          from odata.sllv_nl_noschedule_invoice
          where data_date = '${DATA_DATE}'
          and bddw_end_date = '9999-99-99'
          group by internal_key
                   ,stage_no
          ) j
on h.internal_key = j.internal_key
and h.stage_no = j.stage_no
where a.data_date = '${DATA_DATE}'
and a.bddw_end_date = '9999-99-99'
and a.receipt_type in ('A','B') --A:当期代偿 B:整笔代偿
-------手动代偿-------
union all 
select /*+ REPARTITION(1) */ 
nvl(a.receipt_date,'') as compen_date, --代偿日期
nvl(a.cmisloan_no,'') as bill_no, --借据号
nvl(a.reference,'') as receipt_no, --回收号
nvl(f.prd_code,'') as biz_prod_code, --主产品号
'' as biz_sub_prod_code, --产品子类
nvl(a.guarec_type,'') as compen_type, --代偿类型
nvl(d.stage_no,'') as compen_term_no, --代偿期次
nvl(e.due_date,'') as term_mature_date, --当期还款日
nvl(d.compen_total_amt,0) as compen_total_amt, --代偿总金额
nvl(d.compen_prin,0) as compen_prin, --代偿本金
nvl(d.compen_int,0) as compen_int, --代偿利息
nvl(d.compen_pena,0) as compen_pena, --代偿罚息
nvl(d.compen_compo,0) as compen_compo, --代偿复利
'0' as compen_status, --代偿状态
nvl(d.receipt_no,'') as sym_receipt_no,--回收号
nvl(g.prod_type,'') as prod_code --产品编号
--nvl(substr(a.extend_column1,1,6),'') as prod_code --产品编号
from odata.sllv_mb_guarantee_receipt a 
left join odata.slur_sl_receipt_table b 
on a.receipt_date = b.receipt_date
and a.cmisloan_no = b.cmisloan_no
and b.data_date = '${DATA_DATE}'
and b.bddw_end_date = '9999-99-99'
left join 
(
select acct_internal_key
       ,receipt_no
       ,stage_no
       ,nvl(sum(nvl(rec_amt,0)),0) as compen_total_amt
       ,nvl(sum(if(amt_type = 'PRI',rec_amt,0)),0) as compen_prin
       ,nvl(sum(if(amt_type = 'INT',rec_amt,0)),0) as compen_int
       ,nvl(sum(if(amt_type = 'ODP',rec_amt,0)),0) as compen_pena
       ,nvl(sum(if(amt_type = 'ODI',rec_amt,0)),0) as compen_compo
       from odata.sllv_mb_receipt_detail --线上贷款回收明细表
       where data_date = '${DATA_DATE}'
       and bddw_end_date = '9999-99-99'
       group by acct_internal_key
                ,receipt_no
                ,stage_no
) d 
on a.receipt_no = d.receipt_no
left join (select internal_key,stage_no,min(due_date) as due_date from odata.sllv_mb_invoice
where data_date = '${DATA_DATE}'
and bddw_end_date = '9999-99-99'
group by internal_key,stage_no) e --单据表
on d.acct_internal_key = e.internal_key
and d.stage_no = e.stage_no
left join odata.ols_loan_cont_info f --网贷支用合同信息表
on a.cmisloan_no = f.bill_no
and f.data_date = '${DATA_DATE}'
and f.bddw_end_date = '9999-99-99'
left join odata.sllv_mb_acct g 
on a.cmisloan_no=g.cmisloan_no
and g.data_date = '${DATA_DATE}'
and g.bddw_end_date = '9999-99-99'
where a.data_date = '${DATA_DATE}'
and a.bddw_end_date = '9999-99-99'
and a.guarec_type in ('A','B') --A:当期代偿 B:整笔代偿
and b.cmisloan_no is null 
