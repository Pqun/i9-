--2.gaoyuan.dwd_d_bill_settle_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：银行承兑汇票兑付表取数逻辑.sql
--功能描述：用于创建 dwd.dwd_d_bill_settle_p
--作    者：高源
--开发日期：2022-12-27 
--直属经理：方杰
--来源表:
--1.odata.nbms_bms_draft_centre_info  票据票面信息表  
--2.odata.nbms_bms_accept_details     承兑明细表
--3.odata.nbms_bms_accept_contract    承兑批次表
--4.odata.als_business_duebill        业务借据(账户)信息表
--5.odata.nbms_bms_accept_status      承兑状态表
--6.odata.nbms_bms_accept_due_pay     解付信息表
--7.odata.nbms_dpc_draft_info         票据票面信息表
--8.odata.nbms_cpes_prmtpay_apply     提示付款申请表
--9.odata.nbms_cpes_accept_details    承兑明细表
--10.odata.nbms_cpes_accept_contract  承兑批次表
--目标表：dwd.dwd_d_bill_settle_p  银行承兑汇票兑付表
--修改历史：
--          1.高源   2022-12-27    新建
--          2.高源   2023-08-09    新增兑付状态字段，新增拒付业务数据
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_bill_settle_p partition(data_date='${DATA_DATE}')
 select   /*+ REPARTITION(1) */
          nvl(t1.draft_number          ,'')    as  bill_no              --票据号
         ,'-'                                  as  bill_range           --票据区间
         ,nvl(t2.protocol_no           ,'')    as  cont_no              --协议号
         ,'100000'                             as  org_id               --机构号
         ,case t1.draft_attr
               when 1 then '70020101'       --开出承兑汇票—纸质银行承兑汇票
               when 2 then '70020102'       --开出承兑汇票—电子银行承兑汇票
               else '' end                     as  subj_no              --科目号
         ,nvl(t2.prod_no               ,'')    as  prod_code            --产品号
         ,'CNY'                                as  ccy                  --币种
         ,nvl(t1.draft_attr            ,'')    as  bill_attr            --票据介质
         ,nvl(t1.draft_type            ,'')    as  bill_type            --票据类型
         ,nvl(from_unixtime(unix_timestamp(t1.remit_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                       as  remit_date           --出票日
         ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                       as  bill_expr_date    --票面到期日
         ,nvl(t2.remitter_cust_no      ,'')    as  drawer_cust_id       --出票人客户号
         ,nvl(t1.remitter_name         ,'')    as  drawer_name          --出票人名称
         ,nvl(t1.remitter_account      ,'')    as  drawer_acct_no       --出票人账号
         ,nvl(t1.remitter_cmonid       ,'')    as  drawer_cert_no       --出票人证件代码  
         ,nvl(t1.remitter_bank_no      ,'')    as  drawer_bank_no       --出票人开户行号
         ,nvl(t1.remitter_bank_name    ,'')    as  drawer_bank_name     --出票人开户行名称
         ,nvl(t1.payee_name            ,'')    as  bill_rev_name        --收款人名称    
         ,nvl(t1.payee_organ_code      ,'')    as  rev_cert_no          --票面收款人证件号码
         ,nvl(t1.payee_bank_no         ,'')    as  bill_rev_bank_no     --票面收款人开户行号
         ,nvl(t1.payee_bank_name       ,'')    as  bill_rev_bank_name   --票面收款人开户行名称
         ,coalesce(t8.payee_name, t9.prmt_payer_name       ,'')  
		                                       as  act_rev_cust_name    --实际收款人名称
         ,nvl(t9.prmt_payer_crt_no                         ,'')  
		                                       as  act_rev_cert_no      --实际收款人证件号码
         ,coalesce(t8.payee_bank_no,t9.prmt_payer_bank_no  ,'')  
		                                       as  act_rev_bank_no      --实际收款人开户行号
         ,coalesce(t8.payee_bank_name,t9.prmt_payer_name   ,'')  
		                                       as  act_rev_bank_name    --票面收款人开户行名称
         ,nvl(t.draft_amount           ,0 )    as  pay_amt              --付款金额
         ,case when t8.account_date is not null 
		           then from_unixtime(unix_timestamp(t8.account_date,'yyyyMMdd'),'yyyy-MM-dd')
               when t8.account_date is null and t9.apply_date is not null 
			       then from_unixtime(unix_timestamp(t9.apply_date,'yyyyMMdd'),'yyyy-MM-dd')
               else ''  
		   end                                 as  bill_pay_date        --票据解付日期 
         ,nvl(t8.sig_mk ,'1')                  as  cash_status          --兑付状态  1兑付成功  0拒付
    from odata.nbms_bms_draft_centre_info  t1
    inner join odata.nbms_bms_accept_details t--承兑明细表
           on t1.id=t.draft_id
          and t.data_date='${DATA_DATE}' 
          and t.bddw_end_date='9999-99-99'
          and t.accept_status in ('06')-- 06 - 承兑完成（签发）
    left join  odata.nbms_bms_accept_contract t2--承兑批次表
           on t.contract_id=t2.id
          and t2.data_date='${DATA_DATE}' 
          and t2.bddw_end_date='9999-99-99'
    -- left join odata.nbms_bms_accept_status t7
    --       on t.draft_number = t7.draft_number
    --      and t7.data_date = '${DATA_DATE}'
    --      and t7.bddw_end_date = '9999-99-99'
    left join odata.nbms_bms_accept_due_pay t8  --解付信息表        account_date
           on t8.draft_id=t1.id
          and t8.data_date='${DATA_DATE}' 
          and t8.bddw_end_date='9999-99-99'
         -- and t8.account_flag='2' --记账完成      --新增拒付业务数据 
    left join (
             select b.bms_draft_id, 
                    c.apply_date,
                    c.prmt_payer_name ,
                    c.prmt_payer_crt_no,
                    c.prmt_payer_bank_no 
               from odata.nbms_dpc_draft_info b --票据票面信息表
               left join odata.nbms_cpes_prmtpay_apply c             --c.apply_date   
                 on b.id=c.draft_id 
                and c.data_date='${DATA_DATE}' 
                and c.bddw_end_date='9999-99-99'
              where b.bms_draft_id is not NULL                       --老票据贴现后会有新的id，会有原始id记录
                and c.account_status = '02' --记账成功
                and c.buss_flag ='02' --签收
                and b.data_date='${DATA_DATE}' 
                and b.bddw_end_date='9999-99-99'      
              ) t9
           on t9.bms_draft_id=t1.id  
    where t1.data_date='${DATA_DATE}' 
     and t1.bddw_end_date='9999-99-99'
     and nvl(t9.bms_draft_id ,t8.draft_id) is not null     --解付数据
union all
--------------------------------------等分化票据承兑---------------------------------------------------------
 select  /*+ REPARTITION(1) */ 
          nvl(t8.draft_number          ,'')    as  bill_no              --票据号
         ,nvl(t8.cd_range              ,'')    as  bill_range           --票据区间
         ,nvl(t2.contract_no           ,'')    as  cont_no              --协议号
         ,'100000'                             as  org_id               --机构号
         ,case t8.draft_attr
               when '1' then '70020101'       --开出承兑汇票—纸质银行承兑汇票
               when '2' then '70020102'       --开出承兑汇票—电子银行承兑汇票
               else '' end                     as  subj_no              --科目号
         ,nvl(t2.product_no            ,'')    as  prod_code            --产品号
         ,'CNY'                                as  ccy                  --币种
         ,nvl(t8.draft_attr            ,'')    as  bill_attr            --票据介质
         ,nvl(t8.draft_type            ,'')    as  bill_type            --票据类型
         ,nvl(from_unixtime(unix_timestamp(t1.remit_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                       as  remit_date           --出票日
         ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   
		                                       as  bill_expr_date    --票面到期日
         ,nvl(t2.remitter_cust_no      ,'')    as  drawer_cust_id       --出票人客户号
         ,nvl(t8.remitter_name         ,'')    as  drawer_name          --出票人名称
         ,nvl(t8.remitter_account      ,'')    as  drawer_acct_no       --出票人账号
         ,nvl(t8.remitter_crt_no       ,'')    as  drawer_cert_no       --出票人证件代码  
         ,nvl(t8.remitter_bank_no      ,'')    as  drawer_bank_no       --出票人开户行号
         ,nvl(t8.remitter_bank_name    ,'')    as  drawer_bank_name     --出票人开户行名称
         ,nvl(t8.payee_name            ,'')    as  bill_rev_name        --票面收款人名称    
         ,nvl(t8.payee_crt_no          ,'')    as  rev_cert_no          --票面收款人证件号码
         ,nvl(t8.payee_bank_no         ,'')    as  bill_rev_bank_no     --票面收款人开户行号
         ,nvl(t8.payee_bank_name       ,'')    as  bill_rev_bank_name   --票面收款人开户行名称
         ,nvl(t9.prmt_payer_name       ,'')    as  act_rev_cust_name    --实际收款人名称
         ,nvl(t9.prmt_payer_crt_no     ,'')    as  act_rev_cert_no      --实际收款人证件号码
         ,nvl(t9.prmt_payer_bank_no    ,'')    as  act_rev_bank_no      --实际收款人开户行号
         ,nvl(t9.prmt_payer_name       ,'')    as  act_rev_bank_name    --票面收款人开户行名称
         ,nvl(t8.draft_amount           ,0)    as  pay_amt              --付款金额 
         ,nvl(from_unixtime(unix_timestamp(t9.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')      
		                                       as  bill_pay_date        --票据解付日期
         ,'1'                                  as  cash_status          --兑付状态
      from odata.nbms_dpc_draft_info t1
      inner join odata.nbms_cpes_accept_details  t  --承兑明细表
          on t.draft_id=t1.id
         and t.data_date='${DATA_DATE}' 
         and t.bddw_end_date='9999-99-99'
         and t.accept_status in ('06')-- 06 - 承兑完成（签发）
       left join odata.nbms_cpes_accept_contract t2  --承兑批次表
          on t.contract_id=t2.id
         and t2.data_date='${DATA_DATE}' 
         and t2.bddw_end_date='9999-99-99'
      inner join odata.nbms_dpc_draft_info t8                 --只选择有提示付款的部分
          on t1.draft_number=t8.draft_number
         and t8.data_date='${DATA_DATE}' 
         and t8.bddw_end_date='9999-99-99'
         and t8.src_type='SR014'     --提示付款           --解付会拆分,一个票号有多条解付信息
      inner join odata.nbms_cpes_prmtpay_apply t9             --只取解付成功的部分
          on t8.id=t9.draft_id 
         and t9.account_status = '02' --记账成功
         and t9.buss_flag ='02' --签收
         and t9.data_date='${DATA_DATE}' 
         and t9.bddw_end_date='9999-99-99'
      where t1.data_date='${DATA_DATE}' 
       and t1.bddw_end_date='9999-99-99'
       and t1.status != 'S00' --无效