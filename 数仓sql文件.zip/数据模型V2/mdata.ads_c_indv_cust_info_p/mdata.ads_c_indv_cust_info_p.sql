---------------------------------------------------------------------------------------------------------------
--脚本名称：对私客户信息取数逻辑.sql
--功能描述：用于在hive mdata层创建mdata.ads_c_indv_cust_info_p
--作    者：施金才
--开发日期：2020-11-19
--直属经理：程宏明
--修改历史：
--          1.施金才   2020-11-19    新建
--          2.张礼娟   2021-05-07    源表由gdata.ads_c_indv_cust_info_p改为dwd.dwd_c_indv_cust_info_p
---------------------------------------------------------------------------------------------------------------
insert overwrite table mdata.ads_c_indv_cust_info_p partition(data_date='${DATA_DATE}')
select
    acct_mask(cust_id) as cust_id                    
   ,name_mask(cust_name) as cust_name                  
   ,city_code                  
   ,cust_type_code             
   ,cert_type_code             
   ,case when cert_type_code = '101' and cert_no is not null then id_mask(cert_no) end as cert_no                    
   ,source_sys                 
   ,create_chan                
   ,country_code               
   ,nation_code                
   ,gender_code                
   ,max_edu                    
   ,max_deg                    
   ,birth_date                 
   ,cust_crdt_lvl              
   ,cust_crdt_lvl_cont         
   ,wk_code                    
   ,title_code                 
   ,emp_name                   
   ,addr_mask(emp_addr) as emp_addr                   
   ,emp_addr_post              
   ,emp_indust_type_code       
   ,tel_mask(emp_tel) as emp_tel                    
   ,emp_nature                 
   ,acct_mask(salary_acct_no) as salary_acct_no             
   ,salary_acct_name           
   ,marital_status             
   ,name_mask(spouse_name) as spouse_name                
   ,case when mobile is not null and length(spouse_mobile) = 11 then mobile_mask(spouse_mobile) end as spouse_mobile              
   ,spouse_cert_type           
   ,case when spouse_cert_type = '101' and spouse_cert_no is not null then id_mask(spouse_cert_no) end as spouse_cert_no            
   ,emp_indic_flag             
   ,tel_mask(home_tel) as home_tel                   
   ,case when mobile is not null and length(mobile) = 11 then mobile_mask(mobile) end as mobile                     
   ,indv_income_y              
   ,family_income_y            
   ,addr_mask(family_addr) as family_addr                
   ,family_zip                 
   ,addr_mask(post_addr) as post_addr                  
   ,addr_mask(domicile_addr) as domicile_addr              
   ,crdt_amt                   
   ,used_amt                   
   ,js_loan_dubil_info_cust_id 
   ,indv_cust_id_flag          
   ,cert_grant_loc_code        
   ,cert_start_date            
   ,cert_end_date              
   ,cust_create_date           
   ,cust_belong_org_id         
   ,rela_cust_flag             
   ,rela_cust_type_code        
   ,cust_status_code           
   ,blk_flag                   
   ,overseas_flag              
   ,cust_mgr_id                
   ,biz_license                
   ,unif_soc_crdt              
   ,prod_type_code                    
   ,partner_id                    
   ,remark3                    
   ,remark4                    
   ,remark5                    
from dwd.dwd_c_indv_cust_info_p
where data_date='${DATA_DATE}'