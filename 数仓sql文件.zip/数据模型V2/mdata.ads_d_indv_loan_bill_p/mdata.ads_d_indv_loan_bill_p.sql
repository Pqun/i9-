---------------------------------------------------------------------------------------------------------------
--脚本名称：个人贷款借据信息取数逻辑.sql
--功能描述：用于在hive mdata层创建mdata.ads_d_indv_loan_bill_p
--作    者：施金才
--开发日期：2020-11-19
--直属经理：程宏明
--修改历史：
--          1.施金才   2020-11-19    新建
--          2.张礼娟   2021-05-07    源表由gdata.ads_d_indv_loan_bill_p改为dwd.dwd_d_indv_loan_bill_p
---------------------------------------------------------------------------------------------------------------
insert overwrite table mdata.ads_d_indv_loan_bill_p partition(data_date='${DATA_DATE}')
select
     bill_no 
    ,case when length(acct_no)=19 then acct_mask(acct_no) end as acct_no 
    ,acct_mask(cust_id_core) as cust_id_core 
    ,name_mask(cust_name) as cust_name 
    ,cont_no 
    ,bank_org_id 
    ,fin_license_no 
    ,org_id 
    ,acctng_type 
    ,subj_cd 
    ,org_name 
    ,subj_desc 
    ,biz_type 
    ,ccy 
    ,loan_amt 
    ,loan_bal 
    ,loan_terms 
    ,renewal_cnt 
    ,term_cnt 
    ,term_no 
    ,distr_type 
    ,start_date 
    ,mature_date 
    ,acture_mature_date 
    ,int_overdue_bal 
    ,off_int_overdue_bal 
    ,loan_status 
    ,end_date 
    ,loan_type 
    ,case when length(receive_acct) = 16 then acct_mask(receive_acct) end as receive_acct --长度为20的报错
    ,loan_five_level 
    ,rate_type 
    ,base_rate 
    ,rate_float_ratio 
    ,repay_type 
    ,acct_mask(repay_acct) as repay_acct 
    ,repay_chan 
    ,calc_type 
    ,marg_ratio 
    ,marg_ccy 
    ,marg_bal 
    ,acct_mask(marg_acct) as marg_acct
    ,name_mask(crdt_tlr_name) as crdt_tlr_name 
    ,crdt_tlr_id 
    ,cash_tran_flag 
    ,accu_overdue_num 
    ,cont_overdue_num 
    ,entrusted_pay_flag 
    ,null as remark1 
    ,null as remark2 
    ,null as remark3 
    ,null as remark4
    ,null as remark5 
from dwd.dwd_d_indv_loan_bill_p
where data_date='${DATA_DATE}'