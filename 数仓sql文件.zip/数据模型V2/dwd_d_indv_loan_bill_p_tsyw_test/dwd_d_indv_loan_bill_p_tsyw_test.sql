--2.hts.dwd_d_indv_loan_bill_p
-------------------------------------------------------------------
--脚本名称:dwd_d_indv_loan_bill_p
--功能描述:个人贷款借据信息表
--作    者:于国睿
--开发日期:2021-12-23
--直属经理:方杰
--来源表:odata.slur_bdul_loan_file        借据信息表
--来源表:odata.sym_gl_prod_accounting     产品科目表
--来源表:odata.gl_v_gl_subject            科目名称表
--来源表:odata.sym_cif_client_document    客户证件信息表
--来源表:odata.sym_cif_client_contact_tbl 客户联系信息表
--来源表:odata.plm_loan_info_detail       五级分类表
--来源表:odata.sso_upms_user              历史流程示例表
--来源表:odata.ols_loan_cont_info         支用合同表
--来源表:odata.slur_bdul_rate_file        百度联合贷费率文件表
--来源表:odata.slur_bdul_repayplan_file   百度联合贷还款文件计划表
--来源表:odata.ols_loan_prd_info          贷款产品信息表
--来源表:odata.ols_admin_sm_user          系统用户信息表
--来源表:dwd.dwd_d_indv_credit_cont_p     个人授信合同表              
--目标表  :dwd.dwd_d_indv_loan_bill_p 
--修改历史:
--         1、于国睿     2021-12-27     新建
--         2、高源       2022-06-06     新增应收未收利息、应收利息科目、利息调整、利息调整科目、利息拖欠日期、
--                                      来源系统、贷款投向行业、结清标识等字段,结清日期逻辑调整
--         3、高源       2022-06-22     新增记账时间字段逻辑
--         4、高源       2022-07-07     新增计息基础、客户所属行业、贷款业务细类、贷款用途明细分类字段逻辑
--         5、高源       2022-07-11     剔出冲正部分数据
--         6、高源       2022-08-10     借据起始日期、借据到期日、借据关闭日期逻辑调整，结清时间格式调整
--         7、高源       2022-10-09     新增机构号、贷款支用申请编号字段逻辑
--         8.华天顺      2022-12-02     新增核算状态字段
--         9.华天顺      2022-12-28     逾期天数取数逻辑调整，新增逾期本金，利息和本金逾期日字段
--         10.杨琦浩     2023-03-14     增加到期日字段
-------------------------------------------------------------------
--张家港联合贷
insert overwrite table dwd.dwd_d_indv_loan_bill_p_test20230307 partition(data_date='${DATA_DATE}',prod_code)
    select 
                 /*+ REPARTITION(1) */
				 nvl(t1.loan_id,'')                       as bill_no                   --借据号
                ,'张家港联合贷'                           as prod_name                 --产品名称
                ,nvl(t1.loan_id,'')                       as acct_no                   --账号
                ,''                                       as acct_seq_no               --账户序列号
                ,nvl(t7.loan_no,'')                       as biz_prod_code             --业务产品号
                ,''                                       as sub_biz_prod_code         --业务子产品号
                ,'01'                                     as accting_cacl_mode         --会计核算方式
                ,'10400101'                               as subj_no                   --科目号
                ,'个人消费贷款-成本'                      as subj_name                 --科目名称
                ,nvl(t2.cust_id_core,'')                  as cust_id                   --客户号
                ,nvl(t2.cust_name,'')                     as cust_name                 --客户姓名
                ,nvl(t2.cert_type,'')                     as cert_type                 --证件类型
                ,nvl(t2.cert_code,'')                     as cert_no                   --证件号
                ,nvl(t3.contact_tel,'')                   as mobile_no                 --客户手机号
                ,nvl(t27.credit_limit,0)                  as credit_limit              --授信额度
                ,nvl(t27.credit_terms,'')                 as credit_term               --授信期限
                ,nvl(t27.credit_start_date,'')            as credit_start_date         --授信起始日期
                ,nvl(t27.credit_mature_date,'')           as credit_end_date           --授信到期日期
                ,nvl(t2.crd_cont_no,'')                   as credit_cont_no            --授信合同编号
                ,nvl(t2.repay_type,'')                    as repay_mode                --还款方式
                ,nvl(date_add(t2.loan_start_date,1),'')   as loan_grant_date           --贷款发放日期
                ,'00:00:00'                               as loan_grant_time           --贷款发放时间
                ,nvl(t1.loan_id,'')                       as loan_cont_no              --贷款合同号
                ,''                                       as fin_supp_mode             --贷款财政扶持方式
                ,'D'                                      as loan_guar_mode            --贷款担保方式
                ,'2'                                      as loan_purp_desc            --贷款用途说明
                ,'TR05'                                   as pric_benc                 --定价基准
                ,nvl(t2.cont_status,'')                   as loan_cont_status          --贷款合同状态
                ,nvl(t2.loan_start_date   ,'')            as loan_start_date           --借据起始日期
                ,nvl(t2.loan_end_date     ,'')            as loan_mature_date          --借据到期日期
                ,nvl(t2.loan_clear_date   ,'')            as loan_close_data           --借据关闭日期
                ,nvl(t1.encash_amt,0)/100                 as loan_amt                  --放款金额
                ,nvl(t1.total_terms,0)                    as total_loan_terms          --放款总期数
                ,nvl(t1.cur_term,0)                       as curr_term_no              --当前期次
                ,'RF01'                                   as rate_type                 --利率类型 
                ,nvl(t2.exec_rate,0)                       as real_rate                --实际利率 
                ,''                                       as partner_id                --合作方编码      
                ,''                                       as partner_name              --合作方名称     
                ,nvl(t2.channel_type,'')                  as sub_channel_type          --渠道类型   
                ,'1'                                      as consume_scen_flag         --消费场景标签  
                ,t2.invest_ratio                          as invest_ratio              --出资比例      
                ,'CNY'                                    as ccy                       --币种
                ,nvl(t1.grace_day,0)                      as grace_days                --宽限天数
                ,case when nvl(date_add(t2.loan_clear_date,1),'')>'${DATA_DATE}'
                      then ''
                      else nvl(date_add(t2.loan_clear_date,1),'')
                  end                                     as clear_date                --结清日期
                ,nvl(least(t10.due_date_pri1,t10.due_date_int1),'')                                  as overdue_start_date        --逾期起始日
                ,nvl(greatest(t10.due_date_pri,t10.due_date_int),0)                                     as overdue_days              --逾期天数
                ,''                                       as defer_mature_date         --贷款展期到期日期
                ,case when t10.due_date_pri1 is not null and t10.due_date_int1 is null 
                      then '01'
                      when t10.due_date_pri1 is null and t10.due_date_int1 is not null 
                      then '02'
                      when t10.due_date_pri1 is not null and t10.due_date_int1 is not null 
                      then '03'
					  else ''
                  end                                     as overdue_type              --逾期类型
                ,case when t6.loan_id is not null then t6.manual_five_class
                      when t6.loan_id is null and t2.five_cate = '1' then 'FQ01'
                      when t6.loan_id is null and t2.five_cate = '2' then 'FQ02'
                      when t6.loan_id is null and t2.five_cate = '3' then 'FQ03'
                      when t6.loan_id is null and t2.five_cate = '4' then 'FQ04'
                      when t6.loan_id is null and t2.five_cate = '5' then 'FQ05'
                      else ''
                  end                                     as five_risk_level           --贷款5级分类
                ,nvl(t2.loan_card_no,'')                  as receive_acct_no           --贷款入账账号 
                ,nvl(t2.repay_card_no,'')                 as repay_acct_no             --还款账号
                ,nvl(t7.pay_way,'')                       as payment_mode              --支付方式
                ,'02'                                     as cash_tran_flag            --现转标志
                ,nvl(t8.user_name,'')                     as credit_tlr_name           --信贷员姓名
                ,nvl(t2.biz_manager_id,'')                as credit_tlr_id             --信贷员员工号
                ,'B01'                                    as int_mode                  --计息方式
                ,'01'                                     as repay_freq                --还款频率
                ,''                                       as pay_seq_no                --支付流水号
                ,'1'                                      as loan_biz_class            --业务分类
                ,(nvl(t1.prin_bal,0)+nvl(t1.ovd_prin_bal,0))/100    as bal             --贷款余额
                --,case when t1.loan_form = '1' then nvl(t1.int_bal,0)/100 
                --      else 0 
                --  end                                     as receiv_int                --应收未收利息
                ,nvl(yjlx.receiv_int/100,0)               as receiv_int                --应收未收利息
                ,'10600701'                               as recv_int_subj             --应收利息科目
                ,0                                        as int_adj                   --利息调整
                ,''                                       as int_adj_subj              --利息调整科目
                ,nvl(t10.due_date_int1,'')                                     as overdue_date_int          --利息拖欠日期
                ,'SYM'                                    as source_system             --来源系统
                ,''                                       as loan_indst_type           --贷款投向行业
                ,case when nvl(date_add(t2.loan_clear_date,1),'')>'${DATA_DATE}' then '0'
                      when t2.loan_clear_date  is not null then '1'
                      else  '0'  
                  end                                     as fully_settled             --结清标识 
                ,nvl(substr(t21.tran_date,1,10),'')       as accting_date              --记账日期
                ,''                                       as int_basis                 --计息基础
                ,''                                       as cust_indust_type          --客户所属行业
                ,'A29'                                    as loan_biz_detail           --贷款业务细类
                ,case when t2.loan_purpose ='100' then '资金周转'
                      when t2.loan_purpose ='101' then '投资需求'
                      when t2.loan_purpose ='102' then '扩大经营规模'
                      when t2.loan_purpose ='103' then '店面装修改造'
                      when t2.loan_purpose ='104' then '购房'
                      when t2.loan_purpose ='105' then '购车（自用型）'
                      when t2.loan_purpose ='106' then '购买车位'
                      when t2.loan_purpose ='107' then '房屋装修'
                      when t2.loan_purpose ='108' then '购买大额耐用消费品'
                      when t2.loan_purpose ='109' then '旅游'
                      when t2.loan_purpose ='110' then '出国留学'
                      when t2.loan_purpose ='111' then '教育'
                      when t2.loan_purpose ='112' then '婚嫁'
                      when t2.loan_purpose ='113' then '医疗保健'
                      when t2.loan_purpose ='114' then '购买大额人寿保险'
                      when t2.loan_purpose ='115' then '资产置换'
                      when t2.loan_purpose ='116' then '其他'
                      when t2.loan_purpose ='117' then '土地储备'
                      when t2.loan_purpose ='118' then '房地产开发'
                      when t2.loan_purpose ='119' then '个人住房'
                      when t2.loan_purpose ='120' then '商业用房'
                      when t2.loan_purpose ='121' then '基本建设'
                      when t2.loan_purpose ='122' then '技术改造'
                      when t2.loan_purpose ='123' then '基础设施'
                      when t2.loan_purpose ='124' then '个人日常消费'
                      else  '其他'   
                  end                                     as loan_purp_detail          --贷款用途明细分类
                ,'100000'                                 as org_id                    --机构号
                ,nvl(t2.app_no  ,'')                      as loan_app_no               --贷款支用申请编号
                ,''                                       as accting_status            --核算状态
				,nvl(t9.principal_due,0)/100                                       as overdue_prin              --逾期本金
				,nvl(t9.interest_due,0)/100+nvl(t9.interest_odp,0)/100                                       as overdue_int               --逾期利息
				,nvl(t10.due_date_pri1,'')                as pri_overdue_date          --本金逾期日
				--,''                                       as mature_date               --到期日
                ,'110142'                                 as prod_code                 --产品号
          from  odata.slur_bdul_loan_file_clear t1
     left join 
            (
                 select 
                         loan_id
                        ,tran_date
                  from  odata.slur_bdul_open_file
                 where  data_date ='${DATA_DATE}'
                   and  bddw_end_date = '9999-99-99'
                   --and fund_status = '2'  --限制为放款成功
                   --and upper(tran_status) = 'N'  --正常
                   and  loan_mode = '01'
            )t21
            on  t1.loan_id = t21.loan_id
     left join  odata.ols_loan_cont_info t2
            on  t1.loan_id = t2.bill_no
           and  t2.data_date = '${DATA_DATE}'
           and  t2.bddw_end_date = '9999-99-99'
           and  t2.cont_status in ('105','106','107','108','109','110')
     left join  odata.sym_cif_client_contact_tbl t3
            on  t2.cust_id_core = t3.client_no 
           and  t3.pref_flag='Y'
           and  t3.data_date='${DATA_DATE}'
           and  t3.bddw_end_date='9999-99-99'
     left join  dwd.dwd_d_indv_credit_cont_p t27
            on  t27.credit_cont_no=t2.crd_cont_no
           and  t27.data_date='${DATA_DATE}'
     left join 
            (
                 select 
                         loan_id
                        ,min(end_date) as end_date 
                  from  odata.slur_bdul_repayplan_file
                 where  data_date = '${DATA_DATE}'
                   and  bddw_end_date = '9999-99-99'
                   and  (principal_due>0 or interest_due>0)
              group by  loan_id
            ) t5
            on t1.loan_id = t5.loan_id
     left join
            (
                 select 
                         loan_id
                        ,prod_type
                        ,case when manual_five_class = '正常'  then  'FQ01'
                              when manual_five_class = '关注'  then  'FQ02'
                              when manual_five_class = '次级'  then  'FQ03'
                              when manual_five_class = '可疑'  then  'FQ04'
                              when manual_five_class = '损失'  then  'FQ05'
                          end                          as manual_five_class
                  from  odata.plm_loan_info_detail
                 where  data_date = '${DATA_DATE}'
                   and  bddw_end_date = '9999-99-99'
                   and  prod_type = '110114'
                   and  manual_term_validity_date >= '${DATA_DATE}'
            ) t6
            on  t1.loan_id = t6.loan_id
     left join  odata.ols_loan_prd_info t7
            on  t2.prd_code=t7.loan_no
           and  t7.data_date = '${DATA_DATE}'
           and  t7.bddw_end_date = '9999-99-99'
     left join  odata.ols_admin_sm_user t8
            on  t2.biz_manager_id = t8.login_code
           and  t8.data_date='${DATA_DATE}' 
           and  t8.bddw_end_date='9999-99-99' 
     left join 
     (
              select 
     		      loan_id
     		     ,sum(case when  prin_total-prin_repay>0
     			            and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(end_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))>=31 
     		                and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(end_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))<=60  
     		                then prin_total-prin_repay else 0 end )                         as outstanding_pri_3160  --逾期31-60天未归还贷款本金
                  ,sum(case when  prin_total-prin_repay>0
     			            and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(end_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))>=61 
                             and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(end_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))<=90  
                             then prin_total-prin_repay else 0 end )                         as outstanding_pri_6190  --逾期61-90天未归还贷款本金
                  ,sum(case when  prin_total-prin_repay>0
     			            and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(end_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))>=91 
                             and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(end_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))<=180 
                             then prin_total-prin_repay else 0 end )                         as outstanding_pri_91180 --逾期91-180天未归还贷款本金
                  ,sum(case when  prin_total-prin_repay>0
     			            and datediff(regexp_replace(substr('${DATA_DATE}',1,10),'-',''),end_date)>180 
                             then prin_total-prin_repay else 0 end )                         as outstanding_pri_180   --逾期180天以上未归还贷款本金
                  ,sum(case when  prin_total-prin_repay >0 
     			            and  end_date<regexp_replace('${DATA_DATE}','-','') 
     					    then prin_total-prin_repay end)                                 as principal_due --逾期本金
                  ,sum(case when int_total-int_repay >0 
     			            and end_date<regexp_replace('${DATA_DATE}','-','') 
     					    then int_total-int_repay end)                                   as interest_due  --逾期利息
                  ,sum(case when pnlt_int_total-pnlt_int_repay >0 
     			            and end_date<regexp_replace('${DATA_DATE}','-','') 
     					    then pnlt_int_total-pnlt_int_repay end)                                   as interest_odp  --逾期罚息
     	  from odata.slur_bdul_repayplan_file_clear     --还款计划表
     		  where data_date = '${DATA_DATE}'
     		    and bddw_end_date = '9999-99-99'
     			and loan_mode = '01'
     			--and term_status='2'  该状态有三天宽限期
     		 group by loan_id
     )t9 
     on t1.loan_id = t9.loan_id
     left join
     (
     select 
        yq1.loan_id
        ,nvl(datediff('${DATA_DATE}',yq1.due_date_pri1),0) as due_date_pri
        ,nvl(datediff('${DATA_DATE}',yq1.due_date_int1),0) as due_date_int
		,yq1.due_date_pri1
		,yq1.due_date_int1
     from 
     (
               select 
     		       loan_id
                  ,min(case when prin_total-prin_repay >0
     			           then from_unixtime(unix_timestamp(nvl(end_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) as due_date_pri1  --逾期本金天数
     	         ,min(case when int_total-int_repay >0
     			           then from_unixtime(unix_timestamp(nvl(end_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) as due_date_int1  --逾期利息天数
     	  from odata.slur_bdul_repayplan_file_clear  --还款计划表
     		  where data_date = '${DATA_DATE}'
     		    and bddw_end_date = '9999-99-99'
     			and loan_mode = '01'
     			--and term_status='2'该状态有三天宽限期
     			and ( prin_total>0 or int_total>0)
     			and end_date< regexp_replace('${DATA_DATE}','-','')
     		 group by loan_id)yq1
     )t10 
     on t1.loan_id=t10.loan_id
     left join 
     (
     select loan_id 
            ,sum(rec_amt) as receiv_int
            from smart.mid_etl_rec_int 
            where data_date='${DATA_DATE}' 
            and source_id='110142'
            group by loan_id
     ) yjlx 
     on t1.loan_id=yjlx.loan_id
         where  t1.data_date = '${DATA_DATE}'
           and  t1.bddw_end_date = '9999-99-99'
           and  t1.loan_mode ='01'         --联合出资我行部分
           and  t1.loan_status<>'3'        --剔除冲正部分