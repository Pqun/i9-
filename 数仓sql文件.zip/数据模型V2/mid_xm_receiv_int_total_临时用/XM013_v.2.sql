--XM013实还表内罚息
insert into dwd.mid_xm_recv_int_scene_tran_old partition(data_date='${DATA_DATE}') 		 
select /*+ REPARTITION(1) */ 
xlf.loan_id  as loan_no,
       'XM013' as sence,
       sum(nvl(xrif.pnlt_int_amt, 0))/100 as int_amt
  from odata.slur_xm_loan_file_clear xlf
 inner join odata.slur_xm_loan_file_clear last
    on last.loan_id = xlf.loan_id
   and last.data_date = date_add('${DATA_DATE}',-1)
   and last.bddw_end_date = '9999-99-99'
   and last.loan_status != '6'
   and last.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
 inner join odata.slur_xm_repay_item_file xrif
    on xrif.loan_id = xlf.loan_id
   and xrif.data_date = '${DATA_DATE}'
   and xrif.bddw_end_date = '9999-99-99'
   and xrif.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  where xlf.data_date = '${DATA_DATE}'
   and xlf.bddw_end_date = '9999-99-99'  
   and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')--未核销
   and not exists(select 1
                    from odata.slur_acc_writeoff_hist awh
                   where awh.data_date = '${DATA_DATE}'
                     and awh.bddw_end_date = '9999-99-99' 
				     and awh.loan_no = xlf.loan_id
                     and awh.tran_date < xlf.tran_date
					 )
   --上日核算状态为表内
    and not exists(select 1
                     from odata.slur_xm_term_status_file xtsf
                    where xtsf.data_date = date_add('${DATA_DATE}',-1)
                      and xtsf.bddw_end_date = '9999-99-99'
					  and xtsf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
                      and xtsf.loan_id = xlf.loan_id
                      and xtsf.term_status <> 5                                                    --未结清
                      and not exists (select 1
                                        from odata.slur_dzz_compensatory_detail dcd
                                       where dcd.data_date = '${DATA_DATE}'
									     and dcd.bddw_end_date = '9999-99-99'
									     and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                                         and dcd.loan_no = xtsf.loan_id
                                         and dcd.term_no = xtsf.term_no
                                         and dcd.comps_status = 'S'
                                         and dcd.prod_type = '110126') 
					   having max(xtsf.days_ovd) > 89)
   and not exists(select 1
                    from odata.slur_dzz_compensatory_detail dcd
                   where dcd.data_date = '${DATA_DATE}'
				     and dcd.bddw_end_date = '9999-99-99'
				     and dcd.loan_no = xrif.loan_id
                     and dcd.term_no = xrif.term_no
					 and dcd.comps_status = 'S'      --廖百平修改
                     and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
	group by xlf.loan_id