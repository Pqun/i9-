--XM011  
insert into dwd.mid_xm_recv_int_scene_tran_old partition(data_date='${DATA_DATE}') 		 
--上日数据不为空
select /*+ REPARTITION(1) */ 
xlf.loan_id,
        'XM011' as sence,
       sum(nvl(xrif.int_amt, 0))/100 as int_amt 
  from odata.slur_xm_loan_file_clear xlf
 inner join odata.slur_xm_loan_file_clear last
    on last.loan_id = xlf.loan_id
	and last.data_date = date_add('${DATA_DATE}',-1)
    and last.bddw_end_date = '9999-99-99'
    and last.loan_status !='6'   
    and last.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')                                    
 inner join odata.slur_xm_repay_item_file xrif
    on xrif.loan_id = xlf.loan_id
	and xrif.data_date = '${DATA_DATE}'
    and xrif.bddw_end_date = '9999-99-99'
    and xlf.channel_date = xrif.channel_date                      --未核销
 where xlf.data_date = '${DATA_DATE}'
   and xlf.bddw_end_date = '9999-99-99'
   and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
   and not exists(select 1
                    from odata.slur_acc_writeoff_hist awh
                    where awh.data_date = '${DATA_DATE}'
					  and awh.bddw_end_date = '9999-99-99'
					  and awh.loan_no = xlf.loan_id
                      and awh.tran_date < xlf.tran_date
					  ) 
   --上日核算状态为表内
   and not exists(select 1
                     from odata.slur_xm_term_status_file xtsf
                    where xtsf.data_date = date_add('${DATA_DATE}',-1)
                      and xtsf.bddw_end_date = '9999-99-99'
					  and xtsf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
                      and xtsf.loan_id = xlf.loan_id
                      and xtsf.term_status <> 5                                                    --未结清
                      and not exists (select 1
                                        from odata.slur_dzz_compensatory_detail dcd
                                       where dcd.data_date = '${DATA_DATE}'
									     and dcd.bddw_end_date = '9999-99-99'
									     and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                                         and dcd.loan_no = xtsf.loan_id
                                         and dcd.term_no = xtsf.term_no
                                         and dcd.comps_status = 'S'
                                         and dcd.prod_type = '110126') 
					   having max(xtsf.days_ovd) > 89)
    and not exists (select 1
                      from odata.slur_dzz_compensatory_detail dcd1
                     where dcd1.data_date = '${DATA_DATE}'
					   and dcd1.bddw_end_date = '9999-99-99' 
					   and dcd1.loan_no = xrif.loan_id
                       and dcd1.term_no = xrif.term_no
					   and dcd1.comps_status = 'S'      --廖百平修改
                       and dcd1.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
    group by xlf.loan_id
           
          
union all

          
--上日数据为空 
select  /*+ REPARTITION(1) */ 
xrif.loan_id,
        'XM011' as sence,
       sum(nvl(xrif.int_amt, 0))/100
  from odata.slur_xm_repay_item_file xrif
  inner join odata.slur_xm_loan_file_clear xlf
    on xlf.loan_id = xrif.loan_id
	and xlf.data_date = '${DATA_DATE}'
	and xlf.bddw_end_date = '9999-99-99'
	and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  where xrif.data_date = '${DATA_DATE}'
    and xrif.bddw_end_date = '9999-99-99'
    and not exists(select 1
                     from odata.slur_xm_loan_file_clear last
                     where last.data_date = '${DATA_DATE}'
					  and last.bddw_end_date = '9999-99-99'
					  and last.loan_id = xlf.loan_id
                      and last.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')) --未代偿              
    and not exists (select 1
                      from odata.slur_dzz_compensatory_detail dcd
                      where dcd.data_date = '${DATA_DATE}'
					   and dcd.bddw_end_date = '9999-99-99'
					   and dcd.loan_no = xrif.loan_id
                       and dcd.term_no = xrif.term_no
					   and dcd.comps_status = 'S'      --廖百平修改
                       and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
                  --未核销
    and not exists(select 1
                     from odata.slur_acc_writeoff_hist awh
                    where awh.data_date = '${DATA_DATE}'
					  and awh.bddw_end_date = '9999-99-99'
					  and awh.loan_no = xlf.loan_id
                      --to_char(awh.tran_date, 'yyyymmdd') < xlf.tran_date
					  and awh.tran_date < xlf.tran_date)
	group by xrif.loan_id

union all

select /*+ REPARTITION(1) */ 
a.loan_id,
       'XM011' as sence,
       sum(nvl(a.int_today,0))/100 
  from odata.slur_xm_loan_file_clear a 
  where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
    and a.cur_date = a.start_date 
	and a.int_today > 0
	group by a.loan_id
