--2.gaoyuan.dwd.dwd_e_capt_tran_list_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：dwd_e_capt_tran_list_p.sql
--功能描述：同业资金交易流水表
--来源表  ：odata.tb_vs_accentry2               提供账务分录(包含手工调账分录)信息 
--来源表  ：odata.tb_v_alterbalance             查询当日资产变动信息
--来源表  ：odata.tb_v_balance                  查询当日日终后的资产余额信息
--来源表  ：odata.tb_v_ldrepodeals              查询质押式回购的数据
--来源表  ：odata.tb_vs_cptys                   提供交易对手基础信息
--来源表  ：odata.nbms_cpes_quote_contract      对话报价协议表
--来源表  ：odata.nbms_dpc_draft_info           登记中心票据信息表
--来源表  ：odata.nbms_cpes_quote_details       对话报价明细表
--来源表  ：odata.nbms_cpes_quote_due           对话报价到期表
--来源表  ：odata.nbms_bms_provision            计提主表
--来源表  ：odata.nbms_bms_customer_info        客户信息表
--来源表  ：odata.nbms_bms_trade_detail         记账分录表
--来源表  ：odata.nbms_bms_buy_details          贴现明细表
--来源表  ：odata.nbms_bms_buy_contract         贴现批次表
--来源表  ：odata.nbms_cpes_buy_details         贴现明细表
--来源表  ：odata.nbms_cpes_buy_contract        贴现批次表
--来源表  ：odata.tb_vs_payment_trsi_loandeals  提供同业存放交易的支付信息和清算路径的信息 
--来源表  ：odata.tb_vs_payment_loandeals       查询实际收付确认同业存放的数据
--来源表  ：odata.tb_v_loandeals                查询同业存放的数据
--来源表  ：odata.tb_vs_payment_trsi_iamdeals   提供拆借交易的支付信息和清算路径的信息 
--来源表  ：odata.tb_vs_payment_iamdeals        查询实际收付确认拆借的数据
--来源表  ：odata.tb_v_iamdeals                 查询拆借的数据
--来源表  ：odata.nbms_bms_accept_details       承兑明细表
--来源表  ：odata.nbms_bms_accept_contract      承兑批次表
--来源表  ：odata.nbms_cpes_accept_details      承兑明细表
--来源表  ：odata.nbms_cpes_accept_contract     承兑批次表
--来源表  ：odata.nbms_bms_accept_status        承兑状态表
--来源表  ：odata.nbms_bms_accept_due_pay       解付信息表
--来源表  ：odata.nbms_cpes_prmtpay_apply       提示付款申请表
--来源表  ：odata.tb_v_security                 查询债券基本资料信息
--来源表  ：odata.tb_vs_payment_bondsdeals_all  实际收付确认-现券交易-含衍生
--来源表  ：odata.tb_v_bondsdeals               查询现券交易
--来源表  ：odata.tb_vs_payment_coupondeals     实际收付确认-现券收付息
--来源表  ：odata.tb_v_wtrade_nstd_asset        查询非标资产交易的数据
--来源表  ：odata.tb_v_nstd_asset               查询非标资产基本资料信息
--来源表  ：odata.tb_vs_payment_wtrade_nstd_asset   查询实际收付确认非标资产的数据
--来源表  ：odata.tb_v_nstd_asset_extent2       资产自定义字段值2
--来源表  ：odata.tb_v_wtrade_mmf_asset         货币基金交易
--来源表  ：odata.tb_v_fund_asset               货币基金基本资料
--来源表  ：odata.tb_vs_payment_wtrademmfasset  实际收付确认-货币基金交易
--来源表  ：odata.tb_v_nstd_asset_extent        资产自定义字段值
--来源表  ：odata.tb_v_wtrade_nv_asset          净值型产品主单视图
--来源表  ：odata.tb_vs_payment_wtrade_nv_asset 实际收付确认-净值型产品主单视图
--来源表  ：odata.tb_v_ncd_commission_data      债券发行结果缴款汇总信息
--来源表  ：odata.nbms_ces_quote_deal           对话报价成交单表
--来源表  : odata.nbms_mem_brh_info             会员机构信息表
--目标表  ：dwd.dwd_e_capt_tran_list_p      同业资金交易流水表
--修改历史：
--          1.张礼娟   2022-11-16    新建
--          2.高源     2022-12-06    新增承兑汇票流水、债券投资流水 
--          3.高源     2022-12-21    新增贴现、转贴现业务贴现金额逻辑  
--          4.高源     2022-12-27    新增新票据系统银行承兑、票据贴现流水逻辑  
--          5.高源     2023-02-09    新增本方资金账号、审批人、经办人、到期收益率字段逻辑
--          6.邓权     2023-02-09    新增非标资产、净值资产、货币基金业务逻辑
--          7.高源     2023-03-01    新增同业存单业务逻辑
--          8.高源     2023-03-23    同业存单业务穿透到交易对手力度
--          9.高源     2023-03-28    新增交割日期字段、交易日期逻辑调整,spv业务交易对手编号、交易对手名称逻辑变更
--          10.高源    2023-09-01    转贴现业务交易对手名称、对方账号逻辑调整
--          11.高源    2023-09-20    新增同业存单兑付流水
--          12.高源    2023-10-13    同业拆借、同业借贷流水协新增资产编号逻辑
--          13.高源    2023-11-16    1、票据贴现业务新增协议号逻辑
--                                   2、剔除资金系统业务逻辑
--          14.高源    2023-12-11    1、票据贴现业务经办人、审批人逻辑调整
--          15.高源    2023-12-28    1、票据回购业务、银城兑付流水新增对方账号逻辑
--                                   2、新增交易对手行号、交易对手行名字段
--          16.高源    2024-03-01    贴现贴入流水新增记账成功限制条件
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_capt_tran_list_p partition(data_date='${DATA_DATE}')
----------------------------------买入返售票据------------------------------------------
  select /*+ REPARTITION(1) */
            t1.lsh                                                         as tran_seqno           --交易流水号
           ,t2.contract_no                                                 as deal_id              --业务编码
           ,''                                                             as asset_code           --资产编号
           ,from_unixtime(unix_timestamp(t1.jyrq,'yyyyMMdd'),'yyyy-MM-dd') as tran_date            --交易日期
           ,''                                                             as tran_time            --交易时间
           ,'CNY'                                                          as ccy                  --币种
           ,t1.dr_cr                                                       as debit_flag           --交易方向
           ,t1.jyje                                                        as tran_amt             --交易金额 
           ,t2.rate*100                                                    as exec_rate            --执行利率
           ,'100000'                                                       as org_id               --机构代码
           ,t1.kmh                                                         as subj_no              --科目代码
           ,nvl(td.adver_fund_acct ,'')                                    as  counter_acct        --对方账号/卡号  --update 20231228
           ,''                                                             as counter_acct_name    --对方账户名称
           ,nvl(t2.cust_no,'')                                             as tran_party_id        --交易对手编号
           ,nvl(t3.cust_name,'')                                           as tran_party_name      --交易对手名称
           ,''                                                             as tran_status          --交易状态
           ,'nbms'                                                         as source_system        --数据来源
           ,0                                                              as settle_amt           --结算金额
           ,0                                                              as accru_int            --应计利息
           ,0                                                              as repaid_prin          --还本金额
           ,''                                                             as self_cash_acct_no    --本方资金账号
           ,''                                                             as approver             --审批人
           ,''                                                             as operator             --经办人
           ,0                                                              as yield_mature         --到期收益率
           ,''                                                             as settle_date          --结算日期
		   ,''                                                             as cont_no              --协议号       --update 20230916 新增 
		   ,nvl(tm.ubank_no         ,'')                                   as counter_bank_code    --交易对手行号 --update 20231228
           ,case when  tm.ubank_no is null  then  ''
		         else  nvl(tm.brh_zh_full_name,'')     end                 as counter_bank_name   --交易对手行名     --剔除非银机构  --update 20231228		
  from (
      --质押式买入返售票据-面值（买入）
        select 
            id           as contract_id
            ,contract_no 
            ,sum_amount  as jyje
            ,apply_date  as jyrq
            ,contract_no as lsh
            ,'D'         as dr_cr
            ,'10200201'  as kmh
            ,cust_no
         from odata.nbms_cpes_quote_contract
        where data_date = '${DATA_DATE}'
         and bddw_end_date='9999-99-99'
         and trade_direct = 'CRD01'
         and account_status = '02'
        union all
        --质押式买入返售票据-面值（返售）
        select 
            b.id            as contract_id
            ,b.contract_no
            ,b.sum_amount   as jyje
            ,a.busi_date    as jyrq
            ,a.contract_no  as lsh
            ,'C'            as dr_cr
            ,'10200201'     as kmh
            ,b.cust_no
         from odata.nbms_cpes_quote_due a
        left join odata.nbms_cpes_quote_contract b
          on a.org_cpes_quote_contract_id = b.id
          and b.data_date = '${DATA_DATE}'
          and b.bddw_end_date='9999-99-99'
        where a.data_date = '${DATA_DATE}'
          and a.bddw_end_date='9999-99-99'
          and a.trade_direct = 'CRD02'
          and b.id is not null
         )t1
  left join odata.nbms_cpes_quote_contract t2
         on t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
        and t1.contract_id = t2.id
  left join odata.nbms_ces_quote_deal td
         on t2.deal_id=td.dealed_no
        and td.data_date='${DATA_DATE}' 
        and td.bddw_end_date='9999-99-99'
  left join odata.nbms_mem_brh_info tm 
         on td.adver_brh_no = tm.brh_no
        and tm.data_date = '${DATA_DATE}'
        and tm.bddw_end_date = '9999-99-99' 
  left join odata.nbms_bms_customer_info t3
         on t3.data_date = '${DATA_DATE}'
        and t3.bddw_end_date = '9999-99-99'
        and t2.cust_no = t3.cust_no
        and t3.cust_type='2'
  union all
--------------------------------------------------卖出回购票据----------------------------------------------
  select /*+ REPARTITION(1) */
            t1.lsh                                                         as tran_seqno         --交易流水号
           ,t2.contract_no                                                 as deal_id              --业务编码
           ,''                                                             as asset_code         --资产编号
           ,from_unixtime(unix_timestamp(t1.jyrq,'yyyyMMdd'),'yyyy-MM-dd') as tran_date          --交易日期
           ,''                                                             as tran_time          --交易时间
           ,'CNY'                                                          as ccy                --币种
           ,t1.dr_cr                                                       as debit_flag         --交易方向
           ,t1.jyje                                                        as tran_amt           --交易金额 
           ,t2.rate*100                                                    as exec_rate          --执行利率
           ,'100000'                                                       as org_id             --机构代码
           ,t1.kmh                                                         as subj_no            --科目代码
           ,nvl(td.adver_fund_acct ,'')                                    as counter_acct       --对方账号/卡号   --update 20231228
           ,''                                                             as counter_acct_name  --对方账户名称
           ,nvl(t2.cust_no,'')                                             as tran_party_id      --交易对手编号
           ,nvl(t3.cust_name,'')                                           as tran_party_name    --交易对手名称
           ,''                                                             as tran_status        --交易状态
           ,'nbms'                                                         as source_system      --数据来源
           ,0                                                              as settle_amt         --结算金额
           ,0                                                              as accru_int          --应计利息
           ,0                                                              as repaid_prin        --还本金额
           ,''                                                             as self_cash_acct_no  --本方资金账号
           ,''                                                             as approver           --审批人
           ,''                                                             as operator           --经办人
           ,0                                                              as yield_mature       --到期收益率
           ,''                                                             as settle_date        --结算日期
 		   ,''                                                             as cont_no            --协议号       --update 20230916 新增 
		   ,nvl(tm.ubank_no         ,'')                                   as counter_bank_code  --交易对手行号 --update 20231228
           ,case when  tm.ubank_no is null  then  ''
		         else  nvl(tm.brh_zh_full_name,'')     end                 as counter_bank_name   --交易对手行名     --剔除非银机构  --update 20231228		
  from (
      --卖出回购票据-面值（卖出）
         select 
             id           as contract_id
             ,contract_no 
             ,sum_amount  as jyje
             ,apply_date  as jyrq
             ,contract_no as lsh
             ,'C'         as dr_cr
             ,'20200201'  as kmh
         from odata.nbms_cpes_quote_contract
         where data_date = '${DATA_DATE}'
           and bddw_end_date='9999-99-99'
           and trade_direct = 'CRD02'
           and account_status = '02'
        union all
         --卖出回购票据-面值（回购）
         select 
             b.id            as contract_id
             ,b.contract_no
             ,b.sum_amount   as jyje
             ,a.busi_date    as jyrq
             ,a.contract_no  as lsh
             ,'D'            as dr_cr
             ,'20200201'     as kmh
         from odata.nbms_cpes_quote_due a
         left join odata.nbms_cpes_quote_contract b
           on a.org_cpes_quote_contract_id = b.id
           and b.data_date = '${DATA_DATE}'
           and b.bddw_end_date='9999-99-99'
           and a.trade_direct = 'CRD01'
         where a.data_date = '${DATA_DATE}'
           and a.bddw_end_date='9999-99-99'
           and b.id is not null
        )t1
  left join odata.nbms_cpes_quote_contract t2
     on t2.data_date='${DATA_DATE}'
     and t2.bddw_end_date='9999-99-99'
     and t1.contract_id = t2.id
  left join odata.nbms_ces_quote_deal td
      on t2.deal_id=td.dealed_no
     and td.data_date='${DATA_DATE}' 
     and td.bddw_end_date='9999-99-99'
  left join odata.nbms_mem_brh_info tm 
      on td.adver_brh_no = tm.brh_no
     and tm.data_date = '${DATA_DATE}'
     and tm.bddw_end_date = '9999-99-99' 
  left join odata.nbms_bms_customer_info t3
     on t3.data_date = '${DATA_DATE}'
     and t3.bddw_end_date = '9999-99-99'
     and t2.cust_no = t3.cust_no
     and t3.cust_type='2'
  union all
 -------------------------------------直贴贴入---------------------------------------------
  select   /*+ REPARTITION(1) */
            t1.trade_detail_id                as  tran_seqno           --交易流水号
           ,t1.draft_id                       as  deal_id              --业务编码
           ,t1.draft_number                   as  asset_code           --资产编号
           ,from_unixtime(unix_timestamp(t1.reserve1,'yyyymmdd'),'yyyy-mm-dd')  
		                                      as   tran_date           --交易日期
           ,''                                as  tran_time            --交易时间
           ,'CNY'                             as  ccy                  --币种
           ,t1.dr_cr                          as  debit_flag           --交易方向
           ,nvl(t1.amount,0)                  as  tran_amt             --交易金额
           ,t2.rate                           as  exec_rate            --执行利率
           ,'100000'                          as  org_id               --机构代码
           ,t1.sub_no                         as  subj_no              --科目代码
           ,nvl(t2.cust_account    ,'')       as  counter_acct         --对方账号/卡号
           ,''                                as  counter_acct_name    --对方账户名称
           ,nvl(t2.cust_no         ,'')       as  tran_party_id        --交易对手编号
           ,nvl(t2.cust_name       ,'')       as  tran_party_name      --交易对手名称
           ,t1.status                         as  tran_status          --交易状态
           ,'nbms'                            as  source_system        --数据来源
           ,nvl(t2.pay_amount,0)              as  settle_amt           --结算金额
           ,0                                 as  accru_int            --应计利息
           ,0                                 as  repaid_prin          --还本金额
           ,''                                as  self_cash_acct_no    --本方资金账号
           ,''                                as  approver             --审批人
           ,''                                as  operator             --经办人
           ,0                                 as  yield_mature         --到期收益率
           ,''                                as settle_date           --结算日期
           ,nvl(t2.protocol_no  ,'' )         as cont_no               --协议号       --update 20230916 新增 
		   ,nvl(t2.cust_bank_no  ,'')         as counter_bank_code     --交易对手行号 --update 20231228
		   ,nvl(t2.cust_bank_name,'')         as counter_bank_name     --交易对手行名 --update 20231228
   from  odata.nbms_bms_trade_detail t1 
   inner  join (                                              --2024-03-01   内连接记账成功数据
               select t2.draft_id,
			          t2.pay_amount,
					  t2.rate,
					  t3.cust_account,
					  t3.cust_no,
					  t3.cust_name ,
					  t3.protocol_no,
					  t3.cust_bank_no, 
					  t3.cust_bank_name
               from odata.nbms_bms_buy_details t2          --老票据
               left join odata.nbms_bms_buy_contract t3
                  on t2.contract_id = t3.id
                 and t3.data_date='${DATA_DATE}' 
                 and t3.bddw_end_date='9999-99-99'     
               where t2.data_date='${DATA_DATE}' 
                 and t2.bddw_end_date='9999-99-99' 
                 and t2.account_status='03'               --记账成功状态 update2024-03-01 
              union all
               select t2.draft_id,
			          t2.pay_amount,
					  t2.rate,
					  t3.cust_account,
					  t3.cust_no,
					  t3.cust_name,
					  t3.protocol_no,  
					  t3.cust_bank_no, 
					  t3.cust_bank_name
                 from odata.nbms_cpes_buy_details t2         --新票据
                 left join odata.nbms_cpes_buy_contract t3
                   on t2.contract_id = t3.id
                  and t3.data_date='${DATA_DATE}' 
                  and t3.bddw_end_date='9999-99-99'   
                where t2.data_date='${DATA_DATE}' 
                  and t2.bddw_end_date='9999-99-99' 
                  and t2.account_status='03'            --记账成功状态 update2024-03-01 
          ) t2
     on t2.draft_id=t1.draft_id 
  where t1.data_date='${DATA_DATE}'
    and t1.bddw_end_date='9999-99-99'
    and t1.sub_no ='10300101' 
    and t1.dr_cr='D'
  -----------------------------------------------直贴贴出---------------------------------------------
  union  all
  select /*+ REPARTITION(1) */
            t1.trade_detail_id                as  tran_seqno          --交易流水号
           ,COALESCE(t4.discount_draft_id,t4.bms_draft_id,'')         
		                                      as  deal_id              --业务编码
           ,t1.draft_number                   as  asset_code          --资产编号
           ,from_unixtime(unix_timestamp(t1.reserve1,'yyyymmdd'),'yyyy-mm-dd')  
		                                      as   tran_date          --交易日期
           ,''                                as  tran_time           --交易时间
           ,'CNY'                             as  ccy                 --币种
           ,t1.dr_cr                          as  debit_flag          --交易方向
           ,nvl(t1.amount,0)                  as  tran_amt            --交易金额
           ,nvl(t3.rate*100    ,0)            as  exec_rate           --执行利率
           ,'100000'                          as  org_id              --机构代码
           ,t1.sub_no                         as  subj_no             --科目代码
           ,nvl(td.adver_fund_acct ,'')       as  counter_acct        --对方账号/卡号
           ,''                                as  counter_acct_name   --对方账户名称
           ,nvl(t3.cust_no    ,'')            as  tran_party_id       --交易对手编号
           ,nvl(tm.brh_zh_full_name ,'')      as  tran_party_name     --交易对手名称
           ,t1.status                         as  tran_status         --交易状态
           ,'nbms'                            as  source_system       --数据来源
           ,nvl(t2.settle_amt   ,0)           as  settle_amt          --结算金额
           ,0                                 as  accru_int           --应计利息
           ,0                                 as  repaid_prin         --还本金额
           ,''                                as  self_cash_acct_no   --本方资金账号
           ,nvl(tbl.assign_id, '')            as  approver            --审批人
           ,nvl(t3.created_by, '')            as  operator            --经办人
           ,0                                 as  yield_mature        --到期收益率
           ,''                                as settle_date          --结算日期
           ,nvl(t3.contract_no  ,'' )         as cont_no              --协议号       --update 20230916 新增 
		   ,nvl(tm.ubank_no         ,'')      as counter_bank_code    --交易对手行号 --update 20231228
           ,case when  tm.ubank_no is null  then  ''
		         else  nvl(tm.brh_zh_full_name,'')   
				 end                          as counter_bank_name   --交易对手行名     --剔除非银机构  --update 20231228		
  from odata.nbms_bms_trade_detail t1
  left join odata.nbms_cpes_quote_details t2
     on t2.draft_id=t1.draft_id 
     and t2.id=t1.detail_id
     and t2.data_date='${DATA_DATE}' 
     and t2.bddw_end_date='9999-99-99' 
     and t2.account_status='02' -- 记账成功
  left join odata.nbms_cpes_quote_contract t3
     on  t2.contract_id = t3.id
     and t3.data_date='${DATA_DATE}' 
     and t3.bddw_end_date='9999-99-99' 
     and t3.trade_direct = 'TDD02'  --转出 
  left join
    (select * from
         (select  task_name, task_flag, assign_id, name2, row_number() over(partition by name2 order by create_time desc  ) rn
            from  odata.flowsharp_tbl_repeat_task        --流程表
           where data_date='${DATA_DATE}' 
 	         and bddw_end_date='9999-99-99'
			 and task_flag='2'         --审批状态           --待确认数据
			 ) a 
 	 where a.rn=1) tbl
    on t3.contract_no=tbl.name2   	 
  left join odata.nbms_ces_quote_deal td
      on t3.deal_id=td.dealed_no
     and td.data_date='${DATA_DATE}' 
     and td.bddw_end_date='9999-99-99'
  left join odata.nbms_mem_brh_info tm 
     on td.adver_brh_no = tm.brh_no
     and tm.data_date = '${DATA_DATE}'
     and tm.bddw_end_date = '9999-99-99' 
  left join odata.nbms_dpc_draft_info t4
     on  t1.draft_id=t4.id
     and t4.data_date='${DATA_DATE}' 
     and t4.bddw_end_date='9999-99-99' 
  where t1.data_date='${DATA_DATE}' 
    and t1.bddw_end_date='9999-99-99'
    and t1.sub_no  ='10300101'   
    and t1.dr_cr='C'
  --------------------------------------转贴现转入部分----------------------------------------------
  union all
  select /*+ REPARTITION(1) */
            t1.trade_detail_id                as  tran_seqno          --交易流水号
           ,t1.draft_id                       as  deal_id              --业务编码
           ,t1.draft_number                   as  asset_code          --资产编号
           ,from_unixtime(unix_timestamp(t1.reserve1,'yyyymmdd'),'yyyy-mm-dd')  
		                                      as   tran_date          --交易日期
           ,''                                as  tran_time           --交易时间
           ,'CNY'                             as  ccy                 --币种
           ,t1.dr_cr                          as  debit_flag          --交易方向
           ,nvl(t1.amount,0)                  as  tran_amt            --交易金额
           ,nvl(t3.rate*100,0)                as  exec_rate           --执行利率
           ,'100000'                          as  org_id              --机构代码
           ,t1.sub_no                         as  subj_no             --科目代码
           ,nvl(td.adver_fund_acct ,'')       as  counter_acct        --对方账号/卡号
           ,''                                as  counter_acct_name   --对方账户名称
           ,nvl(t3.cust_no    ,'')            as  tran_party_id       --交易对手编号
           ,nvl(tm.brh_zh_full_name ,'')      as  tran_party_name     --交易对手名称
           ,t1.status                         as  tran_status         --交易状态
           ,'nbms'                            as  source_system       --数据来源
           ,nvl(t2.settle_amt   ,0)           as  settle_amt          --结算金额
           ,0                                 as  accru_int           --应计利息
           ,0                                 as  repaid_prin         --还本金额
           ,''                                as  self_cash_acct_no   --本方资金账号
           ,nvl(tbl.assign_id, '')            as  approver            --审批人
           ,nvl(t3.created_by, '')            as  operator            --经办人
           ,0                                 as  yield_mature        --到期收益率
           ,''                                as settle_date          --结算日期
           ,nvl(t3.contract_no  ,'' )         as cont_no              --协议号       --update 20230916 新增 
		   ,nvl(tm.ubank_no         ,'')      as counter_bank_code    --交易对手行号 --update 20231228
           ,case when  tm.ubank_no is null  then  ''
		         else  nvl(tm.brh_zh_full_name,'')   
				 end                          as counter_bank_name   --交易对手行名     --剔除非银机构  --update 20231228		
  from odata.nbms_bms_trade_detail t1
  left join odata.nbms_cpes_quote_details t2
     on t2.draft_id=t1.draft_id 
     and t2.id=t1.detail_id
     and t2.data_date='${DATA_DATE}' 
     and t2.bddw_end_date='9999-99-99' 
     and t2.account_status='02' -- 记账成功
  inner join odata.nbms_cpes_quote_contract t3
     on  t2.contract_id = t3.id
     and t3.data_date='${DATA_DATE}' 
     and t3.bddw_end_date='9999-99-99' 
     and t3.trade_direct = 'TDD01'  --转入 
  left join
    (select * from
         (select  task_name, task_flag, assign_id, name2, row_number() over(partition by name2 order by create_time desc  ) rn
            from  odata.flowsharp_tbl_repeat_task        --流程表
           where data_date='${DATA_DATE}' 
 	         and bddw_end_date='9999-99-99'
			 and task_flag='2'         --审批状态           --待确认数据
			 ) a 
 	 where a.rn=1) tbl
    on t3.contract_no=tbl.name2   	 
  left join odata.nbms_ces_quote_deal td
      on t3.deal_id=td.dealed_no
     and td.data_date='${DATA_DATE}' 
     and td.bddw_end_date='9999-99-99'
  left join odata.nbms_mem_brh_info tm 
     on td.adver_brh_no = tm.brh_no
     and tm.data_date = '${DATA_DATE}'
     and tm.bddw_end_date = '9999-99-99' 
  where t1.data_date='${DATA_DATE}' 
  and t1.bddw_end_date='9999-99-99'
  and t1.sub_no  in ('10310101','10310201') --转贴现面值
  and t1.dr_cr='D'
  --------------------------------------转贴现转出部分----------------------------------------------
  union all
  select /*+ REPARTITION(1) */
            t1.trade_detail_id                as  tran_seqno          --交易流水号
           ,t1.draft_id                       as  deal_id              --业务编码
           ,t1.draft_number                   as  asset_code          --资产编号
           ,from_unixtime(unix_timestamp(t1.reserve1,'yyyymmdd'),'yyyy-mm-dd')  
		                                      as   tran_date          --交易日期
           ,''                                as  tran_time           --交易时间
           ,'CNY'                             as  ccy                 --币种
           ,t1.dr_cr                          as  debit_flag          --交易方向
           ,nvl(t1.amount,0)                  as  tran_amt            --交易金额
           ,nvl(t3.rate*100   ,0)             as  exec_rate           --执行利率
           ,'100000'                          as  org_id              --机构代码
           ,t1.sub_no                         as  subj_no             --科目代码
           ,nvl(td.adver_fund_acct ,'')       as  counter_acct        --对方账号/卡号
           ,''                                as  counter_acct_name   --对方账户名称
           ,nvl(t3.cust_no   ,'')             as  tran_party_id       --交易对手编号
           ,nvl(tm.brh_zh_full_name ,'')      as  tran_party_name     --交易对手名称
           ,t1.status                         as  tran_status         --交易状态
           ,'nbms'                            as  source_system       --数据来源
           ,nvl(t2.settle_amt   ,0)           as  settle_amt          --结算金额
           ,0                                 as  accru_int           --应计利息
           ,0                                 as  repaid_prin         --还本金额
           ,''                                as  self_cash_acct_no   --本方资金账号
           ,nvl(tbl.assign_id, '')            as  approver            --审批人
           ,nvl(t3.created_by, '')            as  operator            --经办人
           ,0                                 as yield_mature         --到期收益率
           ,''                                as settle_date          --结算日期
           ,nvl(t3.contract_no  ,'' )         as cont_no              --协议号       --update 20230916 新增
		   ,nvl(tm.ubank_no         ,'')      as counter_bank_code    --交易对手行号 --update 20231228
           ,case when  tm.ubank_no is null  then  ''
		         else  nvl(tm.brh_zh_full_name,'')   
				 end                          as counter_bank_name   --交易对手行名     --剔除非银机构  --update 20231228		   
  from odata.nbms_bms_trade_detail t1
  left join odata.nbms_cpes_quote_details t2
         on t2.draft_id=t1.draft_id 
        and t2.id=t1.detail_id
        and t2.data_date='${DATA_DATE}' 
        and t2.bddw_end_date='9999-99-99' 
        and t2.account_status='02' -- 记账成功
  left join odata.nbms_cpes_quote_contract t3
         on t2.contract_id = t3.id
        and t3.data_date='${DATA_DATE}' 
        and t3.bddw_end_date='9999-99-99' 
        and t3.trade_direct ='TDD02'   --转出 
  left join
    (select * from
         (select  task_name, task_flag, assign_id, name2, row_number() over(partition by name2 order by create_time desc  ) rn
            from  odata.flowsharp_tbl_repeat_task        --流程表
           where data_date='${DATA_DATE}' 
 	         and bddw_end_date='9999-99-99'
			 and task_flag='2'         --审批状态           --待确认数据
			 ) a 
 	 where a.rn=1) tbl
    on t3.contract_no=tbl.name2   	 
  left join odata.nbms_ces_quote_deal td
        on t3.deal_id=td.dealed_no
       and td.data_date='${DATA_DATE}' 
       and td.bddw_end_date='9999-99-99'
  left join odata.nbms_mem_brh_info tm 
       on td.adver_brh_no = tm.brh_no
       and tm.data_date = '${DATA_DATE}'
       and tm.bddw_end_date = '9999-99-99' 
  where t1.data_date='${DATA_DATE}' 
     and t1.bddw_end_date='9999-99-99'
     and t1.sub_no  in ('10310101','10310201') --转贴现面值
     and t1.dr_cr='C'
   --------------------------------------------老票承兑汇票流水-----------------------------------
  union  all 
      select /*+ REPARTITION(1) */
  	      nvl(t1.id,'')                       as tran_seqno          --交易流水号
           ,nvl(t1.draft_id,'')               as deal_id              --业务编码
           ,nvl(t1.draft_number,'')           as asset_code          --资产编号
           ,nvl(from_unixtime(unix_timestamp(t1.accept_date,'yyyyMMdd'),'yyyy-MM-dd'),'')      
		                                      as tran_date           --交易日期
           ,'00:00:00'                        as tran_time           --交易时间
           ,'CNY'                             as ccy                 --币种
           ,'C'                               as debit_flag          --交易方向
           ,nvl(t1.draft_amount,0)            as tran_amt            --交易金额
           ,0                                 as exec_rate           --执行利率
           ,'100000'                          as org_id              --机构代码
           ,'70020102'                        as subj_no             --科目代码
           ,nvl(t1.remitter_account,'')       as counter_acct        --对方账号/卡号
           ,''                                as counter_acct_name   --对方账户名称
           ,nvl(t2.remitter_cust_no,'')       as tran_party_id       --交易对手编号
           ,nvl(t1.remitter_name,'')          as tran_party_name     --交易对手名称
           ,nvl(t1.accept_status,'')          as tran_status         --交易状态
           ,'nbms'                            as source_system       --数据来源
           ,0                                 as settle_amt          --结算金额
           ,0                                 as accru_int           --应计利息
           ,0                                 as repaid_prin         --还本金额
           ,''                                as self_cash_acct_no   --本方资金账号
           ,''                                as approver            --审批人
           ,''                                as operator            --经办人
           ,0                                 as yield_mature        --到期收益率
           ,''                                as settle_date         --结算日期
           ,''                                as cont_no             --协议号       --update 20230916 新增 
		   ,nvl(t1.remitter_bank_no  ,'')     as counter_bank_code   --交易对手行号 --update 20231228
           ,nvl(t1.remitter_bank_name,'')     as counter_bank_name   --交易对手行名 --update 20231228
        from odata.nbms_bms_accept_details t1
   left join odata.nbms_bms_accept_contract t2--承兑批次表
          on t1.contract_id=t2.id
         and t2.data_date='${DATA_DATE}' 
         and t2.bddw_end_date='9999-99-99'
       where t1.data_date = '${DATA_DATE}'
  	   and t1.bddw_end_date ='9999-99-99'
  	   and t1.accept_status = '06'
   --------------------------------------------新票据承兑汇票流水-------------------------------------
   union all
      select /*+ REPARTITION(1) */
            nvl(t1.id,'')                     as tran_seqno          --交易流水号
           ,nvl(t1.draft_id,'')               as deal_id             --业务编码
           ,nvl(t1.draft_number,'')           as asset_code          --资产编号
           ,nvl(from_unixtime(unix_timestamp(t1.acceptor_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     
                                              as tran_date    --交易日期
           ,'00:00:00'                        as tran_time           --交易时间
           ,'CNY'                             as ccy                 --币种
           ,'C'                               as debit_flag          --交易方向
           ,nvl(t1.draft_amount,0)            as tran_amt            --交易金额
           ,0                                 as exec_rate           --执行利率
           ,'100000'                          as org_id              --机构代码
           ,'70020102'                        as subj_no             --科目代码
           ,nvl(t1.remitter_account,'')       as counter_acct        --对方账号/卡号
           ,''                                as counter_acct_name   --对方账户名称
           ,nvl(t2.remitter_cust_no,'')       as tran_party_id       --交易对手编号
           ,nvl(t1.remitter_name,'')          as tran_party_name     --交易对手名称
           ,nvl(t1.accept_status,'')          as tran_status         --交易状态
           ,'nbms'                            as source_system       --数据来源
           ,0                                 as settle_amt          --结算金额
           ,0                                 as accru_int           --应计利息
           ,0                                 as repaid_prin         --还本金额
           ,''                                as self_cash_acct_no   --本方资金账号
           ,''                                as approver            --审批人
           ,''                                as operator            --经办人
           ,0                                 as yield_mature        --到期收益率
           ,''                                as settle_date         --结算日期
           ,''                                as cont_no             --协议号       --update 20230916 新增 
		   ,nvl(t1.remitter_bank_no  ,'')     as counter_bank_code   --交易对手行号 --update 20231228
           ,nvl(t1.remitter_bank_name,'')     as counter_bank_name   --交易对手行名 --update 20231228
    from odata.nbms_cpes_accept_details t1
   left join odata.nbms_cpes_accept_contract t2--承兑批次表
          on t1.contract_id=t2.id 
         and t2.data_date='${DATA_DATE}' 
         and t2.bddw_end_date='9999-99-99'
       where t1.data_date = '${DATA_DATE}'
         and t1.bddw_end_date ='9999-99-99'
         and t1.accept_status = '06'
  ---------------------------------------------------老版票据解付流水-----------------------------------------
  union all
  	select  /*+ REPARTITION(1) */
  	      coalesce(t8.id,t9.id,'')            as tran_seqno          --交易流水号
           ,nvl(t1.draft_id,'')               as deal_id             --业务编码
           ,nvl(t1.draft_number,'')           as asset_code          --资产编号
           ,nvl(from_unixtime(unix_timestamp(t2.reserve1,'yyyyMMdd'),'yyyy-MM-dd'),'')      
		                                      as tran_date    --交易日期
           ,'00:00:00'                        as tran_time           --交易时间
           ,'CNY'                             as ccy                 --币种
           ,'D'                               as debit_flag          --交易方向
           ,nvl(t1.draft_amount,0)            as tran_amt            --交易金额
           ,0                                 as exec_rate           --执行利率
           ,'100000'                          as org_id              --机构代码
           ,'70020102'                        as subj_no             --科目代码
           ,case  when  t8.payee_account =0 then  ''
  		          else  nvl(t8.payee_account,'')
 				  end                         as counter_acct        --对方账号/卡号    --update 20231228
           ,''                                as counter_acct_name   --对方账户名称
           ,''                                as tran_party_id       --交易对手编号
           ,coalesce(t8.payee_name,t9.prmt_payer_name,'')             
		                                      as tran_party_name     --交易对手名称
           ,nvl(t2.prmtpay_sign_status,'')    as tran_status         --交易状态
           ,'nbms'                            as source_system       --数据来源
           ,0                                 as settle_amt          --结算金额
           ,0                                 as accru_int           --应计利息
           ,0                                 as repaid_prin         --还本金额
           ,''                                as self_cash_acct_no   --本方资金账号
           ,''                                as approver            --审批人
           ,''                                as operator            --经办人
           ,0                                 as yield_mature        --到期收益率
           ,''                                as settle_date         --结算日期
           ,''                                as cont_no             --协议号       --update 20230916 新增 
		   ,coalesce(t8.payee_bank_no ,t9.prmt_payer_bank_no,'')                
                    		                  as counter_bank_code   --交易对手行号 --update 20231228  
           ,coalesce(t8.payee_bank_name,tm.brh_zh_full_name ,'')                                 
		                                      as counter_bank_name   --交易对手行名 --update 20231228
        from odata.nbms_bms_accept_details t1
       inner join odata.nbms_bms_accept_status t2
          on t1.draft_id = t2.draft_id
         and t2.data_date = '${DATA_DATE}'
         and t2.bddw_end_date ='9999-99-99'
         and t2.prmtpay_sign_status = '2'
        left join odata.nbms_bms_accept_due_pay t8  --解付信息表        account_date
          on t8.draft_id=t1.draft_id
         and t8.data_date='${DATA_DATE}' 
         and t8.bddw_end_date='9999-99-99'
         and t8.account_flag='2' --记账完成      
        left join (
		           select b.bms_draft_id,
		                  c.prmt_payer_name,
						  c.prmt_payer_bank_no,
						  c.id
                     from odata.nbms_dpc_draft_info b --票据票面信息表
                     left join odata.nbms_cpes_prmtpay_apply c             
                       on b.id=c.draft_id 
                      and c.data_date='${DATA_DATE}' 
                      and c.bddw_end_date='9999-99-99'
                    where b.bms_draft_id is not NULL 
                      and c.account_status = '02' --记账成功
                      and c.buss_flag ='02' --签收
                      and b.data_date='${DATA_DATE}' 
                      and b.bddw_end_date='9999-99-99'
					  ) t9
          on t9.bms_draft_id=t1.draft_id  
		left join odata.nbms_mem_brh_info tm 
          on t9.prmt_payer_bank_no = tm.ubank_no
         and tm.data_date = '${DATA_DATE}'
         and tm.bddw_end_date = '9999-99-99' 
       where t1.data_date = '${DATA_DATE}'
         and t1.bddw_end_date ='9999-99-99'
         and t1.accept_status = '06'
   --------------------------------------------新版票据解付流水------------------------
  	union all
  	select  /*+ REPARTITION(1) */
  	        nvl(t3.id          ,'')           as tran_seqno          --交易流水号             
           ,nvl(t1.draft_id    ,'')           as deal_id             --业务编码           
           ,nvl(t1.draft_number,'')           as asset_code          --资产编号
           ,nvl(from_unixtime(unix_timestamp(t3.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')      as tran_date    --交易日期
           ,'00:00:00'                        as tran_time           --交易时间
           ,'CNY'                             as ccy                 --币种
           ,'D'                               as debit_flag          --交易方向
           ,nvl(t2.draft_amount,0)            as tran_amt            --交易金额
           ,0                                 as exec_rate           --执行利率
           ,'100000'                          as org_id              --机构代码
           ,'70020102'                        as subj_no             --科目代码
           ,nvl(t3.rcv_acct_no  ,'')          as counter_acct        --对方账号/卡号  
           ,nvl(t3.rcv_acct_name,'')          as counter_acct_name   --对方账户名称
           ,''                                as tran_party_id       --交易对手编号  
           ,nvl(t3.prmt_payer_name  ,'')      as tran_party_name     --交易对手名称
           ,'2'                               as tran_status         --交易状态
           ,'nbms'                            as source_system       --数据来源
           ,0                                 as settle_amt          --结算金额
           ,0                                 as accru_int           --应计利息
           ,0                                 as repaid_prin         --还本金额
           ,''                                as self_cash_acct_no   --本方资金账号
           ,''                                as approver            --审批人
           ,''                                as operator            --经办人
           ,0                                 as yield_mature        --到期收益率
           ,''                                as settle_date         --结算日期
           ,''                                as cont_no             --协议号       --update 20230916 新增 
		   ,nvl(t3.prmt_payer_bank_no,'')     as counter_bank_code   --交易对手行号
           ,nvl(tm.brh_zh_full_name  ,'')     as counter_bank_name   --交易对手行名   
        from odata.nbms_cpes_accept_details t1                  
       inner join  odata.nbms_dpc_draft_info t2 --票据票面信息表        
          on t2.draft_number=t1.draft_number
         and t2.data_date='${DATA_DATE}' 
         and t2.bddw_end_date='9999-99-99'
         and t2.src_type='SR014'     --提示付款
       inner join odata.nbms_cpes_prmtpay_apply t3           --只取解付成功的部分
          on t2.id=t3.draft_id 
         and t3.data_date='${DATA_DATE}' 
         and t3.bddw_end_date='9999-99-99'
         and t3.account_status = '02' --记账成功
         and t3.buss_flag ='02' --签收
	    left join odata.nbms_mem_brh_info tm 
          on t3.prmt_payer_bank_no = tm.ubank_no
         and tm.data_date = '${DATA_DATE}'
         and tm.bddw_end_date = '9999-99-99' 
       where t1.data_date = '${DATA_DATE}'
  	     and t1.bddw_end_date ='9999-99-99'
  	     and t1.accept_status = '06'