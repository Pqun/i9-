--2.yangqihao.dwd_e_indv_loan_repay_list_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：百度虚拟卡还款取数逻辑.sql
--功能描述：生成每日结果数据并插入 dwd.dwd_e_indv_loan_repay_list_p
--作    者：华天顺
--开发日期：
--直属经理：方杰
--来源表  ：odata.slur_bdvc_repay_file
--来源表  ：odata.ols_loan_cont_info
--目标表  ：dwd.dwd_e_indv_loan_repay_list_p
--修改历史：
--          1.杨琦浩   2023-03-16    转换还款方式码值
--          2.杨琦浩   2023-05-24    新增回收方式字段
--          3.于国睿   2023-10-17    新增记账日期字段
--          4.于国睿   2023-10-24    虚拟卡停批，大于等于20230921的日期写死
--          5.吴镇宇   2023-11-28    剔除冲正
--------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_indv_loan_repay_list_p partition(data_date='${DATA_DATE}',prod_code='110132')
--百度虚拟卡
    select /*+ REPARTITION(4) */
           nvl(t1.repay_ref_nbr,'')                  as repay_seq_no     --还款流水号
          ,nvl(t1.bdvc_seq_no,'')                    as seq_no           --交易序号
          ,''                                        as receipt_no       --回收号
          ,''                                        as reference        --交易参考号
          ,nvl(t1.loan_no,'')                        as bill_no          --借据号
          ,nvl(t2.currency,'')                       as ccy              --币种
          ,nvl(t2.cert_type,'')                      as cert_type        --证件类型
          ,nvl(t2.cert_code,'')                      as cert_no          --证件号码
          ,'2'                                       as fund_flag        --资金方标识
          ,nvl(t2.prd_code,'')                       as biz_prod_code    --业务产品代码
          ,''                                        as sub_biz_prod_code--业务子产品代码
          ,nvl(t1.term_no,'')                        as term_no          --期次
          ,nvl(from_unixtime(unix_timestamp(t1.repay_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     
		                                             as repay_date       --还款日期
          ,nvl(from_unixtime(unix_timestamp(concat_ws(' ',t1.partner_tran_date,t1.partner_tran_timestamp),'yyyyMMdd HHmmss'),'yyyy-MM-dd HH:mm:ss'),'')  
		                                             as repay_time       --还款时间 
          ,case t1.repay_type
                when '11' then 'NS1'                           
                when '12' then 'NS1' 
                when '13' then 'ER1' 
                when '14' then 'PF1' 
                when '15' then 'RF1'
                when '18' then 'RF3'
                else nvl(t1.repay_type,'')
            end                                      as repay_type       --还款方式
          ,nvl(t1.principal_amt,0)                   as repaid_prin      --还款本金 
          ,nvl(t1.interest_amt,0)                    as repaid_int       --还款利息
          ,nvl(t1.penalty_amt,0)                     as repaid_pena      --还款罚息
          ,0                                         as repaid_compo     --还款复利
          ,nvl(t1.guar_amt,0)                        as repaid_guar_fee  --还款担保费
          ,nvl(t1.repay_violate_amt,0)               as adv_repay_fee    --提前还款手续费
          ,0                                         as repay_status     --还款状态（0：成功，1：失败）
          ,''                                        as error_msg        --还款失败信息
          ,0                                         as is_b             --是否B账（0：否，1：是）
          ,nvl(t2.repay_card_no,'')                  as repaycardno      --还款卡号
          ,nvl(t1.principal_amt,0)+nvl(t1.interest_amt,0)+nvl(t1.penalty_amt,0)  
		                                             as repaid_amt       --还款总金额
          ,'0'                                       as is_offline       --是否线下还款
          ,''                                        as recov_mode       --回收方式
		  ,nvl(from_unixtime(unix_timestamp(t1.tran_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     
		                                             as accting_date     --记账日期  update 20231017 yuguorui
     from odata.slur_bdvc_repay_file t1
    inner join odata.ols_loan_cont_info t2
       on t1.loan_no = t2.bill_no
      and t2.data_date='${DATA_DATE}'
      and t2.bddw_end_date='9999-99-99'
      and t2.cont_status in ('105','106','107','108','109','110')
    where t1.tran_status='N' --剔除冲正
      and t1.data_date = case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                              else '2023-09-21'
                          end  --update 20231024 yuguorui 虚拟卡停批
      and t1.bddw_end_date = '9999-99-99'