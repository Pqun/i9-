insert overwrite table dwd.dwd_e_indv_loan_repay_list_p partition(data_date='${DATA_DATE}',prod_code)
select 
nvl(t.app_no,'')                                                          as repay_seq_no  --还款流水号
,nvl(concat(t.bill_no,t.app_no),'')                                       as seq_no   --交易序号
,nvl(t.receipt_no,'')                                                     as receipt_no  --回收号
,nvl(t.reference,'')                                                      as reference  --交易参考号
,nvl(t.bill_no,'')                                                        as bill_no  --借据号
,nvl(case when t1.currency is null then 'CNY' else t1.currency end,'')    as ccy  --币种
,nvl(case when t1.cert_type = '10' then '101' end,'')                     as cert_type  --证件类型
,nvl(t1.cert_code,'')                                                     as cert_no  --证件号码
,'2'                                                                      as fund_flag  --资金方标识
,nvl(t.prd_code,'')                                                       as biz_prod_code  --业务产品代码
,''                                                                       as sub_biz_prod_code  --业务子产品代码
,nvl(t.stage_no,'')                                                       as term_no  --期次
,nvl(t.repay_date,'')                                                     as repay_date  --还款日期
,nvl(t.input_time,'')                                                     as repay_time  --还款时间
,nvl(t.receipt_type,'')                                                   as repay_type  --还款方式
,nvl(t.receipt_pri,'')                                                    as repaid_prin  --还款本金 
,nvl(t.receipt_int,'')                                                    as repaid_int  --还款利息
,nvl(t.receipt_odp,'')                                                    as repaid_pena  --还款罚息
,nvl(t.receipt_odi,'')                                                    as repaid_compo  --还款复利
,nvl(t.receipt_fee,'')                                                    as repaid_guar_fee  --还款担保费
,nvl(t.fee_amt,'')                                                        as adv_repay_fee  --提前还款手续费
,nvl(case when t.repayment_status = '003' then 0 
     when t.repayment_status = '002' then 1
     when t.repayment_status = '001' then 2 end,'')                       as repay_status  --还款状态（0：成功，1：失败）
,nvl(t.sub_reason,'')                                                     as error_msg  --还款失败信息
,''                                                                       as is_b  --是否B账（0：否，1：是）
,nvl(t.repay_card_no,'')                                                  as repaycardno  --还款卡号
,nvl(t.receipt_amt,'')                                                    as repaid_amt
,nvl(case when t.if_offline = 'Y' then 1 else 0 end ,'')                  as is_offline
,nvl(nvl(t2.prod_type,t3.prod_type),t4.prod_type)                         as prod_code
from odata.ols_biz_account_prepayment t
left join odata.ols_loan_cont_info t1 
on t.bill_no = t1.bill_no 
and t.app_no = t1.app_no 
and t1.cont_status in ('105','106','107','108','109','110')
and t1.data_date = '${DATA_DATE}'
and t1.bddw_end_date = '9999-99-99'
left join odata.sllv_mb_acct t2 
on t.bill_no = t2.cmisloan_no
and t2.data_date = '${DATA_DATE}'
and t2.bddw_end_date = '9999-99-99'
left join odata.sllv_nl_acct t3
on t.bill_no = t3.cmisloan_no
and t3.data_date = '${DATA_DATE}'
and t3.bddw_end_date = '9999-99-99'
left join odata.sllv_es_acct t4
on t.bill_no = t4.cmisloan_no
and t4.data_date = '${DATA_DATE}'
and t4.bddw_end_date = '9999-99-99'
where t.data_date = '${DATA_DATE}'
and t.bddw_end_date = '9999-99-99'
and t.repayment_status <> '003'