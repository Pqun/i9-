--2.yangqihao.dwd_e_indv_loan_repay_list_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：联合贷还款成功取数逻辑.sql
--功能描述：生成每日结果数据并插入 dwd.dwd_e_indv_loan_repay_list_p
--作    者：高源
--开发日期：2022-05-11
--直属经理：方杰
--来源表  ：
--1.odata.sllv_nl_receipt               线上贷款回收表         
--2.odata.sllv_nl_receipt_detail        线上贷款回收明细表
--3.odata.sllv_nl_acct                  线上贷款账户基本信息表    
--4.odata.ols_biz_account_prepayment    提前还款信息表                
--5.odata.ols_loan_cont_info            支用合同信息表
--修改历史：
--          1.高源      2022-05-11    新建
--          2.杨琦浩    2023-03-16    转换还款方式码值
--          3.杨琦浩    2023-05-24    新增回收方式字段
--          4.于国睿    2023-10-17    新增记账日期字段
--          5.吴镇宇    2023-11-28    剔除冲正及资金方标识区分对客行内和资方
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_indv_loan_repay_list_p partition(data_date='${DATA_DATE}',prod_code)
    select /*+ REPARTITION(1) */
           coalesce(t.app_no,t1.receipt_no,'')                         as repay_seq_no  --还款流水号  
          ,nvl(concat(t3.cmisloan_no,t1.receipt_no),'')                as seq_no        --交易序号 
          ,nvl(t1.receipt_no,'')                                       as receipt_no    --回收号      
          ,nvl(t1.reference,'')                                        as reference     --交易参考号  
          ,nvl(t3.cmisloan_no,'')                                      as bill_no       --借据号      
          ,nvl(case when t1.ccy is null then 'CNY' else t1.ccy end,'') as ccy           --币种
          ,nvl(t4.document_type,'')                                    as cert_type     --证件类型    
          ,nvl(t4.document_id,'')                                      as cert_no       --证件号      
          ,'1'                                                         as fund_flag     --资金方标识   1 对客  2行内  3资方
          ,coalesce(t5.prd_code,t6.product_type,'')                    as biz_prod_code --业务产品代码
          ,nvl(t6.sub_product_type,'')                                 as sub_biz_prod_code  --业务子产品代码
          ,nvl(t2.stage_no,'')                                         as term_no       --期次
          ,nvl(substr(t1.receipt_date,1,10),'')                        as repay_date    --还款日期
          ,nvl(t1.receipt_date,'')                                     as repay_time    --还款时间 
    	  ,case t1.receipt_type
                   when 'NS' then 'NS1'                           
                   when 'ER' then 'ER3' 
                   when 'PO' then 'PF1' 
                   when 'PR' then 'NS3'
                   else nvl(t1.receipt_type,'')
           end                                                         as repay_type    --还款方式
          ,nvl(t2.repaid_prin,0)                                       as repaid_prin   --还款本金
          ,nvl(t2.repaid_int,0)                                        as repaid_int    --还款利息
          ,nvl(t2.repaid_pena,0)                                       as repaid_pena   --还款罚息
          ,nvl(t2.repaid_compo,0)                                      as repaid_compo  --还款复利
          ,nvl(t.receipt_fee,0)                                        as repaid_guar_fee   --还款担保费       
          ,nvl(a4.orig_fee_amt,0)                                      as adv_repay_fee --提前还款手续费   
          ,'0'                                                         as repay_status  --还款状态（0：成功，1：失败） 
          ,''                                                          as error_msg     --失败信息
          ,'0'                                                         as is_b          --是否为B账
          ,coalesce(regexp_replace(str_to_map(t7.repay_acct_info,',',':')['"payerAcctNo"'],'"',''),t5.repay_card_no,'')   
		                                                               as repaycardno   --还款卡号  
          ,nvl(t2.repaid_amt,'')                                       as repaid_amt    --还款总金额
          ,case when t.if_offline = 'Y' then '1' 
                else case when t7.repay_type = '6'
    	                  then '1'
                          else '0' 
                      end 
            end                                                        as is_offline    --是否线下
          ,nvl(t1.receipt_gen_code,'')                                 as recov_mode    --回收方式
    	  ,nvl(substr(t1.tran_date,1,10),'')                           as accting_date  --记账日期  update 20231017 yuguorui
          ,nvl(t3.prod_type,'')                                        as prod_code     --产品号
      from odata.sllv_nl_receipt t1       --线上贷款回收表
      left join (select receipt_no
	                   ,stage_no
                       ,sum(case when amt_type = 'PRI' then rec_amt else 0 end) as repaid_prin
                       ,sum(case when amt_type = 'INT' then rec_amt else 0 end) as repaid_int
                       ,sum(case when amt_type = 'ODP' then rec_amt else 0 end) as repaid_pena
                       ,sum(case when amt_type = 'ODI' then rec_amt else 0 end) as repaid_compo
                       ,sum(case when amt_type = 'FEE' then rec_amt else 0 end) as repaid_fee
                       ,sum(case when amt_type in ('PRI','INT','ODP','ODI') then rec_amt else 0 end) as repaid_amt
                   from odata.sllv_nl_receipt_detail     --线上贷款回收明细表
                  where data_date = '${DATA_DATE}' 
                    and bddw_end_date = '9999-99-99'
                  group by receipt_no
                          ,stage_no
			    ) t2  
        on t1.receipt_no = t2.receipt_no  
      left join odata.sllv_nl_acct t3       --线上基本信息表
        on t1.internal_key = t3.internal_key         
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
      left join odata.sym_cif_client_document t4
        on t3.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
       and t4.pref_flag = 'Y'
      left join odata.ols_biz_account_prepayment t   --提前还款信息表
        on t1.reference = t.reference 
       and t.data_date = '${DATA_DATE}'
       and t.bddw_end_date = '9999-99-99'
       and t.repayment_status = '003'    
      left join odata.ols_loan_cont_info t5     --支用合同信息表
        on t3.cmisloan_no = t5.bill_no      
       and t5.cont_status in ('105','106','107','108','109','110') --合同状态LOAN_CONT_STATUS 
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
      left join odata.order_main_loan_order t6     --支用合同信息表
        on t3.cmisloan_no = t6.loan_id      
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
       and t6.status in (7,8,9,10)
      left join odata.acct_repayment_log t7
        on t7.receipt_no = t1.receipt_no
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
       and t7.repay_status = 6
      left join(select receipt_no
                      ,nvl(orig_fee_amt,0) as orig_fee_amt
                  from odata.sllv_nl_serv_charge a2 
                 where a2.data_date='${DATA_DATE}' 
                   and a2.bddw_end_date='9999-99-99'
                   and a2.fee_type = 'D005'
			   ) a4
        on t1.receipt_no = a4.receipt_no
     where t1.reversal = 'N'  --剔除冲正
       and t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
union all 
    select /*+ REPARTITION(1) */
           coalesce(t.app_no,t1.receipt_no,'')                         as repay_seq_no  --还款流水号  
          ,nvl(concat(t3.cmisloan_no,t1.receipt_no),'')                as seq_no        --交易序号 
          ,nvl(t1.receipt_no,'')                                       as receipt_no    --回收号      
          ,nvl(t1.reference,'')                                        as reference     --交易参考号  
          ,nvl(t3.cmisloan_no,'')                                      as bill_no       --借据号      
          ,nvl(case when t1.ccy is null then 'CNY' else t1.ccy end,'') as ccy           --币种
          ,nvl(t4.document_type,'')                                    as cert_type     --证件类型    
          ,nvl(t4.document_id,'')                                      as cert_no       --证件号      
          ,'3'                                                         as fund_flag     --资金方标识
          ,coalesce(t5.prd_code,t6.product_type,'')                    as biz_prod_code --业务产品代码
          ,nvl(t6.sub_product_type,'')                                 as sub_biz_prod_code  --业务子产品代码
          ,nvl(t2.stage_no,'')                                         as term_no       --期次
          ,nvl(substr(t1.receipt_date,1,10),'')                        as repay_date    --还款日期
          ,nvl(t1.receipt_date,'')                                     as repay_time    --还款时间 
    	  ,case t1.receipt_type
                   when 'NS' then 'NS1'                           
                   when 'ER' then 'ER3' 
                   when 'PO' then 'PF1' 
                   when 'PR' then 'NS3'
                   else nvl(t1.receipt_type,'')
           end                                                         as repay_type    --还款方式
          ,nvl(t2.repaid_prin,0)                                       as repaid_prin   --还款本金
          ,nvl(t2.repaid_int,0)                                        as repaid_int    --还款利息
          ,nvl(t2.repaid_pena,0)                                       as repaid_pena   --还款罚息
          ,nvl(t2.repaid_compo,0)                                      as repaid_compo  --还款复利
          ,nvl(t.receipt_fee,0)                                        as repaid_guar_fee   --还款担保费       
          ,nvl(a4.orig_fee_amt,0)                                      as adv_repay_fee --提前还款手续费   
          ,'0'                                                         as repay_status  --还款状态（0：成功，1：失败） 
          ,''                                                          as error_msg     --失败信息
          ,'0'                                                         as is_b          --是否为B账
          ,coalesce(regexp_replace(str_to_map(t7.repay_acct_info,',',':')['"payerAcctNo"'],'"',''),t5.repay_card_no,'')   
		                                                               as repaycardno   --还款卡号  
          ,nvl(t2.repaid_amt,'')                                       as repaid_amt    --还款总金额
          ,case when t.if_offline = 'Y' then '1' 
                else case when t7.repay_type = '6'
    	                  then '1'
                          else '0' 
                      end 
            end                                                        as is_offline    --是否线下
          ,nvl(t1.receipt_gen_code,'')                                 as recov_mode    --回收方式
    	  ,nvl(substr(t1.tran_date,1,10),'')                           as accting_date  --记账日期  update 20231017 yuguorui
          ,nvl(t3.prod_type,'')                                        as prod_code     --产品号
      from odata.sllv_nl_receipt t1       --线上贷款回收表
      left join (select receipt_no
	                   ,stage_no
                       ,sum(case when amt_type = 'PRI' then partner_rec_amt else 0 end) as repaid_prin
                       ,sum(case when amt_type = 'INT' then partner_rec_amt else 0 end) as repaid_int
                       ,sum(case when amt_type = 'ODP' then partner_rec_amt else 0 end) as repaid_pena
                       ,sum(case when amt_type = 'ODI' then partner_rec_amt else 0 end) as repaid_compo
                       ,sum(case when amt_type = 'FEE' then partner_rec_amt else 0 end) as repaid_fee
                       ,sum(case when amt_type in ('PRI','INT','ODP','ODI') then partner_rec_amt else 0 end) as repaid_amt
                   from odata.sllv_nl_receipt_detail     --线上贷款回收明细表
                  where data_date = '${DATA_DATE}' 
                    and bddw_end_date = '9999-99-99'
                  group by receipt_no
                          ,stage_no
			    ) t2  
        on t1.receipt_no = t2.receipt_no  
      left join odata.sllv_nl_acct t3       --线上基本信息表
        on t1.internal_key = t3.internal_key         
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
      left join odata.sym_cif_client_document t4
        on t3.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
       and t4.pref_flag = 'Y'
      left join odata.ols_biz_account_prepayment t   --提前还款信息表
        on t1.reference = t.reference 
       and t.data_date = '${DATA_DATE}'
       and t.bddw_end_date = '9999-99-99'
       and t.repayment_status = '003'    
      left join odata.ols_loan_cont_info t5     --支用合同信息表
        on t3.cmisloan_no = t5.bill_no      
       and t5.cont_status in ('105','106','107','108','109','110') --合同状态LOAN_CONT_STATUS 
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
      left join odata.order_main_loan_order t6     --支用合同信息表
        on t3.cmisloan_no = t6.loan_id      
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
       and t6.status in (7,8,9,10)
      left join odata.acct_repayment_log t7
        on t7.receipt_no = t1.receipt_no
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
       and t7.repay_status = 6
      left join(select receipt_no
                      ,nvl(orig_fee_amt,0) as orig_fee_amt
                  from odata.sllv_nl_serv_charge a2 
                 where a2.data_date='${DATA_DATE}' 
                   and a2.bddw_end_date='9999-99-99'
                   and a2.fee_type = 'D005'
			   ) a4
        on t1.receipt_no = a4.receipt_no
     where t1.reversal = 'N'  --剔除冲正
       and t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
union all 
    select /*+ REPARTITION(1) */
           coalesce(t.app_no,t1.receipt_no,'')                         as repay_seq_no  --还款流水号  
          ,nvl(concat(t3.cmisloan_no,t1.receipt_no),'')                as seq_no        --交易序号 
          ,nvl(t1.receipt_no,'')                                       as receipt_no    --回收号      
          ,nvl(t1.reference,'')                                        as reference     --交易参考号  
          ,nvl(t3.cmisloan_no,'')                                      as bill_no       --借据号      
          ,nvl(case when t1.ccy is null then 'CNY' else t1.ccy end,'') as ccy           --币种
          ,nvl(t4.document_type,'')                                    as cert_type     --证件类型    
          ,nvl(t4.document_id,'')                                      as cert_no       --证件号      
          ,'2'                                                         as fund_flag     --资金方标识
          ,coalesce(t5.prd_code,t6.product_type,'')                    as biz_prod_code --业务产品代码
          ,nvl(t6.sub_product_type,'')                                 as sub_biz_prod_code  --业务子产品代码
          ,nvl(t2.stage_no,'')                                         as term_no       --期次
          ,nvl(substr(t1.receipt_date,1,10),'')                        as repay_date    --还款日期
          ,nvl(t1.receipt_date,'')                                     as repay_time    --还款时间 
    	  ,case t1.receipt_type
                   when 'NS' then 'NS1'                           
                   when 'ER' then 'ER3' 
                   when 'PO' then 'PF1' 
                   when 'PR' then 'NS3'
                   else nvl(t1.receipt_type,'')
           end                                                         as repay_type    --还款方式
          ,nvl(t2.repaid_prin,0)                                       as repaid_prin   --还款本金
          ,nvl(t2.repaid_int,0)                                        as repaid_int    --还款利息
          ,nvl(t2.repaid_pena,0)                                       as repaid_pena   --还款罚息
          ,nvl(t2.repaid_compo,0)                                      as repaid_compo  --还款复利
          ,nvl(t.receipt_fee,0)                                        as repaid_guar_fee   --还款担保费       
          ,nvl(a4.orig_fee_amt,0)                                      as adv_repay_fee --提前还款手续费   
          ,'0'                                                         as repay_status  --还款状态（0：成功，1：失败） 
          ,''                                                          as error_msg     --失败信息
          ,'0'                                                         as is_b          --是否为B账
          ,coalesce(regexp_replace(str_to_map(t7.repay_acct_info,',',':')['"payerAcctNo"'],'"',''),t5.repay_card_no,'')   
		                                                               as repaycardno   --还款卡号  
          ,nvl(t2.repaid_amt,'')                                       as repaid_amt    --还款总金额
          ,case when t.if_offline = 'Y' then '1' 
                else case when t7.repay_type = '6'
    	                  then '1'
                          else '0' 
                      end 
            end                                                        as is_offline    --是否线下
          ,nvl(t1.receipt_gen_code,'')                                 as recov_mode    --回收方式
    	  ,nvl(substr(t1.tran_date,1,10),'')                           as accting_date  --记账日期  update 20231017 yuguorui
          ,nvl(t3.prod_type,'')                                        as prod_code     --产品号
      from odata.sllv_nl_receipt t1       --线上贷款回收表
      left join (select receipt_no
	                   ,stage_no
                       ,sum(case when amt_type = 'PRI' then rec_amt-partner_rec_amt else 0 end) as repaid_prin
                       ,sum(case when amt_type = 'INT' then rec_amt-partner_rec_amt else 0 end) as repaid_int
                       ,sum(case when amt_type = 'ODP' then rec_amt-partner_rec_amt else 0 end) as repaid_pena
                       ,sum(case when amt_type = 'ODI' then rec_amt-partner_rec_amt else 0 end) as repaid_compo
                       ,sum(case when amt_type = 'FEE' then rec_amt-partner_rec_amt else 0 end) as repaid_fee
                       ,sum(case when amt_type in ('PRI','INT','ODP','ODI') then rec_amt-partner_rec_amt else 0 end) as repaid_amt
                   from odata.sllv_nl_receipt_detail     --线上贷款回收明细表
                  where data_date = '${DATA_DATE}' 
                    and bddw_end_date = '9999-99-99'
                  group by receipt_no
                          ,stage_no
			    ) t2  
        on t1.receipt_no = t2.receipt_no  
      left join odata.sllv_nl_acct t3       --线上基本信息表
        on t1.internal_key = t3.internal_key         
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
      left join odata.sym_cif_client_document t4
        on t3.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
       and t4.pref_flag = 'Y'
      left join odata.ols_biz_account_prepayment t   --提前还款信息表
        on t1.reference = t.reference 
       and t.data_date = '${DATA_DATE}'
       and t.bddw_end_date = '9999-99-99'
       and t.repayment_status = '003'    
      left join odata.ols_loan_cont_info t5     --支用合同信息表
        on t3.cmisloan_no = t5.bill_no      
       and t5.cont_status in ('105','106','107','108','109','110') --合同状态LOAN_CONT_STATUS 
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
      left join odata.order_main_loan_order t6     --支用合同信息表
        on t3.cmisloan_no = t6.loan_id      
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
       and t6.status in (7,8,9,10)
      left join odata.acct_repayment_log t7
        on t7.receipt_no = t1.receipt_no
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
       and t7.repay_status = 6
      left join(select receipt_no
                      ,nvl(orig_fee_amt,0) as orig_fee_amt
                  from odata.sllv_nl_serv_charge a2 
                 where a2.data_date='${DATA_DATE}' 
                   and a2.bddw_end_date='9999-99-99'
                   and a2.fee_type = 'D005'
			   ) a4
        on t1.receipt_no = a4.receipt_no
     where t1.reversal = 'N'  --剔除冲正
       and t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'       
--还款失败
--union all
--select 
--nvl(t.app_no,'')                                                          as repay_seq_no  --还款流水号
--,nvl(concat(t.bill_no,t.app_no),'')                                       as seq_no   --交易序号
--,nvl(t.receipt_no,'')                                                     as receipt_no  --回收号
--,nvl(t.reference,'')                                                      as reference  --交易参考号
--,nvl(t.bill_no,'')                                                        as bill_no  --借据号
--,nvl(case when t1.currency is null then 'CNY' else t1.currency end,'')    as ccy  --币种
--,nvl(case when t1.cert_type = '10' then '101' end,'')                     as cert_type  --证件类型
--,nvl(t1.cert_code,'')                                                     as cert_no  --证件号码
--,'3'                                                                      as fund_flag  --资金方标识
--,nvl(t1.prd_code,'')                                                      as biz_prod_code  --业务产品代码
--,''                                                                       as sub_biz_prod_code  --业务子产品代码
--,nvl(t.stage_no,'')                                                       as term_no  --期次
--,nvl(t.repay_date,'')                                                     as repay_date  --还款日期
--,nvl(t.input_time,'')                                                     as repay_time  --还款时间
--,nvl(t.receipt_type,'')                                                   as repay_type  --还款方式
--,nvl(t.receipt_pri,'')                                                    as repaid_prin  --还款本金 
--,nvl(t.receipt_int,'')                                                    as repaid_int  --还款利息
--,nvl(t.receipt_odp,'')                                                    as repaid_pena  --还款罚息
--,nvl(t.receipt_odi,'')                                                    as repaid_compo  --还款复利
--,nvl(t.receipt_fee,'')                                                    as repaid_guar_fee  --还款担保费
--,nvl(t.fee_amt,'')                                                        as adv_repay_fee  --提前还款手续费
--,nvl(case when t.repayment_status = '003' then 0 
--     when t.repayment_status = '002' then 1
--     when t.repayment_status = '001' then 2 end,'')                       as repay_status  --还款状态（0：成功，1：失败）
--,nvl(t.sub_reason,'')                                                     as error_msg  --还款失败信息
--,'0'                                                                       as is_b  --是否B账（0：否，1：是）
--,nvl(t1.repay_card_no,'')                                                  as repaycardno  --还款卡号
--,nvl(t.receipt_amt,'')                                                    as repaid_amt
--,nvl(case when t.if_offline = 'Y' then 1 else 0 end ,'')                  as is_offline
--,nvl(t3.prod_type,'')                         as prod_code
--from odata.ols_biz_account_prepayment t
--left join odata.ols_loan_cont_info t1 
--on t.bill_no = t1.bill_no 
--and t.app_no = t1.app_no 
--and t1.cont_status in ('105','106','107','108','109','110')
--and t1.data_date = '${DATA_DATE}'
--and t1.bddw_end_date = '9999-99-99'
--inner join odata.sllv_nl_acct t3
--on t.bill_no = t3.cmisloan_no
--and t3.data_date = '${DATA_DATE}'
--and t3.bddw_end_date = '9999-99-99'
--where t.data_date = '${DATA_DATE}'
--and t.bddw_end_date = '9999-99-99'
--and t.repayment_status <> '003'
