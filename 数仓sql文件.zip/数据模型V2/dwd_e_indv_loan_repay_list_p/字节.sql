--2.yangqihao.dwd_e_indv_loan_repay_list_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：dwd_e_indv_loan_repay_list_p.sql字节取数
--功能描述：生成每日结果数据并插入hive dws层dws.dwd_e_indv_loan_repay_list_p
--作    者：方杰
--开发日期：2024-04-15
--直属经理：方杰
--来源表  ：odata.slur_ac_repay_file
--来源表  ：odata.ols_loan_cont_info
--目标表  ：dwd.dwd_e_indv_loan_repay_list_p
--修改历史：
--          1.杨琦浩   2024-04-15    新建
---------------------------------------------------------------------------------------------------------------
--字节
insert overwrite table dwd.dwd_e_indv_loan_repay_list_p partition(data_date='${DATA_DATE}',prod_code='110193')
    select /*+ REPARTITION(1) */ 
           nvl(t1.refrence,'')                       as repay_seq_no   --还款流水号
          ,nvl(t1.ac_seq_no,'')                      as seq_no         --交易序号
          ,''                                        as receipt_no     --回收号
          ,''                                        as reference      --交易参考号
          ,nvl(t2.bill_no,'')                        as bill_no        --借据号
          ,nvl(t2.currency,'')                       as ccy            --币种
          ,nvl(t2.cert_type,'')                      as cert_type      --证件类型
          ,nvl(t2.cert_code,'')                      as cert_no        --证件号码
          ,'2'                                       as fund_flag      --资金方标识
          ,nvl(t2.prd_code,'')                       as biz_prod_code  --业务产品代码
          ,''                                        as sub_biz_prod_code  --业务子产品代码
          ,nvl(t1.term_no,'')                        as term_no        --期次
          ,nvl(substr(t4.create_time,1,10),'')       as repay_date     --还款日期
          ,nvl(substr(t4.create_time,1,19),'')       as repay_time     --还款时间 
          ,nvl(t1.receipt_type,'')                   as repay_type     --还款方式
          ,nvl(t1.prin_amt,0)                        as repaid_prin    --还款本金 
          ,nvl(t1.int_amt,0)                         as repaid_int     --还款利息
          ,nvl(t1.pnlt_int_amt,0)                    as repaid_pena    --还款罚息
          ,nvl(t1.int_pnlt_amt,0)                    as repaid_compo   --还款复利
          ,0                                         as repaid_guar_fee  --还款担保费
          ,nvl(t1.fee,0)                             as adv_repay_fee  --提前还款手续费
          ,0                                         as repay_status   --还款状态（0：成功，1：失败）
          ,''                                        as error_msg      --还款失败信息
          ,0                                         as is_b           --是否B账（0：否，1：是）
          ,nvl(t3.loan_card_no,'')                   as repaycardno    --还款卡号
          ,nvl(t1.receipt_amt,0)                     as repaid_amt     --还款总金额
          ,'0'                                       as is_offline     --是否线下还款
          ,''                                        as recov_mode     --回收方式
          ,nvl(substr(t1.run_date,1,10),'')          as accting_date   --记账日期
     from odata.slur_ac_repay_file t1
    inner join odata.ols_loan_cont_info t2
       on t1.loan_id = t2.app_no
      and t2.data_date='${DATA_DATE}'
      and t2.bddw_end_date='9999-99-99'
      and t2.cont_status in ('105','106','107','108','109','110')
    left join odata.ols_loan_un_app_info t3
      on t2.bill_no=t3.bill_no
     and t3.data_date='${DATA_DATE}'
     and t3.bddw_end_date='9999-99-99'
    left join odata.acct_repayment_log t4
      on t1.refrence=t4.receipt_no
     and t4.data_date='${DATA_DATE}'
     and t4.bddw_end_date='9999-99-99'
    where t1.data_date = '${DATA_DATE}'
      and t1.bddw_end_date = '9999-99-99'