--2.fj.dwd_e_indv_loan_repay_list_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：网贷还款成功--助贷取数逻辑.sql
--功能描述：生成每日结果数据并插入 dwd.dwd_e_indv_loan_repay_list_p
--作    者：方杰
--开发日期：2022-12-05
--直属经理：程宏明
--来源表  ：
--1.odata.sym_mb_receipt               贷款回收表         
--2.odata.sym_mb_receipt_detail        贷款回收明细表
--3.odata.sym_mb_acct                  贷款账户基本信息表    
--修改历史：
--          1.方杰     2022-12-05    新建
--          2.杨琦浩   2023-05-24    新增回收方式字段
--          3.于国睿   2023-10-17    新增记账日期字段
--          4.吴镇宇   2023-11-28    剔除冲正
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_indv_loan_repay_list_p partition(data_date='${DATA_DATE}',prod_code)
    select /*+ REPARTITION(1) */ 
           nvl(t3.receipt_no,'')                                       as repay_seq_no    --还款流水号  
          ,coalesce(concat(t5.cmisloan_no,t3.receipt_no),'')           as seq_no          --交易序号 
          ,nvl(t3.receipt_no,'')                                       as receipt_no      --回收号      
          ,nvl(t3.reference,'')                                        as reference       --交易参考号  
          ,nvl(t5.cmisloan_no,'')                                      as bill_no         --借据号      
          ,nvl(case when t3.ccy is null then 'CNY' else t3.ccy end,'') as ccy             --币种
          ,nvl(t8.document_type,'')                                    as cert_type       --证件类型    
          ,nvl(t8.document_id,'')                                      as cert_no         --证件号      
          ,'2'                                                         as fund_flag       --资金方标识
          ,''                                                          as biz_prod_code   --业务产品代码
          ,''                                                          as sub_biz_prod_code  --业务子产品代码
          ,nvl(t4.stage_no,'')                                         as term_no         --期次
          ,nvl(substr(t3.receipt_date,1,10),'')                        as repay_date	  --还款日期
          ,coalesce(t3.receipt_date,'')                                as repay_time      --还款时间 
          ,case when upper(t3.receipt_type)='PO' then 'PF1'
                when upper(t3.receipt_type)='ER' then 'ER1'
                when upper(t3.receipt_type)='NS' then 'NS1'
                else '' 
		    end                                                        as repay_type	  --还款方式    
          ,nvl(t4.repaid_prin,0)                                       as repaid_prin     --还款本金
          ,nvl(t4.repaid_int,0)                                        as repaid_int      --还款利息
          ,nvl(t4.repaid_pena,0)                                       as repaid_pena     --还款罚息
          ,nvl(t4.repaid_compo,0)                                      as repaid_compo    --还款复利
          ,nvl(t4.repaid_fee,0)                                        as repaid_guar_fee --还款担保费        
          ,0                                                           as adv_repay_fee   --提前还款手续费   
          ,'0'                                                         as repay_status    --还款状态（0：成功，1：失败） 
          ,''                                                          as error_msg       --失败信息
          ,'0'                                                         as is_b            --是否为B账
          ,''                                                          as repaycardno     --还款卡号  
          ,nvl(t4.repaid_amt,'')                                       as repaid_amt      --还款总金额
          ,'0'                                                         as is_offline      --是否线下
          ,nvl(t3.receipt_gen_code,'')                                 as recov_mode      --回收方式
          ,nvl(from_unixtime(unix_timestamp(t3.tran_date,'yyyyMMdd'),'yyyy-MM-dd'),'')
		                                                               as accting_date    --记账日期  update 20231017 yuguorui
          ,nvl(t5.prod_type,'')                                        as prod_code       --产品号
      from odata.sym_mb_receipt t3       
      left join (select receipt_no
	                   ,stage_no
                       ,sum(case when amt_type = 'PRI' then rec_amt else 0 end) as repaid_prin
                       ,sum(case when amt_type = 'INT' then rec_amt else 0 end) as repaid_int
                       ,sum(case when amt_type = 'ODP' then rec_amt else 0 end) as repaid_pena
                       ,sum(case when amt_type = 'ODI' then rec_amt else 0 end) as repaid_compo
                       ,sum(case when amt_type = 'FEE' then rec_amt else 0 end) as repaid_fee
                       ,sum(case when amt_type in ('PRI','INT','ODP','ODI','FEE') then rec_amt else 0 end) as repaid_amt
                   from odata.sym_mb_receipt_detail     --线上贷款回收明细表
                  where data_date = '${DATA_DATE}' 
				    and bddw_end_date = '9999-99-99'
                  group by receipt_no
				          ,stage_no
				) t4
        on t3.receipt_no = t4.receipt_no 
      left join odata.sym_mb_acct t5       --线上基本信息表
        on t3.acct_internal_key = t5.internal_key         
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
      left join odata.sym_cif_client_document t8
        on t5.client_no = t8.client_no
       and t8.data_date = '${DATA_DATE}'
       and t8.bddw_end_date = '9999-99-99'
       and t8.pref_flag = 'Y'
     where t3.reversal = 'N'  --剔除冲正 
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
       and substr(t5.prod_type,1,3) = '110'



