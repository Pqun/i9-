--2.gaoyuan.dwd.dwd_d_bill_disc_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：票据融资协议表取数逻辑.sql
--功能描述：用于创建 dwd.dwd_d_bill_disc_p
--作    者：高源
--开发日期：2022-08-02
--直属经理：方杰
--来源表:
--1.odata.nbms_bms_draft_centre_info  票据票面信息表 
--2.odata.nbms_bms_draft_centre_trans 票据交易信息表
--3.odata.nbms_bms_provision          利息计提表 
--4.odata.nbms_bms_buy_details        贴现明细表
--5.odata.nbms_bms_buy_contract       贴现批次表
--6.odata.nbms_dpc_draft_info         票据票面信息表
--7.odata.nbms_cpes_quote_details     对话报价明细表
--8.odata.nbms_cpes_quote_contract    对话报价协议表
--9.odata.nbms_ifrs9_valuation        i9票据公允价值表
--10.odata.als_business_contract      业务合同信息表
--11.odata.als_classify_record        风险分类记录表
--12.odata.nbms_htes_draft_his_info   票据历史信息表
--13.odata.nbms_ces_quote_deal        对话报价成交单表
--13.odata.nbms_mem_brh_info          会员机构信息表
--目标表：dwd.dwd_d_bill_disc_p   票据融资协议表
--修改历史：
--          1.高源   2022-08-02    新建
--          2.高源   2022-11-25    新增日计提利息
--          3.高源   2023-02-06    新增卖出结算金额字段，结清日期逻辑调整
--          4.高源   2023-02-10    新增五级分类、五级分类日期、票据区间字段    
--          5.高源   2023-06-16    新增首贴人名称字段
--          6.高源   2023-09-01    转贴现业务贴现人名称、贴现人账号、贴现人行名称逻辑调整
--          7.高源   2023-09-28    新增首贴日期字段  
--          8.姚威   2023-11-07    新增经办人工号、审批人工号
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_bill_disc_p partition (data_date = '${DATA_DATE}')
 select  /*+ REPARTITION(1) */
         nvl(t1.id                  ,'')  as  deal_id              --业务编号   
        ,nvl(t5.protocol_no         ,'')  as  cont_no              --合同编号 
        ,nvl(t1.draft_number        ,'')  as  bill_no              --票据编号
        ,'100000'                         as  org_id               --机构号
        ,case when t1.draft_type='1' then '10300101' --银行承兑汇票贴现
              when t1.draft_type='2' then '10300201' --商业承兑汇票贴现
              else '' end                 as  subj_no              --科目号
        ,nvl(t5.product_no          ,'')  as  prod_code            --产品号
        ,'CNY'                            as  ccy                  --币种
        ,'1'                              as  bill_disc_type       --贴现类型
        ,nvl(from_unixtime(unix_timestamp(t1.remit_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as  remit_date           --出票日
        ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as  bill_expr_date       --票面到期日
        ,nvl(from_unixtime(unix_timestamp(t5.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as  bill_disc_date       --贴现日(贴入)
        ,nvl(from_unixtime(unix_timestamp(t7.ztx_sale_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as  mature_date          --到期日(贴出日)
        ,'2'                              as  int_basis            --计息基础
        ,nvl(t5.cust_no             ,'')  as  disc_cust_id         --贴现人客户号
        ,nvl(t5.cust_name           ,'')  as  disc_cust_name       --贴现人名称
        ,nvl(t5.cust_account        ,'')  as  disc_acct_no         --贴现人账号
        ,''                               as  disc_cert_no         --贴现人证件代码
        ,nvl(t5.cust_bank_no        ,'')  as  disc_bank_no         --贴现人开户行号
        ,nvl(t5.cust_bank_name      ,'')  as  disc_bank_name       --贴现人开户行名称
        ,nvl(t1.remitter_name       ,'')  as  drawer_name          --出票人名称
        ,nvl(t1.remitter_account    ,'')  as  drawer_acct_no       --出票人账号
        ,nvl(t6.remitter_crt_no     ,'')  as  drawer_cert_no       --出票人证件代码
        ,nvl(t1.remitter_bank_no    ,'')  as  drawer_bank_no       --出票人开户行号
        ,nvl(t1.remitter_bank_name  ,'')  as  drawer_bank_name     --出票人开户行名称
        ,nvl(t1.acceptor_name       ,'')  as  acceptor_name        --承兑人名称
        ,nvl(t6.acceptor_crt_no     ,'')  as  acceptor_cert_no     --承兑人证件号码
        ,nvl(t1.acceptor_bank_no    ,'')  as  acceptor_bank_no     --承兑人开户行号
        ,nvl(t1.draft_amount         ,0)  as  bill_amt             --票面金额
        ,nvl(t4.pay_amount           ,0)  as  disc_amt             --贴现金额
        ,nvl(t5.rate                 ,0)  as  disc_rate            --贴现利率
        ,nvl(t4.payment_days        ,'')  as  dis_int_days         --贴现计息天数  
        ,nvl(t4.interest             ,0)  as  interest             --利息  
        ,nvl(t3.prov_interest        ,0)  as  accru_int            --计提利息
        ,if(t6.status in ('S04','S14','S15','S21','S25','S29','S30','S32','S39'),0,nvl(t3.prov_interest-t3.interest,0))as int_adj --利息调整   --码值为结清状态
        ,nvl(t3.it_in_subject_no    ,'')  as  int_adj_subj_no      --利息调整科目
        ,if(t6.status in ('S04','S14','S15','S21','S25','S29','S30','S32','S39'),0,nvl(t8.fv_change,0)) as  fair_value_adj_amt     --公允价值变动金额
        ,case when t1.draft_type='1' then '10300103' --银行承兑汇票贴现-公允价值变动
              when t1.draft_type='2' then '10300203' --商业承兑汇票贴现-公允价值变动    
              else '' end                 as  fair_value_adj_subj  --公允价值变动科目
        ,nvl(t6.status              ,'')  as  bill_status          --票据状态  
        ,case when t7.ztx_sale_date is not null then from_unixtime(unix_timestamp(t7.ztx_sale_date,'yyyyMMdd'),'yyyy-MM-dd')
              when t7.ztx_sale_date is null and from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')<='${DATA_DATE}' 
              then nvl(from_unixtime(unix_timestamp(c.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')
              else  ''   end              as  bill_clear_date      --结清日期             
        ,if(t6.status in ('S04','S14','S15','S21','S25','S29','S30','S32','S39') ,0,nvl(t1.draft_amount,0)) as bill_bal    --当前余额
        ,nvl(t3.ever_pro_amount      ,0)  as  withdraw_int         --日计提利息
        ,nvl(t7.settle_amt           ,0)  as  settle_amt           --卖出结算金额
        ,case when t10.classifyresult ='01' then 'FQ01'            
              when t10.classifyresult ='02' then 'FQ02'            
              when t10.classifyresult ='03' then 'FQ03'            
              when t10.classifyresult ='04' then 'FQ04'            
              when t10.classifyresult ='05' then 'FQ05'            
              else  ''    end             as  five_risk_level      --五级分类    
        ,nvl(t11.five_risk_date     ,'')  as  five_risk_date       --五级分类日期
        ,'-'                              as  bill_range           --票据区间
        ,nvl(t5.cust_name           ,'')  as  first_disc_name      --首贴人名称      --2023-06-16新增字段
		,nvl(from_unixtime(unix_timestamp(t5.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as  first_disc_date --首贴日期    --2023-09-28新增
		,''                               as  oper_emp_id	       --经办人       --贴现业务无经办人  20231107update
        ,''                               as  approver	 	       --审批人       --贴现业务无审批人  20231107update
from odata.nbms_bms_draft_centre_info t1       --票据信息表
inner join odata.nbms_bms_draft_centre_trans t2  --票据交易信息表
   on t1.trans_id=t2.id
  and t2.data_date='${DATA_DATE}' 
  and t2.bddw_end_date='9999-99-99'
  and t2.product_no in ('21020002','22020002')       --电票银票直贴卖方付息,电票商票直贴卖方付息
  and t2.status not like '%_30'                      --30结尾为失败部分
left join odata.nbms_bms_provision  t3 --利息计提表
   on t3.draft_id=t1.id
  and t3.data_date='${DATA_DATE}' 
  and t3.bddw_end_date='9999-99-99' 
  and t3.jiti_type='1'   --贴现
left join odata.nbms_bms_buy_details t4 --贴现明细表
   on t1.id=t4.draft_id
  and t4.data_date='${DATA_DATE}' 
  and t4.bddw_end_date='9999-99-99'
inner join  odata.nbms_bms_buy_contract t5 --贴现批次表
   on t5.id=t4.contract_id
  and t5.data_date='${DATA_DATE}' 
  and t5.bddw_end_date='9999-99-99'
left join odata.nbms_dpc_draft_info t6
  on  t1.id = t6.bms_draft_id
  and t6.data_date='${DATA_DATE}'
  and t6.bddw_end_date='9999-99-99'
  and t6.src_type='SR026'
left join odata.als_business_duebill t10
   on t5.protocol_no=t10.actualartificialno  
  and t4.draft_number=t10.billno
  and t10.businesstype='1020010'
  and t10.data_date= '${DATA_DATE}'
  and t10.bddw_end_date='9999-99-99'
left join (
        select objectno,regexp_replace(classifydate,'/','-')  as  five_risk_date
               ,row_number() over(partition by objectno order by classifydate  desc) as rn
          from odata.als_classify_record 
         where data_date='${DATA_DATE}' 
           and bddw_end_date='9999-99-99' ) t11                                
   on t10.serialno=t11.objectno 
  and t11.rn=1
left join odata.nbms_cpes_prmtpay_apply c             --c.apply_date  到期我行申请解付成功日 
   on t6.id=c.draft_id 
  and c.account_status = '02' --记账成功
  and c.buss_flag ='01' --申请
  and c.data_date='${DATA_DATE}' 
  and c.bddw_end_date='9999-99-99'
  ------------------------转帖卖出的日期---------------------------------
  left join (
    select t1.id, t1.bms_draft_id, t1.draft_number, t3.apply_date as ztx_sale_date,t2.settle_amt
	  from odata.nbms_dpc_draft_info t1 --票据票面信息表
	  inner join odata.nbms_cpes_quote_details t2 --对话报价明细表
		on t2.draft_id=t1.id 
	   and t2.data_date='${DATA_DATE}' 
	   and t2.bddw_end_date='9999-99-99'
	   and t2.account_status='02' -- 记账成功
	  inner join odata.nbms_cpes_quote_contract t3 --对话报价协议表
		on t2.contract_id=t3.id 
	   and t3.data_date='${DATA_DATE}' 
	   and t3.bddw_end_date='9999-99-99'
	   and t3.trade_direct='TDD02'  -- 卖出
	   and t3.busi_type = 'BT01' -- 转贴现
	 where t1.data_date='${DATA_DATE}' 
	   and t1.bddw_end_date='9999-99-99' 
)t7 on t1.id = t7.bms_draft_id
  left join (select  id,sum(fv_change) as fv_change 
               from odata.nbms_ifrs9_valuation 
              where data_date='${DATA_DATE}' 
                and bddw_end_date='9999-99-99' 
                and nvl(reserve1,'') <> '1'   --剔除已卖出部分
               group by id  )t8
    on t8.id=t1.id
where t1.data_date='${DATA_DATE}' 
  and t1.bddw_end_date='9999-99-99'
union all 
-------------------------------------------------等分化票据贴现--------------------------------------------------------
 select  /*+ REPARTITION(1) */
         nvl(t1.id                  ,'')  as  deal_id              --业务编号   
        ,nvl(t5.protocol_no         ,'')  as  cont_no              --合同编号 
        ,nvl(t1.draft_number        ,'')  as  bill_no              --票据编号
        ,'100000'                         as  org_id               --机构号
        ,case when t1.draft_type='1' then '10300101' --银行承兑汇票贴现
              when t1.draft_type='2' then '10300201' --商业承兑汇票贴现
              else '' end                 as  subj_no              --科目号
        ,nvl(t5.product_no          ,'')  as  prod_code            --产品号
        ,'CNY'                            as  ccy                  --币种
        ,'1'                              as  bill_disc_type       --贴现类型
        ,nvl(from_unixtime(unix_timestamp(t1.remit_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as  remit_date           --出票日
        ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as  bill_expr_date       --票面到期日
        ,nvl(from_unixtime(unix_timestamp(t5.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as  bill_disc_date       --贴现日(贴入)
        ,nvl(from_unixtime(unix_timestamp(t7.ztx_sale_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as  mature_date          --到期日(贴出日)
        ,'2'                              as  int_basis            --计息基础
        ,nvl(t5.cust_no             ,'')  as  disc_cust_id         --贴现人客户号
        ,nvl(t5.cust_name           ,'')  as  disc_cust_name       --贴现人名称
        ,nvl(t5.cust_account        ,'')  as  disc_acct_no         --贴现人账号
        ,''                               as  disc_cert_no         --贴现人证件代码
        ,nvl(t5.cust_bank_no        ,'')  as  disc_bank_no         --贴现人开户行号
        ,nvl(t5.cust_bank_name      ,'')  as  disc_bank_name       --贴现人开户行名称
        ,nvl(t1.remitter_name       ,'')  as  drawer_name          --出票人名称
        ,nvl(t1.remitter_account    ,'')  as  drawer_acct_no       --出票人账号
        ,nvl(t1.remitter_crt_no     ,'')  as  drawer_cert_no       --出票人证件代码
        ,nvl(t1.remitter_bank_no    ,'')  as  drawer_bank_no       --出票人开户行号
        ,nvl(t1.remitter_bank_name  ,'')  as  drawer_bank_name     --出票人开户行名称
        ,nvl(t1.acceptor_name       ,'')  as  acceptor_name        --承兑人名称
        ,nvl(t1.acceptor_crt_no     ,'')  as  acceptor_cert_no     --承兑人证件号码
        ,nvl(t1.acceptor_bank_no    ,'')  as  acceptor_bank_no     --承兑人开户行号
        ,nvl(t1.draft_amount         ,0)  as  bill_amt             --票面金额
        ,nvl(t4.pay_amount           ,0)  as  disc_amt             --贴现金额
        ,nvl(t4.rate                 ,0)  as  disc_rate            --贴现利率
        ,nvl(t4.payment_days        ,'')  as  dis_int_days         --贴现计息天数  
        ,nvl(t4.interest             ,0)  as  interest             --利息  
        ,nvl(t3.prov_interest        ,0)  as  accru_int            --计提利息
        ,if(t6.status in ('S04','S14','S15','S21','S25','S29','S30','S32','S39'),0,nvl(t3.prov_interest-t3.interest,0))as int_adj --利息调整   --码值为结清状态
        ,nvl(t3.it_in_subject_no    ,'')  as  int_adj_subj_no      --利息调整科目
        ,if(t6.status in ('S04','S14','S15','S21','S25','S29','S30','S32','S39'),0,nvl(t8.fv_change,0)) as  fair_value_adj_amt     --公允价值变动金额
        ,case when t1.draft_type='1' then '10300103' --银行承兑汇票贴现-公允价值变动
              when t1.draft_type='2' then '10300203' --商业承兑汇票贴现-公允价值变动    
              else '' end                 as  fair_value_adj_subj  --公允价值变动科目
        ,nvl(t6.status              ,'')  as  bill_status          --票据状态  
        ,case when t7.ztx_sale_date is not null then from_unixtime(unix_timestamp(t7.ztx_sale_date,'yyyyMMdd'),'yyyy-MM-dd')
              when t7.ztx_sale_date is null and from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')<='${DATA_DATE}' 
              then nvl(from_unixtime(unix_timestamp(c.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')
              else  ''   end              as  bill_clear_date      --结清日期                       持有到期日期逻辑需要调整
        ,if(t6.status in ('S04','S14','S15','S21','S25','S29','S30','S32','S39') ,0,nvl(t1.draft_amount,0)) as bill_bal    --当前余额
        ,nvl(t3.ever_pro_amount      ,0)  as  withdraw_int         --日计提利息
        ,nvl(t7.settle_amt           ,0)  as  settle_amt           --卖出结算金额
        ,case when t10.classifyresult ='01' then 'FQ01'            
              when t10.classifyresult ='02' then 'FQ02'            
              when t10.classifyresult ='03' then 'FQ03'            
              when t10.classifyresult ='04' then 'FQ04'            
              when t10.classifyresult ='05' then 'FQ05'            
              else  ''    end             as  five_risk_level      --五级分类    
        ,nvl(t11.five_risk_date     ,'')  as  five_risk_date       --五级分类日期
        ,nvl(t1.cd_range            ,'')  as  bill_range           --票据区间
        ,nvl(t5.cust_name           ,'')  as  first_disc_name      --首贴人名称         --2023-06-16新增字段
		,nvl(from_unixtime(unix_timestamp(t5.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   as  first_disc_date --首贴日期    --2023-09-28新增
	    ,''                               as  oper_emp_id	       --经办人   --贴现业务无经办人  20231107update
        ,''                               as  approver	 	       --审批人   --贴现业务无审批人  20231107update
from odata.nbms_dpc_draft_info t1       --票据信息表
inner join odata.nbms_cpes_buy_details t4 --贴现明细表
   on t1.id=t4.draft_id
  and t4.data_date='${DATA_DATE}' 
  and t4.bddw_end_date='9999-99-99'
  and t4.account_status='03'               --记账成功
inner join  odata.nbms_cpes_buy_contract t5 --贴现批次表
   on t5.id=t4.contract_id
  and t5.data_date='${DATA_DATE}' 
  and t5.bddw_end_date='9999-99-99'
 left join odata.nbms_bms_provision  t3 --利息计提表
   on t3.draft_id=t1.id
  and t3.data_date='${DATA_DATE}' 
  and t3.bddw_end_date='9999-99-99' 
  and t3.jiti_type='1'   --贴现
left join odata.nbms_dpc_draft_info t6
  on  t1.id = t6.discount_draft_id
  and t6.data_date='${DATA_DATE}'
  and t6.bddw_end_date='9999-99-99'
  and t6.src_type='SR026'
left join odata.als_business_duebill t10
   on t5.protocol_no=t10.actualartificialno  
  and t4.draft_number=t10.billno
  and t10.businesstype='1020010'
  and t10.data_date= '${DATA_DATE}'
  and t10.bddw_end_date='9999-99-99'
left join (
        select objectno,regexp_replace(classifydate,'/','-')  as  five_risk_date
               ,row_number() over(partition by objectno order by classifydate  desc) as rn
          from odata.als_classify_record 
         where data_date='${DATA_DATE}' 
           and bddw_end_date='9999-99-99' ) t11                                
   on t10.serialno=t11.objectno 
  and t11.rn=1
left join odata.nbms_cpes_prmtpay_apply c             --c.apply_date  到期我行申请解付成功日 
   on t6.id=c.draft_id 
  and c.account_status = '02' --记账成功
  and c.buss_flag ='01' --申请
  and c.data_date='${DATA_DATE}' 
  and c.bddw_end_date='9999-99-99'
 left join (
             select t1.cd_range, t1.draft_number,t1.discount_draft_id , t3.apply_date as ztx_sale_date,t2.settle_amt
               from odata.nbms_dpc_draft_info t1 --票据票面信息表
              inner join odata.nbms_cpes_quote_details t2 --对话报价明细表
                 on t2.draft_id=t1.id 
                and t2.data_date='${DATA_DATE}' 
                and t2.bddw_end_date='9999-99-99'
                and t2.account_status='02' -- 记账成功
              inner join odata.nbms_cpes_quote_contract t3 --对话报价协议表
                 on t2.contract_id=t3.id 
                and t3.data_date='${DATA_DATE}' 
                and t3.bddw_end_date='9999-99-99'
                and t3.trade_direct='TDD02'  -- 卖出
                and t3.busi_type = 'BT01' -- 转贴现
              where t1.data_date='${DATA_DATE}' 
                and t1.bddw_end_date='9999-99-99' 
                and t1.src_type='SR026'                --权属登记
                   )t7
   on t1.id = t7.discount_draft_id
 left join (select  id ,sum(fv_change) as fv_change 
              from odata.nbms_ifrs9_valuation 
             where data_date='${DATA_DATE}' 
               and bddw_end_date='9999-99-99' 
               and nvl(reserve1,'') <> '1' 
             group by id  )t8
   on t8.id=t1.id                
where t1.data_date='${DATA_DATE}' 
  and t1.bddw_end_date='9999-99-99'
  and t1.status != 'S00'         --无效
  and t1.src_type='SR020'        --贴现登记
union all 
--------------------------------------------------转贴现部分----------------------------------------------
 select  /*+ REPARTITION(1) */
         nvl(t1.id                  ,'')  as  deal_id           --业务编号   
        ,nvl(t4.contract_no         ,'')  as  cont_no           --合同编号 
        ,nvl(t1.draft_number        ,'')  as  bill_no           --票据编号
        ,'100000'                         as  org_id            --机构号
        ,case when t1.draft_type='1' then '10310101' --银行承兑汇票转贴现
              when t1.draft_type='2' then '10310201' --商业承兑汇票转贴现
              else '' end                 as  subj_no           --科目号
        ,nvl(t4.product_no          ,'')  as  prod_code         --产品号
        ,'CNY'                            as  ccy               --币种
        ,'2'                              as  bill_disc_type    --贴现类型
        ,nvl(from_unixtime(unix_timestamp(t1.remit_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as  remit_date           --出票日
        ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as  bill_expr_date       --票面到期日
        ,nvl(from_unixtime(unix_timestamp(t4.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as  bill_disc_date       --贴现日(贴入)
        ,nvl(from_unixtime(unix_timestamp(t7.ztx_sale_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as  mature_date          --到期日(贴出日)
        ,'2'                              as  int_basis         --计息基础
        ,nvl(t4.cust_no             ,'')  as  disc_cust_id      --贴现人客户号        --2023-09-01update
        ,nvl(tm.brh_zh_full_name    ,'')  as  disc_cust_name    --贴现人名称          --2023-09-01update
        ,nvl(td.adver_fund_acct     ,'')  as  disc_acct_no      --贴现人账号
        ,''                               as  disc_cert_no      --贴现人证件代码
        ,coalesce(tm2.ubank_no       ,'')  as  disc_bank_no     --贴现人开户行号     --2023-09-01update 
        ,coalesce(tm2.brh_zh_full_name,'') as  disc_bank_name   --贴现人开户行名称   --2023-09-01update
        ,nvl(t1.remitter_name       ,'')  as  drawer_name       --出票人名称
        ,nvl(t1.remitter_account    ,'')  as  drawer_acct_no    --出票人账号
        ,nvl(t1.remitter_crt_no     ,'')  as  drawer_cert_no    --出票人证件代码
        ,nvl(t1.remitter_bank_no    ,'')  as  drawer_bank_no    --出票人开户行号
        ,nvl(t1.remitter_bank_name  ,'')  as  drawer_bank_name  --出票人开户行名称
        ,nvl(t1.acceptor_name       ,'')  as  acceptor_name     --承兑人名称
        ,nvl(t1.acceptor_crt_no     ,'')  as  acceptor_cert_no  --承兑人证件号码
        ,nvl(t1.acceptor_bank_no    ,'')  as  acceptor_bank_no  --承兑人开户行号
        ,nvl(t1.draft_amount         ,0)  as  bill_amt             --票面金额
        ,nvl(t2.settle_amt           ,0)  as  disc_amt             --贴现金额
        ,nvl(t4.rate*100             ,0)  as  disc_rate            --贴现利率
        ,nvl(t2.tenor_days          ,'')  as  dis_int_days         --贴现计息天数  
        ,nvl(t2.pay_interest         ,0)  as  interest             --利息  
        ,nvl(t3.prov_interest        ,0)  as  accru_int              --计提利息
        ,if(t1.status in ('S04','S14','S15','S21','S25','S29','S30','S32','S39'),0,nvl(t3.prov_interest-t3.interest,0))as int_adj --利息调整
        ,nvl(t3.it_in_subject_no    ,'')  as  int_adj_subj_no        --利息调整科目
        ,if(t1.status in ('S04','S14','S15','S21','S25','S29','S30','S32','S39'),0,nvl(t5.fv_change,0)) as  fair_value_adj_amt     --公允价值变动金额
        ,case when t1.draft_type='1' then '10310103' --银行承兑汇票转贴现-公允价值变动
              when t1.draft_type='2' then '10310203' --商业承兑汇票转贴现-公允价值变动
              else '' end                 as  fair_value_adj_subj    --公允价值变动科目
        ,nvl(t1.status              ,'')  as  bill_status            --票据状态  
        ,case when t7.ztx_sale_date is not null then from_unixtime(unix_timestamp(t7.ztx_sale_date,'yyyyMMdd'),'yyyy-MM-dd')
              when t7.ztx_sale_date is null and from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd')<='${DATA_DATE}' 
                   then  nvl(from_unixtime(unix_timestamp(c.apply_date,'yyyyMMdd'),'yyyy-MM-dd'),'')
              else  ''   end              as  bill_clear_date        --结清日期              
        ,if(t1.status in ('S04','S14','S15','S21','S25','S29','S30','S32','S39') ,0,nvl(t1.draft_amount,0)) as bill_bal  --票据余额
        ,nvl(t3.ever_pro_amount      ,0)  as  withdraw_int           --日计提利息
        ,nvl(t7.settle_amt           ,0)  as  settle_amt             --卖出结算金额
        ,''                               as  five_risk_level        --五级分类    
        ,''                               as  five_risk_date         --五级分类日期
        ,nvl(t1.cd_range            ,'')  as  bill_range             --票据区间
        ,coalesce(th2.req_name,th1.req_name,'')  as  first_disc_name --首贴人名称          --2023-06-16新增字段
		,coalesce( from_unixtime(unix_timestamp(th2.buss_occ_dt,'yyyyMMdd'),'yyyy-MM-dd'), from_unixtime(unix_timestamp(th1.buss_occ_dt ,'yyyyMMdd'),'yyyy-MM-dd'),'')
		                                         as  first_disc_date --首贴日期            --2023-09-28新增
		,nvl(t4.created_by, '')                  as  oper_emp_id	  --经办人         -- 20231107update
        ,nvl(tbl.assign_id, '')                  as  approver	 	  --审批人         -- 20231107update
 from odata.nbms_dpc_draft_info t1--票据票面信息表
inner join odata.nbms_cpes_quote_details  t2 --对话报价明细表
   on t1.id=t2.draft_id        
  and t2.data_date='${DATA_DATE}' 
  and t2.bddw_end_date='9999-99-99'     
  and t2.account_status='02'     -- 记账成功
 left join odata.nbms_bms_provision t3 --利息计提表
   on t3.draft_id=t1.id
  and t3.data_date='${DATA_DATE}' 
  and t3.bddw_end_date='9999-99-99' 
  and t3.jiti_type='2' --转贴现
inner join odata.nbms_cpes_quote_contract t4--对话报价协议表
   on t2.contract_id=t4.id 
  and t4.data_date='${DATA_DATE}' 
  and t4.bddw_end_date='9999-99-99'
  and t4.trade_direct = 'TDD01' --买入
  left join
    (select * from
         (select  task_name, task_flag, assign_id, name2, row_number() over(partition by name2 order by create_time desc  ) rn
            from  odata.flowsharp_tbl_repeat_task        --流程表
           where data_date='${DATA_DATE}' 
 	         and bddw_end_date='9999-99-99'
			 and task_flag='2'         --审批状态           --待确认数据
			 ) a 
 	 where a.rn=1) tbl
   on t4.contract_no=tbl.name2   
 left join (select id ,sum(fv_change) as fv_change 
                from odata.nbms_ifrs9_valuation 
               where data_date='${DATA_DATE}' 
                 and bddw_end_date='9999-99-99'    
                 and nvl(reserve1,'') <> '1'    --剔除已卖出部分
               group by id)t5
    on t5.id=t1.id
  left join odata.nbms_ces_quote_deal td
    on t4.deal_id=td.dealed_no
   and td.data_date='${DATA_DATE}' 
   and td.bddw_end_date='9999-99-99'
  left join odata.nbms_mem_brh_info tm 
    on td.adver_brh_no = tm.brh_no
   and tm.data_date = '${DATA_DATE}'
   and tm.bddw_end_date = '9999-99-99' 
  left join 
  (select * from
         (select *,  row_number() over(partition by mem_no order by brh_no) rn
            from odata.nbms_mem_brh_info      --本地用户表
           where data_date='${DATA_DATE}' 
 	         and bddw_end_date='9999-99-99') a 
 	 where a.rn=1) tm2
   on tm.mem_no=tm2.mem_no   
 left join odata.nbms_cpes_prmtpay_apply c             --c.apply_date  到期我行申请解付成功日 
   on t1.id=c.draft_id 
  and c.account_status = '02' --记账成功
  and c.buss_flag ='01' --申请
  and c.data_date='${DATA_DATE}' 
  and c.bddw_end_date='9999-99-99'
  ------------------------转帖卖出的日期---------------------------------
left join (
    select t1.id, t1.bms_draft_id, t1.draft_number, t3.apply_date as ztx_sale_date,t2.settle_amt
	  from odata.nbms_dpc_draft_info t1 --票据票面信息表
	  inner join odata.nbms_cpes_quote_details t2 --对话报价明细表
		on t2.draft_id=t1.id 
	   and t2.data_date='${DATA_DATE}' 
	   and t2.bddw_end_date='9999-99-99'
	   and t2.account_status='02' -- 记账成功
	  inner join odata.nbms_cpes_quote_contract t3 --对话报价协议表
		on t2.contract_id=t3.id 
	   and t3.data_date='${DATA_DATE}' 
	   and t3.bddw_end_date='9999-99-99'
	   and t3.trade_direct='TDD02'  -- 卖出
	   and t3.busi_type = 'BT01' -- 转贴现
	 where t1.data_date='${DATA_DATE}' 
	   and t1.bddw_end_date='9999-99-99' 
)t7 on t1.id = t7.id
 left join odata.nbms_htes_draft_his_info th1   --票据历史表
   on t1.draft_number = th1.draft_number  --票号
  and nvl(t1.cd_range,'-') = nvl(th1.cd_range,'-')
  and th1.data_date = '${DATA_DATE}'
  and th1.bddw_end_date = '9999-99-99'
  and th1.msg_type = '08'                        --贴现（老票据贴现码值）   
 left join  odata.nbms_htes_draft_his_info th2   --票据历史表
   on t1.draft_number = th2.draft_number  --票号
  and nvl(t1.cd_range,'-') = nvl(th2.cd_range,'-')
  and th2.data_date = '${DATA_DATE}'
  and th2.msg_type = 'ET05'               --转让背书（包括贴现、转贴现、转让）
  and th2.req_account <> '0'              --请求方为企业
  and th2.rcv_account =  '0'              --接收方为银行
where t1.data_date='${DATA_DATE}' 
  and t1.bddw_end_date='9999-99-99'
  and t1.src_type = 'SR005' --转贴现
  and t1.status != 'S00' --无效