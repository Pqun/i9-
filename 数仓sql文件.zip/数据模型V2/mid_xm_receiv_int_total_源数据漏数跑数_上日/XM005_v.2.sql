--XM005
insert into dwd.mid_xm_recv_int_scene_tran_new_used partition(data_date='2022-03-16')
select /*+ REPARTITION(1) */ 
xlf.loan_id    as loan_no,
       'XM005'      as sence,	
      (sum(nvl(xlf.pnlt_int_total, 0) - nvl(last.pnlt_int_total, 0)))/100 as pnlt_int_total
  from odata.slur_xm_loan_file xlf                                  --小米日初借据信息表
 inner join odata.slur_xm_loan_file last
    on last.loan_id = xlf.loan_id
   and last.data_date = '${DATA_DATE}'   
   and last.bddw_end_date = '9999-99-99'
   and last.loan_status != '6'
   and last.channel_date = regexp_replace(date_add('${DATA_DATE}',-3),'-','') 
      -- to_char(to_date(xlf.channel_date, 'yyyymmdd') - 1, 'yyyymmdd')
 where xlf.data_date = '${DATA_DATE}'
   and xlf.bddw_end_date = '9999-99-99'
   and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
   and xlf.loan_form = '2'
   and not exists(select 1
                    from odata.slur_acc_writeoff_hist awh
                    where awh.data_date = '${DATA_DATE}'
					  and awh.bddw_end_date = '9999-99-99'
					  and awh.loan_no = xlf.loan_id
                      and awh.tran_date < xlf.tran_date
					  )
      --上日核算状态为表内
   and not exists(select 1
                     from odata.slur_xm_term_status_file xtsf
                    where xtsf.data_date = '${DATA_DATE}'
                      and xtsf.bddw_end_date = '9999-99-99'
					  and xtsf.channel_date = regexp_replace(date_add('${DATA_DATE}',-3),'-','')
                      and xtsf.loan_id = xlf.loan_id
                      and xtsf.term_status <> 5                                                    --未结清
                      and not exists (select 1
                                        from odata.slur_dzz_compensatory_detail dcd
                                       where dcd.data_date = date_add('${DATA_DATE}',-1)
									     and dcd.bddw_end_date = '9999-99-99'
									     and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-2),'-','')
                                         and dcd.loan_no = xtsf.loan_id
                                         and dcd.term_no = xtsf.term_no
                                         and dcd.comps_status = 'S'
                                         and dcd.prod_type = '110126') 
					   having max(xtsf.days_ovd) > 89)
    group by xlf.loan_id
     
union all         
        
 select /*+ REPARTITION(1) */ 
 xlf.loan_id    as loan_no,
        'XM005'      as sence,	
        -(sum(nvl(xsf.pnlt_int_total, 0) - nvl(xsf2.pnlt_int_total, 0)))/100 as PNLT_INT_TOTAL
    from odata.slur_xm_loan_file xlf
    inner join odata.slur_xm_loan_file last
      on last.loan_id = xlf.loan_id
	  and last.data_date = '${DATA_DATE}'
	  and last.bddw_end_date = '9999-99-99'
      and last.loan_status != '6'
      and last.channel_date = regexp_replace(date_add('${DATA_DATE}',-3),'-','')
         --to_char(to_date(xlf.channel_date, 'yyyymmdd') - 1, 'yyyymmdd')
    inner join odata.slur_xm_term_status_file xsf
      on xlf.loan_id = xsf.loan_id
	  and xsf.data_date = '${DATA_DATE}'
	  and xsf.bddw_end_date = '9999-99-99'
      --and xlf.channel_date = xsf.channel_date
      and xsf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
    inner join odata.slur_xm_term_status_file xsf2
      on xsf.loan_id = xsf2.loan_id
	  and xsf2.data_date = '${DATA_DATE}'
	  and xsf2.bddw_end_date = '9999-99-99'
      and xsf.term_no = xsf2.term_no
      and xsf2.channel_date = regexp_replace(date_add('${DATA_DATE}',-3),'-','')
      
      where xlf.data_date = '${DATA_DATE}'
        and xlf.bddw_end_date = '9999-99-99'
        and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
        and exists (select 1 
                    from odata.slur_dzz_compensatory_detail dcd
                   where dcd.data_date = date_add('${DATA_DATE}',-1)
				     and dcd.bddw_end_date = '9999-99-99'
				     and dcd.loan_no = xsf.loan_id
                     and dcd.term_no = xsf.term_no
                     and dcd.comps_status = 'S'
                     and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-2),'-',''))
        and xlf.loan_id in( select xlf.loan_id 
                              from odata.slur_xm_loan_file xlf                                  --小米日初借据信息表
                              inner join odata.slur_xm_loan_file last
                                on last.loan_id = xlf.loan_id
                                and last.data_date = '${DATA_DATE}'   
                                and last.bddw_end_date = '9999-99-99'
                                and last.loan_status != '6'
                                and last.channel_date = regexp_replace(date_add('${DATA_DATE}',-3),'-','') 
                                  -- to_char(to_date(xlf.channel_date, 'yyyymmdd') - 1, 'yyyymmdd')
								and last.loan_status != '6'
                              where xlf.data_date = '${DATA_DATE}'
                                and xlf.bddw_end_date = '9999-99-99'
                                and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
                                and xlf.loan_form = '2'
                                and not exists(select 1
                                                from odata.slur_acc_writeoff_hist awh
                                                where awh.data_date = '${DATA_DATE}'
                             					  and awh.bddw_end_date = '9999-99-99'
                             					  and awh.loan_no = xlf.loan_id
                                                  and awh.tran_date < xlf.tran_date
                             					  )
                                  --上日核算状态为表内
                                and not exists(select 1
                                                  from odata.slur_xm_term_status_file xtsf
                                                  where xtsf.data_date = '${DATA_DATE}'
                                                   and xtsf.bddw_end_date = '9999-99-99'
                                				   and xtsf.channel_date = regexp_replace(date_add('${DATA_DATE}',-3),'-','')
                                                   and xtsf.loan_id = xlf.loan_id
                                                   and xtsf.term_status <> 5                                                    --未结清
                                                   and not exists (select 1
                                                                     from odata.slur_dzz_compensatory_detail dcd
                                                                    where dcd.data_date = date_add('${DATA_DATE}',-1)
                                								     and dcd.bddw_end_date = '9999-99-99'
                                								     and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-2),'-','')
                                                                     and dcd.loan_no = xtsf.loan_id
                                                                     and dcd.term_no = xtsf.term_no
                                                                     and dcd.comps_status = 'S'
                                                                     and dcd.prod_type = '110126') 
					                           having max(xtsf.days_ovd) > 89)
                        )
		group by xlf.loan_id 
	 
	