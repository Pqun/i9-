-- XM023
insert into dwd.mid_xm_recv_int_scene_tran_new_used partition(data_date='2022-03-16')
select  /*+ REPARTITION(1) */ 
xlf.loan_id              as loan_no,
        'XM023'                  as sence,
       sum(nvl(xlf.int_bal, 0) + nvl(xlf.ovd_int_bal, 0))/100  as int_amt
  from odata.slur_xm_loan_file xlf 
  inner join odata.slur_xm_loan_file last 
    on last.loan_id = xlf.loan_id
	and last.data_date = '${DATA_DATE}'
	and last.bddw_end_date = '9999-99-99'
    and last.channel_date = regexp_replace(date_add('${DATA_DATE}',-3),'-','') 
	and last.loan_status != '6'
  where xlf.data_date = '${DATA_DATE}'
    and xlf.bddw_end_date = '9999-99-99'
	and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
	-- 上日核算状态表内
    and not exists(select 1
                 from (select distinct a.loan_id
				             ,a.channel_date 
						 from odata.slur_xm_term_status_file a 
						 where a.data_date = '${DATA_DATE}'
                           and a.bddw_end_date = '9999-99-99' 
						   and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
						   and a.days_ovd > 89 
						   and a.term_status <> '5'
                           and not exists(select 1 
						                    from odata.slur_dzz_compensatory_detail dcd 
											where dcd.data_date = date_add('${DATA_DATE}',-1)
											and dcd.bddw_end_date = '9999-99-99'
											and dcd.loan_no = a.loan_id 
											and dcd.term_no = a.term_no 
											and dcd.comps_status = 'S' 
											and dcd.channel_date < a.channel_date)) fyj
               where fyj.loan_id = xlf.loan_id 
			     and fyj.channel_date = xlf.channel_date)
    -- 上日核算状态表外
    and exists(select 1
                     from (select distinct a.loan_id, 
					              a.channel_date 
						     from odata.slur_xm_term_status_file a 
							 where a.data_date = '${DATA_DATE}'
							   and a.bddw_end_date = '9999-99-99' 
							   and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-3),'-','')
							   and a.days_ovd > 89 
							   and a.term_status <> '5'
                               and not exists(select 1 
							                    from odata.slur_dzz_compensatory_detail dcd 
												where dcd.loan_no = a.loan_id 
												  and dcd.term_no = a.term_no 
												  and dcd.data_date = date_add('${DATA_DATE}',-1)
											      and dcd.bddw_end_date = '9999-99-99'
												  and dcd.comps_status = 'S'
                                                  and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-2),'-',''))) fyj
                     where fyj.loan_id = last.loan_id 
					   and fyj.channel_date = last.channel_date)
    and not exists (select 1
                      from odata.slur_acc_writeoff_hist awh
                     where awh.data_date = '${DATA_DATE}'
                       and awh.bddw_end_date = '9999-99-99'
				       and awh.loan_no = xlf.loan_id
                       and awh.tran_date < xlf.tran_date
                       )
    group by xlf.loan_id 
	
union all

-- 减已代偿未结清期次
select /*+ REPARTITION(1) */ 
xsf.loan_id              as loan_no,
        'XM023'                  as sence,
       - sum(nvl(xsf.int_bal, 0))/100 as int_amt
  from odata.slur_xm_term_status_file xsf 
  where xsf.data_date = '${DATA_DATE}'
    and xsf.bddw_end_date = '9999-99-99'
    and xsf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
    and xsf.term_status <> '5'
    and exists (select 1 
	              from odata.slur_dzz_compensatory_detail dcd 
				    where dcd.data_date = date_add('${DATA_DATE}',-1)
					  and dcd.bddw_end_date = '9999-99-99'
					  and dcd.loan_no = xsf.loan_id
                      and dcd.term_no = xsf.term_no 
					  and dcd.comps_status = 'S' 
					  and dcd.channel_date < xsf.channel_date)
    and xsf.loan_id in (select xlf.loan_id
                          from odata.slur_xm_loan_file xlf 
						  inner join odata.slur_xm_loan_file last 
						    on last.loan_id = xlf.loan_id
							and last.data_date = '${DATA_DATE}'
							and last.bddw_end_date = '9999-99-99'
							and last.channel_date = regexp_replace(date_add('${DATA_DATE}',-3),'-','') 
                            and last.loan_status != '6'							
						  where xlf.data_date = '${DATA_DATE}'
						    and xlf.bddw_end_date = '9999-99-99'
							and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')   
                           
    -- 当日日核算状态表内
    and not exists(select 1 
						from odata.slur_xm_term_status_file a 
						where a.data_date = '${DATA_DATE}'
						  and a.bddw_end_date = '9999-99-99'
						  and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')  
						  and a.days_ovd > 89 
						  and a.term_status <> '5'
						  and a.loan_id = xlf.loan_id 
                          and not exists(select 1 
						                   from odata.slur_dzz_compensatory_detail dcd 
										   where dcd.data_date = date_add('${DATA_DATE}',-1)
						                     and dcd.bddw_end_date = '9999-99-99'
										     and dcd.loan_no = a.loan_id 
										     and dcd.term_no = a.term_no 
										     and dcd.comps_status = 'S' 
										     and dcd.channel_date < a.channel_date) 
               )
    -- 上日核算状态表外
    and exists(select 1 
						    from odata.slur_XM_TERM_STATUS_FILE a 
							where a.data_date = '${DATA_DATE}'
						      and a.bddw_end_date = '9999-99-99'
                              and a.CHANNEL_DATE = regexp_replace(date_add('${DATA_DATE}',-3),'-','')   
							  and a.DAYS_OVD > 89 
							  and a.term_status <> '5'
							  and a.LOAN_ID = last.LOAN_ID
                              and not exists(select 1 
							                   from odata.slur_dzz_compensatory_detail dcd 
											   where dcd.data_date = date_add('${DATA_DATE}',-1)
											     and dcd.bddw_end_date = '9999-99-99'
											     and dcd.LOAN_NO = a.LOAN_ID 
												 and dcd.TERM_NO = a.TERM_NO 
												 and dcd.COMPS_STATUS = 'S'
                                                 and dcd.CHANNEL_DATE < regexp_replace(date_add('${DATA_DATE}',-2),'-',''))
               )
	and not exists (select 1
                      from odata.slur_acc_writeoff_hist awh
                     where awh.data_date = '${DATA_DATE}'
                       and awh.bddw_end_date = '9999-99-99'
				       and awh.loan_no = xlf.loan_id
                       and awh.tran_date < xlf.tran_date
                       )
     ) 
	 group by xsf.loan_id
