--2.zhanglijuan.dwd.dwd_c_corp_cust_rela_info_p
-------------------------------------------------------------------
--脚本名称:dwd.dwd_c_corp_cust_rela_info_p
--功能描述:对公客户关系信息表
--开发日期:2023-02-09
--直属经理:方杰
--目标表  :dwd.dwd_c_corp_cust_rela_info_p
--数据原表:
--修改历史:
--         1、张礼娟  20230427 新建
--         2、邓权    20230516 新增投资日期、维护日期、证件起始日期、证件到期日期
--         3、邓权    20230704 合并信贷及核心重合部分
--         4、邓权    20230725 新增关系类型描述、关系人证件类型描述、来源系统字段；取消信贷与核心重叠部分互补逻辑，改为拼接；信贷部分关系类型及关系人证件类型转为核心码值
--		   5、彭群    20231121 新增手机号码、创建日期字段
--		   6、杨琦浩  20240306 剔除已被删除、状态失效的关联客户信息
-------------------------------------------------------------------
insert overwrite table dwd.dwd_c_corp_cust_rela_info_p partition (data_date='${DATA_DATE}')
--核心1
select /*+repartition(1)*/
     nvl(rel.client_a,'')                                                            as cust_id  --客户号
    ,nvl(client.ch_client_name,'')                                                   as cust_name  --客户名称
    ,nvl(ecm.relation_type,'')                                                       as rela_type  --关系类型
    ,nvl(rel.client_b,'')                                                            as rela_cust_id  --关系人客户编号
    ,nvl(client1.ch_client_name,'')                                                  as rela_cust_nm  --关系人客户名称
    ,nvl(cdt.document_type,'')                                                       as rela_cert_type  --关系人证件类型
    ,nvl(doc.document_id,'')                                                         as rela_cert_no  --关系人证件号码
    ,'1'                                                                             as rela_status  --关系状态   1 有效  0 无效
    ,''                                                                              as invest_ccy  --出资币种
    ,''                                                                              as invest_amt  --实际出资额
    ,nvl(rel.equity_percent,'')                                                      as invest_ratio  --投资比例
    ,''                                                                              as hold_stock  --持股情况
    ,''                                                                              as invest_date  --投资日期
    ,nvl(from_unixtime(unix_timestamp(doc.last_change_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as rela_update_date  --维护日期
    ,nvl(from_unixtime(unix_timestamp(doc.iss_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as cert_start_date  --证件起始日期
    ,nvl(from_unixtime(unix_timestamp(doc.expiry_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as cert_mature_date  --证件到期日期
    ,nvl(ecm.relation_desc,'')                                                       as rela_type_desc  --关系类型
    ,nvl(cdt.document_type_desc,'')                                                  as rela_cert_type_desc  --关系人证件类型
    ,'1'                                                                             as source_system
	,nvl(rel.rela_tel,'')														     as tel_no 	--手机号码  --updata20231121 pengqun新增字段
	,case 
	  when length(rel.creation_date) = 8
		then concat(substring(rel.creation_date,1,4),'-',substring(rel.creation_date,5,2),'-',substring(rel.creation_date,7,2))
	  when length(rel.creation_date) = 10
		then concat(substring(rel.creation_date,1,4),'-',substring(rel.creation_date,6,2),'-',substring(rel.creation_date,9,2)) 
	else ''
    end                         													 as create_date --创建日期 --updata20231121 pengqun新增字段
from odata.sym_cif_cross_relations rel 
left join odata.sym_cif_client client 
on rel.client_a = client.client_no
and client.data_date = '${DATA_DATE}'
and client.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client client1
on rel.client_b = client1.client_no
and client1.data_date = '${DATA_DATE}'
and client1.bddw_end_date = '9999-99-99'
left join odata.sym_cif_relation_type ecm
on rel.relation = ecm.relation_type
and ecm.data_date = '${DATA_DATE}'
and ecm.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client_document doc --客户证件信息
on doc.client_no = rel.client_b
and doc.pref_flag = 'Y'
and doc.data_date = '${DATA_DATE}'
and doc.bddw_end_date = '9999-99-99'
left join odata.sym_cif_document_type cdt --客户证件类别
on doc.document_type = cdt.document_type
and cdt.data_date = '${DATA_DATE}'
and cdt.bddw_end_date = '9999-99-99'
where rel.data_date = '${DATA_DATE}'
and rel.bddw_end_date = '9999-99-99'
--and rel.client_a <> '80000001' --剔除该客户 总账户
and (substr(rel.client_a, 1, 1) <> '1' or substr(rel.client_b, 1, 1) <> '1') --个人客户关系信息之外的
--and client.category_type not in ('601', '301') --剔除内部户，人民银行    
--and doc.document_id <> '91320200MA218DRH1T' ----剔除我行的识别码
union all 
--核心2
select /*+repartition(1)*/
     nvl(con.client_no,'')                                                           as cust_id  --客户号
    ,nvl(client.ch_client_name,'')                                                   as cust_name  --客户名称
    ,nvl(con.people_type,'')                                                         as rela_type  --关系类型
    ,nvl(doc.client_no,'')                                                           as rela_cust_id  --关系人客户编号
    ,nvl(con.custname,'')                                                            as rela_cust_nm  --关系人客户名称
    ,nvl(cdt.document_type,'')                                                       as rela_cert_type  --关系人证件类型
    ,nvl(con.document_id,'')                                                         as rela_cert_no  --关系人证件号码
    ,'1'                                                                             as rela_status  --关系状态   1 有效  0 无效
    ,''                                                                              as invest_ccy  --出资币种
    ,''                                                                              as invest_amt  --实际出资额
    ,''                                                                              as invest_ratio  --投资比例
    ,''                                                                              as hold_stock  --持股情况
    ,''                                                                              as invest_date  --投资日期
    ,''                                                                              as rela_update_date  --维护日期
    ,nvl(from_unixtime(unix_timestamp(con.iss_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as cert_start_date  --证件起始日期
    ,nvl(from_unixtime(unix_timestamp(con.expiry_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as cert_mature_date  --证件到期日期
    ,case when con.people_type = '100' then '关联人100-法人或负责人'                 
          when con.people_type = '101' then '关联人101-实际控股股东'                 
          when con.people_type = '102' then '关联人102-控股股东'                     
          when con.people_type = '103' then '关联人103-财务人员'                     
          when con.people_type = '104' then '关联人104-经办人员'                     
          when con.people_type = '105' then '关联人105-其他人员'                     
          else '' end                                                                as rela_type_desc  --关系类型  
    ,nvl(cdt.document_type_desc,'')                                                  as rela_cert_type_desc  --关系人证件类型
    ,'2'                                                                             as source_system
	,nvl(con.contact_tel,'')														 as tel_no 	--手机号码  --updata20231121 pengqun新增字段
	,''																				 as create_date --创建日期 （目前没有创建时间） --updata20231121 pengqun新增字段
from odata.sym_cif_client_contacts_info con
left join odata.sym_cif_client client
on con.client_no = client.client_no
and client.data_date = '${DATA_DATE}'
and client.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client_document doc 
on con.document_type = doc.document_type
and con.document_id = doc.document_id
and doc.data_date = '${DATA_DATE}'
and doc.bddw_end_date = '9999-99-99'
left join odata.sym_cif_document_type cdt --客户证件类别
on con.document_type = cdt.document_type
and cdt.data_date = '${DATA_DATE}'
and cdt.bddw_end_date = '9999-99-99'
where con.data_date = '${DATA_DATE}'
and con.bddw_end_date = '9999-99-99'
--and con.client_no <> '80000001' --剔除该客户 总账户
--and scd.document_id <> '91320200MA218DRH1T' ----剔除我行的识别码
--and client.category_type not in ('601', '301') --剔除内部户，人民银行
union all 
--供应链1
select /*+repartition(1)*/
     nvl(agi.keymembercustomerid,'')                                                 as cust_id  --客户号
    ,nvl(agi.groupname,'')                                                           as cust_name  --客户名称
    ,''                                                                              as rela_type  --关系类型
    ,nvl(agmi.membercustomerid,'')                                                   as rela_cust_id  --关系人客户编号
    ,nvl(scc.ch_client_name,'')                                                      as rela_cust_nm  --关系人客户名称
    ,nvl(cdt.document_type,'')                                                       as rela_cert_type  --关系人证件类型
    ,nvl(doc.document_id,'')                                                         as rela_cert_no  --关系人证件号码
    ,'1'                                                                             as rela_status  --关系状态   1 有效  0 无效
    ,nvl(acr.currencytype,'')                                                        as invest_ccy  --出资币种
    ,nvl(acr.investmentsum,'')                                                       as invest_amt  --实际出资额
    ,nvl(acr.investmentprop,'')                                                      as invest_ratio  --投资比例
    ,nvl(acr.holdstock,'')                                                           as hold_stock  --持股情况
    ,nvl(regexp_replace(acr.investdate,'/','-'),'')                                  as invest_date  --投资日期
    ,nvl(regexp_replace(acr.updatedate,'/','-'),'')                                  as rela_update_date  --维护日期
    ,nvl(regexp_replace(acc.inputdate,'/','-'),'')                                   as cert_start_date  --证件起始日期
    ,nvl(regexp_replace(acc.idexpiry,'/','-'),'')                                    as cert_mature_date  --证件到期日期
    ,'供应链上下游、担保关系'                                                        as rela_type_desc  --关系类型
    ,nvl(cdt.document_type_desc,'')                                                  as rela_cert_type_desc  --关系人证件类型
    ,'3'                                                                             as source_system
	,nvl(acr.telephone,'')                                                           as tel_no 	--手机号码  --updata20231121 pengqun新增字段
	,case 
	  when length(acr.inputdate) = 8
		then concat(substring(acr.inputdate,1,4),'-',substring(acr.inputdate,5,2),'-',substring(acr.inputdate,7,2))
	  when length(acr.inputdate) = 10
		then concat(substring(acr.inputdate,1,4),'-',substring(acr.inputdate,6,2),'-',substring(acr.inputdate,9,2)) 
	else ''
    end        															             as create_date --创建日期(该日期可能不准，数据每次同步核心后会被覆盖掉) --updata20231121 pengqun新增字段
from odata.als_group_info agi
left join odata.als_group_member_relative agmi 
on agi.groupid = agmi.groupid
and agmi.data_date = '${DATA_DATE}'
and agmi.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client scc 
on agmi.membercustomerid = scc.client_no 
and scc.data_date = '${DATA_DATE}'
and scc.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client_document doc 
on agmi.membercustomerid = doc.client_no
and doc.data_date = '${DATA_DATE}'
and doc.bddw_end_date = '9999-99-99'
left join odata.sym_cif_document_type cdt --客户证件类别
on doc.document_type = cdt.document_type
and cdt.data_date = '${DATA_DATE}'
and cdt.bddw_end_date = '9999-99-99'
left join odata.als_customer_relative acr 
on agmi.membercustomerid=acr.relativeid
and acr.data_date = '${DATA_DATE}'
and acr.bddw_end_date = '9999-99-99'
and acr.relationship like '52%'
and nvl(acr.operatetype,'')<>'03' --删除
and acr.effstatus = '1' --有效
left join odata.als_customer_cert acc--客户证件信息
on agmi.membercustomerid =acc.customerid
and acc.data_date = '${DATA_DATE}'
and acc.bddw_end_date = '9999-99-99'
where agi.data_date = '${DATA_DATE}'
and agi.bddw_end_date = '9999-99-99'    
and agi.status = '10'
and agi.keymembercustomerid<>agmi.membercustomerid  --新增
--and  (scc.ch_client_name not  like '%金城%' or   agi.groupname  not like  '%金城%' )
union all 
--供应链2
select /*+repartition(1)*/
     nvl(agmi.membercustomerid,'')                                                   as cust_id  --客户号
    ,nvl(scc.ch_client_name,'')                                                      as cust_name  --客户名称
    ,''                                                                              as rela_type  --关系类型
    ,nvl(agi.keymembercustomerid,'')                                                 as rela_cust_id  --关系人客户编号
    ,nvl(agi.groupname,'')                                                           as rela_cust_nm  --关系人客户名称
    ,nvl(cdt.document_type,'')                                                       as rela_cert_type  --关系人证件类型
    ,nvl(doc.document_id,'')                                                         as rela_cert_no  --关系人证件号码
    ,'1'                                                                             as rela_status  --关系状态    1 有效  0 无效
    ,nvl(acr.currencytype,'')                                                        as invest_ccy  --出资币种
    ,nvl(acr.investmentsum,'')                                                       as invest_amt  --实际出资额
    ,nvl(acr.investmentprop,'')                                                      as invest_ratio  --投资比例
    ,nvl(acr.holdstock,'')                                                           as hold_stock  --持股情况    
    ,nvl(regexp_replace(acr.investdate,'/','-'),'')                                  as invest_date  --投资日期
    ,nvl(regexp_replace(acr.updatedate,'/','-'),'')                                  as rela_update_date  --维护日期
    ,nvl(regexp_replace(acc.inputdate,'/','-'),'')                                   as cert_start_date  --证件起始日期
    ,nvl(regexp_replace(acc.idexpiry,'/','-'),'')                                    as cert_mature_date  --证件到期日期
    ,'供应链上下游、担保关系'                                                        as rela_type_desc  --关系类型
    ,nvl(cdt.document_type_desc,'')                                                  as rela_cert_type_desc  --关系人证件类型
    ,'4'                                                                             as source_system
	,nvl(acr.telephone,'')                                                           as tel_no 	--手机号码  --updata20231121 pengqun新增字段
	,case 
	  when length(acr.inputdate) = 8
		then concat(substring(acr.inputdate,1,4),'-',substring(acr.inputdate,5,2),'-',substring(acr.inputdate,7,2))
	  when length(acr.inputdate) = 10
		then concat(substring(acr.inputdate,1,4),'-',substring(acr.inputdate,6,2),'-',substring(acr.inputdate,9,2)) 
	else ''
    end        															             as create_date --创建日期(该日期可能不准，数据每次同步核心后会被覆盖掉) --updata20231121 pengqun新增字段
from odata.als_group_info agi 
inner join odata.als_group_member_relative agmi 
on agi.groupid = agmi.groupid
and agmi.data_date = '${DATA_DATE}'
and agmi.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client scc 
on agmi.membercustomerid = scc.client_no 
and scc.data_date = '${DATA_DATE}'
and scc.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client_document doc 
on agi.keymembercustomerid = doc.client_no
and doc.data_date = '${DATA_DATE}'
and doc.bddw_end_date = '9999-99-99'
left join odata.sym_cif_document_type cdt --客户证件类别
on doc.document_type = cdt.document_type
and cdt.data_date = '${DATA_DATE}'
and cdt.bddw_end_date = '9999-99-99'
left join odata.als_customer_relative acr 
on agmi.membercustomerid=acr.relativeid
and acr.data_date = '${DATA_DATE}'
and acr.bddw_end_date = '9999-99-99'
and acr.relationship like '52%'
and nvl(acr.operatetype,'')<>'03' --删除
and acr.effstatus = '1' --有效
left join odata.als_customer_cert acc--客户证件信息
on agmi.membercustomerid =acc.customerid
and acc.data_date = '${DATA_DATE}'
and acc.bddw_end_date = '9999-99-99'
where agi.data_date = '${DATA_DATE}'
and agi.bddw_end_date = '9999-99-99'
and agi.status = '10'
and agi.keymembercustomerid<>agmi.membercustomerid  --新增
--and  (scc.ch_client_name not  like '%金城%' or   agi.groupname  not like  '%金城%' )
union all
select /*+repartition(1)*/
     nvl(acr.customerid,'')                                                          as cust_id  --客户号
    ,nvl(scc.ch_client_name,'')                                                      as cust_name  --客户名称
    ,case when acl.itemno = '0100' then '100' 
          when acl.itemno = '0102' then '102' 
          when acl.itemno = '0103' then '103' 
          when acl.itemno = '0104' then '104' 
          when acl.itemno = '0109' then '101' 
          when acl.itemno = '0199' then '105' 
          else nvl(acl.itemno,'') end                                                as rela_type  --关系类型
    ,nvl(scc1.client_no,'')                                                          as rela_cust_id  --关系人客户编号
    ,nvl(acr.customername,'')                                                        as rela_cust_nm  --关系人客户名称
    ,nvl(acl1.coreitemno,'')                                                         as rela_cert_type  --关系人证件类型
    ,nvl(acr.certid,'')                                                              as rela_cert_no  --关系人证件号码
    ,'1'                                                                             as rela_status  --关系状态     1 有效  0 无效
    ,nvl(acr.currencytype,'')                                                        as invest_ccy  --出资币种
    ,nvl(acr.investmentsum,'')                                                       as invest_amt  --实际出资额
    ,nvl(acr.investmentprop,'')                                                      as invest_ratio  --投资比例
    ,nvl(acr.holdstock,'')                                                           as hold_stock  --持股情况    
    ,nvl(regexp_replace(acr.investdate,'/','-'),'')                                  as invest_date  --投资日期
    ,nvl(regexp_replace(acr.updatedate,'/','-'),'')                                  as rela_update_date  --维护日期
    ,nvl(regexp_replace(acc.inputdate,'/','-'),'')                                   as cert_start_date  --证件起始日期
    ,nvl(regexp_replace(acc.idexpiry,'/','-'),'')                                    as cert_mature_date  --证件到期日期
    ,case when acl.itemno = '0100' then '关联人100-法人或负责人'                 
          when acl.itemno = '0109' then '关联人101-实际控股股东'                 
          when acl.itemno = '0102' then '关联人102-控股股东'                     
          when acl.itemno = '0103' then '关联人103-财务人员'                     
          when acl.itemno = '0104' then '关联人104-经办人员'                     
          when acl.itemno = '0199' then '关联人105-其他人员'                     
          else nvl(acl.itemname,'') end                                              as rela_type_desc  --关系类型
    ,nvl(cdt.document_type_desc,nvl(acl1.itemname,''))                               as rela_cert_type_desc  --关系人证件类型
    ,'5'                                                                             as source_system
	,nvl(acr.telephone,'')                                                           as tel_no 	--手机号码  --updata20231121 pengqun新增字段
	,case 
	  when length(acr.inputdate) = 8
		then concat(substring(acr.inputdate,1,4),'-',substring(acr.inputdate,5,2),'-',substring(acr.inputdate,7,2))
	  when length(acr.inputdate) = 10
		then concat(substring(acr.inputdate,1,4),'-',substring(acr.inputdate,6,2),'-',substring(acr.inputdate,9,2)) 
	else ''
    end        														                 as create_date --创建日期(该日期可能不准，数据每次同步核心后会被覆盖掉) --updata20231121 pengqun新增字段
from odata.als_customer_relative acr 
left join odata.sym_cif_client scc 
on acr.customerid = scc.client_no 
and scc.data_date = '${DATA_DATE}'
and scc.bddw_end_date = '9999-99-99'
left join odata.sym_cif_client scc1 
on acr.relativeid = scc1.client_no 
and scc1.data_date = '${DATA_DATE}'
and scc1.bddw_end_date = '9999-99-99'
left join odata.als_code_library acl1 
on acr.certtype = acl1.itemno
and acl1.data_date = '${DATA_DATE}'
and acl1.bddw_end_date = '9999-99-99'
and acl1.codeno = 'CertType'
and acl1.isinuse = '1'  --有效
left join odata.als_customer_cert acc--客户证件信息
on acr.relativeid =acc.customerid
and acc.data_date = '${DATA_DATE}'
and acc.bddw_end_date = '9999-99-99'
left join odata.als_code_library acl 
on acr.relationship = acl.itemno
and acl.data_date = '${DATA_DATE}'
and acl.bddw_end_date = '9999-99-99'
and acl.codeno = 'RelationShip'
and acl.isinuse = '1'  --有效
left join odata.sym_cif_document_type cdt --客户证件类别
on trim(acl1.coreitemno) = cdt.document_type
and cdt.data_date = '${DATA_DATE}'
and cdt.bddw_end_date = '9999-99-99'
where acr.data_date = '${DATA_DATE}'
and acr.bddw_end_date = '9999-99-99' 
and acr.effstatus = '1' --有效
and nvl(acr.operatetype,'')<>'03' --删除
--and substr(acr.customerid,1,2) <>'LS' --临时客户不需要进行报送
--and (scc.ch_client_name not  like '%金城%' or acr.customername not like '%金城%' )