---------------------------------------------------------------------------------------------------------------
--脚本名称：同业客户信息加工.sql
--功能描述：生成每日结果数据并插入hive gdata层dwd.dwd_c_inter_cust_info_p
--作    者：吴龙昊
--开发日期：2021-02-08
--直属经理：程宏明
--来源表  ：odata.sym_cif_client                  客户信息表                
--来源表  ：odata.sym_cif_client_document         客户证件信息
--来源表  ：odata.sym_cif_client_corp             法人客户附加信息表
--来源表  ：odata.sym_cif_client_contact_address  客户联系地址
--来源表  ：gdata.ads_g_related_p                 关联方信息表
--目标表  ：dwd.dwd_c_inter_cust_info_p         同业客户基础信息表
--修改历史：
--          1.吴龙昊   2021-02-08    新建

---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_c_inter_cust_info_p partition(data_date='${DATA_DATE}')
 select
 t1.client_no                                   as cust_id            --客户号      
,t1.ch_client_name                              as cust_name          --客户名称     
,t1.category_type                               as cust_subdiv_cate   --客户细分类    
,t2.document_id                                 as unif_soc_crdt      --统一社会信用代码 
,t3.document_id                                 as fin_org_code       --金融机构代码   
,t4.basic_acct_no                               as basic_acct_no      --基本存款账号   
,t4.basic_acct_openat                           as basic_acct_openat  --基本账户开户行名称
,t5.address                                     as regist_addr        --注册地址     
,t2.dist_code                                   as area_code          --地区代码     
,t4.incor_date                                  as incor_date         --成立日期     
,case when t6.cert_no is not null then 'Y'                            
      else 'N' end                              as rela_cust_flag     --是否我行关联方
,t4.sponsor_fin                                 as fin_component      --经济成分   
,t4.natiomal_economy                            as nat_econ_depar     --国民经济部门 
,t4.corp_size                                   as corp_scale         --企业规模   
,t4.auth_capital                                as regist_captial     --注册资本   
,t4.emp_num                                     as empy_num           --员工数    
,t4.business_scope                              as opra_scope         --经营范围   
,null                                           as crdt_total_lvl     --信用总等级  
,null                                           as crdt_rating        --信用评级   
,null                                           as remark1            --备用字段1  
,null                                           as remark2            --备用字段2  
,null                                           as remark3            --备用字段3  
,null                                           as remark4            --备用字段4  
,null                                           as remark5            --备用字段5  
from odata.sym_cif_client t1
 left join odata.sym_cif_client_document t2
        on t1.client_no = t2.client_no
       and t2.document_type = '231'    --231为统一社会信用代码
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date='9999-99-99'
 left join odata.sym_cif_client_document t3
        on t1.client_no = t3.client_no
       and t3.document_type = '260'   --260时为同业金融机构代码
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date='9999-99-99'
 left join odata.sym_cif_client_corp t4
        on t1.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date='9999-99-99'
 left join odata.sym_cif_client_contact_address t5
        on t1.client_no = t5.client_no
       and t5.contact_type = '02'
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date='9999-99-99'
 left join gdata.ads_g_related_p t6
        on t2.document_id = t6.cert_no
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
       and t1.client_type = '03'