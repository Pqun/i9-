---------------------------------------------------------------------------------------------------------------
--脚本名称：dwd_f_gl_p.sql
--功能描述：总账科目余额
--作    者：于国睿
--开发日期：2022-08-12
--直属经理：方杰
--来源表:
--1.odata.gl_v_gl_balance
--2.odata.gl_v_gl_subject
--目标表：ads.acct_files_i9subjbal
--修改历史：
--          1.于国睿   2022-08-12    新建
--          2.于国睿   2022-11-12    新增gl_data_date字段
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_f_gl_p partition (data_date = '${DATA_DATE}') 
    select /*+ REPARTITION(1) */
            nvl(t1.gl_code,'')                     as subj_no                   --科目代码   
           ,nvl(t2.gl_code_name,'')                as subj_name                 --科目名称                   
           ,nvl(t1.branch,'')                      as org_id                    --机构代码           
           ,nvl(t1.ccy,'')                         as ccy                       --币种             
           ,nvl(t1.dr_cr_ind,'')                   as dr_cr_ind                 --借贷方向           
           ,nvl(t1.dr_beg_bal_ori,0)               as dr_beg_bal_ori            --借方期初余额（原币）     
           ,nvl(t1.cr_beg_bal_ori,0)               as cr_beg_bal_ori            --贷方期初余额（原币）     
           ,nvl(t1.dr_trx_amt_ori,0)               as dr_amt_ori                --借方本期发生额（原币）    
           ,nvl(t1.cr_trx_amt_ori,0)               as cr_amt_ori                --贷方本期发生额（原币）    
           ,nvl(t1.dr_end_bal_ori,0)               as dr_cur_bal                --借方期末余额（原币）     
           ,nvl(t1.cr_end_bal_ori,0)               as cr_cur_bal                --贷方期末余额（原币）     
           ,nvl(t1.pd_dr_trx_amt_ori,0)            as m_dr_amt_ori              --本月借方发生额累计（原币）  
           ,nvl(t1.pd_cr_trx_amt_ori,0)            as m_cr_amt_ori              --本月贷方发生额累计（原币）  
           ,nvl(t1.qtr_dr_trx_amt_ori,0)           as q_dr_amt_ori              --本季借方发生额累计（原币）  
           ,nvl(t1.qtr_cr_trx_amt_ori,0)           as q_cr_amt_ori              --本季贷方发生额累计（原币）  
           ,nvl(t1.hy_dr_trx_amt_ori,0)            as hy_dr_amt_ori             --半年借方发生额累计（原币）  
           ,nvl(t1.hy_cr_trx_amt_ori,0)            as hy_cr_amt_ori             --半年贷方发生额累计（原币）  
           ,nvl(t1.yr_dr_trx_amt_ori,0)            as y_dr_amt_ori              --本年借方发生额累计（原币）  
           ,nvl(t1.yr_cr_trx_amt_ori,0)            as y_cr_amt_ori              --本年贷方发生额累计（原币）  
           ,nvl(t1.ytd_dr_end_bal_ori,0)           as y_dr_end_bal_ori          --本年借方期末余额累计（原币） 
           ,nvl(t1.ytd_cr_end_bal_ori,0)           as y_cr_end_bal_ori          --本年贷方期末余额累计（原币） 
           ,nvl(t1.dr_beg_bal,0)                   as dr_beg_bal                --借方期初余额（本外币）    
           ,nvl(t1.cr_beg_bal,0)                   as cr_beg_bal                --贷方期初余额（本外币）    
           ,nvl(t1.dr_trx_amt,0)                   as dr_amt                    --借方本期发生额（本外币）   
           ,nvl(t1.cr_trx_amt,0)                   as cr_amt                    --贷方本期发生额（本外币）   
           ,nvl(t1.dr_end_bal,0)                   as dr_end_bal                --借方期末余额（本外币）    
           ,nvl(t1.cr_end_bal,0)                   as cr_end_bal                --贷方期末余额（本外币）    
           ,nvl(t1.pd_dr_trx_amt,0)                as m_dr_amt                  --本月借方发生额累计（本外币） 
           ,nvl(t1.pd_cr_trx_amt,0)                as m_cr_amt                  --本月贷方发生额累计（本外币） 
           ,nvl(t1.qtr_dr_trx_amt,0)               as q_dr_amt                  --本季借方发生额累计（本外币） 
           ,nvl(t1.qtr_cr_trx_amt,0)               as q_cr_amt                  --本季贷方发生额累计（本外币） 
           ,nvl(t1.hy_dr_trx_amt,0)                as hy_dr_amt                 --半年借方发生额累计（本外币） 
           ,nvl(t1.hy_cr_trx_amt,0)                as hy_cr_amt                 --半年贷方发生额累计（本外币） 
           ,nvl(t1.yr_dr_trx_amt,0)                as y_dr_amt                  --本年借方发生额累计（本外币） 
           ,nvl(t1.yr_cr_trx_amt,0)                as y_cr_amt                  --本年贷方发生额累计（本外币） 
           ,nvl(t1.ytd_dr_end_bal,0)               as y_dr_end_bal              --本年借方期末余额累计（本外币）
           ,nvl(t1.ytd_cr_end_bal,0)               as y_cr_end_bal              --本年贷方期末余额累计（本外币）
           ,nvl(t1.mtd_dr_end_bal_ori,0)           as m_dr_end_bal_ori          --本月借方期末余额累计（原币） 
           ,nvl(t1.mtd_cr_end_bal_ori,0)           as m_cr_end_bal_ori          --本月贷方期末余额累计（原币） 
           ,nvl(t1.mtd_dr_end_bal,0)               as m_dr_end_bal              --本月借方期末余额累计（本外币）
           ,nvl(t1.mtd_cr_end_bal,0)               as m_cr_end_bal              --本月贷方期末余额累计（本外币）
		   ,nvl(t1.gl_data_date,'')                   as gl_data_date
       from odata.gl_v_gl_balance t1
       left join odata.gl_v_gl_subject t2
         on t1.gl_code = t2.gl_code
        and t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
      where t1.data_date='${DATA_DATE}'
        and t1.bddw_end_date='9999-99-99'
        --and length(t1.gl_code)=8
        and t1.endflag='N'