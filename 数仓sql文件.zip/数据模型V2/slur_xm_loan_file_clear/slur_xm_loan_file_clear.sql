--1.yh.slur核算xm clear表(首批)
with temp1 as (
select 
      t1.*,t2.first_tran_date as first_tran_date
     from (
     select row_number() over (partition by loan_id order by cur_date desc) as row_num,* 
    from odata.slur_xm_loan_file   
	where data_date='${DATA_DATE}' and bddw_end_date='9999-99-99' 
	)t1 
	left join
	(
	 select
     loan_id,min(tran_date) as first_tran_date
    from odata.slur_xm_loan_file
    where data_date='${DATA_DATE}' and bddw_end_date='9999-99-99' group by loan_id
    )t2 on t1.loan_id=t2.loan_id
	where t1.row_num=1
),temp2 as (
select 
      *
     from odata.slur_xm_loan_file_clear 
     where data_date=date_add('${DATA_DATE}',-1)
)
insert overwrite table odata.slur_xm_loan_file_clear partition(data_date='${DATA_DATE}',database_name='slur')
select 
   xm_seq_no
  ,batch_no
  ,prod_class
  ,tran_date
  ,channel_date
  ,cur_date
  ,loan_id
  ,apply_date
  ,start_date
  ,end_date
  ,clear_date
  ,encash_amt
  ,currency
  ,repay_mode
  ,repay_cycle
  ,total_terms
  ,cur_term
  ,repay_day
  ,grace_day
  ,prin_total
  ,prin_repay
  ,prin_bal
  ,ovd_prin_bal
  ,int_total
  ,int_repay
  ,int_bal
  ,ovd_int_bal
  ,pnlt_int_total
  ,pnlt_int_repay
  ,pnlt_int_bal
  ,int_pnlt_total
  ,int_pnlt_repay
  ,int_pnlt_bal
  ,int_today
  ,pre_pmt_fee_repay
  ,loan_status
  ,loan_form
  ,days_ovd
  ,add_event
  ,interesttransferstatus
  ,tran_status
  ,tran_time
  ,tran_timestamp
  ,router_key
  ,bak1
  ,bak2
  ,bak3
  ,bak4
  ,bak5
  ,bak6
  ,bak7
  ,bak8
  ,bak9
  ,bak10
  ,'${DATA_DATE}'    as bddw_start_date
  ,'9999-99-99'    as bddw_end_date        
  ,first_tran_date
 from temp1 
union all
select 
   t2.xm_seq_no
  ,t2.batch_no
  ,t2.prod_class
  ,t2.tran_date
  ,t2.channel_date
  ,t2.cur_date
  ,t2.loan_id
  ,t2.apply_date
  ,t2.start_date
  ,t2.end_date
  ,t2.clear_date
  ,t2.encash_amt
  ,t2.currency
  ,t2.repay_mode
  ,t2.repay_cycle
  ,t2.total_terms
  ,t2.cur_term
  ,t2.repay_day
  ,t2.grace_day
  ,t2.prin_total
  ,t2.prin_repay
  ,t2.prin_bal
  ,t2.ovd_prin_bal
  ,t2.int_total
  ,t2.int_repay
  ,t2.int_bal
  ,t2.ovd_int_bal
  ,t2.pnlt_int_total
  ,t2.pnlt_int_repay
  ,t2.pnlt_int_bal
  ,t2.int_pnlt_total
  ,t2.int_pnlt_repay
  ,t2.int_pnlt_bal
  ,t2.int_today
  ,t2.pre_pmt_fee_repay
  ,t2.loan_status
  ,t2.loan_form
  ,t2.days_ovd
  ,t2.add_event
  ,t2.interesttransferstatus
  ,t2.tran_status
  ,t2.tran_time
  ,t2.tran_timestamp
  ,t2.router_key
  ,t2.bak1
  ,t2.bak2
  ,t2.bak3
  ,t2.bak4
  ,t2.bak5
  ,t2.bak6
  ,t2.bak7
  ,t2.bak8
  ,t2.bak9
  ,t2.bak10
  ,'${DATA_DATE}'    as bddw_start_date
  ,'9999-99-99'    as bddw_end_date    
  ,t2.first_tran_date
  from temp2 t2 left join temp1 t1  on t2.loan_id=t1.loan_id 
where t1.loan_id is  null