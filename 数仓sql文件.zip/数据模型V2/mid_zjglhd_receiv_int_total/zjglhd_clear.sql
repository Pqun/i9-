with tmp as (
select 
  nvl(yjlx.loan_id,'') as loan_id,
  nvl(yjlx.rec_amt,0)  as rec_amt
from dwd.mid_zjglhd_recv_int_scene_tran yjlx
where yjlx.data_date = date_add('${DATA_DATE}',-1)
  and yjlx.source_id = '110142'
  and yjlx.rec_amt <> 0
  
union all 

select
  nvl(yjlx.loan_id,'') as loan_id,
  nvl(yjlx.rec_amt,0)  as rec_amt
from dwd.mid_zjglhd_recv_int_scene_tran yjlx
where yjlx.data_date = '${DATA_DATE}'
  and yjlx.source_id = '110142'
  and yjlx.rec_amt <> 0
)

insert overwrite table dwd.mid_zjglhd_recv_int_scene_tran partition(data_date='${DATA_DATE}', source_id = '110142')
select /*+ REPARTITION(1) */
  tmp.loan_id,
  '',
  sum(tmp.rec_amt),
  '',
  ''
from tmp 
group by tmp.loan_id 