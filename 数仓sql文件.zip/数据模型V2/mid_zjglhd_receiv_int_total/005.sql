--005场景
insert overwrite table dwd.mid_zjglhd_recv_int_scene_tran partition (data_date = '${DATA_DATE}', source_id = '110142')
select /*+ REPARTITION(1) */
   a.loan_id
  ,'${DATA_DATE}'
  ,sum(nvl(accrued_int,0)) as amt
  ,'005'
  ,''
from odata.slur_bdul_loan_file a
where a.data_date = date_add(current_date(),-1)
  and a.bddw_end_date = '9999-99-99'
  and a.loan_mode = '01'
  and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and a.cur_ovd_days <= 90
group by a.loan_id