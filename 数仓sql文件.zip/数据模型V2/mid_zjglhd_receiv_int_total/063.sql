--短期贷款逾期利息（表内）转逾期利息（表外）
insert into dwd.mid_zjglhd_recv_int_scene_tran partition (data_date = '${DATA_DATE}', source_id = '110142')
select /*+ REPARTITION(1) */
       a.loan_id
       ,'${DATA_DATE}'
       ,-sum(nvl(c.int_bal,0))                    as amt
	   ,'063'
	   ,''
  from odata.slur_bdul_loan_file_clear           a            --百度联合贷借据文件表
  inner join odata.slur_bdul_loan_file_clear      b            --百度联合贷借据文件表
    on  b.loan_id = a.loan_id
    and b.data_date=date_add('${DATA_DATE}',-1)
    and b.bddw_end_date='9999-99-99'
    and b.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
    and b.cur_ovd_days <= 90                                  --当前逾期天数（表内） 
    and b.loan_mode = '01'                                    --放款渠道 01我行，02张家港，03我行出资100%
  inner join odata.slur_bdul_repayplan_file_clear c            --百度联合贷还款计划表
    on c.loan_id = a.loan_id
    and c.data_date='${DATA_DATE}'
    and c.bddw_end_date='9999-99-99'
    and c.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')  
    and c.term_status = '2'                                   --本期状态,1：正常 2：逾期 3：已冲正 4：已撤销 5：已结清
    and c.loan_mode = '01'
  inner join odata.slur_bdul_repayplan_file_clear d             --百度联合贷借据文件表
    on d.loan_id = a.loan_id
    and d.data_date=date_add('${DATA_DATE}',-1)
    and d.bddw_end_date='9999-99-99'
    and d.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
    and d.term_status = '2'
    and d.loan_mode = '01'
    and d.term_no = c.term_no                                 --还款期数
 where a.data_date='${DATA_DATE}'
    and a.bddw_end_date='9999-99-99'
    and a.loan_mode = '01'
    and a.cur_ovd_days > 90                                   --当前逾期天数（表外） 
    and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
	group by a.loan_id