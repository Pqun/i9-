--085 短期贷款减免正常利息（表内）（自动）
insert into dwd.mid_zjglhd_recv_int_scene_tran partition (data_date = '${DATA_DATE}', source_id = '110142')
select /*+ REPARTITION(1) */
      a.loan_id
     ,'${DATA_DATE}'
     ,-sum(b.int_reduced_amt_coupon) as amt
     ,'085'
     ,''
from odata.slur_bdul_loan_file a
inner join odata.slur_bdul_repay_item_file b
   on a.loan_id = b.loan_id
  and b.data_date = date_add(current_date(),-1)
  and b.bddw_end_date = '9999-99-99'
  and b.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and b.event != '11'
  and b.int_reduced_amt_coupon <> 0
  and b.loan_mode = '01'
where a.data_date = date_add(current_date(),-1)
  and a.bddw_end_date = '9999-99-99'
  and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and a.cur_ovd_days <= 90
  and a.loan_mode = '01'
group by a.loan_id
