--117 短期贷款减免正常利息（表内）（手动）
insert into dwd.mid_zjglhd_recv_int_scene_tran partition (data_date = '${DATA_DATE}', source_id = '110142')
select /*+ REPARTITION(1) */
     a.loan_id
    ,'${DATA_DATE}'
    ,-sum(c.int_reduced_amt_manual) as amt
    ,'117'
    ,''
from odata.slur_bdul_loan_file a
inner join odata.slur_bdul_repay_item_file b
   on a.loan_id = b.loan_id
  and b.data_date = date_add(current_date(),-1)
  and b.bddw_end_date = '9999-99-99'
  and b.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and b.loan_mode = '01'
  and b.event != '11'
inner join odata.slur_bdul_reduce_file c
   on b.loan_id = c.loan_id
  and b.term_no = c.term_no
  and c.data_date = date_add(current_date(),-1)
  and c.bddw_end_date = '9999-99-99'
  and c.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and c.loan_mode = '01'
  and c.int_reduced_amt_manual > 0
where a.data_date = date_add(current_date(),-1)
  and a.bddw_end_date = '9999-99-99'
  and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and a.cur_ovd_days <= 90
  and a.loan_mode = '01'
group by a.loan_id