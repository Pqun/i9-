--2.dq.dwd_d_guar_cont_p
-------------------------------------------------------------------
--脚本名称:dwd_d_guar_cont_p
--功能描述:担保合同信息表
--作    者:邓权
--开发日期:2022-08-21
--直属经理:方杰
--目标表  :dwd.dwd_d_guar_cont_p                      担保物信息表
--数据原表: odata.pawn_pawn_base                      押品主表
--         odata.pawn_pawn_car                        车辆抵押品信息表
--         odata.order_main_loan_order                订单主表
--         odata.order_product_loan_info              产品贷款信息
--         odata.sllv_nl_acct                         线上贷款客户信息表
--         odata.order_contract_sign                  合同签署表
--         odata.order_custom_info                    客户信息表
--         odata.pawn_pawn_house                      房贷抵押品表
--         odata.order_loan_order_house               房抵贷订单表
--         odata.sllv_mb_acct                         账户基本信息表
--         odata.pawn_house_evaluate                  房屋估价信息表
--         odata.order_credit_order_info              授信信息表
--         odata.order_loan_order_car_dealer          车主贷贷款信息表
--         odata.pawn_pawn_machine                    机器抵押品信息表
--         odata.order_coborrower_info                共借人信息表
--         odata.sym_cif_client                       客户信息表
--         odata.sym_cif_client_document              客户证件信息
--         odata.als_guaranty_contract                担保合同信息表 
--         odata.als_cl_occupy                        额度占用关系表
--         odata.als_contract_relative                合同关联表
--         odata.als_business_contract                业务合同信息表
--         odata.als_business_duebill                 业务借据(账户)信息表
--         odata.als_ent_info                         企业基本信息
--         odata.als_customer_address                 客户联系地址信息表
--         odata.als_customer_cert                    客户证件信息表
--         odata.uquam_ps_product_limit_change        个人产品总额度变更表
--         odata.order_guarantee_company_info         担保企业信息表  
--         odata.xscontract_business_contract_records 业务合同记录表
--修改历史:
--         1、邓权     20220821     新建
--         2、邓权     20230110     新增锡惠贷、变更信贷部分产品号逻辑、变更信贷部分被担保合同取数源
--         3、邓权     20230207     修改信贷部分担保合同金额、担保方式取数逻辑
--         4、邓权     20230323     新增抵质押率字段
--         5、邓权     20230627     调整锡惠贷、锡机贷、车商贷、车主贷、铁甲、孚厘、锡惠贷担保合同号/被担保合同号/担保人名称/担保人证件号/被担保人名称/被担保人证件号逻辑
--         6、邓权     20230704     1、调整担保合同信息表锡惠贷部分范围：增加企业法人代表签署的担保合同；2、调整担保合同信息表锡惠贷，调整担保人及担保合同对应关系，一一对应
--         7、高源     20230803     1、新增希望贷上牌车、希望贷非上牌车、锡惠贷个人产品逻辑
--                                  2、锡惠贷对公、锡惠贷个人贷款产品，新增最高额保证合同（企业）类型逻辑
--                                  3、锡机贷-上牌车新增担保公司担保合同类型逻辑            
--                                  4、车商贷新增最高额保证合同个人担保类型逻辑
--                                  5、订单中心产品担保合同金额、开始日期、结束日期调整为额度中心逻辑      
--                                  6、个金产品的担保人证件代码类型、被担保人证件代码，企业社会信用代码码值由'B01'调整为'231'（信贷系统码值保持不变）    
----       8、高源     20230824     担保公司担保协议(合同类型为4)，担保人信息逻辑由合同签署人调整取为担保公司
--         9、高源     20230830     1、担保合同状态码值调整
--                                  2、新增经办人工号字段
--         10、高源    20230920     个金系统担保合同担保方式调整方式
--         11、高源    20230927     新增锡望贷-京东担保合同  
--         12、杨琦浩  20231108     新增签约日期字段
--         13、高源    20231122     锡惠贷关联额度中心逻辑优化
--         14、彭群    20231215     新增合同签署状态字段
--         15、高源    20240112     孚厘产品新增迁移后逻辑，新增vivo产品担保合同
--         16、高源    20240129     1、新增锡锡贷-洋钱罐产品担保合同
--                                  2、vivo、锡望贷京东产品原始逻辑关联逻辑担保合同与贷款合同重复关联，优化为一对一
--         17、姚威    20240312     调整逻辑:补充之前遗漏的担保信息;信贷产品剔除授信数据,只保留用信数据
--         18、高源    20240320     新增锡享贷-找钢(企业)、锡享贷-厚沃（个人）、锡享贷-厚沃（企业）产品担保合同 
--         19、高源    20240330     调整最高额保证合同担保人名称、担保人证件类型、担保人证件号码、被担保人姓名、被担保人证件类型、本担保人证件号、担保方式代码、剔除重复关联的订单主表  
--         19、刘丽红  20240402     新增数据来源字段
--         20、高源    20240514     1、新增孚厘企业贷产品担保合同
--                                  2、担保人证件类别、被担保人证件类型统一为核心码值
------------------------------------------------------------------
insert overwrite table dwd.dwd_d_guar_cont_p partition(data_date='${DATA_DATE}') 
  select   /*+ REPARTITION(1) */
        nvl(t1.org_id                                    ,'')  as  org_id                 --内部机构号 
       ,trim(nvl(t1.guar_cont_no                         ,'')) as  guar_cont_no           --担保合同号 
       ,nvl(t1.guar_cont_name                            ,'')  as  guar_cont_name         --担保合同名称
       ,nvl(t1.guartor_name                              ,'')  as  guartor_name           --担保人名称             
       ,nvl(t1.guar_cert_type                            ,'')  as  guartor_cert_type      --担保人证件类别 101身份证  231统一社会信用代码
       ,nvl(t1.guar_cert_no                              ,'')  as  guartor_cert_no        --担保人证件号码              
       ,trim(nvl(t1.wart_cont_no                         ,'')) as  be_guar_cont_no        --被担保合同号    
       ,nvl(t1.wart_name                                 ,'')  as  be_guartor_name        --被担保人姓名    
       ,nvl(t1.wart_cert_type                            ,'')  as  be_guartor_cert_type   --被担保人证件类型  
       ,nvl(t1.wart_cert_no                              ,'')  as  be_guartor_cert_no     --被担保人证件号   
       ,nvl(t1.tran_type                                 ,'')  as  tran_type              --交易类型信贷交易  
       ,nvl(t1.prod_code                                 ,'')  as  prod_code              --产品代码  
       ,nvl(t1.guar_cont_type_code                       ,'')  as  guar_cont_type_code    --担保合同类型代码    一般担保合同
       ,case when  t12.effective_status in (1,3)  then  '01'                                                 
             else      '02'       end                          as  guar_cont_status       --担保合同状态       --update 20230830调整合同状态码值逻辑
       ,nvl(t1.ccy                                       ,'')  as  ccy                    --担保币种          无法确定担保合同对应的币种
       ,coalesce(t12.total_limit,t1.guar_amt ,'')              as  guar_amt               --担保金额  
       ,nvl(t1.guar_mode                                 ,'')  as  guar_mode              --担保方式
       ,nvl(t1.main_guar_flag                            ,'')  as  main_guar_flag         --是否主担保
       ,coalesce(substr(t12.limit_begin_time,1,10), t1.guar_begin_date,'')  
                                                               as  guar_begin_date        --担保开始日期   
       ,coalesce(substr(t12.limit_end_time,1,10),  t1.guar_end_date  ,'')  
                                                               as  guar_end_date          --担保到期日期   
       ,nvl(t1.guar_order                                ,'')  as  guar_order             --担保顺位
       ,nvl(t1.guartor_nat_econ_depar                    ,'')  as  guartor_nat_econ_depar --担保人国民经济部门
       ,nvl(t1.guartor_indst                             ,'')  as  guartor_indst          --担保人行业
       ,nvl(t1.guartor_area_code                         ,'')  as  guartor_area_code      --担保人地区代码
       ,nvl(t1.guartor_corp_scale                        ,'')  as  guartor_corp_scale     --担保人企业规模
       ,nvl(t1.guar_rate                                 ,'')  as  guar_rate              --抵质押率
       ,''                                                     as  oper_emp_id            --经办人工号
       ,nvl(t1.sign_date                                 ,'')  as  sign_date              --签约日期
       ,nvl(t1.sign_status                               ,'')  as  sign_status            --合同签署状态
	   ,'ORDER'                                                as  source_system          --数据来源         --add llh 20240402
  from 
      (select              --一般担保合同
             nvl(t4.branch,'100000')        as  org_id              --内部机构号 
            ,nvl(t2.contract_no,'')         as  guar_cont_no        --担保合同号 
            ,''                             as  guar_cont_name      --担保合同名称    无法获知担保合同名称
            ,case when t2.contract_type ='3' and t7.coborrower_name is not null then nvl(t7.coborrower_name ,'')
                  when t2.contract_type ='4' and t82.guarantee_name is not null then nvl(t82.guarantee_name ,'')
                  when nvl(t7.coborrower_name ,'') = '' and nvl(t82.guarantee_name ,'') = '' and t2.sub_product_type = '12' then '陕西大秦丝路融资担保有限公司'
                  when nvl(t7.coborrower_name ,'') = '' and nvl(t82.guarantee_name ,'') = '' and t2.sub_product_type = '14' and substr(t2.sign_time,1,10) <= '2022-05-24' then '深圳市中裔信息工程融资担保有限公司'
                  when nvl(t7.coborrower_name ,'') = '' and nvl(t82.guarantee_name ,'') = '' and t2.sub_product_type = '18' then '深圳市中裔信息工程融资担保有限公司'
                  end                       as  guartor_name        --担保人名称                       
            ,case when t2.contract_type ='3' then  '101'                                               
                  when t2.contract_type ='4' then  '231'                                               
                  end                       as  guar_cert_type      --担保人证件类别 101身份证         
            ,case when t2.contract_type ='3' and t7.coborrower_name is not null then  nvl(t7.card_no ,'')                                 
                  when t2.contract_type ='4' and t82.guarantee_name is not null then  nvl(t82.social_credit_code,'')    
                  when nvl(t7.coborrower_name ,'') = '' and nvl(t82.guarantee_name ,'') = '' and t2.sub_product_type = '12' then '91610000689369085B'
                  when nvl(t7.coborrower_name ,'') = '' and nvl(t82.guarantee_name ,'') = '' and t2.sub_product_type = '14' and substr(t2.sign_time,1,10) <= '2022-05-24' then '91440300782764370G'
                  when nvl(t7.coborrower_name ,'') = '' and nvl(t82.guarantee_name ,'') = '' and t2.sub_product_type = '18' then '91440300782764370G'
                  end                       as  guar_cert_no        --担保人证件号码                   
            ,trim(nvl(t3.contract_no,''))   as  wart_cont_no        --被担保合同号    
            ,coalesce(t8.user_name,t83.user_name,'')           
                                            as  wart_name           --被担保人姓名    
            ,'101'                          as  wart_cert_type      --被担保人证件类型  
            ,coalesce(t8.id_card,t83.id_card,'')             
                                            as  wart_cert_no        --被担保人证件号   
            ,'02'                           as  tran_type           --交易类型信贷交易  
            ,t4.prod_type                   as  prod_code           --产品代码  
            ,'1'                            as  guar_cont_type_code --担保合同类型代码   一般担保合同
            ,nvl(case when t12.loan_id is not null then t12.status else t1.status end,'') 
                                            as  guar_status         --担保合同状态    
            ,'CNY'                          as  ccy                 --担保币种  无法确定担保合同对应的币种
            ,case when t12.loan_id is not null then t12.credit_amount 
                  else t1.apply_amount end  as  guar_amt            --担保金额     --update 20230803优先取额度中心额度
            ,case when t1.sub_product_type in ('3','12','14','19','26','29','23','28','33','39','35','41','18')  then 'C'          
                  when t1.sub_product_type in ('2','9','30') and t25.loan_method = 2 then 'D'   --1 担保贷款  2信用贷款  3保证贷款
                  when t1.sub_product_type in ('2','9','30') and t25.loan_method = 3 then 'C' 
                  else '' end               as  guar_mode           --担保方式代码   
            ,''                             as  main_guar_flag      --是否主担保
            ,case when t12.loan_id is not null then substr(t12.credit_start_time,1,10) 
                  else substr(t2.sign_time,1,10) end 
                                            as guar_begin_date     --担保开始日期   
            ,case when t12.loan_id is not null then substr(t12.credit_end_time,1,10) 
                  else from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd') end 
                                            as  guar_end_date       --担保到期日期   
            ,''                             as  guar_order          --担保顺位
            ,''                             as  guartor_nat_econ_depar  --担保人国民经济部门
            ,''                             as  guartor_indst       --担保人行业
            ,''                             as  guartor_area_code   --担保人地区代码
            ,''                             as  guartor_corp_scale  --担保人企业规模
            ,''                             as  guar_rate           --抵质押率
            ,case when t12.loan_id is not null then t12.loan_id 
                  when t12.loan_id is null and t1.credit_order_id is null then t1.loan_id 
                  when t12.loan_id is null then t61.loan_id 
                  else ''
                  end                       as  credit_order_no     --授信号
            ,substr(t2.sign_time,1,10)      as  sign_date           --签约日期
            ,nvl(t2.status,'')              as  sign_status      --合同签署状态
          from (select trim(nvl(a.contract_no,b.contract_no))     as contract_no
                       ,nvl(a.contract_type,b.contract_type)      as contract_type
                       ,nvl(a.sub_product_type,b.product_code)    as sub_product_type
                       ,nvl(a.sign_time,b.template_generate_time) as sign_time
                       ,nvl(a.status,b.status)                    as status
                       ,nvl(a.loan_id,b.loan_id)                  as loan_id
                       ,nvl(a.sign_id_card,b.id_card)             as sign_id_card
                       ,nvl(a.signer_type,b.sign_subject)         as signer_type
                  from (select contract_no
                               ,contract_type
                               ,sub_product_type
                               ,nvl(sign_time,gmt_create)  as sign_time
                               ,status
                               ,loan_id
                               ,sign_id_card
                               ,signer_type
                          from odata.order_contract_sign
                         where data_date='${DATA_DATE}' 
                           and bddw_end_date='9999-99-99'
                           and contract_type in ('3','4')   --个人担保协议、担保公司担保协议 
                           and id not in ('2161510','6829028')
                           and sub_product_type in ('2','3','9','12','14','19','26','29','30','23','28','33','39','35','18','41')) a   --2锡机贷-非上牌车、3锡车贷、9锡机贷-上牌车、29锡望贷-上牌车、30锡望贷-非上牌车、23孚厘、39锡望贷-京东、33锡锡贷-51贷、35锡锡贷-小赢拒量、41-vivo
             full join (select t.contract_no
                               ,t.contract_type
                               ,t.product_code
                               ,t.template_generate_time
                               ,case when t.status = '1' and t1.status =0 then 1 else 0 end as status
                               ,t.loan_id
                               ,t1.id_card
                               ,t1.sign_subject
                          from odata.xscontract_business_contract_records t
                     left join (select contract_id
                                       ,id_card
                                       ,sign_subject
                                       ,sum(if(status = 1,0,1)) as status 
                                  from odata.xscontract_business_contract_detail 
                                 where data_date = '${DATA_DATE}'
                                   and bddw_end_date = '9999-99-99'
                                   and id_card is not null
                              group by contract_id,id_card,sign_subject) t1
                            on t.id = t1.contract_id
                         where t.data_date = '${DATA_DATE}'
                           and t.bddw_end_date = '9999-99-99'
                           and ((t.status = '1' and t1.status =0)
                            or (t.status = '1' and t1.contract_id is null))
                           and t.product_code in ('2','3','9','12','14','19','26','29','30','23','28','33','39','35','18','41')  --2锡机贷-非上牌车、3锡车贷、9锡机贷-上牌车、29锡望贷-上牌车、30锡望贷-非上牌车、23孚厘、39锡望贷-京东、33锡锡贷-51贷、35锡锡贷-小赢拒量、18铁甲、41vivo、19洋钱罐H5 
                           and t.contract_type in ('3','4')) b   --个人担保协议、担保公司担保协议 
                    on a.loan_id = b.loan_id
                   and a.sub_product_type = b.product_code
                   and a.contract_type = b.contract_type
                   and trim(a.contract_no) = trim(b.contract_no)
               ) t2 
        inner join odata.order_main_loan_order t1
                on t1.loan_id=t2.loan_id 
               and t1.data_date='${DATA_DATE}' 
               and t1.bddw_end_date='9999-99-99' 
               and t1.order_type = '2'  --用信
               and t1.loan_time is not null
               and t1.sub_product_type in ('2','3','9','12','14','19','26','29','30','23','28','33','39','35','18','41')   --2锡机贷-非上牌车、3锡车贷、9锡机贷-上牌车、29锡望贷-上牌车、30锡望贷-非上牌车、23孚厘、39锡望贷-京东、33锡锡贷-51贷、35锡锡贷-小赢拒量、18铁甲、41vivo、19洋钱罐H5 
         left join odata.order_main_credit_order t12
                on t1.credit_order_id=t12.loan_id
               and t12.data_date= '${DATA_DATE}'
               and t12.bddw_end_date ='9999-99-99' 
         left join odata.order_main_loan_order t61
                on t1.credit_order_id=t61.loan_id 
               and t1.data_date='${DATA_DATE}' 
               and t1.bddw_end_date='9999-99-99' 
               and t1.order_type = '1'  --授信
         left join odata.order_product_loan_info t25             --订单粒度抵押类型
                on t1.loan_id=t25.loan_id
               and t25.data_date='${DATA_DATE}' 
               and t25.bddw_end_date='9999-99-99'
         left join (select trim(nvl(a.contract_no,b.contract_no))     as contract_no
                           ,nvl(a.contract_type,b.contract_type)      as contract_type
                           ,nvl(a.sub_product_type,b.product_code)    as sub_product_type
                           ,nvl(a.sign_time,b.template_generate_time) as sign_time
                           ,nvl(a.status,b.status)                    as status
                           ,nvl(a.loan_id,b.loan_id)                  as loan_id
                           ,nvl(a.sign_id_card,b.id_card)             as sign_id_card
                           ,nvl(a.signer_type,b.sign_subject)         as signer_type
                      from (select contract_no
                                   ,contract_type
                                   ,sub_product_type
                                   ,sign_time
                                   ,status
                                   ,loan_id
                                   ,sign_id_card
                                   ,signer_type
                              from odata.order_contract_sign
                             where data_date='${DATA_DATE}' 
                               and bddw_end_date='9999-99-99'
                               and contract_type = '2'   
                               and id not in ('2161510','6829028')
                               and signer_type = '1'    --签署人为主借人
                               and sub_product_type in ('2','3','9','12','14','19','26','29','30','23','28','33','39','35','18','41')) a    --2锡机贷-非上牌车、3锡车贷、9锡机贷-上牌车、29锡望贷-上牌车、30锡望贷-非上牌车、23孚厘、39锡望贷-京东、33锡锡贷-51贷、35锡锡贷-小赢拒量、18铁甲、41vivo、19洋钱罐H5 
                  full join (select t.contract_no
                                   ,t.contract_type
                                   ,t.product_code
                                   ,t.template_generate_time
                                   ,case when t.status = '1' and t1.status =0 then 1 else 0 end as status
                                   ,t.loan_id
                                   ,t1.id_card
                                   ,t1.sign_subject
                              from odata.xscontract_business_contract_records t
                         left join (select contract_id
                                           ,id_card
                                           ,sign_subject
                                           ,sum(if(status = 1,0,1)) as status 
                                      from odata.xscontract_business_contract_detail 
                                     where data_date = '${DATA_DATE}'
                                       and bddw_end_date = '9999-99-99'
                                       and id_card is not null
                                  group by contract_id,id_card,sign_subject) t1
                                on t.id = t1.contract_id
                             where t.data_date = '${DATA_DATE}'
                               and t.bddw_end_date = '9999-99-99'
                               and ((t.status = '1' and t1.status =0)
                                or (t.status = '1' and t1.contract_id is null))
                               and t.product_code in ('2','3','9','12','14','19','26','29','30','23','28','33','39','35','18','41')   --2锡机贷-非上牌车、3锡车贷、9锡机贷-上牌车、29锡望贷-上牌车、30锡望贷-非上牌车、23孚厘、39锡望贷-京东、33锡锡贷-51贷、35锡锡贷-小赢拒量、18铁甲、41vivo、19洋钱罐H5 
							   and t1.sign_subject = '1'    --签署人为主借人  
                               and t.contract_type = '2') b  
                         on a.loan_id = b.loan_id
                        and a.sub_product_type = b.product_code
                        and a.contract_type = b.contract_type
                        and trim(a.contract_no) = trim(b.contract_no)) t3 
                on t1.loan_id=t3.loan_id 
        inner join odata.sllv_mb_acct t4
                on t1.receipt_no=t4.cmisloan_no  --t1.loan_id改为receipt_no,20240115
               and t4.data_date='${DATA_DATE}'
               and t4.bddw_end_date='9999-99-99' 
               --and t4.prod_type in ('110115','110116','110129','110130','110110','110122','110165','110166')
         left join odata.order_coborrower_info t7 
                on t1.loan_id=t7.loan_id
               and t7.data_date='${DATA_DATE}'
               and t7.bddw_end_date = '9999-99-99'
               and t7.borrower_type = '2' --担保人 
               and t2.sign_id_card = t7.card_no
         left join 
		 (select loan_id,unify_society_credit_code
		   from 
		   (select *,row_number()over(partition by loan_id order by id desc ) rn
		      from odata.order_guarantee_order_info
             where 	data_date='${DATA_DATE}'
               and 	bddw_end_date = '9999-99-99') t0
             where t0.rn=1) t81       --update 20230824新增逻辑
                on t2.loan_id=t81.loan_id    
         left join odata.uquam_guarantee_limit t82            --update 20230824新增逻辑
                on t82.social_credit_code =t81.unify_society_credit_code  
               and t82.data_date='${DATA_DATE}' 
               and t82.bddw_end_date ='9999-99-99'     
         left join odata.order_custom_info t8         
                on t1.loan_id=t8.loan_id 
               and t8.data_date= '${DATA_DATE}'
               and t8.bddw_end_date ='9999-99-99' 
         left join odata.order_custom_info t83         
                on t1.credit_order_id=t83.loan_id 
               and t83.data_date= '${DATA_DATE}'
               and t83.bddw_end_date ='9999-99-99' 
     union all 
            --最高额保证合同
       select /*+ REPARTITION(1) */
              nvl(t4.branch,'100000')             as  org_id                  --内部机构号     
             ,nvl(t3.contract_no,'')              as  guar_cont_no            --担保合同号     
             ,''                                  as  guar_cont_name          --担保合同名称                                          
             ,coalesce(t7.coborrower_name,t9.company_name,t82.user_name,'') 
                                                  as  guartor_name --担保人名称                                           
             ,case when t7.loan_id  is not null then  '101'                                                                           
                   when t9.loan_id  is not null then  '231'
                   when t82.loan_id  is not null then '101'
                   else  ''  end                  as  guar_cert_type          --担保人证件类别 101身份证 231社会统一信用代码          
             ,case when t7.loan_id  is not null then  nvl(t7.card_no ,'')                                                                         
                   when t9.loan_id  is not null then  nvl(t9.business_license,'')
                   when t82.loan_id is not null then nvl(t82.id_card ,'')
                   else  ''  end                  as  guar_cert_no --担保人证件号码                                        
             ,nvl(t31.contract_no,'')             as  wart_cont_no            --被担保合同号        
             ,case when t4.prod_type in ('120111','120113','120114') then t8.company_name 
                   when t4.prod_type in ('110160','110187') then t81.user_name
                   else  ''  end                  as  wart_name               --被担保人姓名      
             ,case when t4.prod_type in ('120111','120113','120114')  then  '231'
                   when t4.prod_type in ('110160','110187')  then  '101'
                   else  ''  end                  as  wart_cert_type          --被担保人证件类型 
             ,case when t4.prod_type in ('120111','120113','120114') then t8.business_license
                   when t4.prod_type in ('110160','110187') then t81.id_card
                   else  ''  end                  as  wart_cert_no            --被担保人证件号       
             ,'02'                                as  tran_type               --交易类型信贷交易      
             ,nvl(t4.prod_type,'')                as  prod_code               --产品代码      
             ,'2'                                 as  guar_cont_type_code     --担保合同类型代码  一般担保合同  
             ,nvl(t5.status,'')                   as  guar_status             --担保合同状态        
             ,'CNY'                               as  ccy                     --担保币种      
             ,t5.credit_amount                    as guar_amt --担保金额                                                 
             --,case when t1.sub_product_type ='24'  then 'C'
             --      when t1.sub_product_type ='25' and nvl(t7.loan_id,t9.loan_id) is not null then 'C'                    
             --      else 'D' end                   as  guar_mode               --担保方式代码               
             ,case when nvl(t7.loan_id,t9.loan_id) is not null then 'C'  
                   when t3.contract_type='53'   then  'C'
                   else 'D' end                   as  guar_mode               --担保方式代码               
             ,''                                  as  main_guar_flag          --是否主担保  
             ,case when t5.loan_id is not null then substr(t5.credit_start_time,1,10) else substr(t3.sign_time,1,10) end as guar_begin_date         --担保开始日期         
             ,case when t5.loan_id is not null then substr(t5.credit_end_time,1,10) else from_unixtime(unix_timestamp(t4.maturity_date,'yyyyMMdd'),'yyyy-MM-dd') end as guar_end_date           --担保到期期日期       
             ,''                                  as  guar_order              --担保顺位             
             ,''                                  as  guartor_nat_econ_depar  --担保人国民经济部门
             ,''                                  as  guartor_indst           --担保人行业
             ,coalesce(substr(t7.curr_residence_code,-6),substr(t9.company_address_code,-6),'')   
                                                  as  guartor_area_code   
             ,''                                  as  guartor_corp_scale      --担保人企业规模
             ,''                                  as  guar_rate               --抵质押率
             ,t5.loan_id                          as  credit_order_no         --授信号         --update20231122   授信号逻辑调整
             ,substr(t3.sign_time,1,10)           as  sign_date               --签约日期
             ,nvl(t3.status,'')                   as sign_status              --合同签署状态              --updata20231214 pengqun --update gy 20240326
           from   (select trim(nvl(a.contract_no,b.contract_no))     as contract_no
                       ,nvl(a.contract_type,b.contract_type)      as contract_type
                       ,nvl(a.sub_product_type,b.product_code)    as sub_product_type
                       ,nvl(a.sign_time,b.template_generate_time) as sign_time
                       ,nvl(a.status,b.status)                    as status
                       ,nvl(a.loan_id,b.loan_id)                  as loan_id
                       ,nvl(a.sign_id_card,b.id_card)             as sign_id_card
                       ,nvl(a.signer_type,b.sign_subject)         as signer_type
                  from (select contract_no
                               ,contract_type
                               ,sub_product_type
                               ,nvl(sign_time,gmt_create)  as sign_time
                               ,status
                               ,loan_id
                               ,sign_id_card
                               ,signer_type
                          from odata.order_contract_sign t3
                         where t3.data_date='${DATA_DATE}'
                           and t3.bddw_end_date= '9999-99-99' 
                           and t3.contract_type in ('44','53') --最高额保证合同(个人、企业)
                           and t3.id not in ('2161510','6829028')  --20220630 重复数据, 去掉—条 
                           and t3.sub_product_type in ('24','25','42','43','44')  --锡惠贷个人、锡惠贷对公、锡享贷-找钢、锡享贷-厚沃（个人）、锡享贷-找钢-厚沃（企业）
                           ) a 
--update gy 20240326增加个基础服务平台的逻辑取新产品担保信息                         
                   full join (select t.contract_no
                                     ,t.contract_type
                                     ,t.product_code
                                     ,t.template_generate_time
                                     ,case when t.status = '1' and t1.status='1' then '1' else '0' end as status
                                     ,t.loan_id
                                     ,t1.id_card
                                     ,t1.sign_subject
                                from odata.xscontract_business_contract_records t
                           left join (select contract_id
                                             ,id_card
                                             ,sign_subject
                                             ,status 
                                        from odata.xscontract_business_contract_detail 
                                       where data_date = '${DATA_DATE}'
                                         and bddw_end_date = '9999-99-99'
                                         and id_card is not null                        --id_card非空时唯一
                                         and status='1'                                 --签署成功
                                    group by contract_id,id_card,sign_subject,status) t1
                                  on t.id = t1.contract_id
                               where t.data_date = '${DATA_DATE}'
                                 and t.bddw_end_date = '9999-99-99'
                                 and t.status = '1' 
                                 and t.product_code in ('24','25','42','43','44')  --锡惠贷个人、锡惠贷对公、锡享贷-找钢（企业）、锡享贷-厚沃（个人）、锡享贷-厚沃（企业）
                                 and t.contract_type in ('44','53') ) b   --最高额保证合同(个人、企业)
                          on a.loan_id = b.loan_id
                         and a.sub_product_type = b.product_code
                         and a.contract_type = b.contract_type
                         and trim(a.contract_no) = trim(b.contract_no)
                 ) t3 
       inner join odata.order_main_loan_order t1
            on t1.loan_id=t3.loan_id
           and t1.data_date='${DATA_DATE}'
           and t1.bddw_end_date='9999-99-99'
           and t1.order_type = '2'  --用信
           --and t1.sub_product_type in ('24','25')  --锡惠贷个人、锡惠贷对公
           and t1.loan_time is not null
       left join odata.order_main_credit_order t5
            on t1.credit_order_id=t5.loan_id
           and t5.data_date= '${DATA_DATE}'
           and t5.bddw_end_date ='9999-99-99' 
           --and t5.sub_product_type in ('24','25') 
           --and t5.status = '3'
      -- left join odata.order_main_loan_order t51               --会重复关联，剔除此段逻辑0330
      --      on t5.loan_id=t51.credit_order_id
      --     and t51.order_type = '2'  --用信
      --     and t51.data_date='${DATA_DATE}'
      --     and t51.bddw_end_date='9999-99-99'
      --     and t51.loan_time is not null
      --     --and t51.sub_product_type in ('24','25') 
     inner join (select trim(nvl(a.contract_no,b.contract_no))     as contract_no
                  ,nvl(a.contract_type,b.contract_type)      as contract_type
                  ,nvl(a.sub_product_type,b.product_code)    as sub_product_type
                  ,nvl(a.sign_time,b.template_generate_time) as sign_time
                  ,nvl(a.status,b.status)                    as status
                  ,nvl(a.loan_id,b.loan_id)                  as loan_id
                  ,nvl(a.sign_id_card,b.id_card)             as sign_id_card
                  ,nvl(a.signer_type,b.sign_subject)         as signer_type
             from (select contract_no
                          ,contract_type
                          ,sub_product_type
                          ,sign_time
                          ,status
                          ,loan_id
                          ,sign_id_card
                          ,signer_type
                     from odata.order_contract_sign
                    where data_date='${DATA_DATE}' 
                      and bddw_end_date='9999-99-99'
                      and signer_type  in (1,6)    --签署人为主借人、签署人为法人
                      and contract_type in (2,41) --个人贷款协议、人民币流动资金贷款合同
                      and sub_product_type in ('24','25','42','43','44')  --锡惠贷个人、锡惠贷对公、锡享贷-找钢、锡享贷-厚沃（个人）、锡享贷-找钢-厚沃（企业）
                      and id not in ('2161510','6829028')  --20220630 重复数据, 去掉—条 
                     ) a
--update gy 20240326增加个基础服务平台的逻辑取新产品被担保合同号    
                 full join (select t.contract_no
                                  ,t.contract_type
                                  ,t.product_code
                                  ,t.template_generate_time
                                  ,case when t.status = '1' and t1.status ='1' then '1' else '0' end as status
                                  ,t.loan_id
                                  ,t1.id_card
                                  ,t1.sign_subject
                             from odata.xscontract_business_contract_records t
                        left join (select contract_id
                                          ,id_card
                                          ,sign_subject
                                          ,status 
                                     from odata.xscontract_business_contract_detail 
                                    where data_date = '${DATA_DATE}'
                                      and bddw_end_date = '9999-99-99'
                                      and sign_subject in('7','8')       --7签署个人章  8签署企业章  签署个人、企业章时id_card为null值
                                   --   and id_card is not null
                                      and status='1'                     --已签署状态
                                 group by contract_id,id_card,sign_subject,status) t1
                               on t.id = t1.contract_id
                            where t.data_date = '${DATA_DATE}'
                              and t.bddw_end_date = '9999-99-99'
                              and t.status = '1' 
                              and t.product_code  in ('24','25','42','43','44')  --锡惠贷个人、锡惠贷对公、锡享贷-找钢（企业）、锡享贷-厚沃（个人）、锡享贷-厚沃（企业）
                              and t.contract_type in (2,41)  --个人贷款协议、人民币流动资金贷款合同
                              ) b  
                      on a.loan_id = b.loan_id
                     and a.sub_product_type = b.product_code
                     and a.contract_type = b.contract_type
                     and trim(a.contract_no) = trim(b.contract_no)
                ) t31 
            on t1.loan_id=t31.loan_id 
       left join odata.sllv_mb_acct t4
            on t1.receipt_no=t4.cmisloan_no 
           and t4.data_date='${DATA_DATE}' 
           and t4.bddw_end_date='9999-99-99' 
           --and t4.prod_type in ('120111','110160') 
       left join odata.order_coborrower_info t7 
            on t1.credit_order_id=t7.loan_id
           and t7.data_date='${DATA_DATE}'
           and t7.bddw_end_date ='9999-99-99'
           and t7.borrower_type=2 --担保人 
           and t3.sign_id_card = t7.card_no
      left join odata.order_custom_info t81 
            on t1.credit_order_id=t81.loan_id 
           and t81.data_date='${DATA_DATE}' 
           and t81.bddw_end_date ='9999-99-99' 
       left join odata.order_company_info t8          --被担保人
            on t1.credit_order_id=t8.loan_id
           and t8.data_date='${DATA_DATE}' 
           and t8.bddw_end_date ='9999-99-99' 
       left join odata.order_custom_info t82             --update0330
            on t1.credit_order_id=t82.loan_id
           and t82.data_date='${DATA_DATE}' 
           and t82.bddw_end_date ='9999-99-99'     
           and t3.sign_id_card=t82.id_card               --锡享贷最高额保证合同签署人为担保人
       left join odata.order_guarantee_company_info t9
            on t1.credit_order_id=t9.loan_id  
           and t3.sign_id_card=t9.business_license   --社会信用代码
           and t9.data_date='${DATA_DATE}'
           and t9.bddw_end_date ='9999-99-99'
 union all 
            --孚厘一对一担保合同
       select /*+ REPARTITION(1) */ 
             nvl(t4.branch,'100000')        as  org_id              --内部机构号 
            ,nvl(t2.contract_no,'')         as  guar_cont_no        --担保合同号 
            ,nvl(t2.cont_name,'')           as  guar_cont_name      --担保合同名称   
            ,'上海晋福融资担保有限公司'     as  guartor_name        --担保人名称                       
            ,'231'                          as  guar_cert_type      --担保人证件类别   
            ,'91310000594719863P'           as  guar_cert_no        --担保人证件号码                   
            ,trim(nvl(t3.contract_no,''))   as  wart_cont_no        --被担保合同号    
            ,nvl(t82.ch_client_name,'')     as  wart_name           --被担保人姓名    
            ,'231'                          as  wart_cert_type      --被担保人证件类型  
            ,nvl(t83.document_id,'')        as  wart_cert_no        --被担保人证件号   
            ,'02'                           as  tran_type           --交易类型信贷交易  
            ,t4.prod_type                   as  prod_code           --产品代码  
            ,'1'                            as  guar_cont_type_code --担保合同类型代码   一般担保合同
            ,nvl(t12.status ,'')            as  guar_status         --担保合同状态    
            ,'CNY'                          as  ccy                 --担保币种   
            ,t12.credit_amount              as  guar_amt            --担保金额   
            ,'C'                            as  guar_mode           --担保方式代码   
            ,''                             as  main_guar_flag      --是否主担保
            ,substr(t12.credit_start_time,1,10)   as guar_begin_date     --担保开始日期   
            ,substr(t12.credit_end_time,1,10)     as guar_end_date       --担保到期日期   
            ,''                             as  guar_order          --担保顺位
            ,''                             as  guartor_nat_econ_depar  --担保人国民经济部门
            ,''                             as  guartor_indst       --担保人行业
            ,''                             as  guartor_area_code   --担保人地区代码
            ,''                             as  guartor_corp_scale  --担保人企业规模
            ,''                             as  guar_rate           --抵质押率
            , t12.loan_id                   as  credit_order_no     --授信号
            ,substr(t8.sign_time,1,10)      as  sign_date           --签约日期
            ,'1'                            as  sign_status         --合同签署状态
          from (        select  trim(t.contract_no)                                          as contract_no
                               ,t.contract_type                                              as contract_type
                               ,t.product_code                                               as sub_product_type
                               ,t.template_generate_time                                     as sign_time
                               ,t.status                                                     as status
                               ,t.loan_id                                                    as loan_id
                               ,''                                                           as sign_id_card
                               ,''                                                           as signer_type
                               ,t.template_name                                              as cont_name --合同名称
                          from odata.xscontract_business_contract_records t
                         where t.data_date = '${DATA_DATE}'
                           and t.bddw_end_date = '9999-99-99'
                           and t.status = '1' 
                           and t.product_code='45'                   --孚厘企业贷
                           and t.contract_type ='12'            --一对一担保函 
               ) t2 
        inner join odata.order_main_loan_order t1
                on t1.loan_id=t2.loan_id 
               and t1.data_date='${DATA_DATE}' 
               and t1.bddw_end_date='9999-99-99' 
               and t1.order_type = '2'  --用信
               and t1.loan_time is not null
               and t1.sub_product_type='45'                   --孚厘企业贷
         left join odata.order_main_credit_order t12
                on t1.credit_order_id=t12.loan_id
               and t12.data_date= '${DATA_DATE}'
               and t12.bddw_end_date ='9999-99-99' 
         left join (        select  trim(t.contract_no)                                          as contract_no
                                   ,t.contract_type                                              as contract_type
                                   ,t.product_code                                               as sub_product_type
                                   ,t.template_generate_time                                     as sign_time
                                   ,case when t.status = '1' and t1.status =1 then 1 else 0 end  as status
                                   ,t.loan_id                                                    as loan_id
                                   ,t1.id_card                                                   as sign_id_card
                                   ,t1.sign_subject                                              as signer_type
                              from odata.xscontract_business_contract_records t                          
                         left join (select contract_id
                                           ,id_card
                                           ,sign_subject
                                           ,status 
                                      from odata.xscontract_business_contract_detail 
                                     where data_date = '${DATA_DATE}'
                                       and bddw_end_date = '9999-99-99'
                                       and sign_subject in('7','8')       --7签署个人章  8签署企业章  签署个人、企业章时id_card为null值
                                       --and id_card is not null
                                       and status='1'                     --已签署状态
                                  group by contract_id,id_card,sign_subject,status) t1
                                on t.id = t1.contract_id
                             where t.data_date = '${DATA_DATE}'
                               and t.bddw_end_date = '9999-99-99'
                               and t.status = '1' 
                               and t.product_code  ='45'                --孚厘企业贷
                               and t.contract_type = '41'               --人民币流动资金贷款
                               ) t3 
                on t1.loan_id=t3.loan_id 
        inner join odata.sllv_mb_acct t4
                on t1.receipt_no=t4.cmisloan_no  
               and t4.data_date='${DATA_DATE}'
               and t4.bddw_end_date='9999-99-99' 
               and t4.prod_type = '120115'           --孚厘企业贷
        left join odata.sym_cif_client t82
                on t4.client_no=t82.client_no 
               and t82.data_date= '${DATA_DATE}'
               and t82.bddw_end_date ='9999-99-99' 
        left join odata.sym_cif_client_document t83
                on t4.client_no=t83.client_no 
               and t83.data_date= '${DATA_DATE}'
               and t83.bddw_end_date ='9999-99-99'
        left join
                  (select a.business_key_
                         ,b.proc_inst_id_
                         ,b.assignee_ 
                         ,b.id_ 
                         ,b.end_time_  as sign_time 
                         ,row_number() over(partition by b.proc_inst_id_ order by b.end_time_ desc) as rn
                     from odata.work_act_hi_procinst a 
                     left join odata.work_act_hi_taskinst b 
                       on a.proc_inst_id_ = b.proc_inst_id_
                      and b.data_date='${DATA_DATE}'
                      and b.bddw_end_date='9999-99-99'
                    where a.data_date='${DATA_DATE}' 
                      and a.bddw_end_date='9999-99-99'
                      and b.task_def_key_  ='LETTER_INFORMATION' ) t8
             on t1.loan_id=t8.business_key_
            and t8.rn=1
      union all 
            --担保合同存于借款合同中（仅长安新生）
      select /*+ REPARTITION(1) */
            nvl(t4.branch,'100000')     as  org_id              --内部机构号     
            ,nvl(t3.contract_no,'')     as  guar_cont_no        --担保合同号
            ,''                         as  auar_cont_name      --担保合同名称 无法获知担保合同名称
            ,nvl(t8.ch_client_name, '') as  guartor_name        --担保人名称
            ,nvl(t9.document_type, '')  as  guar_cert_type      --担保人证件类别 101身份证
            ,nvl(t9.document_id, '')    as  guar_cert_no        --担保人证件号码
            ,nvl(t3.contract_no, '')    as  wart_cont_no        --被担保合同号
            ,nvl(t8.ch_client_name, '') as  wart_name           --被担保人姓名
            ,nvl(t9.document_type, '')  as  wart_cert_type      --被担保人证件类型
            ,nvl(t9.document_id, '')    as  wart_cert_no        --被担保人证件号
            ,'02'                       as  tran_type           --交易类型信贷交易
            ,t4.prod_type               as  prod_code           --产品代码
            ,'1'                        as  guar_cont_type_code --担保合同类型代码 一般担保合同
            ,nvl(t1.status, '')         as  guar_status         --担保合同状态
            ,'CNY'                      as  ccy                 --担保币种 无法确定担保合同对应的币种
            ,t5.actual_loan_amount      as  guar_amt            --担保金额  --update 20230804优先取额度中心额度
            ,'D'                        as  guar_mode           --担保方式代码
            ,''                         as  main_guar_flag      --是否主担保                          
            ,substr(t4.acct_open_date,1,10)  
                                        as  guar_begin_date--担保开始日期                        
            ,substr(t4.maturity_date,1,10)   
                                        as guar_end_date   --担保到期日期                        
            ,''                         as  guar_order          --担保顺位
            ,''                         as  guartor_nat_econ_depar  --担保人国民经济部门
            ,''                         as  guartor_indst       --担保人行业
            ,''                         as  guartor_area_code   --担保人地区代码
            ,''                         as  guartor_corp_scale  --担保人企业规模
            --,''                             as  oper_emp_id         --经办人工号
            ,''                         as  guar_rate           --抵质押率
            ,t1.loan_id                 as  credit_order_no     --授信号
            ,substr(t3.sign_time,1,10)  as sign_date            --签约日期
            ,nvl(t3.status,'')          as sign_status    --合同签署状态              --updata20231214 pengqun 
       from odata.order_contract_sign t3 
       left join odata.order_main_loan_order t1 
          on t1.loan_id=t3.loan_id 
          and t1.data_date= '${DATA_DATE}'
          and t1.bddw_end_date='9999-99-99'
          and t1.product_type='4'
          and t1.sub_product_type='7'   --新生贷
       --and substr(t1.apply_time,1,10)<='${DATA_DATE}' 
       left join odata.sllv_nl_acct t4
          on t1.receipt_no=t4.cmisloan_no
          and t4.data_date='${DATA_DATE}' 
          and t4.bddw_end_date='9999-99-99'
          and t4.prod_type in ('110118', '110119', '110127')
       left join odata.order_product_loan_info t5
          on t1.loan_id=t5.loan_id 
          and t5.data_date='${DATA_DATE}' 
          and t5.bddw_end_date = '9999-99-99'
       left join odata.sym_cif_client t8 
          on t4.client_no = t8.client_no
          and t8.data_date='${DATA_DATE}'
          and t8.bddw_end_date = '9999-99-99'
       left join odata.sym_cif_client_document t9
          on t8.client_no = t9.client_no
          and t9.data_date = '${DATA_DATE}'
          and t9.bddw_end_date = '9999-99-99'
       where t3.signer_type=1    --签署人为主借人
         and t3.contract_type=2 --个人贷款协议 
         and t3.id not in ('2161510','6829028') --20220630 重复数据，去掉一条 
         and t3. data_date='${DATA_DATE}' 
         and t3.bddw_end_date='9999-99-99'
         and t3.sub_product_type ='7'  --新生贷  
      union all                   
            --锡房贷（目前锡房贷合同独立存储）                   
      select /*+ REPARTITION(1) */                
            nvl(t4.branch,'100000')     as  org_id          --内部机构号     
            ,nvl(t31.contract_no,'')    as  guar_cont_no    --担保合同号 无法获知担保合同号   
            ,''                         as  guar_cont_name  --担保合同名称    无法获知担保合同名称  
            ,nvl(t82.ch_client_name,'') as  guartor_name    --担保人名称 
            ,nvl(t83.document_type, '') as  guar_cert_type  --担保人证件类别 101身份证        
            ,nvl(t83.document_id,'')    as  guar_cert_no        --担保人证件号码   
            ,nvl(t31.contract_no,'')    as  wart_cont_no    --被担保合同号        
            ,nvl(t82.ch_client_name,'') as  wart_name           --被担保人姓名    
            ,nvl(t83.document_type, '') as  wart_cert_type  --被担保人证件类型
            ,nvl(t83.document_id,'')    as  wart_cert_no    --被担保人证件号   
            ,'02'                       as  tran_type       --交易类型信贷交易
            ,t4.prod_type               as  prod_code       --产品代码
            ,'1'                        as  guar_cont_type_code --担保合同类型代码  一般担保合同
            ,nvl(t1.status,'')          as  guar_status     --担保合同状态
            ,'CNY'                      as  ccy             --担保币种
            ,t31.actual_loan_amount     as guar_amt         --担保金额     --update 20230803优先取额度中心额度
            ,'B'                        as  guar_mode       --担保方式代码
            ,''                         as  main_guar_flag  --是否主担保
            ,from_unixtime(unix_timestamp(t4.acct_open_date, 'yyyyMMdd'), 'yyyy-MM-dd')
                                        as  guar_begin_date --担保开始日期                            
            ,from_unixtime(unix_timestamp(t4.maturity_date, 'yyyyMMdd'), 'yyyy-MM-dd')                 
                                        as  guar_end_date   --担保结束日期  无法确定担保结束日期      
            ,''                         as  guar_order      --担保顺位
            ,''                         as  guartor_nat_econ_depar --担保人国民经济部门
            ,''                         as  guartor_indst--担保人行业
            ,''                         as  guartor_area_code--担保人地区代码
            ,''                         as  guartor_corp_scale--担保人企业规模
            ,''                         as  guar_rate           --抵质押率
            ,t1.loan_id                 as  credit_order_no     --授信号
            ,substr(t31.create_time,1,10) as sign_date          --签约日期
            ,case when t31.create_time is null then 0   --待签署
                  when t31.create_time is not null then 1  --已签署
                  else '' end           as sign_status    --合同签署状态              --updata20231214 pengqun 
        from odata.order_loan_order_house t31 
       inner join odata.order_main_loan_order t1  
          on t1.loan_id =t31.loan_id
         and t1.data_date='${DATA_DATE}'
         and t1.bddw_end_date='9999-99-99'
         and t1.sub_product_type  in  ('4','5')         --锡房贷（房抵经营贷、房抵消费贷）
         and t1.loan_time is not null   
        left join odata.sllv_mb_acct t4 
          on nvl(t1.receipt_no,t1.loan_id)=t4.cmisloan_no 
         and t4.data_date='${DATA_DATE}' 
         and t4.bddw_end_date='9999-99-99'
         and t4.prod_type = '110108' 
        left join odata.sym_cif_client t82
          on t4.client_no=t82.client_no 
         and t82.data_date= '${DATA_DATE}'
         and t82.bddw_end_date ='9999-99-99' 
        left join odata.sym_cif_client_document t83
          on t4.client_no=t83.client_no 
         and t83.data_date= '${DATA_DATE}'
         and t83.bddw_end_date ='9999-99-99' 
       where t31.data_date='${DATA_DATE}'
         and t31.bddw_end_date= '9999-99-99'
         and nvl(t31.contract_no,'') <> ''
      --and substr(t1.apply_time,1,10)<='${DATA_DATE}' 
    --and status in (7,8,9,10)
          union all
            --车商贷（车商贷分别存储于不同的表中，且为最高额质押合同）    
     select /*+ REPARTITION(1) */
            nvl(t5.branch,'100000')         as  org_id              --内部机构号 
            ,nvl(t2.contract_no,'')         as  guar_cont_no        --担保合同号 
            ,''                             as  guar_cont_name      --担保合同名称    无法获知担保合同名称
            ,coalesce(t82.ch_client_name,t81.coborrower_name ,'') 
                                            as  guartor_name        --担保人名称                 
            ,case when t81.loan_id is not null  then  '101'                                      
                  else  nvl(t83.document_type, '')                                               
                  end                       as  guar_cert_type      --担保人证件类别 101身份证   
            ,coalesce(t83.document_id ,t81.card_no,'')  
                                            as  guar_cert_no --担保人证件号码        
            ,nvl(t4.contract_no,'')         as  wart_cont_no        --被担保合同号    
            ,nvl(t82.ch_client_name,'')     as  wart_name           --被担保人姓名    
            ,nvl(t83.document_type, '')     as  wart_cert_type      --被担保人证件类型  
            ,nvl(t83.document_id,'')        as  wart_cert_no        --被担保人证件号   
            ,'02'                           as  tran_type           --交易类型信贷交易  
            ,t5.prod_type                   as  prod_code           --产品代码  
            ,'2'                            as  guar_cont_type_code --担保合同类型代码   一般担保合同
            ,nvl(t61.status,'' )            as  guar_status        --担保合同状态    
            ,'CNY'                          as  ccy                 --担保币种  无法确定担保合同对应的币种
            ,t61.apply_amount               as  guar_amt            --担保金额       
            ,case when t25.mortgage_type in ('2','3','4') then 'A'   
                else  'C'    end            as  guar_mode           --担保方式代码                        
            ,''                             as  main_guar_flag      --是否主担保     
            ,nvl(substr(t2.sign_time,1,10),from_unixtime(unix_timestamp(t5.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'))      
                                            as  guar_begin_date     --担保开始日期   
            ,from_unixtime(unix_timestamp(t5.maturity_date,'yyyyMMdd'),'yyyy-MM-dd') 
                                            as  guar_end_date       --担保到期日期   
            ,''                             as  guar_order          --担保顺位
            ,''                             as  guartor_nat_econ_depar  --担保人国民经济部门
            ,''                             as  guartor_indst       --担保人行业
            ,''                             as  guartor_area_code   --担保人地区代码
            ,''                             as  guartor_corp_scale  --担保人企业规模
            ,''                             as  guar_rate           --抵质押率
            ,t61.loan_id                    as  credit_order_no     --授信号
            ,coalesce(substr(t2.sign_time,1,10),substr(t3.create_time,1,10),'')      
                                            as  sign_date           --签约日期
            ,nvl(t2.status,'')              as  sign_status         --合同签署状态
      from (select nvl(a.loan_id,b.loan_id)          as loan_id
                   ,nvl(a.contract_no,b.contract_no) as contract_no
                   ,nvl(a.sign_id_card,'')           as sign_id_card
                   ,nvl(a.sign_time,b.create_time)   as sign_time
                   ,nvl(a.status,b.sign_status)      as status
              from (select loan_id
                           ,contract_no
                           ,sign_id_card
                           ,sign_time
                           ,status                   
                      from odata.order_contract_sign
                     where data_date='${DATA_DATE}'
                       and bddw_end_date='9999-99-99'
                       and contract_type in ('29','44')  --最高额动产质押合同、最高额保证合同（个人） 
                       and signer_type = '1'
                       and id not in ('2161510','6829028')  --20220630 重复数据，去掉一条
                       and sub_product_type ='6') a 
         full join (select  loan_id
                            ,split(contract_no,',')[2] as  contract_no
                            ,null as create_time
                            ,case when create_time is null then 0   --待签署
                                  when create_time is not null then 1  --已签署
                                  else '' end as sign_status 
                      from odata.order_loan_order_car_dealer     
                     where data_date='${DATA_DATE}'
                       and bddw_end_date='9999-99-99'
                       and nvl(split(contract_no,',')[2],'0') <> '0'    
                 union all 
                    select loan_id 
                           ,split(contract_no,',')[5]  as contract_no
                           ,null as create_time
                           ,case when create_time is null then 0   --待签署
                                 when create_time is not null then 1  --已签署
                                 else '' end as sign_status 
                      from odata.order_loan_order_car_dealer             
                     where data_date='${DATA_DATE}'
                       and bddw_end_date='9999-99-99'
                       and nvl(split(contract_no,',')[5],'0') <> '0'    
                                ) b 
                on a.loan_id = b.loan_id 
               and a.contract_no = b.contract_no) t2  
      inner join odata.order_main_loan_order t3
              on t3.loan_id=t2.loan_id
             and t3.order_type = '2'  --用信
             and t3.data_date='${DATA_DATE}'
             and t3.bddw_end_date='9999-99-99'
             and t3.sub_product_type ='6'                 --车商贷
             and t3.loan_time is not null
       left join odata.order_product_loan_info t25             --订单粒度抵押类型
              on t2.loan_id=t25.loan_id
             and t25.data_date='${DATA_DATE}' 
             and t25.bddw_end_date='9999-99-99'
       left join odata.order_main_loan_order t61
              on t61.loan_id=t3.credit_order_id
             and t61.data_date='${DATA_DATE}'
             and t61.bddw_end_date='9999-99-99'
             and t61.order_type = '1'  --授信
             and t61.sub_product_type ='6'                 --车商贷
       left join odata.order_main_loan_order t31             
              on t61.loan_id=t31.credit_order_id 
             and t31.data_date='${DATA_DATE}'
             and t31.bddw_end_date='9999-99-99'
             and t31.loan_time is not null
             and t31.sub_product_type ='6'                 --车商贷
             and t31.order_type = '2'  --用信
       left join odata.order_contract_sign t4
              on t31.loan_id=t4.loan_id 
             and t4.data_date='${DATA_DATE}' 
             and t4.bddw_end_date='9999-99-99' 
             and t4.signer_type=1    --签署人为主借人
             and t4.contract_type=2  --个人借款协议
             and t4.id not in ('2161510','6829028')  --20220630 重复数据，去掉一条 
       left join odata.sllv_mb_acct t5
              on t31.loan_id=t5.cmisloan_no
             and t5.data_date='${DATA_DATE}'
             and t5.bddw_end_date='9999-99-99' 
        --and t5.prod_type in ('110120','110121')
       left join odata.order_coborrower_info t81         
              on t3.credit_order_id=t81.loan_id  
             --and t2.sign_id_card=t81.card_no  
             and t81.borrower_type=2 --担保人 
             and t81.data_date='${DATA_DATE}'
             and t81.bddw_end_date ='9999-99-99'
       left join odata.sym_cif_client t82
              on t5.client_no=t82.client_no 
             and t82.data_date= '${DATA_DATE}'
             and t82.bddw_end_date ='9999-99-99' 
       left join odata.sym_cif_client_document t83
              on t5.client_no=t83.client_no 
             and t83.data_date= '${DATA_DATE}'
             and t83.bddw_end_date ='9999-99-99')t1 
  left join odata.uquam_ps_product_limit t12
    on t12.credit_order_no = t1.credit_order_no
   and t12.data_date='${DATA_DATE}'
   and t12.bddw_end_date='9999-99-99'
  ----------------------------------------信贷----------------------------
  union all
  select      
       /*+ REPARTITION(1) */
        distinct    
        '100000'                    as  org_id                  --内部机构号
        ,nvl(t1.serialno,'')        as  guar_cont_no            --担保合同号
        ,''                         as  guar_cont_name          --担保合同名称
        ,nvl(t1.guarantorname,'')   as  guartor_name            --担保人名称
        ,nvl(t9.document_type,'')   as  guartor_cret_type       --担保人证件类型
        ,nvl(t1.certid,'')          as  guartor_cert_no         --担保人证件代码
        ,coalesce(gyl_contract.objectno,t2.serialno,'') 
                                    as  be_guar_cont_no         --被担保合同号
        ,nvl(t3.customername,'')    as  be_guartor_name         --被担保人
        ,nvl(t91.document_type,'')  as  be_guartor_cret_type    --被担保人证件类型
        ,nvl(t7.certid,'')          as  be_guartor_cret_id      --被担保人证件代码
        ,'02'                       as  tran_type               --交易类型信贷交易
        ,coalesce(gyl_contract.prod_code,t3.prod_code,'') 
                                    as  prod_code               --产品编号
        ,nvl(regexp_replace(t1.contracttype,0, ''), '')   
                                    as guar_cont_type           --担保合同类型（010:—般担保合同，020:最高额担保合同）
        ,case  when   t1.contractstatus='020'  then  '01'       --有效
               when   t1.contractstatus='050'  then  '03'       --已到期
             else    '02'    end    as  guar_cont_status        --担保状态        --20230830调整合同状态码值逻辑
        ,case when  t1.guarantycurrency='01' then 'CNY'     
              else  t1.guarantycurrency 
        end                         as ccy                      --担保合同币种
        ,round(t1.guarantyvalue,2)  as  guar_cont_amt           --担保合同金额
        ,nvl(t1.guarantytype,'')    as  guar_mode               --担保方式代码    
        ,''                         as  main_guar_flag          --是否主担保
        ,nvl(regexp_replace(t1.signdate, '/','-'), '')  
                                    as guar_cont_start_date     --担保合同起始日期
        ,nvl(regexp_replace(t1.enddate, '/','-'), '')   
                                    as guar_cont_mature_date     --担保合同到期日期
        ,''                         as  guar_order               --担保顺位
        ,nvl(t1.certtype, '')       as  guartor_nat_econ_depar   --担保人国民经济部门
        ,nvl(t4.industrytype, '')   as  guartor_indst --担保人行业
        ,case when  t1.certtype  like 'Ent%' then t5.city
              when  t1.certtype like 'Ind%' then t6.cnidregcity
              end                   as  guartor_area_code        --担保人地区代码
        ,nvl(t4.scope, '')          as  guartor_corp_scale       --担保人企业规模
        ,nvl(t1.guarantyrate,'')    as  guar_rate                --抵质押率
        ,nvl(t1.inputuserid ,'')    as  oper_emp_id              --经办人工号    --update 20230830新增经办人工号逻辑
        ,nvl(regexp_replace(signdate,'/','-'),'')
                                    as  sign_date                --签约日期
        ,case when t1.contractstatus in ('020','030','050') then '1'
              else '0' end          as sign_status    --合同签署状态              --updata20231214 pengqun 
	    ,'ALS'                      as source_system             --数据来源      --add llh 20240402
  from odata.als_guaranty_contract t1
  left join odata.als_contract_relative t2 
      on t1.serialno=t2.objectno
      and t2.objecttype= 'GuarantyContract'
      and t2.data_date='${DATA_DATE}'
      and t2.bddw_end_date='9999-99-99'	  
  left join
          (select  a.relativeserialno                     --原授信额度编号（原授信号）
                  ,b.objectno                             --拆分后的被担保合同(贷款合同)
                  ,c.businesssum                          --贷款合同金额
                  ,concat_ws(',',collect_set(nvl(e.prod_type,f.product_type))) prod_code
             from odata.als_cl_occupy a
             left join odata.als_cl_occupy b
                  on a.objectno = b.relativeserialno
                 and b.data_date = '${DATA_DATE}'
                 and b.bddw_end_date = '9999-99-99'
             left join odata.als_business_contract c
                  on b.relativeserialno = c.serialno
                 and c.data_date = '${DATA_DATE}'
                 and c.bddw_end_date = '9999-99-99'
             inner join odata.als_business_duebill d
                  on d.data_date = '${DATA_DATE}'
                 and d.bddw_end_date = '9999-99-99'
                 and d.businesstype = '1070010'--供应链金融
                 and b.objectno = d.relativeserialno2
             left join odata.sym_mb_acct e
                  on d.serialno=e.cmisloan_no 
                 and e.data_date='${DATA_DATE}' 
                 and e.bddw_end_date= '9999-99-99'
                 and e.source_module = 'CL'     --对公贷款
                 and e.lead_acct_flag = 'N'     --限制非主账户
             left join odata.supacct_enterprise_loan_info f --贷款信息表
                  on d.serialno = f.iou_no
                 and f.data_date='${DATA_DATE}'
                 and f.bddw_end_date='9999-99-99'
               where a.data_date = '${DATA_DATE}'
                 and a.bddw_end_date = '9999-99-99'
                 and b.objectno is not null
             group by a.relativeserialno                     --原担保合同
                     ,b.objectno                             --拆分后的被担保合同(贷款合同)
                     ,c.businesssum                          --获批的授信额度
           union all
           select  a.relativeserialno  --为拆分前的担保合同
                  ,a.objectno          --贷款合同
                  ,c.businesssum       --获批的授信额度
                  ,concat_ws(',',collect_set(nvl(e.prod_type,f.product_type))) prod_code
             from odata.als_cl_occupy a
             left join odata.als_business_contract c
                     on a.objectno = c.serialno
                    and c.data_date = '${DATA_DATE}'
                    and c.bddw_end_date = '9999-99-99'
             inner join odata.als_business_duebill d
                     on d.data_date = '${DATA_DATE}'
                    and d.bddw_end_date = '9999-99-99'
                    and d.businesstype not in ('1020010','2010') 
                    and d.mfareaid = 'Model2' --用信线上化的合同
                    and a.objectno = d.relativeserialno2
              left join odata.sym_mb_acct e
                     on d.serialno=e.cmisloan_no 
                    and e.data_date='${DATA_DATE}' 
                    and e.bddw_end_date= '9999-99-99'
                    and e.source_module = 'CL'     --对公贷款
                    and e.lead_acct_flag = 'N'     --限制非主账户
              left join odata.supacct_enterprise_loan_info f --贷款信息表
                     on d.serialno = f.iou_no
                    and f.data_date='${DATA_DATE}'
                    and f.bddw_end_date='9999-99-99'
                  where a.data_date = '${DATA_DATE}'
                    and a.bddw_end_date = '9999-99-99'
               group by a.relativeserialno                     --原担保合同
                 ,a.objectno                             --拆分后的被担保合同(贷款合同)
                 ,c.businesssum                          --获批的授信额度
                     ) gyl_contract 
            on gyl_contract.relativeserialno = t2.serialno
         inner join(select  t.serialno                 
                           ,t.customerid
                           ,t.customername
                           ,t.businesstype 
                           ,concat_ws(',',collect_set(nvl(t2.prod_type,t3.product_type))) prod_code
                      from odata.als_business_contract t
                 left join odata.als_business_duebill t1
                        on t.serialno = t1.relativeserialno2
                       and t1.data_date='${DATA_DATE}'
                       and t1.bddw_end_date= '9999-99-99'
                 left join odata.sym_mb_acct t2
                        on t1.serialno=t2.cmisloan_no 
                       and t2.data_date='${DATA_DATE}' 
                       and t2.bddw_end_date= '9999-99-99'
                       and t2.source_module = 'CL'     --对公贷款
                       and t2.lead_acct_flag = 'N'     --限制非主账户
                 left join odata.supacct_enterprise_loan_info t3 --贷款信息表
                        on t1.serialno = t3.iou_no
                       and t3.data_date='${DATA_DATE}'
                       and t3.bddw_end_date='9999-99-99'
                     where t.data_date='${DATA_DATE}'
                       and t.bddw_end_date= '9999-99-99' 
					   and substr(t.businesstype,1,1) <> '3'  
                  group by t.serialno
                          ,t.customerid
                          ,t.customername
                          ,t.businesstype 
  --and balance > 0
                   )t3
     on nvl(gyl_contract.objectno,t2.serialno) = t3.serialno 
  left join odata.als_ent_info t4
     on guarantorid = t4.customerid 
     and t4.data_date='${DATA_DATE}' 
     and t4.bddw_end_date='9999-99-99' 
  left join (select distinct customerid,city 
               from odata.als_customer_address 
              where addtype='010' 
                and data_date='${DATA_DATE}' 
                and bddw_end_date= '9999-99-99') t5
     on t1.guarantorid=t5.customerid 
  left join odata.als_customer_cert t6
     on t1.guarantorid=t6.customerid 
     and t6.customerid not like 'LS%' 
     and t6.data_date='${DATA_DATE}' 
     and t6.bddw_end_date= '9999-99-99'
    left join odata.sym_cif_client_document t9 
      on t1.guarantorid = t9.client_no 
     and t9.pref_flag='Y'    --首选信息
     and t9.data_date='${DATA_DATE}' 
     and t9.bddw_end_date='9999-99-99'
  left join odata.als_customer_cert t7 
     on t3.customerid=t7.customerid 
     and t7.data_date='${DATA_DATE}' 
     and t7.bddw_end_date = '9999-99-99' 
  left join odata.sym_cif_client_document t91 
    on t3.customerid = t91.client_no 
   and t91.pref_flag='Y'    --首选信息
   and t91.data_date='${DATA_DATE}' 
   and t91.bddw_end_date='9999-99-99'
  where t1. data_date='${DATA_DATE}' 
    and t1.bddw_end_date= '9999-99-99' 
   --and t1.contractstatus <> '010'