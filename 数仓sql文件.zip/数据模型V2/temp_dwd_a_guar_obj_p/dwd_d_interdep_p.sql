--2.dq.temp_dwd_a_guar_obj_p
-------------------------------------------------------------------
--脚本名称:temp_dwd_a_guar_obj_p
--功能描述:数仓担保物信息表
--作    者:吴镇宇
--开发日期:2022-08-26
--直属经理:方杰
--目标表  :dwd.dwd_a_guar_obj_p                       担保物信息表
--数据原表:odata.pawn_pawn_base                       押品主表
--         odata.pawn_pawn_car                        车辆抵押品信息表
--         odata.order_main_loan_order                订单主表
--         odata.order_product_loan_info              产品贷款信息
--         odata.sllv_nl_acct                         线上贷款客户信息表
--         odata.order_contract_sign                  合同签署表
--         odata.order_custom_info                    客户信息表
--         odata.pawn_pawn_house                      房贷抵押品表
--         odata.order_loan_order_house               房抵贷订单表
--         odata.sllv_mb_acct                         账户基本信息表
--         odata.pawn_house_evaluate                  房屋估价信息表
--         odata.order_credit_order_info              授信信息表
--         odata.order_loan_order_car_dealer          车主贷贷款信息表
--         odata.als_guaranty_contract                担保合同信息表
--         odata.als_guaranty_info                    担保物信息表
--         odata.als_contract_relative                合同关联表
--         odata.als_business_contract                业务合同信息表
--         odata.als_org_info                         机构信息
--         odata.als_guaranty_relative                业务合同、担保合同与担保物关联表
--         odata.als_customer_info                    客户基本信息表
--修改历史:
--         1、吴镇宇     20220826     新建
--         2、邓权       20230207     新增字段抵质押资产编号、抵质押资产签发机构；修改信贷部分评估机构类型代码、评估方式代码取数逻辑
------------------------------------------------------------------
insert overwrite table dwd.temp_dwd_a_guar_obj_p partition(data_date='${DATA_DATE}')
--对公
select
    /*+ REPARTITION(1) */
nvl(t4.mainframeorgid,'100000')                              as org_id                       --内部机构号        
,nvl(t1.guarantyid,'')                                       as guar_obj_no                  --担保物品编号
,nvl(t3.serialno,'')                                         as guar_cont_no                 --担保合同编码
,''                                                          as guar_cont_name               --担保合同名称     
,nvl(t1.guarantyname,'')                                     as guar_obj_name                --担保物品名称
,nvl(t21.customerid,'')                                      as be_guar_cust_id              --被担保人客户号
,nvl(t21.customername,'')                                    as be_guar_cust_name            --被担保人客户名称
,nvl(t1.guarantytype,'')                                     as guar_obj_type_code           --质或抵押物品类型代码 
,t1.evalnetvalue                                             as guar_obj_value               --质或抵押物账面价值     
,nvl(t1.evalcurrency,'')                                     as ccy                          --币种代码
,t1.evalnetvalue                                             as estimate_value               --评估价值  
,nvl(from_unixtime(unix_timestamp(t1.evaldate,'yyyy/MM/dd'),'yyyy-MM-dd'),'')                         as estimate_date                --评估日期
,nvl(t1.evalorgname,'')                                      as estimate_org_name            --评估机构名称
,nvl(t1.guarantyrate,0)                                      as guar_rate                    --质或抵押率    
,nvl(t1.ownername,'')                                        as guar_obj_owner_name          --抵押物所有权人名称   
,case when t1.ownerid = t21.customerid then 0 else 1 end     as guar_obj_third_flag          --押品权属人是否第三方   
,nvl(t7.customertype,'')                                     as guar_obj_owner_type_code     --押品权属人类型代码  
,nvl(t7.certtype,'')                                         as owner_cert_type              --押品权属人证件类型代码  
,nvl(t7.certid,'')                                           as owner_cert_no                --押品权属人证件代码  
,nvl(t1.evalnetvalue,0)                                      as have_guar_value              --已抵押价值  
,nvl(from_unixtime(unix_timestamp(t1.inputdate,'yyyy/MM/dd'),'yyyy-MM-dd'),'')                       as regtd_date                   --登记日期  
,nvl(t4.mainframeorgid,'')                                   as regtd_org_name               --登记机构名称  
,nvl(from_unixtime(unix_timestamp(t3.begindate,'yyyy/MM/dd'),'yyyy-MM-dd'),'')                       as guar_start_date              --担保起始日期  
,nvl(from_unixtime(unix_timestamp(t3.enddate,'yyyy/MM/dd'),'yyyy-MM-dd'),'')                         as guar_mature_date             --担保到期日期    
,nvl(t1.otherguarantyright,'')                               as warrt_regtd_id               --权证登记号码      
,''                                                          as warrt_regtd_name             --权证名称  
,''                                                          as warrt_regtd_expr_date        --权证到期日期   
,''                                                          as regtd_expr_date              --登记有效终止日期   
,''                                                          as obj_coll_date                --实物收取日期  
,nvl(from_unixtime(unix_timestamp(t1.evaldate,'yyyy/MM/dd'),'yyyy-MM-dd'),'')                         as first_estimate_date          --首次评估日期  
,''                                                          as estimate_mature_date         --评估到期日期   押品表内未发现此字段
,''                                                          as guar_mode                    --担保方式类型代码   
,nvl(t1.guarantystatus,'')                                   as guar_obj_status              --担保物品状态代码  
,t1.evalnetvalue                                             as first_estimate_value         --初次评估价值    
,nvl(t1.evalmethod,'')                                       as estimate_org_type            --评估机构类型代码  （评估方式）
,nvl(t1.assessmentway,'')                                    as estimate_way_code            --评估方式代码  （评估方法）
,nvl(t1.isfirstnumber,0)                                     as colla_amt                    --优先受偿权数额 
,nvl(t1.valuationcycle,'')                                   as estimate_perod_code          --估值周期代码 
,''                                                          as warrt_regtd_area             --权证登记面积
,nvl(t1.isfirstorder,'')                                     as disp_right_order             --处置权顺位 
,nvl(t1.guarantyrightid,'')                                  as warrt_asset_no               --抵质押资产编号
,nvl(t1.guarantyusing,t1.guarantylocation)                   as asset_issue_org_nm           --抵质押资产签发机构
from odata.als_guaranty_info t1
left join 
    (select a.guarantyid,a.contractno from
        (select guarantyid,contractno,row_number()over(partition by contractno,guarantyid order by objectno )rn
        from odata.als_guaranty_relative 
        where objecttype='BusinessContract'
        and data_date='${DATA_DATE}'
        and bddw_end_date='9999-99-99'
        )a where a.rn=1)t2
       on t1.guarantyid = t2.guarantyid
left join odata.als_guaranty_contract t3
       on t2.contractno=t3.serialno
        and t3.data_date='${DATA_DATE}'
        and t3.bddw_end_date='9999-99-99'
left join odata.als_org_info t4 --信贷机构信息表
       on t3.inputorgid = t4.orgid
        and t4.data_date='${DATA_DATE}'
        and t4.bddw_end_date='9999-99-99'
left join 
(select a.objectno,a.customerid,a.customername from 
        (select t.objectno,t1.customerid ,t1.customername,row_number()over(partition by t.objectno,t1.customerid order by t.serialno) rn
        from odata.als_contract_relative t
        inner join odata.als_business_contract t1
        on t.serialno = t1.serialno
        and t1.data_date='${DATA_DATE}'
        and t1.bddw_end_date='9999-99-99'
        and t1.customerid is not null
        where t.objecttype='GuarantyContract'
        and t.data_date='${DATA_DATE}'
        and t.bddw_end_date='9999-99-99'
        )a where a.rn=1)t21
        on t3.serialno=t21.objectno
left join odata.als_customer_info t7
        on t1.ownerid = t7.customerid
        and t7.data_date='${DATA_DATE}'
        and t7.bddw_end_date='9999-99-99'
where t1.data_date='${DATA_DATE}'
  and t1.bddw_end_date='9999-99-99'
--长安新生
union all
select
    /*+ REPARTITION(1) */
nvl(t5.branch,'100000' )                                     as org_id                       --内部机构号       
,nvl(t1.id,'')                                               as guar_obj_no                  --担保物品编号
,nvl(t6.contract_no,'')                                      as guar_cont_no                 --担保合同编码
,''                                                          as guar_cont_name               --担保合同名称     
--,''                                                            as seq_num                      --担保物品序号     
,nvl(t2.pledge_name,t2.car_configuration)                    as guar_obj_name                --担保物品名称
,nvl(t5.client_no,'')                                        as be_guar_cust_id              --被担保人客户号
,nvl(t7.user_name,'')                                        as be_guar_cust_name            --被担保人客户名称
,nvl(t1.product_type,'')                                     as guar_obj_type_code           --质或抵押物品类型代码  
,t1.assess_amount                                            as guar_obj_value               --质或抵押物账面价值
,'CNY'                                                       as ccy                          --币种代码
,t1.assess_amount                                            as estimate_value               --评估价值
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as estimate_date                --评估日期
,'长安新生（深圳）金融投资有限公司'                          as estimate_org_name            --评估机构名称
,nvl(t4.mortgage_rate,0)                                     as guar_rate                    --质或抵押率   
,nvl(t2.owner_name,'')                                       as guar_obj_owner_name          --抵押物所有权人名称
,case when t3.user_id=t7.user_id and  t2.credential_no <> t7.id_card then 1 else 0 end                              as guar_obj_third_flag           --押品权属人是否第三方  
,nvl(t2.owner_type,'')                                       as guar_obj_owner_type_code     --押品权属人类型代码  
,nvl(t2.credential_type,'')                                  as owner_cert_type              --押品权属人证件类型代码  
,nvl(t2.credential_no,'')                                    as owner_cert_no                --押品权属人证件代码  
,0                                                           as have_guar_value              --已抵押价值  
,nvl(from_unixtime(unix_timestamp(substr(t2.register_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                       as regtd_date                    --登记日期  
,nvl(t2.vehicle_certificate_name,'')                         as regtd_org_name               --登记机构名称  
,nvl(from_unixtime(unix_timestamp(substr(t5.acct_open_date,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                      as guar_start_date               --担保起始日期  
,nvl(from_unixtime(unix_timestamp(substr(t5.maturity_date,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                       as guar_mature_date              --担保到期日期    
,nvl(t2.vin_code,'')                                         as warrt_regtd_id               --权证登记号码      
,nvl(t2.vehicle_certificate_name,'')                         as warrt_regtd_name             --权证名称  
,''                                                          as warrt_regtd_expr_date        --权证到期日期  
,''                                                          as regtd_expr_date              --登记有效终止日期   表内未发现此字段
,nvl(from_unixtime(unix_timestamp(substr(t2.register_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                       as obj_coll_date                 --实物收取日期  
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as first_estimate_date          --首次评估日期  
,''                                                          as estimate_mature_date         --评估到期日期   押品表内未发现此字段
,'B99'                                                       as guar_mode                    --担保方式类型代码  
,''                                                          as guar_obj_status              --担保物品状态代码  
,t1.assess_amount                                            as first_estimate_value         --初次评估价值  
,''                                                          as estimate_org_type            --评估机构类型代码  
,''                                                          as estimate_way_code            --评估方式代码  
,''                                                          as colla_amt                    --优先受偿权数额 
,''                                                          as estimate_perod_code          --估值周期代码 
,''                                                          as warrt_regtd_area             --权证登记面积 
,''                                                          as disp_right_order             --处置权顺位 
,''                                                          as warrt_asset_no               --抵质押资产编号
,''                                                          as asset_issue_org_nm           --抵质押资产签发机构
from odata.pawn_pawn_base t1
 left join odata.pawn_pawn_car t2
   on t1.id=t2.pawn_id
  and t2.data_date='${DATA_DATE}'
  and t2.bddw_end_date='9999-99-99'
 left join odata.order_main_loan_order t3
   on t1.loan_id=t3.loan_id
  and t3.data_date='${DATA_DATE}'
  and t3.bddw_end_date='9999-99-99'
 left join odata.order_product_loan_info t4
   on t1.loan_id=t4.loan_id
  and t4.data_date='${DATA_DATE}'
  and t4.bddw_end_date='9999-99-99'
 left join odata.sllv_nl_acct t5
   on t3.receipt_no=t5.cmisloan_no
  and t5.data_date='${DATA_DATE}'
  and t5.bddw_end_date='9999-99-99'
  and t5.prod_type in ('110118','110119','110127')
left join odata.order_contract_sign t6
   on t1.loan_id=t6.loan_id
  and t6.data_date='${DATA_DATE}'
  and t6.bddw_end_date='9999-99-99'
  and t6.signer_type=1    --签署人为借款人
  and t6.contract_type=2  --个人借款协议
left join odata.order_custom_info t7
   on t3.loan_id = t7.loan_id
   and t7.data_date='${DATA_DATE}'
   and t7.bddw_end_date='9999-99-99'
where t1.data_date='${DATA_DATE}'
  and t1.bddw_end_date='9999-99-99'
  --and substr(t3.apply_time,1,10)<='${DATA_DATE}'
  and t3.product_type='4'
  and t3.sub_product_type='7'
--锡房贷
union all
select
    /*+ REPARTITION(1) */
nvl(t5.branch,'100000')                                      as org_id                       --内部机构号       
,nvl(t1.id,'')                                               as guar_obj_no                  --担保物品编号
,nvl(t4.contract_no,'')                                      as guar_cont_no                 --担保合同编码
,''                                                          as guar_cont_name               --担保合同名称     
,nvl(t2.estate,'')                                           as guar_obj_name                --担保物品名称
,nvl(t5.client_no,'')                                        as be_guar_cust_id              --被担保人客户号
,nvl(t8.user_name,'')                                        as be_guar_cust_name            --被担保人客户名称
,nvl(t1.product_type,'')                                     as guar_obj_type_code           --质或抵押物品类型代码  
,t1.assess_amount*10000                                      as guar_obj_value               --质或抵押物账面价值   
,'CNY'                                                       as ccy                          --币种代码
,t1.assess_amount*10000                                      as estimate_value               --评估价值   
,nvl(from_unixtime(unix_timestamp(substr(t9.modified_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                        as estimate_date                --评估日期   
,'上海瑞家信息技术有限公司'                                  as estimate_org_name            --评估机构名称
,nvl(t2.mortgage_rate,0)                                     as guar_rate                    --质或抵押率    
,nvl(t2.house_owner,'')                                      as guar_obj_owner_name          --抵押物所有权人名称
,nvl(t4.is_pledge_user,'')                                   as guar_obj_third_flag          --押品权属人是否第三方   
,''                                                          as guar_obj_owner_type_code     --押品权属人类型代码    
,''                                                          as owner_cert_type              --押品权属人证件类型代码  
,''                                                          as owner_cert_no                --押品权属人证件代码  
,case when t2.unique_mortgage = '1' then nvl(t2.pre_pledge_balance*10000,0)  --如果已经抵押第一次，就是第一次抵押价；假如之前没有抵押过，就填充0
      when t2.unique_mortgage = '0' then 0
      else 0 end                                             as have_guar_value              --已抵押价值  
,nvl(from_unixtime(unix_timestamp(t2.house_register_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                               as regtd_date                   --登记日期  
,nvl(t2.cachet_name,'')                                      as regtd_org_name               --登记机构名称  
,nvl(from_unixtime(unix_timestamp(t5.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                                    as guar_start_date              --担保起始日期  
,nvl(from_unixtime(unix_timestamp(t5.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')                                     as guar_mature_date                 --担保到期日期    
,nvl(t2.house_vin_no,'')                                     as warrt_regtd_id               --权证登记号码      
,nvl(t2.cachet_name,'')                                      as warrt_regtd_name             --权证名称  
,nvl(from_unixtime(unix_timestamp(substr(t2.expire_date,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as warrt_regtd_expr_date         --权证到期日期     
,''                                                          as regtd_expr_date              --登记有效终止日期   
,''                                                          as obj_coll_date                --实物收取日期    
,nvl(from_unixtime(unix_timestamp(substr(t9.modified_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                       as first_estimate_date          --首次评估日期  
,''                                                          as estimate_mature_date         --评估到期日期   押品表内未发现此字段
,'B01'                                                       as guar_mode                    --担保方式类型代码  
,nvl(t2.house_status,'')                                     as guar_obj_status              --担保物品状态代码  
,t1.assess_amount*10000                                      as first_estimate_value         --初次评估价值    
,''                                                          as estimate_org_type            --评估机构类型代码  
,''                                                          as estimate_way_code            --评估方式代码  
,''                                                          as colla_amt                    --优先受偿权数额 
,''                                                          as estimate_perod_code          --估值周期代码 
,nvl(t2.floorage,0)                                          as warrt_regtd_area             --权证登记面积 
,case when t2.unique_mortgage = '0' then '1' --如果已经抵押一次，则我行为第二顺位受偿权
      when t2.unique_mortgage = '1' then '2' else '' end     as disp_right_order             --处置权顺位     
,''                                                          as warrt_asset_no               --抵质押资产编号
,''                                                          as asset_issue_org_nm           --抵质押资产签发机构
from odata.pawn_pawn_base t1
left join odata.pawn_pawn_house t2
       on t1.id=t2.pawn_id
      and t2.data_date='${DATA_DATE}'
      and t2.bddw_end_date='9999-99-99'
left join odata.order_main_loan_order t3
       on t1.loan_id=t3.loan_id
      and t3.data_date='${DATA_DATE}'
      and t3.bddw_end_date='9999-99-99'
left join odata.order_loan_order_house t4
       on t1.loan_id=t4.loan_id
      and t4.data_date='${DATA_DATE}'
      and t4.bddw_end_date='9999-99-99'
left join odata.sllv_mb_acct t5
       on t1.loan_id=t5.cmisloan_no
      and t5.data_date='${DATA_DATE}'
      and t5.bddw_end_date='9999-99-99'
      and t5.prod_type='110108'
left join 
(select user_id,loan_id,user_name  from (
    select user_id,
           loan_id,
           user_name,
           row_number() over(partition by user_id,loan_id  order by user_name) rn
    from odata.order_custom_info
    where data_date='${DATA_DATE}'
       and bddw_end_date='9999-99-99') a where a.rn=1) t8
       on t3.user_id=t8.user_id
       and t3.loan_id = t8.loan_id
left  join odata.pawn_house_evaluate t9
        on t1.loan_id=t9.loan_id
       and t9.data_date='${DATA_DATE}'
       and t9.bddw_end_date='9999-99-99'
       and t9.evaluate_type = '0'
where t1.data_date='${DATA_DATE}'
  and t1.bddw_end_date='9999-99-99'
  and t3.product_type='1'
--车商贷
union all 
select
    /*+ REPARTITION(1) */
'100000'                                                     as org_id                       --内部机构号       
,nvl(t1.id,'')                                               as guar_obj_no                  --担保物品编号   
,nvl(t7.contract_no,split(t8.contract_no,',')[2])            as guar_cont_no                 --担保合同编码
,''                                                          as guar_cont_name               --担保合同名称     
,nvl(t2.pledge_name,t2.car_configuration)                    as guar_obj_name                --担保物品名称
,nvl(t3.user_id,'')                                          as be_guar_cust_id              --被担保人客户号
,nvl(t9.user_name,'')                                        as be_guar_cust_name            --被担保人客户名称
,nvl(t1.product_type,'')                                     as guar_obj_type_code           --质或抵押物品类型代码  
,t1.assess_amount                                            as guar_obj_value               --质或抵押物账面价值
,'CNY'                                                       as ccy                          --币种代码
,t1.assess_amount                                            as estimate_value               --评估价值
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'') as estimate_date  --评估日期
,'无锡普翎信息科技有限公司'                                          as estimate_org_name            --评估机构名称
,nvl(t8.pledge_rate,0)                                       as guar_rate                    --质或抵押率    
,nvl(t2.owner_name,'')                                       as guar_obj_owner_name          --抵押物所有权人名称
,case when t3.user_id=t9.user_id and t2.credential_no <> t9.id_card then 1 else 0 end as guar_obj_third_flag           --押品权属人是否第三方  
,nvl(t2.owner_type,'')                                       as guar_obj_owner_type_code     --押品权属人类型代码  
,nvl(t2.credential_type,'')                                  as owner_cert_type              --押品权属人证件类型代码  
,nvl(t2.credential_no,'')                                    as owner_cert_no                --押品权属人证件代码  
,0                                                           as have_guar_value              --已抵押价值  
,nvl(from_unixtime(unix_timestamp(substr(t2.register_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'') as regtd_date                    --登记日期  
,nvl(t2.vehicle_certificate_name,'')                         as regtd_org_name               --登记机构名称  
,nvl(from_unixtime(unix_timestamp(t10.limit_begin_time,'yyyyMMdd'),'yyyy-MM-dd'),'')   as guar_start_date               --担保起始日期    
,nvl(from_unixtime(unix_timestamp(t10.limit_end_time,'yyyyMMdd'),'yyyy-MM-dd'),'')   as guar_mature_date                --担保到期日期     
,nvl(t2.vin_code,'')                                         as warrt_regtd_id               --权证登记号码     
,nvl(t2.vehicle_certificate_name,'')                         as warrt_regtd_name             --权证名称   
,''                                                          as warrt_regtd_expr_date        --权证到期日期  
,''                                                          as regtd_expr_date              --登记有效终止日期   
,nvl(from_unixtime(unix_timestamp(substr(t2.register_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'') as obj_coll_date                 --实物收取日期  
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'') as first_estimate_date          --首次评估日期  
,''                                                          as estimate_mature_date         --评估到期日期   押品表内未发现此字段
,'A'                                                         as guar_mode                    --担保方式类型代码  
,''                                                          as guar_obj_status              --担保物品状态代码  
,t1.assess_amount                                            as first_estimate_value         --初次评估价值  
,''                                                          as estimate_org_type            --评估机构类型代码  
,''                                                          as estimate_way_code            --评估方式代码  
,''                                                          as colla_amt                    --优先受偿权数额 
,''                                                          as estimate_perod_code          --估值周期代码 
,''                                                          as warrt_regtd_area             --权证登记面积 
,''                                                          as disp_right_order             --处置权顺位 
,''                                                          as warrt_asset_no               --抵质押资产编号
,''                                                          as asset_issue_org_nm           --抵质押资产签发机构
from odata.pawn_pawn_base t1
 left join odata.pawn_pawn_car t2
   on t1.id=t2.pawn_id
  and t2.data_date='${DATA_DATE}'
  and t2.bddw_end_date='9999-99-99'
 left join (select t.loan_id,t1.loan_id loan_id_origin,t.user_id,t.product_type,t.sub_product_type from 
           (select t.loan_id,t.user_id,t.product_type,t.sub_product_type
              from (select loan_id,user_id,product_type,sub_product_type
                   ,row_number() over(partition by user_id,product_type,sub_product_type order by apply_time) rn
              from odata.order_main_loan_order
             where order_type = '1'  --授信
               and data_date='${DATA_DATE}'
               and bddw_end_date='9999-99-99'
               and product_type = '5'
               and sub_product_type = '6'
               and status = '13')   t 
               where t.rn <> 1) t 
          left join (select t.loan_id,t.user_id,t.product_type,t.sub_product_type
              from (select loan_id,user_id,product_type,sub_product_type
                   ,row_number() over(partition by user_id,product_type,sub_product_type order by apply_time) rn
              from odata.order_main_loan_order
             where order_type = '1'  --授信
               and data_date='${DATA_DATE}'
               and bddw_end_date='9999-99-99'
               and product_type = '5'
               and sub_product_type = '6'
               and status = '13')   t 
               where t.rn = 1) t1 
               on t.user_id = t1.user_id
           union all     
           select t.loan_id,t.loan_id loan_id_origin,t.user_id,t.product_type,t.sub_product_type
              from (select loan_id,user_id,product_type,sub_product_type
                   ,row_number() over(partition by user_id,product_type,sub_product_type order by apply_time) rn
              from odata.order_main_loan_order
             where order_type = '1'  --授信
               and data_date='${DATA_DATE}'
               and bddw_end_date='9999-99-99'
               and product_type = '5'
               and sub_product_type = '6'
               and status = '13')   t 
               where t.rn = 1) t6
   on t1.loan_id = t6.loan_id_origin
 left join (select t.loan_id,t.credit_order_id,t.user_id,t.product_type,t.sub_product_type
              from (select loan_id,credit_order_id,product_type,sub_product_type 
                   ,user_id
                   ,row_number() over(partition by credit_order_id,user_id,product_type,sub_product_type order by loan_time) rn
              from odata.order_main_loan_order
             where order_type = '2'  --用信
               and data_date='${DATA_DATE}'
               and bddw_end_date='9999-99-99'
               and loan_time is not null) t 
               where t.rn = 1) t3
   on t6.loan_id=t3.credit_order_id
left join odata.order_contract_sign t7
   on t3.loan_id=t7.loan_id
  and t7.data_date='${DATA_DATE}'
  and t7.bddw_end_date='9999-99-99'
  and t7.contract_type=29 --最高额动产质押合同
  and t7.signer_type = 1 --签署人为主借人
left join odata.order_loan_order_car_dealer t8
   on t8.loan_id=t3.loan_id
  and t8.data_date='${DATA_DATE}'
  and t8.bddw_end_date='9999-99-99'
  and t8.first_loan='1'
left join odata.order_custom_info t9
   on t3.loan_id=t9.loan_id
   and t9.data_date='${DATA_DATE}'
   and t9.bddw_end_date='9999-99-99'
left join (select 
                 credit_order_no ,
                 limit_begin_time ,
                 limit_end_time 
            from odata.limit_ps_product_limit 
           where data_date = '${DATA_DATE}' 
             and bddw_end_date = '9999-99-99') t10
   on t1.loan_id = t10.credit_order_no
where t1.data_date='${DATA_DATE}'
  and t1.bddw_end_date='9999-99-99'
  --and substr(t3.apply_time,1,10)<='${DATA_DATE}'
  and t1.product_type = '5'
  and t1.sub_product_type = '6'
--车主贷     
union all 
select
    /*+ REPARTITION(1) */
nvl(t4.branch,'100000')                                      as org_id                       --内部机构号       
,nvl(t1.id,'')                                               as guar_obj_no                  --担保物品编号   
,nvl(t7.contract_no,'')                                      as guar_cont_no                 --担保合同编码
,''                                                          as guar_cont_name               --担保合同名称     
,nvl(t2.pledge_name,concat(t2.brand,t2.car_configuration))   as guar_obj_name                --担保物品名称
,nvl(t4.client_no,'')                                        as be_guar_cust_id              --被担保人客户号
,nvl(t9.user_name,'')                                        as be_guar_cust_name            --被担保人客户名称
,nvl(t1.product_type,'')                                     as guar_obj_type_code           --质或抵押物品类型代码  
,t1.assess_amount                                            as guar_obj_value               --质或抵押物账面价值
,'CNY'                                                       as ccy                          --币种代码
,t1.assess_amount                                            as estimate_value               --评估价值
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as estimate_date                --评估日期
,''                                                          as estimate_org_name            --评估机构名称   车主贷评估机构名称是什么
,nvl(t5.mortgage_rate,0)                                     as guar_rate                    --质或抵押率    
,nvl(t2.owner_name,'')                                       as guar_obj_owner_name          --抵押物所有权人名称
,case when t3.user_id=t9.user_id and t2.credential_no <> t9.id_card then 1 else 0 end                               as guar_obj_third_flag           --押品权属人是否第三方  
,nvl(t2.owner_type,'')                                       as guar_obj_owner_type_code     --押品权属人类型代码  
,nvl(t2.credential_type,'')                                  as owner_cert_type              --押品权属人证件类型代码  
,nvl(t2.credential_no,'')                                    as owner_cert_no                --押品权属人证件代码  
,0                                                           as have_guar_value              --已抵押价值  
,nvl(from_unixtime(unix_timestamp(substr(t2.register_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                       as regtd_date                    --登记日期  
,nvl(t2.vehicle_certificate_name,'')                         as regtd_org_name               --登记机构名称  
,nvl(from_unixtime(unix_timestamp(t10.limit_begin_time,'yyyyMMdd'),'yyyy-MM-dd'),'')   as guar_start_date               --担保起始日期    
,nvl(from_unixtime(unix_timestamp(t10.limit_end_time,'yyyyMMdd'),'yyyy-MM-dd'),'')  as guar_mature_date             --担保到期日期     
,nvl(t2.vin_code,'')                                         as warrt_regtd_id               --权证登记号码      
,nvl(t2.vehicle_certificate_name,'')                         as warrt_regtd_name             --权证名称   
,''                                                          as warrt_regtd_expr_date        --权证到期日期  
,''                                                          as regtd_expr_date              --登记有效终止日期   
,nvl(from_unixtime(unix_timestamp(substr(t2.register_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                       as obj_coll_date                 --实物收取日期  
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as first_estimate_date          --首次评估日期  
,''                                                          as estimate_mature_date         --评估到期日期   
,case when t7.loan_id is null then 'B99' else 'E' end        as guar_mode                    --担保方式类型代码  
,''                                                          as guar_obj_status              --担保物品状态代码  
,t1.assess_amount                                            as first_estimate_value         --初次评估价值  
,''                                                          as estimate_org_type            --评估机构类型代码  
,''                                                          as estimate_way_code            --评估方式代码  
,''                                                          as colla_amt                    --优先受偿权数额 
,''                                                          as estimate_perod_code          --估值周期代码 
,''                                                          as warrt_regtd_area             --权证登记面积 
,''                                                          as disp_right_order             --处置权顺位 
,''                                                          as warrt_asset_no               --抵质押资产编号
,''                                                          as asset_issue_org_nm           --抵质押资产签发机构
from odata.pawn_pawn_base t1
 left join odata.pawn_pawn_car t2
   on t1.id=t2.pawn_id
  and t2.data_date='${DATA_DATE}'
  and t2.bddw_end_date='9999-99-99'
 left join odata.order_main_loan_order t3
   on t3.loan_id=t1.loan_id
  and t3.data_date='${DATA_DATE}'
  and t3.bddw_end_date='9999-99-99'
  and t3.order_type = '2'  --授信
 left join odata.sllv_mb_acct t4
   on t3.loan_id=t4.cmisloan_no
  and t4.data_date='${DATA_DATE}'
  and t4.bddw_end_date='9999-99-99'
  and t4.prod_type in ('110115','110116')
left join odata.order_contract_sign t7
   on t3.loan_id=t7.loan_id
  and t7.data_date='${DATA_DATE}'
  and t7.bddw_end_date='9999-99-99'
  and t7.contract_type in (3) --担保合同
  --and t7.signer_type = 2 --签署人为担保人
left join odata.order_product_loan_info t5
   on t1.loan_id=t5.loan_id
  and t5.data_date='${DATA_DATE}'
  and t5.bddw_end_date='9999-99-99'
left join odata.order_custom_info t9
   on t3.loan_id=t9.loan_id
   and t9.data_date='${DATA_DATE}'
   and t9.bddw_end_date='9999-99-99'
left join (select 
                 credit_order_no ,
                 limit_begin_time ,
                 limit_end_time 
            from odata.limit_ps_product_limit 
           where data_date = '2023-06-07' 
             and bddw_end_date = '9999-99-99') t10
   on t3.loan_id = t10.credit_order_no
where t1.data_date='${DATA_DATE}'
  and t1.bddw_end_date='9999-99-99'
  --and substr(t3.apply_time,1,10)<='${DATA_DATE}'
  and t3.product_type='3'
  and t3.sub_product_type='3'
--锡机贷
 union all 
 select
	 /*+ REPARTITION(1) */
nvl(t4.branch,'100000')                                      as org_id                       --内部机构号       
,nvl(t1.id,'')                                               as guar_obj_no                  --担保物品编号   
,nvl(t7.contract_no,'')                                      as guar_cont_no                 --担保合同编码
,''                                                          as guar_cont_name               --担保合同名称     
,nvl(t2.machine_type,'')                                     as guar_obj_name                --担保物品名称
,nvl(t4.client_no,'')                                        as be_guar_cust_id              --被担保人客户号
,nvl(t9.user_name,'')                                        as be_guar_cust_name            --被担保人客户名称
,nvl(t1.product_type,'')                                     as guar_obj_type_code           --质或抵押物品类型代码  
,t1.assess_amount*10000                                      as guar_obj_value               --质或抵押物账面价值
,'CNY'                                                       as ccy                          --币种代码
,t1.assess_amount*10000                                      as estimate_value               --评估价值
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as estimate_date                --评估日期
,''                                                          as estimate_org_name            --评估机构名称   锡机贷评估机构名称是什么
,nvl(t5.mortgage_rate,'')                                    as guar_rate                    --质或抵押率    
,''                                                          as guar_obj_owner_name          --抵押物所有权人名称
,''                                                          as guar_obj_third_flag          --押品权属人是否第三方 
,''                                                          as guar_obj_owner_type_code     --押品权属人类型代码  
,''                                                          as owner_cert_type              --押品权属人证件类型代码  
,''                                                          as owner_cert_no                --押品权属人证件代码  
,0                                                           as have_guar_value              --已抵押价值  
,nvl(from_unixtime(unix_timestamp(substr(t2.create_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as regtd_date                    --登记日期  
,''                                                          as regtd_org_name               --登记机构名称  
,nvl(from_unixtime(unix_timestamp(t10.limit_begin_time,'yyyyMMdd'),'yyyy-MM-dd'),'')   as guar_start_date               --担保起始日期    
,nvl(from_unixtime(unix_timestamp(t10.limit_end_time,'yyyyMMdd'),'yyyy-MM-dd'),'')   as guar_mature_date                --担保到期日期      
,nvl(t2.vin_code,'')                                         as warrt_regtd_id               --权证登记号码      
,nvl(t2.manufacturer,'')                                     as warrt_regtd_name             --权证名称    
,''                                                          as warrt_regtd_expr_date        --权证到期日期  
,''                                                          as regtd_expr_date              --登记有效终止日期   
,nvl(from_unixtime(unix_timestamp(substr(t2.create_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as obj_coll_date                 --实物收取日期  
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as first_estimate_date          --首次评估日期  
,''                                                          as estimate_mature_date         --评估到期日期   
,case when t4.prod_type in ('110110','110122') and t16.loan_id is not null and t16.coll_type = '信用' then 'D'
	  when t4.prod_type in ('110110','110122') and t16.loan_id is not null and t16.coll_type = '保证' then 'C99'
	  when t4.prod_type in ('110110','110122') and t16.loan_id is null then 'Z'
	  when t4.prod_type in ('110129','110130') then 'C99' end
															 as guar_mode                    --担保方式类型代码  
,''                                                          as guar_obj_status              --担保物品状态代码  
,t1.assess_amount*10000                                      as first_estimate_value         --初次评估价值  
,''                                                          as estimate_org_type            --评估机构类型代码  
,''                                                          as estimate_way_code            --评估方式代码  
,''                                                          as colla_amt                    --优先受偿权数额 
,''                                                          as estimate_perod_code          --估值周期代码 
,''                                                          as warrt_regtd_area             --权证登记面积 
,''                                                          as disp_right_order             --处置权顺位 
,''                                                          as warrt_asset_no               --抵质押资产编号
,''                                                          as asset_issue_org_nm           --抵质押资产签发机构
from odata.pawn_pawn_base t1
 left join odata.pawn_pawn_machine t2
   on t1.id=t2.pawn_id
  and t2.data_date='${DATA_DATE}'
  and t2.bddw_end_date='9999-99-99'
 left join odata.order_main_loan_order t3
   on t3.loan_id=t1.loan_id
  and t3.data_date='${DATA_DATE}'
  and t3.bddw_end_date='9999-99-99'
 left join odata.sllv_mb_acct t4
   on t3.loan_id=t4.cmisloan_no
  and t4.data_date='${DATA_DATE}'
  and t4.bddw_end_date='9999-99-99'
  and t4.prod_type in ('110110','110122','110129','110130')
left join odata.order_contract_sign t7
   on t3.loan_id=t7.loan_id
  and t7.data_date='${DATA_DATE}'
  and t7.bddw_end_date='9999-99-99'
  and t7.contract_type=3 --担保合同
  and t7.signer_type = 2 --签署人为担保人
left join odata.order_product_loan_info t5
   on t3.loan_id=t5.loan_id
  and t5.data_date='${DATA_DATE}'
  and t5.bddw_end_date='9999-99-99'
left join odata.order_custom_info t9
   on t3.loan_id=t9.loan_id
   and t9.data_date='${DATA_DATE}'
   and t9.bddw_end_date='9999-99-99'
--锡机贷(非上牌车)担保方式逻辑(110122、110110)
left join (select 
				 credit_order_no ,
				 limit_begin_time ,
				 limit_end_time 
			from odata.limit_ps_product_limit 
		   where data_date = '2023-06-07' 
			 and bddw_end_date = '9999-99-99') t10
   on t1.loan_id = t10.credit_order_no
left join(select distinct a.loan_id
				 ,if(b.device_type='0' and c.loan_id is NULL, '信用', '保证')  as coll_type
			from odata.pawn_pawn_base a
	   left join odata.pawn_pawn_machine b
			  on a.id=b.pawn_id
			 and b.data_date='${DATA_DATE}'
			 and b.bddw_end_date='9999-99-99'
	   left join odata.order_contract_sign c
			  on a.loan_id=c.loan_id
			 and c.data_date='${DATA_DATE}'
			 and c.bddw_end_date='9999-99-99'
			 and c.contract_type in ('3','4')
		   where a.data_date='${DATA_DATE}'
			 and a.bddw_end_date='9999-99-99') t16
	   on t3.loan_id = t16.loan_id
where t1.data_date='${DATA_DATE}'
  and t1.bddw_end_date='9999-99-99'
  --and substr(t3.apply_time,1,10)<='${DATA_DATE}'
  and t3.product_type='2'
union all
--铁甲
select
    /*+ REPARTITION(1) */
nvl(t4.branch,'100000')                                      as org_id                       --内部机构号       
,nvl(t1.id,'')                                               as guar_obj_no                  --担保物品编号   
,nvl(t7.contract_no,'')                                      as guar_cont_no                 --担保合同编码
,''                                                          as guar_cont_name               --担保合同名称     
,nvl(t2.machine_type,'')                                     as guar_obj_name                --担保物品名称
,nvl(t4.client_no,'')                                        as be_guar_cust_id              --被担保人客户号
,nvl(t9.user_name,'')                                        as be_guar_cust_name            --被担保人客户名称
,nvl(t1.product_type,'')                                     as guar_obj_type_code           --质或抵押物品类型代码  
,t1.assess_amount                                            as guar_obj_value               --质或抵押物账面价值
,'CNY'                                                       as ccy                          --币种代码
,t1.assess_amount                                            as estimate_value               --评估价值
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as estimate_date                --评估日期
,''                                                          as estimate_org_name            --评估机构名称   锡机贷评估机构名称是什么
,nvl(t5.mortgage_rate,'')                                    as guar_rate                    --质或抵押率    
,''                                                          as guar_obj_owner_name          --抵押物所有权人名称
,''                                                          as guar_obj_third_flag          --押品权属人是否第三方 
,''                                                          as guar_obj_owner_type_code     --押品权属人类型代码  
,''                                                          as owner_cert_type              --押品权属人证件类型代码  
,''                                                          as owner_cert_no                --押品权属人证件代码  
,0                                                           as have_guar_value              --已抵押价值  
,nvl(from_unixtime(unix_timestamp(substr(t2.create_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as regtd_date                    --登记日期  
,''                                                          as regtd_org_name               --登记机构名称  
,nvl(from_unixtime(unix_timestamp(t10.limit_begin_time,'yyyyMMdd'),'yyyy-MM-dd'),'')   as guar_start_date               --担保起始日期    
,nvl(from_unixtime(unix_timestamp(t10.limit_end_time,'yyyyMMdd'),'yyyy-MM-dd'),'')   as guar_mature_date                --担保到期日期      
,nvl(t2.vin_code,'')                                         as warrt_regtd_id               --权证登记号码      
,nvl(t2.manufacturer,'')                                     as warrt_regtd_name             --权证名称    
,''                                                          as warrt_regtd_expr_date        --权证到期日期  
,''                                                          as regtd_expr_date              --登记有效终止日期   
,nvl(from_unixtime(unix_timestamp(substr(t2.create_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as obj_coll_date                 --实物收取日期  
,nvl(from_unixtime(unix_timestamp(substr(t1.assess_time,1,10),'yyyyMMdd'),'yyyy-MM-dd'),'')                         as first_estimate_date          --首次评估日期  
,''                                                          as estimate_mature_date         --评估到期日期   
,'A'                                                         as guar_mode                    --担保方式类型代码  
,''                                                          as guar_obj_status              --担保物品状态代码  
,t1.assess_amount                                            as first_estimate_value         --初次评估价值  
,''                                                          as estimate_org_type            --评估机构类型代码  
,''                                                          as estimate_way_code            --评估方式代码  
,''                                                          as colla_amt                    --优先受偿权数额 
,''                                                          as estimate_perod_code          --估值周期代码 
,''                                                          as warrt_regtd_area             --权证登记面积 
,''                                                          as disp_right_order             --处置权顺位 
,''                                                          as warrt_asset_no               --抵质押资产编号
,''                                                          as asset_issue_org_nm           --抵质押资产签发机构
from odata.pawn_pawn_base t1
 left join odata.pawn_pawn_machine t2
   on t1.id=t2.pawn_id
  and t2.data_date='${DATA_DATE}'
  and t2.bddw_end_date='9999-99-99'
 left join odata.order_main_loan_order t3
   on t3.loan_id=t1.loan_id
  and t3.data_date='${DATA_DATE}'
  and t3.bddw_end_date='9999-99-99'
 left join odata.order_main_credit_order t31
   on t3.credit_order_id=t31.loan_id
  and t31.data_date='${DATA_DATE}'
  and t31.bddw_end_date='9999-99-99'
 left join odata.sllv_mb_acct t4
   on t3.loan_id=t4.cmisloan_no
  and t4.data_date='${DATA_DATE}'
  and t4.bddw_end_date='9999-99-99'
  and t4.prod_type in ('110151')
left join odata.order_product_loan_info t5
   on t3.loan_id=t5.loan_id
  and t5.data_date='${DATA_DATE}'
  and t5.bddw_end_date='9999-99-99'
left join odata.order_custom_info t9
   on t3.loan_id=t9.loan_id
   and t9.data_date='${DATA_DATE}'
   and t9.bddw_end_date='9999-99-99'
left join odata.order_contract_sign t7
   on t3.loan_id=t7.loan_id
  and t7.data_date='${DATA_DATE}'
  and t7.bddw_end_date='9999-99-99'
  and t7.contract_type=4 --担保公司担保合同
  and t7.sign_id_card = t9.id_card 
left join (select 
                 credit_order_no ,
                 limit_begin_time ,
                 limit_end_time 
            from odata.limit_ps_product_limit 
           where data_date = '2023-06-07' 
             and bddw_end_date = '9999-99-99') t10
   on t31.loan_id = t10.credit_order_no
where t1.data_date='${DATA_DATE}'
  and t1.bddw_end_date='9999-99-99'
  --and substr(t3.apply_time,1,10)<='${DATA_DATE}'
  and t3.product_type='12'
  and t3.sub_product_type='18'