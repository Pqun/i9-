--2.yangqihao.dwd_e_loan_corp_payment_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：对公贷款支付交易表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive dwd层dwd.dwd_e_loan_corp_payment_p
--作    者：杨琦浩
--开发日期：2023-02-24
--直属经理：方杰
--来源表  ：odata.als_payment_info 受托支付信息表
--来源表  ：odata.als_business_duebill 业务借据(账户)信息表
--来源表  ：odata.als_business_contract 业务合同信息表
--来源表  ：odata.supacct_enterprise_loan_info 借据信息表
--来源表  ：odata.suporder_scp_payment_record 支付记录表
--来源表  ：odata.suporder_scp_sub_order 子订单信息
--来源表  ：odata.suporder_scp_sub_order_payee_account 收款方账号信息
--来源表  ：odata.va_am_aa_maint_hist 账户间关系修改历史表
--来源表  ：odata.va_am_bank_acct 银行一类账户
--目标表  ：dwd.dwd_e_loan_corp_payment_p
--修改历史：
--          1.杨琦浩   2023-02-24    新建
--          2.杨琦浩   2023-09-08    拆分为信贷、供应链实、虚账户
--          3.杨琦浩   2023-09-25    放款金额做转换操作
--          4.杨琦浩   2023-10-09    调整供应链贷款合同号取数逻辑
--          5.杨琦浩   2023-10-11    调整供应链虚账户类信息取数逻辑
--          6.杨琦浩   2024-01-22    剔除药师帮个人产品
--          7.杨琦浩   2024-03-20    新增锡享贷产品
--          8.姚威     2024-05-14    新增孚厘企业贷
--------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_loan_corp_payment_p partition(data_date = '${DATA_DATE}')
------------------------------------------------信贷--------------------------------------------------
    select /*+ REPARTITION(1) */
            nvl(t1.serialno,'')                                                                                       as tran_seqno              --支付流水号
            ,nvl(t2.serialno,'')                                                                                      as cont_no                 --贷款合同号
            ,nvl(t3.serialno,'')                                                                                      as bill_no                 --借据号
            ,nvl(t1.customerid,'')                                                                                    as cust_id                 --客户号
            ,nvl(t1.customername,'')                                                                                  as cust_name               --客户名称
            ,nvl(regexp_replace(t1.paymentdate,'/','-'),'')                                                           as tran_date               --交易日期
            ,case when t1.paymentmode='020' then 2 else 1 end                                                         as payment_mode            --支付方式
            ,nvl(t1.paymentstatus,'')                                                                                 as tran_status             --交易状态
            ,nvl(cast(t3.businesssum as string),0)                                                                    as loan_amt                --放款金额 
            ,nvl(t4.paymentsum,0)                                                                                     as tran_amt                --交易金额
            ,coalesce(t1.payeeaccount,t1.oldpayeeaccount,'')                                                          as entrusted_pay_acct_no   --受托支付对象账号
            ,case when t1.payeeaccount is not null then nvl(t1.payeename,'')
                  when t1.oldpayeeaccount is not null then nvl(t1.oldpayeename,'')
                  else ''
             end                                                                                                      as entrusted_pay_acct_name --受托支付对象户名
            ,case when t1.payeeaccount is not null then nvl(case when length(t1.payeebankno)=12 then t1.payeebankno else '' end,'')
                  when t1.oldpayeeaccount is not null then nvl(case when length(t1.oldpayeebankno)=12 then t1.oldpayeebankno else '' end,'')
                  else ''
             end                                                                                                      as entrusted_pay_bank_no   --受托支付对象行号
            ,case when t1.payeeaccount is not null then nvl(if(t1.payeebankno='314305679000','张家港农村商业银行大新支行',t1.payeebank),'')
                  when t1.oldpayeeaccount is not null then nvl(t1.oldpayeebank,'')
                  else ''
             end                                                                                                      as entrusted_pay_bank_name --受托支付对象行名 该行号部分数据只显示农村商业银行
    from odata.als_payment_info t1             --受托支付信息表
    left join odata.als_business_duebill  t3   --业务借据(账户)信息表
        on t1.putoutserialno=t3.relativeserialno1
        and t3.data_date='${DATA_DATE}' 
        and t3.bddw_end_date='9999-99-99' 
    inner join odata.als_payment_info t4       --因为受托支付信息表 2022-05-12之前的部分金额多了两位，所以之前的用2022-05-12的金额
        on t4.data_date=if ('${DATA_DATE}' <'2022-05-12','2022-05-12','${DATA_DATE}')
        and t4.bddw_end_date='9999-99-99' 
        and t1.serialno=t4.serialno
    inner join odata.als_business_contract t2   --业务合同信息表
        on t3.relativeserialno2=t2.serialno
        and t2.data_date='${DATA_DATE}' 
        and t2.bddw_end_date='9999-99-99'
        and t2.paymentmode = '020'  --受托支付
    left join odata.supacct_enterprise_loan_info t5
        on t3.serialno=t5.iou_no
        and t5.data_date='${DATA_DATE}' 
        and t5.bddw_end_date='9999-99-99'
    where t1.data_date='${DATA_DATE}' 
      and t1.bddw_end_date='9999-99-99' 
      and t1.paymentstatus is not null --为null是做了放款申请，没做受托支付申请
      and t3.businesssum<>0 --businesssum为0时是冲正数据
      and t5.iou_no is null 
    ---------------------------------------------供应链实账户--------------------------------------------------
union all 
    select /*+ REPARTITION(1) */
             nvl(e.reference,'')                                                                                      as tran_seqno              --支付流水号                
            ,nvl(g.relativeserialno2,'')                                                                              as cont_no                 --贷款合同号                   
            ,nvl(a.cmisloan_no,'')                                                                                    as bill_no                 --借据号                     
            ,nvl(a.client_no,'')                                                                                      as cust_id                 --客户号                     
            ,nvl(f.ch_client_name,'')                                                                                 as cust_name               --客户名称                  
            ,nvl(from_unixtime(unix_timestamp(substr(b.tran_timestamp,1,8),'yyyyMMdd'),'yyyy-MM-dd'),'')              as tran_date               --交易日期                  
            ,'2'                                                                                                      as payment_mode            --支付方式               
            ,case when e.tran_status='N' then '020'                                                                      
                when e.tran_status='X' then '030'                                                                                    
                else ''                                                                                               
             end                                                                                                      as tran_status             --交易状态    --支付成功              
            ,nvl(cast (d.total_amount as string),0)                                                                   as loan_amt                --放款金额    --X:冲销 030：支付失败        
            ,nvl(b.settle_amt,0)                                                                                      as tran_amt                --交易金额                           
            ,nvl(b.settle_base_acct_no,'')                                                                            as entrusted_pay_acct_no   --受托支付对象账号          
            ,nvl(b.settle_acct_name,'')                                                                               as entrusted_pay_acct_name --受托支付对象户名        
            ,nvl(case when length(b.payee_bank_code)=12 then b.payee_bank_code else '' end,'')                        as entrusted_pay_bank_no   --受托支付对象行号          
            ,nvl(if(b.payee_bank_code='314305679000','张家港农村商业银行大新支行',b.payee_bank_name),'')              as entrusted_pay_bank_name 
            --受托支付对象行名           
    from odata.sym_mb_acct a 
    inner join odata.sym_mb_acct_settle b 
        on a.internal_key=b.internal_key
        and b.event_type='DRW' --放款
        and b.settle_acct_class='TPP' --实际结算账户
        and b.trusted_pay_no is not null 
        and b.data_date='${DATA_DATE}'
        and b.bddw_end_date='9999-99-99'
    inner join odata.supacct_enterprise_loan_info c
        on a.cmisloan_no = c.iou_no
        and c.data_date='${DATA_DATE}'
        and c.bddw_end_date='9999-99-99'
    left join odata.sym_mb_acct_balance d 
        on a.internal_key=d.internal_key
        and d.amt_type='DDA'
        and d.data_date='${DATA_DATE}'
        and d.bddw_end_date='9999-99-99'
    left join odata.sym_mb_tran_hist e 
        on a.internal_key=e.internal_key
        and e.tran_type = 'DRW1'
        and e.data_date='${DATA_DATE}'
        and e.bddw_end_date='9999-99-99'
    left join odata.sym_cif_client f 
        on a.client_no=f.client_no
        and f.data_date='${DATA_DATE}'
        and f.bddw_end_date='9999-99-99'
    left join odata.als_business_duebill g 
        on c.iou_no=g.serialno
        and g.data_date='${DATA_DATE}'
        and g.bddw_end_date='9999-99-99'
    where a.data_date='${DATA_DATE}'
      and a.bddw_end_date='9999-99-99'
      and a.lead_acct_flag='N'
      and a.prod_type not in ('110150','110184')
      and (nvl(c.account_type,'')<>'VIRTUAL' ) 
    ----------------------------------------------供应链虚账户---------------------------------------------
union all 
    select  /*+ REPARTITION(1) */
             nvl(a.loan_serial_no,'')                                                                                as tran_seqno              --支付流水号                     
            ,nvl(h.relativeserialno2,'')                                                                            as cont_no                 --贷款合同号      
            ,nvl(a.iou_no,'')                                                                                       as bill_no                 --借据号        
            ,nvl(a.cust_id,'')                                                                                      as cust_id                 --客户号        
            ,nvl(a.cust_name,'')                                                                                    as cust_name               --客户名称     
            ,nvl(substr(b.payment_time,1,10),'')                                                                    as tran_date               --交易日期     
            ,2                                                                                                      as payment_mode            --支付方式  
            ,case when b.payment_status in('01','05') then '010' --待支付                                           
                when b.payment_status='10' then '020' --支付成功                                                    
                when b.payment_status='09' then '030' --支付失败                                                    
                else ''                                                                                             
             end                                                                                                    as tran_status             --交易状态    --支付成功             
            --,nvl(a.loan_amount ,0)                                                                                       
            ,cast (nvl(a.loan_amount,0) as decimal(24,6))/100                                                       as loan_amt                --放款金额    --X:冲销 030：支付失败       
            ,coalesce(b.credit_payment_amount,b.total_payment_amount,0)/100                                         as tran_amt                --交易金额                              
            ,coalesce(e.linked_base_acct_no,d.payee_account,'')                                                     as entrusted_pay_acct_no   --受托支付对象账号             
            ,case when e.linked_base_acct_no is not null then nvl(e.linked_acct_name,'')
                  when d.payee_account is not null then nvl(d.payee_name,'')
                  else ''
             end                                                 as entrusted_pay_acct_name --受托支付对象户名
            ,case when e.linked_base_acct_no is not null then nvl(case when length(f.bank_code)=12 then f.bank_code else '' end,'')
                  when d.payee_account is not null then nvl(case when length(d.payee_bank_code)=12 then d.payee_bank_code else '' end,'')
                  else ''
             end                                                 as entrusted_pay_bank_no   --受托支付对象行号
            ,case when e.linked_base_acct_no is not null then nvl(f.bank_name,'')
                  when d.payee_account is not null then nvl(d.payee_bank_name,'')
                  else ''
             end                                                 as entrusted_pay_bank_name --受托支付对象行名
    from  odata.supacct_enterprise_loan_info a
    left join odata.suporder_scp_payment_record b 
        on a.pay_order_no  = b.payment_no 
        and b.data_date='${DATA_DATE}'
        and b.bddw_end_date='9999-99-99'
    left join odata.suporder_scp_sub_order c 
        on b.sub_order_no  = c.sub_order_no 
        and c.data_date='${DATA_DATE}'
        and c.bddw_end_date='9999-99-99'
    left join odata.suporder_scp_sub_order_payee_account d
        on b.sub_order_no  = d.sub_order_no 
        and d.data_date='${DATA_DATE}'
        and d.bddw_end_date='9999-99-99'
    left join (
                select t.base_acct_no
                      ,t.linked_base_acct_no
                      ,t.linked_acct_name 
                      ,t.iou_no
                      from 
                          (
                           select
                            c.base_acct_no
                           ,c.linked_base_acct_no
                           ,a.linked_acct_name
                           ,g.iou_no
                           ,row_number() over(partition by a.base_acct_no,g.iou_no order by abs(unix_timestamp(nvl(f.time_stamp,concat(substr(a.tran_date,1,10),' 00:00:00')))-unix_timestamp(concat((regexp_replace(h.putoutdate,'/','-')),' 00:00:00')))) rn
                from odata.va_am_aa_maint_hist a 
                left join (
                           select base_acct_no 
                           from odata.va_va_loan_acct
                           where data_date='${DATA_DATE}' 
                           and bddw_end_date='9999-99-99'
                           union all 
                           select base_acct_no 
                           from odata.va_va_acct
                           where data_date='${DATA_DATE}' 
                           and bddw_end_date='9999-99-99'
                           ) b 
                on a.linked_base_acct_no=b.base_acct_no
                inner join (
                            select base_acct_no
                                   ,linked_base_acct_no
                            from odata.va_am_rel_acct_acct
                            where data_date='${DATA_DATE}' 
                            and bddw_end_date='9999-99-99'
                            --and linked_status='A'
                            group by base_acct_no
                            ,linked_base_acct_no
                            ) c  
                on a.base_acct_no=c.base_acct_no
                and a.linked_base_acct_no=c.linked_base_acct_no
                left join odata.va_cm_tran_comm f
                on a.main_seq_no=f.main_seq_no
                and f.data_date=if ('${DATA_DATE}' <'2023-10-11','2023-10-11','${DATA_DATE}') --20231011之前数据不全
                and f.bddw_end_date='9999-99-99'
                left join odata.suporder_scp_sub_order_payee_account d
                on c.base_acct_no  = d.payee_account 
                and d.data_date='${DATA_DATE}'
                and d.bddw_end_date='9999-99-99'
                left join odata.suporder_scp_payment_record e 
                on d.sub_order_no  = e.sub_order_no 
                and e.data_date='${DATA_DATE}'
                and e.bddw_end_date='9999-99-99'
                left join odata.supacct_enterprise_loan_info g
                on e.payment_no=g.pay_order_no
                and g.data_date='${DATA_DATE}' 
                and g.bddw_end_date='9999-99-99'
                left join odata.als_business_duebill h
                on g.iou_no=h.serialno
                and h.data_date='${DATA_DATE}' 
                and h.bddw_end_date='9999-99-99'
                left join 
                          (
                           select   base_acct_no
                                   ,bank_code
                                   ,bank_name
                                   ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
                           from odata.va_am_bank_acct
                           where data_date='${DATA_DATE}'
                             and bddw_end_date='9999-99-99'
                             and acct_status='A'
                           ) i
                on c.linked_base_acct_no=i.base_acct_no
                and i.rn=1
                where a.data_date='${DATA_DATE}' 
                and a.bddw_end_date='9999-99-99'
                and b.base_acct_no is null
                and g.iou_no is not null 
                and length(i.bank_code)=12
                                      ) t 
                          where t.rn =1
                ) e 
        on d.payee_account  = e.base_acct_no 
        and a.iou_no=e.iou_no
    left join (
                select   base_acct_no
                        ,bank_code
                        ,bank_name
                        ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
                from odata.va_am_bank_acct
                where data_date='${DATA_DATE}'
                    and bddw_end_date='9999-99-99'
                    and acct_status='A'
            ) f
        on e.linked_base_acct_no = f.base_acct_no 
        and f.rn=1
    left join odata.sym_mb_acct g 
        on a.iou_no =g.cmisloan_no 
        and g.data_date='${DATA_DATE}'
        and g.bddw_end_date='9999-99-99' 
        and g.lead_acct_flag='N'
    left join odata.als_business_duebill h
        on a.iou_no=h.serialno
        and h.data_date='${DATA_DATE}'
        and h.bddw_end_date='9999-99-99'
    where a.data_date='${DATA_DATE}' 
        and a.bddw_end_date='9999-99-99' 
        and a.pay_type ='02' 
        and a.account_type='VIRTUAL'
        and nvl(g.prod_type,'') not in ('110150','110184')
        and a.status<>'01' --失败
    ----------------------------------------------锡享贷---------------------------------------------
union all 
select /*+ REPARTITION(1) */
            reference                    as tran_seq_no             --支付流水号
            ,trim(cont_no)               as cont_no                 --贷款合同号
            ,bill_no                     as bill_no                 --借据号
            ,cust_id                     as cust_id                 --客户号
            ,cust_name                   as cust_name               --客户名称
            ,loan_time                   as tran_date               --交易日期
            ,'2'                         as payment_mode            --支付方式
            ,tran_status                 as tran_status             --交易状态
            ,loam_amt                    as loan_amt                --放款金额
            ,tran_amt                    as tran_amt                --交易金额
            ,entrusted_pay_acct_no       as entrusted_pay_acct_no   --受托支付对象账号
            ,entrusted_pay_acct_name     as entrusted_pay_acct_name --受托支付对象户名         
            ,entrusted_pay_bank_no       as entrusted_pay_bank_no   --受托支付对象行号           
            ,entrusted_pay_bank_name     as entrusted_pay_bank_name --受托支付对象行名         
     from ( 
                select   nvl(t9.reference,'')   as reference
                        ,coalesce(t62.contract_no,'') 
                                                as cont_no      --贷款合同号
                        ,nvl(t1.cmisloan_no,'') as bill_no      --借据号
                        ,nvl(t1.client_no,'')   as cust_id      --客户号
                        ,nvl(t3.ch_client_name,'') 
                                                as cust_name    --客户名称
                        ,nvl(t2.total_amount,0) as loam_amt     --贷款金额
                        ,nvl(t2.total_amount,0) as tran_amt     --交易金额
                        ,nvl(substr(t14.loan_time,1,10),'') 
                                                as loan_time    --交易日期
                        ,nvl(t28.account_no,'') as entrusted_pay_acct_no --受托支付对象账号
                        ,nvl(t28.payee_name,'') as entrusted_pay_acct_name --受托支付对象户名
                        ,nvl(t28.bank_name_code,'') 
                                                as entrusted_pay_bank_no --受托支付对象行号
                        ,nvl(t28.bank_name,'')  as entrusted_pay_bank_name --受托支付对象行名
                        ,coalesce(t25.payment_mode,t28.payment_mode,'') 
                                                as payment_mode --支付方式
                        ,nvl(t9.tran_status,'') as tran_status
                        ,nvl(t1.prod_type,'')   as prod_type
                from odata.sllv_mb_acct t1
                left join odata.sym_cif_client t3
                    on t1.client_no=t3.client_no
                    and t3.data_date='${DATA_DATE}'
                    and t3.bddw_end_date='9999-99-99'
                left join (  
                            select  a.loan_id
                                   ,a.sub_product_type
                                   ,a.status
                                   ,a.xsbank_salesman
                                   ,a.product_type
                                   ,a.credit_order_id
                                   ,a.loan_time
                            from odata.order_main_loan_order a
                            where a.data_date = '${DATA_DATE}'
                              and a.bddw_end_date = '9999-99-99'
                              and order_type='2'
                           ) t14
                    on t1.cmisloan_no = t14.loan_id
                left join odata.order_product_loan_info t25             --与借据关联 产品贷款信息
                    on t14.loan_id=t25.loan_id
                    and t25.data_date='${DATA_DATE}' 
                    and t25.bddw_end_date='9999-99-99'
                left join odata.order_bank_account_info t28
                    on trim(t1.cmisloan_no)=trim(t28.loan_id) 
                    and t28.data_date='${DATA_DATE}' 
                    and t28.bddw_end_date='9999-99-99' 
                left join odata.xscontract_business_contract_records t62
                    on t14.loan_id = t62.loan_id
                    and t62.data_date = '${DATA_DATE}'
                    and t62.bddw_end_date = '9999-99-99'
                    and t62.contract_type = '41'
                    and nvl(t62.status,'') ='1'
                left join odata.sllv_mb_acct_balance t2 
                    on t1.internal_key=t2.internal_key
                    and t2.amt_type='DDA'
                    and t2.data_date='${DATA_DATE}'
                    and t2.bddw_end_date='9999-99-99'
                left join odata.sllv_mb_tran_hist t9
                    on t1.internal_key=t9.internal_key
                    and t9.tran_type = 'DRW1'
                    and t9.data_date='${DATA_DATE}'
                    and t9.bddw_end_date='9999-99-99'
                where t1.data_date='${DATA_DATE}'
                and t1.bddw_end_date='9999-99-99'
                and from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd') <= '${DATA_DATE}'
                and nvl(t1.acct_close_reason,'')<>'发放冲正'
                and nvl(t1.prod_type,'') in('120113','120115')
     )a 
    where a.payment_mode='2' 