---------------------------------------------------------------------------------------------------------------
--脚本名称：授信合同表dwd.dwd_d_crdt_cont_p取数逻辑.sql
--功能描述：生成每日结果数据并插入hive smart层dwd.dwd_d_crdt_cont_p分区表
--作    者：吴龙昊
--开发日期：2020-12-30
--直属经理：程宏明
--来源表  :odata.als_business_contract            业务合同信息表
--来源表  :odata.als_customer_info                客户基本信息表
--来源表  :odata.als_business_approve             业务批准信息表
--来源表  :odata.ols_crd_cont_info                授信合同信息表
--来源表  :odata.ols_loan_prd_info                贷款产品信息表
--来源表  :odata.ols_admin_sm_user                系统用户表
--来源表  :odata.order_main_loan_order            订单主表
--来源表  :odata.order_product_loan_info          产品贷款信息
--来源表  :odata.order_credit_order_info          授信信息表
--来源表  :odata.order_custom_info                客户信息表
--来源表  :odata.order_order_audit_operation_log  订单审核操作日志记录表
--来源表  :odata.order_audit_result_info          审批结果信息录入
--来源表  :odata.sllv_nl_acct                     线上贷款账户基本信息表
--来源表  :odata.sllv_mb_acct                     账户基本信息表
--来源表  :odata.sym_cif_client                   客户信息表
--来源表  :odata.sym_cif_client_document          客户证件信息
--来源表  :odata.sso_upms_user                    历史流程实例表
--目标表  :dwd.dwd_d_crdt_cont_p                授信合同表
--修改历史：
--          1.吴龙昊   2020-12-30    新建

---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_d_crdt_cont_p partition(data_date='${DATA_DATE}')
select
 a.serialno                             as crdt_cont_no          --授信合同编号
,'01'                                   as cust_type             --客户类型
,a.customerid                           as cust_id               --客户号
,a.customername                         as cust_name             --客户姓名
,a.businesstype                         as prod_code             --产品编号
,d.typename                             as prod_name             --产品名称
,b.certtype                             as cert_type             --证件类型
,b.certid                               as cert_no               --证件号码
,case when a.creditcycle ='1' then  '01'--是
      else '02'                         --否
      end                               as cycle_flag            --循环标识
,case when a.businesscurrency = '01' then 'CNY'
      else a.businesscurrency end       as ccy                   --币种
,a.businesssum                          as crdt_limit            --授信额度
,a.termmonth                            as crdt_term             --授信期限
,regexp_replace(a.putoutdate,'/','-')   as crdt_start_date       --授信起始日期
,regexp_replace(a.maturity,'/','-')     as crdt_mature_date      --授信到期日期
,case when a.status = 'EFFECTIVE' then '01' --有效
      else '02'                             --无效
      end                               as crdt_status           --授信状态
,regexp_replace(a.occurdate,'/','-')    as app_date              --申请日期
,a.status                               as cont_status           --合同状态
,c.operateuserid                        as approver              --审批人
,c.approveopinion                       as approve_opinion       --审批意见
,null                                   as remark1              --保留字段1
,null                                   as remark2              --保留字段2
,null                                   as remark3              --保留字段3
,null                                   as remark4              --保留字段4
,null                                   as remark5              --保留字段5
from odata.als_business_contract a
left join odata.als_customer_info b
       on a.customerid = b.customerid
      and b.data_date = '${DATA_DATE}'
      and b.bddw_end_date='9999-99-99'
left join odata.als_business_approve c
       on a.relativeserialno = c.serialno
      and c.data_date = '${DATA_DATE}'
      and c.bddw_end_date='9999-99-99'
left join odata.als_business_type d
       on a.businesstype = d.typeno
      and d.data_date = '${DATA_DATE}'
      and d.bddw_end_date='9999-99-99'
    where a.data_date = '${DATA_DATE}'
      and a.bddw_end_date='9999-99-99'
      and a.businesstype like '3%'    --3开头的为授信类合同

union all
--网贷
select
 t1.crd_cont_no                         as crdt_cont_no         --授信合同编号
,'02'                                   as cust_type            --客户类型
,t1.cust_id_core                        as cust_id              --客户号
,t1.cust_name                           as cust_name            --客户姓名
,case when t1.prd_code = '10031001001' then '110106'  --lz
      when t1.prd_code = '10101001001' then '110117'  --51rpd
      when t1.prd_code = '10091001001' then '110114'  --dxm
      when t1.prd_code = '10011001003' then '110104'  --jdjt
      when t1.prd_code = '10051001001' then '110109'  --sh
      when t1.prd_code = '10021001001' then '110105'  --sjyh
      when t1.prd_code = '10081001001' then '110111'  --xh
      when t1.prd_code = '10111001001' then '110126'  --xm
      when t1.prd_code = '10061001001' then '110112'  --xy
      when t1.prd_code = '10071001001' then '110113'  --yqg
      when t1.prd_code = '10091004002' then '110128'  --bdzz
      end                               as prod_code            --产品编号
,t2.prd_name                            as prod_name            --产品名称
,t1.cert_type                           as cert_type            --证件类型
,t1.cert_code                           as cert_no              --证件号码
,case when t1.cycle_flag = 'Y' then '01' --是
      when t1.cycle_flag = 'N' then '02' --否
      end                               as cycle_flag           --循环标识
,'CNY'                                  as ccy                  --币种
,t1.crd_amt                             as crdt_limit           --授信额度
,t1.crd_term                            as crdt_term            --授信期限
,t1.crd_start_date                      as crdt_start_date      --授信起始日期
,t1.crd_end_date                        as crdt_mature_date     --授信到期日期
,case when t1.cont_status in ('103','105') then '01' --有效
      else '02'                                      --无效
      end                               as crdt_status          --授信状态(103,105:有效,其他无效)
,substr(t1.sign_time,1,10)              as app_date             --申请日期
,t1.cont_status                         as cont_status          --合同状态
,t3.user_name                           as approver             --审批人
,case when trim(t1.cont_status) in ('103','104','105') then '通过'
      else null end                     as approve_opinion      --审批意见
,null                                   as remark1              --保留字段1
,null                                   as remark2              --保留字段2
,null                                   as remark3              --保留字段3
,null                                   as remark4              --保留字段4
,null                                   as remark5              --保留字段5
from odata.ols_crd_cont_info t1
left join odata.ols_loan_prd_info t2
       on trim(t1.prd_code) = trim(t2.loan_no)
      and t2.data_date = '${DATA_DATE}'
      and t2.bddw_end_date = '9999-99-99'
left join odata.ols_admin_sm_user t3
       on t1.biz_manager_id = t3.login_code
      and t3.data_date='${DATA_DATE}'
      and t3.bddw_end_date = '9999-99-99'
    where t1.data_date = '${DATA_DATE}'
      and t1.bddw_end_date = '9999-99-99'
      and t1.prd_code in ('10031001001',  --lz
                          '10101001001',  --51rpd
                          '10091001001',  --dxm
                          '10011001003',  --jdjt
                          '10051001001',  --sh
                          '10021001001',  --sjyh
                          '10081001001',  --xh
                          '10111001001',  --xm
                          '10061001001',  --xy
                          '10071001001',  --yqg
                          '10091004002'   --bdzz
                          )
      and trim(t1.cont_status) in ('103','104','105')
      and substr(t1.input_time,1,10) <= '${DATA_DATE}'

union all
--长安新生
select
 t1.apply_no                            as crdt_cont_no         --授信合同编号
,'02'                                   as cust_type            --客户类型
,t2.client_no                           as cust_id              --客户号
,t3.user_name                           as cust_name            --客户姓名
,t2.prod_type                           as prod_code            --产品编号
,'长安新生'                             as prod_name            --产品名称
,t7.document_type                       as cert_type            --证件类型
,t7.document_id                         as cert_no              --证件号码
,'02'                                   as cycle_flag           --循环标识(01-循环，02-非循环)
,'CNY'                                  as ccy                  --币种
,t4.audit_amount                        as crdt_limit           --授信额度
,null                                   as crdt_term            --授信期限
,substr(t2.acct_open_date,1,10)         as crdt_start_date      --授信起始日期
,substr(t2.maturity_date,1,10)          as crdt_mature_date     --授信到期日期
,case when t2.acct_status != 'C'  then '01' --有效
      else '02'                             --无效
      end                               as crdt_status          --授信状态
,substr(t1.apply_time,1,10)             as app_date             --申请日期
,t1.status                              as cont_status          --合同状态
,t6.realname                            as approver             --审批人
,case when t5.process_result = '1'  then '通过'
      when t5.process_result = '2'  then '回退'
      when t5.process_result = '-1' then '拒绝'
      when t5.process_result = '-1' then '取消'
      end                               as approve_opinion      --审批意见(1:通过 2:回退 -1:拒绝 -2:取消)
,null                                   as remark1              --保留字段1
,null                                   as remark2              --保留字段2
,null                                   as remark3              --保留字段3
,null                                   as remark4              --保留字段4
,null                                   as remark5              --保留字段5
from odata.order_main_loan_order t1
inner join odata.sllv_nl_acct t2
        on t1.receipt_no = t2.cmisloan_no
       and t2.prod_type in ('110118','110119','110127')
       and t2.data_date ='${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99'
 left join odata.order_custom_info t3
        on t1.loan_id = t3.loan_id
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
 left join(select  loan_id
                  ,audit_amount
                  ,row_number() over(partition by loan_id order by modified_time desc) as rownum
             from odata.order_audit_result_info
            where data_date='${DATA_DATE}'
              and bddw_end_date = '9999-99-99')t4
               on t1.loan_id = t4.loan_id
              and t4.rownum = 1
 left join(select  loan_id
                  ,processor
                  ,process_result
                  ,row_number() over(partition by loan_id order by process_time desc) as seq
             from odata.order_order_audit_operation_log
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99')t5
        on t1.loan_id=t5.loan_id
       and t5.seq = 1
 left join odata.sso_upms_user t6
        on t5.processor = t6.user_id
       and t6.data_date = '${DATA_DATE}'
       and t6.bddw_end_date = '9999-99-99'
 left join odata.sym_cif_client_document t7
       on t2.client_no = t7.client_no
      and t7.data_date = '${DATA_DATE}'
      and t7.bddw_end_date = '9999-99-99'
    where t1.data_date = '${DATA_DATE}'
      and t1.bddw_end_date = '9999-99-99'
      and t1.product_type = '4'
      and t1.sub_product_type = '7'
      and t1.status in (7,8,9,10)

union all
--车商贷
--车商贷在授信阶段区分不出具体是免征还是非免征
select
 t1.apply_no                                 as crdt_cont_no         --授信合同编号
,'02'                                        as cust_type            --客户类型
,t2.client_no                                as cust_id              --客户号
,t3.user_name                                as cust_name            --客户姓名
,'110120'                                    as prod_code            --产品编号
,'车商贷'                                    as prod_name            --产品名称
,t5.document_type                            as cert_type            --证件类型
,t5.document_id                              as cert_no              --证件号码
,'02'                                        as cycle_flag           --循环标识(01-循环，02-非循环)
,'CNY'                                       as ccy                  --币种
,t4.credit_line                              as crdt_limit           --授信额度
,null                                        as crdt_term            --授信期限
,substr(t4.credit_start_time,1,10)           as crdt_start_date      --授信起始日期
,substr(t4.credit_end_time,1,10)             as crdt_mature_date     --授信到期日期
,case when t4.credit_status = '1' then '01'   --有效
      when t4.credit_status = '2' then '02'   --无效
     end                                     as crdt_status          --授信状态
,substr(t1.apply_time,1,10)                  as sign_date            --签订日期
,t1.status                                   as cont_status          --合同状态
,t7.realname                                 as approver             --审批人
,case when t6.process_result = '1'  then '通过'
      when t6.process_result = '2'  then '回退'
      when t6.process_result = '-1' then '拒绝'
      when t6.process_result = '-1' then '取消'
      end                                    as approve_opinion      --审批意见(1:通过 2:回退 -1:拒绝 -2:取消)
,null                                        as remark1              --保留字段1
,null                                        as remark2              --保留字段2
,null                                        as remark3              --保留字段3
,null                                        as remark4              --保留字段4
,null                                        as remark5              --保留字段5
from odata.order_main_loan_order t1
left join(select a.credit_order_id,
                 b.client_no
            from odata.order_main_loan_order a
      inner join odata.sllv_mb_acct b
              on a.loan_id = b.cmisloan_no
             and b.prod_type in ('110121','110120')
             and b.data_date = '${DATA_DATE}'
             and b.bddw_end_date = '9999-99-99'
           where a.data_date = '${DATA_DATE}'
             and a.bddw_end_date = '9999-99-99'
             and a.product_type = '5'
             and a.sub_product_type = '6'
             and a.status in ('7','8','9','10')
             and a.order_type = '2' 
        group by a.credit_order_id,
                 b.client_no)t2
       on t1.loan_id = t2.credit_order_id
 left join odata.order_custom_info t3
        on t1.loan_id = t3.loan_id
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
 left join odata.order_credit_order_info t4
        on t1.loan_id = t4.loan_id
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
 left join odata.sym_cif_client_document t5
        on t2.client_no = t5.client_no
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
 left join(select  loan_id
                  ,processor
                  ,process_result
                  ,row_number() over(partition by loan_id order by process_time desc) as seq
             from odata.order_order_audit_operation_log
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99')t6
        on t1.loan_id = t6.loan_id
       and t6.seq = 1
 left join odata.sso_upms_user t7
        on t6.processor = t7.user_id
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
       and t1.product_type = '5'
       and t1.sub_product_type = '6'
       and t1.status in ('7','8','9','10','13')
       and t1.order_type = '1'
       and t2.credit_order_id is not null

union all
--锡机贷
select
 t1.loan_id                                  as crdt_cont_no         --授信合同编号
,'02'                                        as cust_type            --客户类型
,t3.client_no                                as cust_id              --客户号
,t4.client_short                             as cust_name            --客户姓名
,t3.prod_type                                as prod_code            --产品编号
,'锡机贷'                                    as prod_name            --产品名称
,t5.document_type                            as cert_type            --证件类型
,t5.document_id                              as cert_no              --证件号码
,'02'                                        as cycle_flag           --循环标识(01-循环，02-非循环)
,'CNY'                                       as ccy                  --币种
,t2.actual_loan_amount                       as crdt_limit           --授信额度
,null                                        as crdt_term            --授信期限
,t3.acct_open_date                           as crdt_start_date      --授信起始日期
,t3.maturity_date                            as crdt_mature_date     --授信到期日期
,case when t3.acct_status != 'C'  then '01' --有效
      else '02'                             --无效
      end                                    as crdt_status          --授信状态
,substr(t1.apply_time,1,10)                  as app_date             --申请日期
,t1.status                                   as cont_status          --合同状态
,t7.realname                                 as approver             --审批人
,case when t6.process_result = '1'  then '通过'
      when t6.process_result = '2'  then '回退'
      when t6.process_result = '-1' then '拒绝'
      when t6.process_result = '-1' then '取消'
      end                                    as approve_opinion      --审批意见(1:通过 2:回退 -1:拒绝 -2:取消)
,null                                        as remark1              --保留字段1
,null                                        as remark2              --保留字段2
,null                                        as remark3              --保留字段3
,null                                        as remark4              --保留字段4
,null                                        as remark5              --保留字段5
from odata.order_main_loan_order t1
 left join odata.order_product_loan_info t2
        on t1.loan_id = t2.loan_id
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date='9999-99-99'
inner join odata.sllv_mb_acct t3
        on t1.loan_id = t3.cmisloan_no
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
       and t3.prod_type in ('110110','110122')
 left join odata.sym_cif_client t4
        on t3.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
 left join odata.sym_cif_client_document t5
        on t3.client_no = t5.client_no
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
 left join(select  loan_id
                  ,processor
                  ,process_result
                  ,row_number() over(partition by loan_id order by process_time desc) as seq
             from odata.order_order_audit_operation_log
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99'
              and process_node = 'MACHINE_RISK_RECHECK')t6
        on t1.loan_id = t6.loan_id
       and t6.seq = 1
 left join odata.sso_upms_user t7
        on t6.processor = t7.user_id
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
       and t1.product_type = '2'
       and t1.sub_product_type = '2'
       and t1.status in (7,8,9,10)

union all
--锡车贷
select
 t1.loan_id                                  as crdt_cont_no         --授信合同编号
,'02'                                        as cust_type            --客户类型
,t3.client_no                                as cust_id              --客户号
,t4.client_short                             as cust_name            --客户姓名
,t3.prod_type                                as prod_code            --产品编号
,'锡车贷'                                    as prod_name            --产品名称
,t5.document_type                            as cert_type            --证件类型
,t5.document_id                              as cert_no              --证件号码
,'02'                                        as cycle_flag           --循环标识(01-循环，02-非循环)
,'CNY'                                       as ccy                  --币种
,t2.actual_loan_amount                       as crdt_limit           --授信额度
,null                                        as crdt_term            --授信期限
,t3.acct_open_date                           as crdt_start_date      --授信起始日期
,t3.maturity_date                            as crdt_mature_date     --授信到期日期
,case when t3.acct_status != 'C'  then '01' --有效
      else '02'                             --无效
      end                                    as crdt_status          --授信状态
,substr(t1.apply_time,1,10)                  as app_date             --申请日期
,t1.status                                   as cont_status          --合同状态
,t7.realname                                 as approver             --审批人
,case when t6.process_result = '1'  then '通过'
      when t6.process_result = '2'  then '回退'
      when t6.process_result = '-1' then '拒绝'
      when t6.process_result = '-1' then '取消'
      end                                    as approve_opinion      --审批意见(1:通过 2:回退 -1:拒绝 -2:取消)
,null                                        as remark1              --保留字段1
,null                                        as remark2              --保留字段2
,null                                        as remark3              --保留字段3
,null                                        as remark4              --保留字段4
,null                                        as remark5              --保留字段5
from odata.order_main_loan_order t1
 left join odata.order_product_loan_info t2
        on t1.loan_id = t2.loan_id
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99'
inner join odata.sllv_mb_acct t3
        on t1.loan_id = t3.cmisloan_no
       and t3.prod_type in ('110115','110116')
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date='9999-99-99'
 left join odata.sym_cif_client t4
        on t3.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
 left join odata.sym_cif_client_document t5
        on t3.client_no = t5.client_no
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
 left join(select  loan_id
                  ,processor
                  ,process_result
                  ,row_number() over(partition by loan_id order by process_time desc) as seq
             from odata.order_order_audit_operation_log
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99'
              )t6
        on t1.loan_id = t6.loan_id
       and t6.seq = 1
 left join odata.sso_upms_user t7
        on t6.processor = t7.user_id
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
       and t1.product_type = '3'
       and t1.sub_product_type = '3'
       and t1.status in (7,8,9,10)

union all
--平安普惠
select
 t1.loan_id                                  as crdt_cont_no         --授信合同编号
,'02'                                        as cust_type            --客户类型
,t3.client_no                                as cust_id              --客户号
,t4.client_short                             as cust_name            --客户姓名
,t3.prod_type                                as prod_code            --产品编号
,'平安普惠'                                  as prod_name            --产品名称
,t5.document_type                            as cert_type            --证件类型
,t5.document_id                              as cert_no              --证件号码
,'02'                                        as cycle_flag           --循环标识(01-循环，02-非循环)
,'CNY'                                       as ccy                  --币种
,t2.actual_loan_amount                       as crdt_limit           --授信额度
,null                                        as crdt_term            --授信期限
,t3.acct_open_date                           as crdt_start_date      --授信起始日期
,t3.maturity_date                            as crdt_mature_date     --授信到期日期
,case when t3.acct_status != 'C'  then '01' --有效
      else '02'                             --无效
      end                                    as crdt_status          --授信状态
,substr(t1.apply_time,1,10)                  as app_date             --申请日期
,t1.status                                   as cont_status          --合同状态
,t7.realname                                 as approver             --审批人
,case when t6.process_result = '1'  then '通过'
      when t6.process_result = '2'  then '回退'
      when t6.process_result = '-1' then '拒绝'
      when t6.process_result = '-1' then '取消'
      end                                    as approve_opinion      --审批意见(1:通过 2:回退 -1:拒绝 -2:取消)
,null                                        as remark1              --保留字段1
,null                                        as remark2              --保留字段2
,null                                        as remark3              --保留字段3
,null                                        as remark4              --保留字段4
,null                                        as remark5              --保留字段5
from odata.order_main_loan_order t1
 left join odata.order_product_loan_info t2
        on t1.loan_id = t2.loan_id
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99'
inner join odata.sllv_mb_acct t3
        on t1.loan_id = t3.cmisloan_no
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
       and t3.prod_type in ('110123','110124','110125')
 left join odata.sym_cif_client t4
        on t3.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
 left join odata.sym_cif_client_document t5
        on t3.client_no = t5.client_no
       and t5.data_date = '${DATA_DATE}'
       and t5.bddw_end_date = '9999-99-99'
 left join(select  loan_id
                  ,processor
                  ,process_result
                  ,row_number() over(partition by loan_id order by process_time desc) as seq
             from odata.order_order_audit_operation_log
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99'
              )t6
        on t1.loan_id = t6.loan_id
       and t6.seq = 1
 left join odata.sso_upms_user t7
        on t6.processor = t7.user_id
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date = '9999-99-99'
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
       and t1.product_type = '6'
       and t1.sub_product_type = '8'
       and t1.status in (7,8,9,10)

union all
--锡房贷
select
 t1.loan_id                                  as crdt_cont_no         --授信合同编号
,'02'                                        as cust_type            --客户类型
,t3.client_no                                as cust_id              --客户号
,t4.client_short                             as cust_name            --客户姓名
,'110108'                                    as prod_code            --产品编号
,'锡房贷'                                    as prod_name            --产品名称
,t5.document_type                            as cert_type            --证件类型
,t5.document_id                              as cert_no              --证件号码
,'02'                                        as cycle_flag           --循环标识(01-循环，02-非循环)
,'CNY'                                       as ccy                  --币种
,t2.actual_loan_amount                       as crdt_limit           --授信额度
,null                                        as crdt_term            --授信期限
,t3.acct_open_date                           as crdt_start_date      --授信起始日期
,t3.maturity_date                            as crdt_mature_date     --授信到期日期
,case when t3.acct_status != 'C'  then '01' --有效
      else '02'                             --无效
      end                                    as crdt_status          --授信状态
,substr(t1.apply_time,1,10)                  as app_date             --申请日期
,t1.status                                   as cont_status          --合同状态
,t7.realname                                 as approver             --审批人
,t6.process_result                           as approve_opinion      --审批意见(1:通过 2:回退 -1:拒绝 -2:取消)
,null                                        as remark1              --保留字段1
,null                                        as remark2              --保留字段2
,null                                        as remark3              --保留字段3
,null                                        as remark4              --保留字段4
,null                                        as remark5              --保留字段5
from odata.order_main_loan_order t1
 left join odata.order_loan_order_house t2
        on t1.loan_id = t2.loan_id
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99'
 left join odata.sllv_mb_acct t3
        on t1.loan_id = t3.cmisloan_no
       and t3.data_date = '${DATA_DATE}'
       and t3.bddw_end_date = '9999-99-99'
 left join odata.sym_cif_client t4
        on t3.client_no = t4.client_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
 left join odata.sym_cif_client_document t5
        on t3.client_no = t5.client_no
       and t5.data_date='${DATA_DATE}'
       and t5.bddw_end_date='9999-99-99'
 left join(select  loan_id
                  ,processor
                  ,process_result
                  ,row_number() over(partition by loan_id order by process_time desc) as seq
             from odata.order_order_audit_operation_log
            where data_date = '${DATA_DATE}'
              and bddw_end_date = '9999-99-99')t6
        on t1.loan_id = t6.loan_id
       and t6.seq = 1
 left join odata.sso_upms_user t7
        on t6.processor = t7.user_id
       and t7.data_date = '${DATA_DATE}'
       and t7.bddw_end_date='9999-99-99'
     where t1.data_date = '${DATA_DATE}'
       and t1.bddw_end_date = '9999-99-99'
       and t1.product_type = '1'
       and t1.sub_product_type = '4'
       and t1.status in (7,8,9,10)