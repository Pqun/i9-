-- XM23_01表外代偿后利息表外转表内
insert into dwd.mid_xm_recv_int_scene_tran_new_used partition(data_date='${DATA_DATE}') 
select /*+ REPARTITION(1) */ 
xsf.loan_id                     as loan_no,
       'XM23_01'                       as sence,
       sum(nvl(last.int_bal,0))/100
  from odata.slur_xm_term_status_file xsf 
  inner join odata.slur_xm_term_status_file last 
    on xsf.loan_id = last.loan_id 
    and xsf.term_no = last.term_no
    and last.data_date = '${DATA_DATE}'
    and last.bddw_end_date = '9999-99-99'
    and last.channel_date = regexp_replace(date_add(last.data_date,-1),'-','') 
    
 where xsf.data_date = '${DATA_DATE}'
   and xsf.bddw_end_date = '9999-99-99' 
   and xsf.channel_date = regexp_replace(date_add(xsf.data_date,-1),'-','')
   and last.term_status <> '5'
   and exists(select 1
                 from odata.slur_dzz_compensatory_detail dcd
                where dcd.data_date = '${DATA_DATE}'
		          and dcd.bddw_end_date = '9999-99-99'
		          and dcd.channel_date = regexp_replace(date_add(dcd.data_date,-1),'-','')
                  and dcd.loan_no = xsf.loan_id
                  and dcd.comps_status = 'S'
                  and dcd.loan_type = 'O')
   and not exists(select 1
                    from odata.slur_dzz_compensatory_detail dcd
                   where dcd.data_date =  '${DATA_DATE}'
		             and dcd.bddw_end_date = '9999-99-99'
		             and dcd.channel_date <= regexp_replace(date_add(dcd.data_date,-1),'-','')
                     and dcd.loan_no = xsf.loan_id
                     and dcd.term_no = xsf.term_no
                     and dcd.comps_status = 'S')
   group by xsf.loan_id
         
                    
           

    
                    
           

    