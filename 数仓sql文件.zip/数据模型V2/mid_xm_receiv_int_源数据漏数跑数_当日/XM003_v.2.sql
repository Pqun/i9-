--XM003 逾期90天以内计提当日利息
insert into dwd.mid_xm_recv_int_scene_tran_new_used partition(data_date='${DATA_DATE}') 
select /*+ REPARTITION(1) */ 
xlf.loan_id,
       'XM003',
       sum(nvl(xlf.int_total, 0))/100   as int_total
   from odata.slur_xm_loan_file xlf
  where xlf.data_date = '${DATA_DATE}'
    and xlf.bddw_end_date = '9999-99-99'
    and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
    and xlf.cur_date = xlf.start_date
    and not exists(select 1
                           from odata.slur_xm_loan_file last
                          where last.data_date = '${DATA_DATE}'
                            and last.bddw_end_date = '9999-99-99'
						    and last.loan_id = xlf.loan_id
                           
							and last.channel_date = date_add(xlf.channel_date,-1)
							)
	and not exists (select 1
                      from odata.slur_acc_writeoff_hist awh
                     where awh.data_date = '${DATA_DATE}'
                       and awh.bddw_end_date = '9999-99-99'
					   and awh.loan_no = xlf.loan_id
                       and awh.tran_date < xlf.tran_date
                       )
	group by xlf.loan_id
				
									   
union all

select /*+ REPARTITION(1) */ 
xlf.loan_id,
       'XM003',
       sum(nvl(xlf.int_total,0) - nvl(last.int_total,0))/100 as int_total
  from odata.slur_xm_loan_file xlf
 inner join odata.slur_xm_loan_file last
   on last.loan_id = xlf.loan_id
   and last.data_date = '${DATA_DATE}'
   and last.bddw_end_date = '9999-99-99'
   and last.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
   and last.loan_status != '6'
 where xlf.data_date = '${DATA_DATE}'
   and xlf.bddw_end_date = '9999-99-99'
   and xlf.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
   
    --to_char(to_date(xlf.channel_date, 'yyyymmdd') - 1, 'yyyymmdd')
   and not exists (select 1
                     from odata.slur_acc_writeoff_hist awh
                    where awh.data_date = '${DATA_DATE}'
                      and awh.bddw_end_date = '9999-99-99'
                      and awh.loan_no = xlf.loan_id
                      and awh.tran_date < xlf.tran_date
                      )
--上日核算状态为表内
    and not exists(select 1
                     from odata.slur_xm_term_status_file xtsf
                    where xtsf.data_date = '${DATA_DATE}'
                      and xtsf.bddw_end_date = '9999-99-99'
					  and xtsf.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
                      and xtsf.loan_id = xlf.loan_id
                      and xtsf.term_status <> 5                                                    --未结清
                      and not exists (select 1
                                        from odata.slur_dzz_compensatory_detail dcd
                                       where dcd.data_date = '${DATA_DATE}'
									     and dcd.bddw_end_date = '9999-99-99'
									     and dcd.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                                         and dcd.loan_no = xtsf.loan_id
                                         and dcd.term_no = xtsf.term_no
                                         and dcd.comps_status = 'S'
                                         and dcd.prod_type = '110126') 
					   having max(xtsf.days_ovd) > 89)

    group by xlf.loan_id
	
union all

        
select /*+ REPARTITION(1) */ 
a.loan_id,
       'XM003',
       sum(nvl(a.int_today,0))/100 
  from odata.slur_xm_loan_file a 
 where a.data_date = '${DATA_DATE}'
  and a.bddw_end_date = '9999-99-99'
  and a.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
  and a.cur_date = a.start_date 
  and a.int_today > 0
  group by a.loan_id
  




