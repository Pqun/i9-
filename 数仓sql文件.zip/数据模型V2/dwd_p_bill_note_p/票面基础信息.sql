--2.gaoyuan.dwd.dwd_p_bill_note_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：票据基础信息表取数逻辑.sql
--功能描述：用于创建 dwd.dwd_p_bill_note_p
--作    者：高源
--开发日期：2022-07-27 
--直属经理：方杰
--来源表:
--1.odata.nbms_bms_draft_centre_info 票据票面信息表  
--2.odata.nbms_dpc_draft_info 票据票面信息表
--目标表：dwd.dwd_p_bill_note_p
--修改历史：
--          1.高源   2022-07-27    新建
--          2.高源   2023-01-10    新增票据区间字段,新增新票据系统票面信息逻辑
--          3.高源   2023-01-10    新增票面收款人账号
---------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_p_bill_note_p partition(data_date='${DATA_DATE}')
select      /*+ REPARTITION(1) */
            bill_no              --票据编号
           ,org_id               --机构号
           ,ccy                  --币种
           ,bill_attr            --票据介质
           ,bill_type            --票据类型      
           ,remit_date           --出票日
           ,bill_expr_date       --票面到期日
           ,bill_amt             --票面金额
           ,drawer_name          --出票人名称
           ,drawer_acct_no       --出票人账号
           ,drawer_cert_no       --出票人证件代码    
           ,drawer_bank_no       --出票人开户行号
           ,drawer_bank_name     --出票人开户行名称
           ,acceptor_name        --承兑人名称
           ,acceptor_cert_no     --承兑人证件号码
           ,acceptor_bank_no     --承兑人开户行号
           ,bill_rev_name        --票面收款人名称    
           ,rev_cert_no          --票面收款人证件号码
           ,bill_rev_bank_no     --票面收款人开户行号
           ,bill_rev_bank_name   --票面收款人开户行名称
           ,status               --票据状态    
           ,bill_range           --票据区间  
           ,bill_rev_acct_no     --票面收款人账号
from(select *,
     row_number() over(partition by bill_no,bill_range order by last_date desc) as row_num 
     from (select  nvl(t1.draft_number          ,'')    as  bill_no              --票据编号
                  ,'100000'                             as  org_id               --机构号
                  ,'CNY'                                as  ccy                  --币种
                  ,nvl(t1.draft_attr            ,'')    as  bill_attr            --票据介质
                  ,nvl(t1.draft_type            ,'')    as  bill_type            --票据类型      
                  ,nvl(from_unixtime(unix_timestamp(t1.remit_date,'yyyyMMdd'),'yyyy-MM-dd'),'')    as  remit_date           --出票日
                  ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as  bill_expr_date       --票面到期日
                  ,nvl(t1.draft_amount           ,0)    as  bill_amt             --票面金额
                  ,nvl(t1.remitter_name         ,'')    as  drawer_name          --出票人名称
                  ,nvl(t1.remitter_account      ,'')    as  drawer_acct_no       --出票人账号
                  ,nvl(t1.remitter_cmonid       ,'')    as  drawer_cert_no       --出票人证件代码    
                  ,nvl(t1.remitter_bank_no      ,'')    as  drawer_bank_no       --出票人开户行号
                  ,nvl(t1.remitter_bank_name    ,'')    as  drawer_bank_name     --出票人开户行名称
                  ,nvl(t1.acceptor_name         ,'')    as  acceptor_name        --承兑人名称
                  ,''                                   as  acceptor_cert_no     --承兑人证件号码
                  ,nvl(t1.acceptor_bank_no      ,'')    as  acceptor_bank_no     --承兑人开户行号
                  ,nvl(t1.payee_name            ,'')    as  bill_rev_name        --票面收款人名称    
                  ,nvl(t1.payee_organ_code      ,'')    as  rev_cert_no          --票面收款人证件号码
                  ,nvl(t1.payee_bank_no         ,'')    as  bill_rev_bank_no     --票面收款人开户行号
                  ,nvl(t1.payee_bank_name       ,'')    as  bill_rev_bank_name   --票面收款人开户行名称
                  ,nvl(t3.status                ,'')    as  status               --票据状态   
                  ,'-'                                  as  bill_range           --票据区间
                  ,nvl(t1.payee_account         ,'')    as  bill_rev_acct_no     --票面收款人账号
                  ,from_unixtime(unix_timestamp(t1.last_txn_date,'yyyy-MM-dd HH:mm:ss'),'yyyyMMddHHmmss') as last_date  --最新状态日期
          from odata.nbms_bms_draft_centre_info  t1                          
          left join odata.nbms_dpc_draft_info t3  
              on t1.id = t3.bms_draft_id
            and t3.data_date='${DATA_DATE}'
            and t3.bddw_end_date='9999-99-99'
            and t3.src_type='SR026'        --权属登记部分
          where t1.data_date='${DATA_DATE}'                      --老票承兑、贴现部分
            and t1.bddw_end_date='9999-99-99'
          union all
--------------------------------------------------转贴现及返售回购部分-----------------------------------------------------------
           select  nvl(t1.draft_number          ,'')    as  bill_no              --票据编号
                  ,'100000'                             as  org_id               --机构号
                  ,'CNY'                                as  ccy                  --币种
                  ,nvl(t1.draft_attr            ,'')    as  bill_attr            --票据介质
                  ,nvl(t1.draft_type            ,'')    as  bill_type            --票据类型      
                  ,nvl(from_unixtime(unix_timestamp(t1.remit_date,'yyyyMMdd'),'yyyy-MM-dd'),'')    as  remit_date           --出票日
                  ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as  bill_expr_date       --票面到期日
                  ,nvl(t1.draft_amount           ,0)    as  bill_amt             --票面金额
                  ,nvl(t1.remitter_name         ,'')    as  drawer_name          --出票人名称
                  ,nvl(t1.remitter_account      ,'')    as  drawer_acct_no       --出票人账号
                  ,nvl(t1.remitter_crt_no       ,'')    as  drawer_cert_no       --出票人证件代码    
                  ,nvl(t1.remitter_bank_no      ,'')    as  drawer_bank_no       --出票人开户行号
                  ,nvl(t1.remitter_bank_name    ,'')    as  drawer_bank_name     --出票人开户行名称
                  ,nvl(t1.acceptor_name         ,'')    as  acceptor_name        --承兑人名称
                  ,nvl(t1.acceptor_crt_no       ,'')    as  acceptor_cert_no     --承兑人证件号码
                  ,nvl(t1.acceptor_bank_no      ,'')    as  acceptor_bank_no     --承兑人开户行号
                  ,nvl(t1.payee_name            ,'')    as  bill_rev_name        --票面收款人名称  
                  ,nvl(t1.payee_crt_no          ,'')    as  rev_cert_no          --票面收款人证件号码
                  ,nvl(t1.payee_bank_no         ,'')    as  bill_rev_bank_no     --票面收款人开户行号
                  ,nvl(t1.payee_bank_name       ,'')    as  bill_rev_bank_name   --票面收款人开户行名称
                  ,nvl(t1.status                ,'')    as  status               --票据状态  
                  ,nvl(t1.cd_range             ,'-')    as  bill_range           --票据区间
                  ,nvl(t1.payee_account         ,'')    as  bill_rev_acct_no     --票面收款人账号
                  ,last_upd_time                        as  last_date            --最新状态日期
          from odata.nbms_dpc_draft_info  t1
          where t1.data_date='${DATA_DATE}' 
            and t1.bddw_end_date='9999-99-99'
            and t1.src_type in('SR005','SR006','SR007','SR020','SR026','SR505')      --数据来源为转贴现、质押式回购、买断式回购 ，新票承兑、新票贴现
            )t
   )tt
where tt.row_num=1