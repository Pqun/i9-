---------------------------------------------------------------------------------------------------------------
--脚本名称：对公贷款借据信息取数逻辑.sql
--功能描述：用于在hive mdata层创建mdata.ads_d_corp_loan_bill_p
--作    者：施金才
--开发日期：2020-11-19
--直属经理：程宏明
--修改历史：
--          1.施金才   2020-11-19    新建
--          2.张礼娟   2021-05-07    源表由gdata.ads_d_corp_loan_bill_p改为dwd.dwd_d_corp_loan_bill_p
---------------------------------------------------------------------------------------------------------------
insert overwrite table mdata.ads_d_corp_loan_bill_p partition(data_date='${DATA_DATE}')
select
     bill_no          
    ,cont_no          
    ,acct_mask(loan_acct) as loan_acct       
    ,acct_mask(cust_id) as cust_id          
    ,name_mask(cust_name) as cust_name        
    ,cust_type        
    ,subj_no          
    ,prod_type        
    ,ccy              
    ,bill_amt         
    ,bill_bal         
    ,overdue_prin     
    ,overdue_int      
    ,overdue_pena_int 
    ,overdue_compo    
    ,unmat_bal        
    ,term_m           
    ,renew_times      
    ,total_term       
    ,present_term     
    ,grant_date       
    ,mature_date      
    ,real_mature_date 
    ,five_lvl         
    ,operr_id         
    ,oper_org_id      
    ,rate_adjust_date 
    ,acctng_status    
    ,acct_mask(repay_acct) as repay_acct       
    ,repay_mode       
    ,acct_mask(entry_acct) as entry_acct       
    ,inout_flag       
    ,end_type         
    ,end_date         
    ,review_flag      
    ,exec_rate_y          
    ,remark2          
    ,remark3          
    ,remark4          
    ,remark5          
from dwd.dwd_d_corp_loan_bill_p
where data_date='${DATA_DATE}'