--2.zhanglijuan.dwd_c_indv_cust_info_p
-------------------------------------------------------------------
--脚本名称:dwd_c_indv_cust_info_p
--功能描述:主题模型对私客户信息表
--作    者:施金才
--开发日期:2020-09-27
--直属经理:程宏明
--目标表  :dwd.dwd_c_indv_cust_info_p                 对私客户信息表
--数据原表:odata.sllv_nl_acct                         线上贷款账户基本信息表
--         odata.sllv_nl_acct_balance                 线上贷款账户余额表
--         odata.ols_loan_cont_info                   支用合同信息
--         odata.slur_dzz_compensatory_detail         文件类代偿明细表
--         odata.slur_compensatory_clear_total        代偿清分主表
--         odata.slur_compensatory_clear_detail       代偿清分明细表
--         odata.sym_mb_acct                          账户基本信息表
--         odata.sym_mb_acct_balance                  账户余额表
--         odata.slur_acc_duebill_info                借据信息表
--         odata.order_custom_info                    客户信息表
--         odata.sym_cif_client_document              客户证件信息
--         odata.order_job_info                       工作信息表
--         odata.ols_crd_cont_info                    授信合同信息表
--         odata.order_main_loan_order                订单主表
--         odata.order_loan_order_house               房抵贷订单表
--         odata.order_product_loan_info              产品贷款信息
--         odata.order_main_credit_order              授信订单主表
--         odata.uc_um_uia_info                       用户实名信息表
--         odata.auth_um_ocr_record                   ORC登记表
--         odata.order_spouse_info                    配偶信息表
--         odata.sym_cif_client                       客户信息表
--         odata.sym_cif_client_indvl                 个人客户信息表
--         odata.sym_cif_client_contact_tbl           客户联系信息表
--         odata.sllv_mb_acct
--         odata.sllv_mb_acct_balance
--         odata.ols_cus_info
--         odata.als_ind_info
--         odata.sym_cif_client_contact_address
--         odata.blf_bl_record_id_number
--         smart.js_mbml
--         dwd.dwd_d_depo_cont_p                      存款协议表
--         dwd.dwd_c_corp_cust_info_p                 对公客户信息表
--         dwd.dwd_c_indv_cust_info_p_cust_type_tmp
--修改历史:
--         1、施金才     20200927     新建
--         2、施金才     20201105     更新缩写
--         3、施金才     20201119     添加保留字段
--         4、施金才     20201211     参考人行数据报送逻辑对代码进行重构
--         5、方杰       20210603     获取手机号码逻辑更改
--         6.华天顺      20210929     已用额度改成取在贷余额
--         7.华天顺      20211011     京东授信额度已用大于授信的取有在贷余额的借据本金总和
--         8.华天顺      20211020     调整表结构，更新缩写，新增存款余额字段
--         9.华天顺      20220224     个人客户类型取数逻辑修改，增加周转贷部分客户类型
--         10.华天顺     20220328     个人客户类型取数逻辑修改，新增是否农户字段
--         11.吴镇宇     20220819    新增来源系统,机构号,工作单位名称,工作单位地址,工作单位地址邮编,工作单位行业类型代码,
--                                    工作单位电话,单位组织机构类型代码,单位经营组织形式代码,单位工作起始年月,工资账号,
--                                    工资账号开户行号,工资账号开户行名称,配偶客户号,配偶单位名称,居住状况代码,电子邮箱,
--                                    家庭地址/居住地区代码,通讯地区代码,通讯地址邮编,户籍地址邮编,职业状态代码,发证机关名称
--                                    ,发证机关所在地的地区代码,客户常住地区代码,是否黑名单标志,上黑名单开始/结束日,
--                                    上黑名单原因字段 
--         12.张礼娟     20221010    修复黑名单字段导致客户发散问题
--         13.张礼娟     20221027     根据金数逻辑修改下列字段逻辑：授信额度、婚姻状况、民族、最高学历、个人年收入、家庭年收入
--         14.张礼娟     20230103     修改字段逻辑：发证机关地区代码，常住地地区代码
--         15.张礼娟     20230110     修改字段逻辑：家庭地址/居住地区代码，通讯地区代码
--         16.张礼娟     20230321     新增税收身份字段，修改客户名称逻辑，优化通讯地址取值逻辑
--         17.张礼娟     20230629     调整字段（出生日期）取数逻辑
--         18.张礼娟     20230822     调整家庭地址/居住地址、通讯地址、户籍地址、工作单位地址逻辑，由源业务系统取值调整为优先取核心，有空值时补业务系统地址（网贷、基塔石）
--         19.于国睿     20231024     将limit_ps_product_limit替换为uquam_ps_product_limit      
--         20.彭群       20240109     工作单位名称，工作单位行，业类型字段，通讯地址逻辑修改，新增经营范围字段
--         21.彭群       20240123     社会统一信用代码，工作单位名称，工作单位行业类型字段，通讯地址，经营范围字段逻辑修改  
--         22.杨琦浩     20240301     关联农户中间表取是否农户  
--         23.姚威       20240328     临时修复供应链单位名称、单位行业类型重复问题
--         24.张礼娟     20240514     新增字段：是否民办非企业
-------------------------------------------------------------------
with t9  as 
(
    --联合贷余额
    select                                                      
     t1.client_no                                                          as  cust_id --客户号
    ,cast(t2.total_amount_bal-t2.total_amount_partner as decimal(20,2))    as  dkye    -- 贷款余额
    from  odata.sllv_nl_acct t1
    left join  
    (
        select
         internal_key
        ,sum(bal)                                            as total_amount_bal
        ,sum(partner_bal)                                    as total_amount_partner
        from  odata.sllv_nl_acct_balance
        where  data_date='${DATA_DATE}' 
        and  bddw_end_date='9999-99-99'
        group by  internal_key
    ) t2
    on t1.internal_key = t2.internal_key
    where t1.data_date = '${DATA_DATE}'
    and t1.bddw_end_date = '9999-99-99'
    and substr(t1.acct_open_date,1,10)<='${DATA_DATE}'    
    union all 
    select       --网贷，特色业务余额                                                   
    t1.client_no                                             as  khh     -- 客户号
    ,t2.total_amount                                         as  dkye   -- 贷款余额
    from  odata.sllv_mb_acct t1
    left join  odata.sllv_mb_acct_balance t2
    on  t1.internal_key = t2.internal_key
    and  t2.amt_type ='BAL'
    and  t2.data_date='${DATA_DATE}' 
    and  t2.bddw_end_date='9999-99-99'
    where  t1.data_date = '${DATA_DATE}'
    and  t1.bddw_end_date = '9999-99-99'
    and  from_unixtime(unix_timestamp(t1.acct_open_date,'yyyymmdd'),'yyyy-mm-dd')<='${DATA_DATE}'
    union all     --行外产品余额
    select 
     t2.cust_id_core                                         as cust_id
    ,case when t3.loan_no is not null 
    then 0 
    else t2.loan_bal-nvl(dc_amt.comps_prin,0)+nvl(qf_amt.clear_prin,0)     
    end                                                      as loan_bal
    from  odata.ols_loan_cont_info t2
    left join  odata.slur_dzz_compensatory_detail t3
    on  t2.bill_no = t3.loan_no
    and  t3.data_date='${DATA_DATE}'
    and  t3.bddw_end_date='9999-99-99'
    and  t3.comps_status='S'
    and  t3.sl_id = 'BDVC'
    and  t3.prod_class='01'
    left join 
    (
        select                
        loan_no
        ,sum(comps_prin) comps_prin            --代偿本金 
        ,sum(comps_int) comps_int              --代偿利息
        ,sum(comps_prin_pnlt) comps_prin_pnlt  --代偿罚息
        from  odata.slur_compensatory_clear_total
        where  data_date ='${DATA_DATE}'
        and  bddw_end_date = '9999-99-99'
        group by  loan_no
    ) dc_amt
    on  t2.bill_no = dc_amt.loan_no
    left join 
    (
        select
        loan_no
        ,sum(clear_prin) clear_prin            --清分本金 
        ,sum(clear_int) clear_int              --清分利息
        ,sum(clear_prin_pnlt) clear_prin_pnlt  --清分罚息
        from  odata.slur_compensatory_clear_detail
        where  data_date ='${DATA_DATE}'
        and  bddw_end_date = '9999-99-99'
        group by  loan_no
    ) qf_amt
    on  t2.bill_no = qf_amt.loan_no
    where  t2.data_date='${DATA_DATE}' 
    and  t2.bddw_end_date='9999-99-99'
    and  t2.prd_code in ('10011001003','10091001001','10111001001','10091004003','10091004002','10091004005','10091004006','10091004007','10091004') 
    and  substr(t2.input_time,1,10)<='${DATA_DATE}'
    and  t2.cont_status in ('105','107')
    union all
    select     --个人经营贷款柜面放款
    t1.client_no                                              as  khh     -- 客户号
    ,t2.total_amount_prev                                     as  dkye    -- 贷款余额
    from  odata.sym_mb_acct  t1
    left join  odata.sym_mb_acct_balance t2
    on  t1.internal_key = t2.internal_key
    and  t2.amt_type = 'BAL' 
    and  t2.data_date='${DATA_DATE}'
    and  t2.bddw_end_date='9999-99-99' 
    where  t1.data_date='${DATA_DATE}'
    and  t1.bddw_end_date='9999-99-99'
    and  t1.lead_acct_flag='N'
    and  t1.prod_type='110101'
    and  nvl(t1.acct_close_reason,'') not in ('发放冲正','贷款未发放复核关闭')
    union all      --锡望贷
    select 
    c.client_no
    ,a.prin_bal                                               as dkye
    from odata.slur_acc_duebill_info a
    left join odata.order_custom_info b
    on a.loan_id = b.loan_id
    and b.data_date = '${DATA_DATE}'
    and b.bddw_end_date = '9999-99-99'
    left join odata.sym_cif_client_document c
    on b.id_card = c.document_id 
    and c.data_date = '${DATA_DATE}'
    and c.bddw_end_date = '9999-99-99'
    where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
)
,t16 as 
(
    select
         nvl(case when a1.acct_no='14408220000002016' and a1.acct_seq_no='0'
                  then '1000842473'
                  else  a1.cust_id
              end ,'') as khh --客户号
        ,sum(nvl(a1.bal,0)) as ckye --存款余额
    from dwd.dwd_d_depo_cont_p a1
    left join dwd.dwd_c_corp_cust_info_p a5
    on a5.data_date='${DATA_DATE}'
    and a1.cust_id=a5.cust_id
    where a1.data_date='${DATA_DATE}'
    and a1.acct_real_flag='Y'
    and a1.acct_open_date<='${DATA_DATE}'
    and ((a1.cust_type='01' and (a1.prod_class like 'RB%' or a1.prod_class in ('7000','8000'))) or a1.subj_no='20300103' or a5.cust_subdiv_type='210')
    group by nvl(case when a1.acct_no='14408220000002016' and a1.acct_seq_no='0'
                  then '1000842473'
                  else  a1.cust_id
              end ,'')
) 
insert overwrite table dwd.dwd_c_indv_cust_info_p partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(10) */
     t1.client_no                                                                               as cust_id                      -- 客户号
    ,t1.ch_client_name                                                                          as cust_name                    -- 客户名称
    ,case when t13.curr_residence_code is not null and length(t13.curr_residence_code) = 20 then substr(t13.curr_residence_code,15)
          when t13.curr_residence_code is not null and length(t13.curr_residence_code) = 13 then substr(t13.curr_residence_code,8)
          when t3.document_type in ('100','101','102') then nvl(if(t3.iss_place='999999',null,t3.iss_place),substr(t3.document_id,1,6))
          else ''  
     end                                                                                        as area_code                    -- 地区代码  --20211021修改缩写
    ,t1.client_type                                                                             as cust_type                    -- 客户类型代码 --20211021修改缩写
    ,t3.document_type                                                                           as cert_type                    -- 证件类型   --20211021修改缩写
    ,t3.document_id                                                                             as cert_no                      -- 证件号码 
    ,t1.country_loc                                                                             as country_code                 -- 国籍
    ,nvl(t4.mz,'')                                                                              as nation_code                  -- 民族  --20221017 张礼娟  
    ,nvl(t2.sex,'')                                                                             as gender_code                  -- 性别
    ,coalesce(t13.edu_level,t14.ifeduc,'')                                                      as max_edu                      -- 最高学历  --20221017 张礼娟      
    ,nvl(t2.max_degree,'')                                                                      as max_degree                   -- 最高学位  --20211021修改缩写
    ,nvl(case when t3.document_type = '101' then from_unixtime(unix_timestamp(substr(t3.document_id,7,8),'yyyymmdd'),'yyyy-mm-dd')
              when t3.document_type <>'101' then from_unixtime(unix_timestamp(t2.birth_date,'yyyymmdd'),'yyyy-mm-dd')
              end,'')                                                                           as birth_date                     -- 出生日期  --20230629修改
    ,nvl(t2.occupation_code,'')                                                                 as vocatn                       -- 职业代码 --20211021修改缩写
    ,nvl(t2.qualification,'')                                                                   as vocatn_title                 -- 职称代码 --20211021修改缩写
    ,case when t2.marital_status='S' then 'M01'
          when t2.marital_status='M' then 'M02'
          when t2.marital_status='W' then 'M06'
          when t2.marital_status='D' then 'M07'
          when t2.marital_status ='U' and t14.ifwedd='S' then 'M01'
          when t2.marital_status ='U' and t14.ifwedd='M' then 'M02'
          when t2.marital_status ='U' and t14.ifwedd='W' then 'M06'
          when t2.marital_status ='U' and t14.ifwedd='D' then 'M07'
          when t2.marital_status ='U' and t14.ifwedd='U' then ''
          when t2.marital_status is null and t14.ifwedd='S' then 'M01'
          when t2.marital_status is null and t14.ifwedd='M' then 'M02'
          when t2.marital_status is null and t14.ifwedd='W' then 'M06'
          when t2.marital_status is null and t14.ifwedd='D' then 'M07'
          when t2.marital_status is null and t14.ifwedd='U' then ''
          else '' end                                                                            as marry_status  -- 婚姻状况  M01：未婚；M02 ：已婚；M06：丧偶；M07：离异 
    --20221013 张礼娟 根据金数改逻辑
    --s单身，m已婚，d离婚，w丧偶，u未说明婚姻情况；                                         
    ,coalesce(t13.spouse_name,t14.spouse_name,'')                                                as spouse_name                  -- 配偶姓名
    ,nvl(t13.spouse_mobile,'')                                                                   as spouse_mobile                -- 配偶移动电话
    ,coalesce(t13.spouse_cert_type,t14.spouse_cert_type,'')                                      as spouse_cert_type             -- 配偶证件类型
    ,coalesce(t13.spouse_cert_no,t14.spouse_cert_no,'')                                          as spouse_cert_no               -- 配偶证件号码
    ,nvl(t1.internal_ind,'N')                                                                    as emp_flag                   -- 是否本行员工标志Y 是N 否 -20211021修改缩写
    ,nvl(t14.home_tel,'')                                                                        as home_tel_no                  -- 家庭电话  -20211021修改缩写
    ,nvl(t5.contact_tel,'')                                                                      as mobile                       -- 移动电话
    ,case when coalesce(t14.indiv_ann_incm,t13.annual_income,0) > 0 then coalesce(t14.indiv_ann_incm,t13.annual_income,0) 
    else 0 end as indv_income_y   -- 个人年收入 --20221017 张礼娟 根据金数改逻辑
    ,case when coalesce(t14.family_ann_incm,t13.family_annual_income,0) > 0 then coalesce(t14.family_ann_incm,t13.family_annual_income,0)
    when coalesce(t14.family_ann_incm,t13.family_annual_income,0) = 0 and coalesce(t14.indiv_ann_incm,t13.annual_income,0) <> 0 
    then coalesce(t14.indiv_ann_incm,t13.annual_income,0)
    else 0 end                                                                                   as family_income_y              -- 家庭年收入 --20221017 张礼娟 根据金数改逻辑
        --当家庭年收入为空，个人年收入不为空时，用个人年收入作为家庭年收入
    ,coalesce(t21.address,t13.family_addr,t14.family_addr   ,'')                                 as family_addr                  -- 家庭地址/居住地址
    ,nvl(t14.family_zip    ,'')                                                                  as family_zip                   -- 家庭地址/居住地址邮编
	,coalesce(t20.address,t14.post_addr,t35.manage_space,t36.ry_reg_address,t38.register_addr,t13.emp_addr,'') 
	                                                                                             as post_addr        		     -- 通讯地址		--updata pengqun  20240103
    ,coalesce(t22.address,t13.domicile_addr,t14.domicile_addr ,'')                               as domicile_addr                -- 户籍地址
    ,coalesce(t6.crd_amt,t61.crd_amt,0)                                                          as credit_limit               -- 授信额度 --20221013 张礼娟 根据金数改逻辑
    ,nvl(t9.loan_bal_sum,0)                                                                      as used_limit                     -- 已用额度 -20211021修改缩写
    ,nvl(from_unixtime(unix_timestamp(t3.iss_date,'yyyymmdd'),'yyyy-mm-dd'),'')                  as cert_start_date             -- 证件起始日期
    ,from_unixtime(unix_timestamp(t3.expiry_date,'yyyymmdd'),'yyyy-mm-dd')                       as cert_mature_date               -- 证件到期日期
    ,from_unixtime(unix_timestamp(t1.creation_date,'yyyymmdd'),'yyyy-mm-dd')                     as cust_create_date            -- 客户创建日期
    ,case when t1.inland_offshore='O' then 1 else 0 end                                          as oversea_flag                -- 境外标志Y 是N 否
    ,nvl(t1.acct_exec,'')                                                                        as cust_mgr_id                  -- 客户经理号
    ,case when t7.cust_type = '2' then nvl(t13.business_license,'') else '' end                  as biz_license     -- 个体工商户营业执照代码
    ,case   
		    when t35.corporate_type = '01' then '2'
		    when t35.corporate_type = '02' then '3'
	        when t36.ry_customers_type = '01' then '2'
		    when t36.ry_customers_type = '02' then '3'
			when t38.enterprise_type = '210' then '2'
	        when t38.enterprise_type <> '210' then '3'
			when t13.work_kind = '1' then '2'
		    when t13.work_kind = '3' then '3'
		   else '9'
	 end                                                                  as indv_cust_type             -- 个人客户类型1:农户,2:个体工商户,3:小微企业主,9:其他 --20240103pengqun修改
    ,case  when t35.corporate_type in ('01','02') then nvl(t35.com_uscc,'')
	       when t36.ry_customers_type in ('01','02' ) then nvl(t36.ry_credit_code,'') 
	       when t38.personal_cust_id is not null then nvl(t38.social_credit_code,'')
	       when t13.work_kind in ('1','3') then coalesce(t13.business_license,t13.creditCode,'') 
	       else nvl(t2.employer_name,'')    end                                                  as unif_soc_crdt   -- 小微企业社会统一信用代码         --updata20240118 pengqun
    ,nvl(t1.partner_id,'')                                                                       as partner_id                   -- 合作方标识
    ,''                                                                                          as partner_name                 --合作方名称
    ,nvl(t16.ckye,0)                                                                             as depo_bal                     --存款余额
    --,nvl(t71.is_farmer,'0')                                                                      as is_farmer                    --是否农户
	,nvl(if(t40.is_farmer='1','1','0'),'0')                                                      as is_farmer                    --是否农户
    ,''                                                                                          as source_sys_code              --来源系统
    ,nvl(t1.ctrl_branch,'')                                                                      as org_id                          --机构号
    ,coalesce(t35.corporate_name,t36.ry_ent_name,t38.enterprise_name,t13.emp_name,t2.employer_name,'')                                                                    	 
	                                                                                             as emp_name                       --工作单位名称     --updata20231227 pengqun
    ,coalesce(t31.address,t30.workadd,'')                                                        as emp_addr                       --工作单位地址
    ,''                                                                                          as emp_addr_post                  --工作单位地址邮编
    ,case when t38.personal_cust_id is not null then nvl(t38.industry_category_tiny_code,'')
          when t13.work_kind in ('1','3') then nvl(t13.emp_indust_type_code,'')
	      else '' end                                                                            as emp_indust_type_code          --工作单位行业类型代码  --updata2023122 pengqun
    ,nvl(t30.worktel,'')                                                                         as emp_tel_no                    --工作单位电话
    ,''                                                                                          as emp_org_type                  --单位组织机构类型代码
    ,''                                                                                          as emp_org_oper_type              --单位经营组织形式代码
    ,''                                                                                          as emp_work_begin_ym              --单位工作起始年月
    ,''                                                                                          as wages_acct_no                  --工资账号
    ,''                                                                                          as wages_acct_bank_code          --工资账号开户行号
    ,''                                                                                          as wages_acct_bank_name         --工资账号开户行名称
    ,''                                                                                          as spouse_cust_id                  --配偶客户号
    ,''                                                                                          as spouse_emp_name              --配偶单位名称
    ,''                                                                                          as resi_status                  --居住状况代码
    ,''                                                                                          as email                           --电子邮箱
    ,''                                                                                          as home_area_code                  --家庭地址/居住地区代码
    ,''                                                                                          as postal_area_code              --通讯地区代码
    ,nvl(t32.postal_code,'')                                                                     as postal_post                  --通讯地址邮编   为何还有为空的？
    ,''                                                                                          as domicile_post                   --户籍地址邮编
    ,''                                                                                          as vocatn_status                  --职业状态代码
    ,''                                                                                          as cert_issue_org_name          --发证机关名称
    ,nvl(t3.dist_code,'')                                                                        as cert_issue_loc_area          --发证机关所在地的地区代码 --20230103 张礼娟
    ,nvl(t32.dist,'')                                                                            as resi_area_code                  --客户常住地区代码 --20230103 张礼娟
    ,case when t34.id_value is null then 0 else 1 end                                            as black_list_flag               --是否黑名单标志
    ,nvl(substr(t34.created_date,1,10),'')                                                       as black_list_start_date        --上黑名单开始日期
    ,'9999-99-99'                                                                                as black_list_end_date          --上黑名单结束日期
    ,''                                                                                          as black_list_reason               --上黑名单原因
    ,nvl(t1.resident_status,'')                                                                  as tax_id                           -- 税收身份
    ,case  when t35.corporate_type in ('01','02') then nvl(t35.business_scope,'')
		   when t36.ry_customers_type in ('01','02' )  then nvl(t36.ry_operate_scope,'') 
	       when t38.personal_cust_id is not null then nvl(t38.business_scope,'')
           when t13.work_kind in ('1','3') then
	       coalesce(t13.busiscope,t13.business_scope,'')
	  else '' end              							                                         as opra_scope                    --经营范围  --updata20240119 pengqun
    ,case when t38.social_org_type='01' then 1 else 0 end as private_non_ent_flag	--是否民办非企业  20240514新增 张礼娟
from odata.sym_cif_client t1
left join odata.sym_cif_client_indvl t2
on t1.client_no = t2.client_no 
and t2.data_date='${DATA_DATE}' 
and t2.bddw_end_date='9999-99-99'
left join odata.sym_cif_client_document t3
on t1.client_no = t3.client_no 
and t3.pref_flag='Y'
and t3.data_date='${DATA_DATE}' 
and t3.bddw_end_date='9999-99-99' 
left join
(--影像数据 民族 
    select 
        a.client_no
        ,a.document_id
        ,a.nationality
        ,case when b.dm is not null then b.dm 
            when a.nationality = '穿青人族' then '57'
            else '' end as mz
    from
    (  --影像数据 民族 汉字都不含族字
        select  
            t1.document_id
            ,t2.client_no
            ,concat(t1.nationality,'族') as nationality
            ,row_number() over(partition by t1.document_id order by t1.tran_date desc) rk
        from odata.auth_um_ocr_record t1
        inner join odata.sym_cif_client_document t2
        on t1.document_id = t2.document_id
        and t2.document_type = '101'
        and t2.data_date='${DATA_DATE}'
        and t2.bddw_end_date='9999-99-99'
        where t1.data_date='${DATA_DATE}'
        and t1.bddw_end_date='9999-99-99'            
    )a
    left join smart.js_mbml b  --人行码值表
    on a.nationality = b.mc
    and b.mbbh = 'C0047'
    where a.rk = 1
)t4
on t1.client_no = t4.client_no
left join odata.sym_cif_client_contact_tbl t5 --获取客户手机号码
on t1.client_no = t5.client_no 
and t5.pref_flag='Y'
and t5.data_date='${DATA_DATE}'
and t5.bddw_end_date='9999-99-99'
left join 
(   --取授信额度
    select 
    b.client_no
    ,sum(a.total_limit) crd_amt 
    from odata.uquam_ps_product_limit a  --update 20231024 yuguorui
    left join odata.sym_cif_client_document b
    on a.document_id = b.document_id
    and b.data_date = '${DATA_DATE}'
    and b.bddw_end_date = '9999-99-99'
    and b.document_type = '101'
    where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and a.is_parent_product = '1'
    group by b.client_no
) t6 
on t1.client_no=t6.client_no 
left join
(   --取授信额度
    select 
    t1.cust_id_core as client_no
    ,sum(nvl(t1.crd_amt,0)) as crd_amt
    from odata.ols_crd_cont_info t1
    where t1.cont_status = '103'  --额度生效
    and substr(input_time,1,10)<='${DATA_DATE}'
    and data_date='${DATA_DATE}'
    and bddw_end_date='9999-99-99'
    and t1.prd_code = '10051001002' --数禾还享借
    group by t1.cust_id_core
) t61 
on t1.client_no=t61.client_no 
left join 
(
    select 
    *
    ,row_number() over (partition by cust_id order by start_date desc ) as rn
    from dwd.dwd_c_indv_cust_info_p_cust_type_tmp 
    where  cust_type in ('2','3')
)t7 
on t1.client_no=t7.cust_id
and t7.rn=1
left join 
(
    select 
    *
    ,row_number() over (partition by cust_id order by start_date desc ) as rn
    from dwd.dwd_c_indv_cust_info_p_cust_type_tmp 
)t71
on t1.client_no=t71.cust_id
 and t71.rn=1
left join 
(
    select 
    cust_id
    ,sum(dkye) as loan_bal_sum 
    from t9 
    group by cust_id
) t9 
on t1.client_no=t9.cust_id
left join t16
on t1.client_no=t16.khh
left join 
(
   select  
     t1.id_card                      
    ,t1.loan_id                           as loan_id
    ,case when t1.edu_level='10' then '71'
          when t1.edu_level='11' then '41'
          when t1.edu_level='12' then '31'
          when t1.edu_level='13' then '21'
          when t1.edu_level='20' then '14'
          when t1.edu_level='21' then '11'
          when t1.edu_level='22' then '90'
          end as edu_level
    ,t1.marriage                          as ifwedd
    ,t1.annual_income                     as annual_income
    ,t1.family_annual_income              as family_annual_income
    ,coalesce(t1.industry_code,t6.industry_involved) as emp_indust_type_code
    ,t1.curr_residence_address            as family_addr
    ,t1.id_card_address                   as domicile_addr
    ,t1.curr_residence_code
    ,t1.mobile                            as mobile
    ,t2.annual_income                     as spouse_annual_income
    ,t2.contact_name                      as spouse_name
    ,t2.mobile                            as spouse_mobile
    ,'101'                                as spouse_cert_type
    ,t2.id_card                           as spouse_cert_no
    ,coalesce(t3.company_name,t1.company_name,t6.company_name) as emp_name
	,coalesce(t3.company_address,t6.business_operation_address,t3.company_code_desc,t6.business_operation_code_desc) as emp_addr
    ,t3.company_tel                       as emp_tel
    ,t3.company_category                  as emp_nature
	,t3.work_kind                  		  as work_kind  --(1:个体工商  3：小微企业)
	,coalesce(t3.unify_society_credit_code,t5.business_license_no,
	                          t4.business_license,t6.business_license) as business_license
    ,get_json_object(t7.info_content,'$.basicIncList[0].creditCode')   as creditCode --updata20240118  pengqun
	,t6.business_scope					  as business_scope	  --updata20240118  pengqun
    ,coalesce(get_json_object(t7.info_content,'$.basicIncList[0].busiScope1'),get_json_object(t7.info_content,'$.basicIncList[0].busiScope2'),'')  as busiscope --updata20240118  pengqun
    ,row_number() over(partition by t1.id_card order by t1.create_time desc ) as rk
    from odata.order_custom_info t1
    left join odata.order_spouse_info t2 
    on t1.loan_id = t2.loan_id 
    and t2.data_date='${DATA_DATE}' 
    and t2.bddw_end_date='9999-99-99'
    left join odata.order_job_info t3 
    on t1.loan_id = t3.loan_id 
    and t3.data_date='${DATA_DATE}' 
    and t3.bddw_end_date='9999-99-99'
    left join odata.order_product_loan_info t4 
    on t1.loan_id = t4.loan_id 
    and t4.data_date='${DATA_DATE}' 
    and t4.bddw_end_date='9999-99-99'
    left join odata.order_loan_order_house t5           --updata20240118  pengqun
    on t1.loan_id = t5.loan_id 
    and t5.data_date='${DATA_DATE}' 
    and t5.bddw_end_date='9999-99-99'
    left join odata.order_company_info t6                --updata20240118  pengqun
    on t1.loan_id = t6.loan_id 
    and t6.data_date='${DATA_DATE}' 
    and t6.bddw_end_date='9999-99-99'
    left join odata.order_ph_apply_income t7            --updata20240118  pengqun
    on t1.loan_id = t7.loan_id 
    and t7.data_date='${DATA_DATE}' 
    and t7.bddw_end_date='9999-99-99'
    where t1.data_date='${DATA_DATE}' 
    and t1.bddw_end_date='9999-99-99'                
) t13
on t3.document_id = t13.id_card
and t13.rk=1
left join
(
    select 
        cust_id_core
        ,cert_code as cert_no
        ,'00'  as loan_id
        ,case when ifeduc='10' then '14'
              when ifeduc='20' then '21'
              when ifeduc='30' then '31'
              when ifeduc='40' then '41'
              when ifeduc='60' then '61'
              when ifeduc='70' then '71'
              when ifeduc='80' then '81'
              when ifeduc='90' then '90'
              end as ifeduc   --学历 10研究生,20本科,30大专,40中专、职高、技校,60高中,70初中,80小学,90其他
        ,ifwedd
        ,indiv_ann_incm                 
        ,family_ann_incm                    
        ,indiv_com_name                 as emp_name
        ,comp_addr                      as emp_addr
        ,std_zx_employmet               as emp_indust_type_code
        ,comp_tel                       as emp_tel
        ,indiv_com_typ                  as emp_nature
        ,spouse_name
        ,spouse_type                    as spouse_cert_type
        ,spouse_code                    as spouse_cert_no
        ,sitelp                         as home_tel
        ,ifmobl                         as mobile
        ,siaddr                         as family_addr
        ,sizpcd                         as family_zip
        ,addr                           as post_addr
        ,rgster_addr                    as domicile_addr
    from odata.ols_cus_info  
    where data_date='${DATA_DATE}' 
    and bddw_end_date='9999-99-99'
)t14
on t1.client_no = t14.cust_id_core
left join odata.als_ind_info t30
on t1.client_no=t30.customerid 
and t30.data_date='${DATA_DATE}'
and t30.bddw_end_date='9999-99-99'
left join odata.sym_cif_client_contact_address t20 
on t1.client_no = t20.client_no 
and t20.contact_type='01' --01联系地址，02注册地址，03单位地址，04办公地址，05居住地址，06户籍地址，07综合账单地址，08信用卡账单地址，09其他物理地址  
and t20.data_date='${DATA_DATE}'
and t20.bddw_end_date='9999-99-99' 
left join odata.sym_cif_client_contact_address t21 
on t1.client_no = t21.client_no 
and t21.contact_type='05' --01联系地址，02注册地址，03单位地址，04办公地址，05居住地址，06户籍地址，07综合账单地址，08信用卡账单地址，09其他物理地址  
and t21.data_date='${DATA_DATE}'
and t21.bddw_end_date='9999-99-99' 
left join odata.sym_cif_client_contact_address t22
on t1.client_no = t22.client_no 
and t22.contact_type='06' --01联系地址，02注册地址，03单位地址，04办公地址，05居住地址，06户籍地址，07综合账单地址，08信用卡账单地址，09其他物理地址  
and t22.data_date='${DATA_DATE}'
and t22.bddw_end_date='9999-99-99' 
left join odata.sym_cif_client_contact_address t31 
on t1.client_no = t31.client_no 
and t31.contact_type in ('03','04') --01联系地址，02注册地址，03单位地址，04办公地址，05居住地址，06户籍地址，07综合账单地址，08信用卡账单地址，09其他物理地址  
and t31.data_date='${DATA_DATE}'
and t31.bddw_end_date='9999-99-99' 
left join odata.sym_cif_client_contact_address t32 
on t1.client_no = t32.client_no 
and t32.pref_flag='Y' --首选信息  
and t32.data_date='${DATA_DATE}'
and t32.bddw_end_date='9999-99-99' 
left join 
(
    select 
         t1.id_value
        ,t1.created_date
        ,row_number() over(partition by id_value order by created_date desc) as rk
    from odata.blf_bl_record_id_number t1  --黑名单表
    where data_date='${DATA_DATE}' 
    and bddw_end_date='9999-99-99'
)t34  
on t3.document_id=t34.id_value
and t34.rk='1'
left join (select cust_id_core,input_time,app_no from 
(select cust_id_core,input_time,app_no
,row_number()over(partition by cust_id_core order by input_time desc ) as rn  --取最新的input_time
from odata.ols_biz_borr_info
where data_date = '${DATA_DATE}'
and bddw_end_date='9999-99-99')t
where t.rn = 1) t39   
on t39.cust_id_core = t1.client_no                                        --updata20231227新增关联逻辑
left join odata.ols_biz_corporate_info t35                                --updata20231227新增关联逻辑
  on t35.app_no = t39.app_no
 and t35.data_date = '${DATA_DATE}'
 and t35.bddw_end_date = '9999-99-99'
left join odata.ols_biz_baidu_xwjy_character t36                           --updata20231227新增关联逻辑
  on t36.app_no = t39.app_no  
 and t36.data_date = '${DATA_DATE}'
 and t36.bddw_end_date = '9999-99-99'
left join odata.supwall_scp_personal_cust_info t37                         --updata20231227新增关联逻辑
  on t37.idcard_no = t3.document_id  
 and t37.data_date = '${DATA_DATE}'
 and t37.bddw_end_date = '9999-99-99'
 and t37.status = '10' --有效
left join (select  a.personal_cust_id
                  ,a.register_addr
                  ,a.enterprise_type
                  ,a.social_credit_code
                  ,a.enterprise_name
                  ,a.industry_category_tiny_code
                  ,a.business_scope
				  ,social_org_type   --20240514新增
             from 
                 (select personal_cust_id
                        ,register_addr
                        ,enterprise_type
                        ,social_credit_code
                        ,enterprise_name
                        ,industry_category_tiny_code
                        ,business_scope
						,social_org_type   --20240514新增
			       	   ,row_number() over(partition by personal_cust_id order by create_time desc) rn
                    from odata.supwall_scp_personal_cust_enterprise_info
                   where data_date = '${DATA_DATE}'
                     and bddw_end_date = '9999-99-99'
		             and status = '10' --有效
		          ) a
			 where a.rn =1
		      ) t38               --updata20231227新增关联逻辑    		
  on t38.personal_cust_id = t37.id  
left join dwd.dwd_c_farmer_cust_mid t40 
  on t1.client_no=t40.cust_id
 and t40.data_date='${DATA_DATE}'
where t1.data_date='${DATA_DATE}'
and t1.bddw_end_date='9999-99-99' 
and t1.client_type='01'