-------------------------------------------------------------------
--脚本名称:dwd_c_indv_cust_info_p_cust_type_tmp
--功能描述:对私客户信息表客户细类做预处理
--作    者:施金才
--开发日期:2022-03-28
--直属经理:程宏明
--目标表  :dwd.dwd_c_indv_cust_info_p_cust_type_tmp                 对私客户信息表
--数据原表:odata.sllv_nl_acct                         线上贷款账户基本信息表
--         odata.sllv_nl_acct_balance                 线上贷款账户余额表
--         odata.slur_dzz_compensatory_detail         文件类代偿明细表
--         odata.ols_crd_cont_info                    授信合同信息表
--         odata.order_main_loan_order                订单主表
--         odata.order_loan_order_house               房抵贷订单表
--         odata.order_product_loan_info              产品贷款信息
--         odata.order_main_credit_order              授信订单主表
--修改历史:
--         1、华天顺     20220328     新建

-------------------------------------------------------------------
insert overwrite table dwd.dwd_c_indv_cust_info_p_cust_type_tmp
select /*+ REPARTITION(1) */
 t1.client_no
,t1.cmisloan_no               as dkjjbm               --贷款借据编码
,case when t5.work_kind = '1' then '2'
      when t5.work_kind in ('2','3','9') then '3'
      else '0' end            as sfgtgshdk            --是否个体工商户贷款
,case when t5.work_kind in ('2','9')  then '1'
      else '0' end           as sndklx               --是否农户贷款
,t3.total_amount              as dkye                 --贷款余额
,from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')                --开户日期
,t1.prod_type                 as cph                  --产品号
 from odata.sllv_mb_acct t1
 left join odata.order_loan_order_house t41  --锡房贷合同表
   on t1.cmisloan_no = t41.loan_id
  and t41.data_date = '${DATA_DATE}'
  and t41.bddw_end_date = '9999-99-99'
inner join odata.sym_gl_prod_accounting t2
   on t1.prod_type = t2.prod_type
  and t2.data_date = '${DATA_DATE}'
  and t2.bddw_end_date = '9999-99-99'
  and t2.gl_code_a = '10400201'
  and t2.accounting_status = 'ZHC'
 left join odata.sllv_mb_acct_balance t3
   on t1.internal_key = t3.internal_key
  and t3.amt_type = 'BAL'
  and t3.data_date = '${DATA_DATE}'
  and t3.bddw_end_date = '9999-99-99'
 left join odata.order_main_loan_order t7
   on t1.cmisloan_no = t7.loan_id 
  and t7.data_date='${DATA_DATE}'
  and t7.bddw_end_date='9999-99-99'
 left join odata.order_job_info t5
   on t7.loan_id = t5.loan_id
  and t5.data_date = '${DATA_DATE}'
  and t5.bddw_end_date = '9999-99-99'
 left join odata.order_product_loan_info t6
   on t1.cmisloan_no = t6.loan_id
  and t6.data_date = '${DATA_DATE}'
  and t6.bddw_end_date = '9999-99-99'
where t1.data_date = '${DATA_DATE}'
  and t1.bddw_end_date = '9999-99-99'
  and t3.total_amount > 0
  and t7.status in ('7','8','9','10')
  and (t5.work_kind in ('1','2','3','9') or substr(t6.loan_cast_industry_code,-5) like 'A%' or substr(t41.loan_industry,-5) like 'A%')
  and  t1.prod_type not in ('110120','110121','110124','110125')
--110110,110122,110129要保留类型是"9"的借据
and not exists(select 1
               from odata.sllv_mb_acct a
                  inner join odata.order_job_info b
                  on a.cmisloan_no = b.loan_id
                  and b.data_date = '${DATA_DATE}'
                  and b.bddw_end_date = '9999-99-99'
                  and b.work_kind = '9'
                  where a.data_date = '${DATA_DATE}'
                  and a.bddw_end_date = '9999-99-99'
                  and a.prod_type in ('110116','110130')
                  and t1.cmisloan_no = a.cmisloan_no)
union all

select /*+ REPARTITION(1) */
 t1.client_no
,t1.cmisloan_no               as dkjjbm               --贷款借据编码
,case when t6.person_business_type = '1' then '2'
      when t6.person_business_type = '2' then '3'
      else '0' end            as sfgtgshdk            --是否个体工商户贷款
,'0'                         as sndklx               --是否农户贷款
,t5.total_amount_prev         as dkye                 --贷款余额
,from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')                --开户日期
,t1.prod_type                 as cph                  --产品号
from odata.sllv_mb_acct t1
--锡惠贷
left join odata.sllv_mb_acct_balance t5
       on t1.internal_key = t5.internal_key
      and t5.data_date = '${DATA_DATE}'
      and t5.bddw_end_date = '9999-99-99'
      and t5.amt_type = 'BAL'
left join odata.order_product_loan_info t6
       on trim(t1.cmisloan_no) = trim(t6.loan_id)
      and t6.data_date = '${DATA_DATE}'
      and t6.bddw_end_date = '9999-99-99'
    where t1.data_date = '${DATA_DATE}'
      and t1.bddw_end_date = '9999-99-99'
      and t6.person_business_type in ('1','2')
      and from_unixtime(unix_timestamp(t1.acct_open_date,'yyyymmdd'),'yyyy-mm-dd') <= '${DATA_DATE}'
      and t1.prod_type in (
                            '110124'  --锡惠贷个人经营贷款-免征
                           ,'110125'  --锡惠贷个人经营贷款
      )

union all
--车商贷单独处理
select /*+ REPARTITION(1) */
 t1.client_no
,t1.cmisloan_no               as dkjjbm               --贷款借据编码
,case when t5.work_kind = '1' then '2'
      when t5.work_kind = '3' then '3'
      else '0' end            as sfgtgshdk            --是否个体工商户贷款
,'0'                         as sndklx               --是否农户贷款
,t3.total_amount              as dkye                 --贷款余额
,from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')                --开户日期
,t1.prod_type                 as cph                  --产品号
 from odata.sllv_mb_acct t1
 left join odata.sllv_mb_acct_balance t3
   on t1.internal_key = t3.internal_key
  and t3.amt_type = 'BAL'
  and t3.data_date = '${DATA_DATE}'
 left join odata.order_main_loan_order t7
   on t1.cmisloan_no = t7.loan_id 
  and t7.data_date='${DATA_DATE}'
  and t7.bddw_end_date='9999-99-99'
  and t7.order_type= '2'
 left join odata.order_job_info t5
   on t7.credit_order_id = t5.loan_id
  and t5.data_date = '${DATA_DATE}'
  and t5.bddw_end_date = '9999-99-99'
 left join odata.order_product_loan_info t6
   on t1.cmisloan_no = t6.loan_id
  and t6.data_date = '${DATA_DATE}'
  and t6.bddw_end_date = '9999-99-99'
where t1.data_date = '${DATA_DATE}'
  and t1.bddw_end_date = '9999-99-99'
  and t7.status in ('7','8','9','10')
  and (t5.work_kind in ('1','3') or substr(t6.loan_cast_industry_code,-5) like 'A%')
  and  t1.prod_type in ('110120','110121')
union all
--长安新生
select /*+ REPARTITION(1) */
 t1.client_no
,t1.cmisloan_no               as dkjjbm               --贷款借据编码
,case when t5.work_kind = '1' then '2'
      when t5.work_kind = '3' then '3'
      else '0' end            as sfgtgshdk            --是否个体工商户贷款
,case when t5.work_kind = '2'  then '1'
      else '0' end           as sndklx               --是否农户贷款
,t3.bal - t3.partner_bal      as dkye                 --贷款余额
,substr(t1.acct_open_date,1,10)                --开户日期
,t1.prod_type                 as cph                  --产品号
 from odata.sllv_nl_acct t1
 left join odata.order_main_loan_order t4
   on t1.cmisloan_no = t4.receipt_no
  and t4.data_date = '${DATA_DATE}'
  and t4.bddw_end_date = '9999-99-99'
 left join odata.sllv_nl_acct_balance t3
   on t1.internal_key = t3.internal_key
  and t3.data_date = '${DATA_DATE}'
  and t3.bddw_end_date = '9999-99-99'
 left join odata.order_contract_sign t41
   on t4.loan_id = t41.loan_id
  and t41.data_date = '${DATA_DATE}'
  and t41.bddw_end_date = '9999-99-99'
  and t41.signer_type = '1' --签署人为借款人
  and t41.contract_type = '2' --个人借款合同
 left join odata.order_job_info t5
   on t4.loan_id = t5.loan_id
  and t5.data_date = '${DATA_DATE}'
  and t5.bddw_end_date = '9999-99-99'
 left join odata.order_product_loan_info t6
   on t41.loan_id = t6.loan_id
  and t6.data_date = '${DATA_DATE}'
  and t6.bddw_end_date = '9999-99-99'
where t1.data_date = '${DATA_DATE}'
  and t1.bddw_end_date = '9999-99-99'
  and t4.status in ('7','8','9','10')
  and (t5.work_kind in ('1','2','3') or substr(t6.loan_cast_industry_code,-5) like 'A%')
  and t1.prod_type in (
                         '110118'  --新生贷经营性贷款
                       , '110127'  --新生贷经营性贷款-非免征
                       )
 union all
--大鹅经营贷
select /*+ REPARTITION(1) */
 t1.client_no
,t1.cmisloan_no               as dkjjbm               --贷款借据编码
,'2'            as sfgtgshdk            --是否个体工商户贷款
,'0'           as sndklx               --是否农户贷款
,t3.total_amount              as dkye                 --贷款余额
,from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')                --开户日期
,t1.prod_type                 as cph                  --产品号
  from odata.sllv_mb_acct t1
  left join odata.sllv_mb_acct_balance t3
   on t1.internal_key = t3.internal_key
  and t3.amt_type = 'BAL'
  and t3.data_date = '${DATA_DATE}'
 where t1.data_date = '${DATA_DATE}'
   and t1.bddw_end_date = '9999-99-99'
   and prod_type= '110153'
union all
--百度周转贷
select /*+ REPARTITION(1) */
 t2.cust_id_core
,t1.loan_no                   as dkjjbm               --贷款借据编码
,case when t2.prd_code in('10091004007') then '2'
      when t2.prd_code in('10091004006') then '3'
      else '0' end            as sfgtgshdk            --是否个体工商户贷款
,'0'                         as sndklx               --涉农贷款类型
,case when t4.loan_no is not null then 0
      else t1.principal_bal
      end                     as dkye                 --贷款余额
,from_unixtime(unix_timestamp(t1.loan_start_date,'yyyyMMdd'),'yyyy-MM-dd')                 --开户日期
,'110145'                     as cph                  --产品号
from odata.slur_bdzz_loan_file_clear t1
inner join odata.ols_loan_cont_info t2
        on t1.loan_no = t2.bill_no
       and t2.data_date = '${DATA_DATE}'
       and t2.bddw_end_date = '9999-99-99'
       and t2.cont_status in ('105','106','107','108','109','110')
 left join odata.slur_dzz_compensatory_detail t4
        on t1.loan_no = t4.loan_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
       and t4.comps_status = 'S'
       and t4.sl_id = 'BDZZ'
       and t4.prod_class = '01'
where t1.data_date = '${DATA_DATE}'
  and t1.bddw_end_date = '9999-99-99'