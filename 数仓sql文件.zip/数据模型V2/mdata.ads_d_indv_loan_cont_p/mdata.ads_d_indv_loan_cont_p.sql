---------------------------------------------------------------------------------------------------------------
--脚本名称：个人贷款合同信息取数逻辑.sql
--功能描述：用于在hive mdata层创建mdata.ads_d_indv_loan_cont_p
--作    者：施金才
--开发日期：2020-11-19
--直属经理：程宏明
--修改历史：
--          1.施金才   2020-11-19    新建
--          2.张礼娟   2021-05-07    源表由gdata.ads_d_indv_loan_cont_p改为dwd.dwd_d_indv_loan_cont_p
---------------------------------------------------------------------------------------------------------------
insert overwrite table mdata.ads_d_indv_loan_cont_p partition(data_date='${DATA_DATE}')
select
     cont_no
    ,acct_mask(cust_id_core) as cust_id_core
    ,name_mask(cust_name) as cust_name
    ,prod_name 
    ,loan_new_type 
    ,loan_type 
    ,ccy 
    ,cont_amt 
    ,cont_start_date
    ,cont_mature_date 
    ,pri_guar_mode 
    ,loan_purp 
    ,loan_invest_area 
    ,loan_invest_indust 
    ,limit_indust 
    ,crdt_cont_no 
    ,approve_date 
    ,cont_valid_status 
    ,remark1
    ,remark2
    ,remark3
    ,remark4
    ,remark5
from dwd.dwd_d_indv_loan_cont_p
where data_date='${DATA_DATE}'