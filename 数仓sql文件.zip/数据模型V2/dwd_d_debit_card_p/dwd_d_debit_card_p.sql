--2.zhanglijuan.dwd_d_passbook_p
-------------------------------------------------------------------
--脚本名称:dwd_d_debit_card_p
--功能描述:卡片信息表
--作    者:张礼娟
--开发日期:2022-08-20
--直属经理:程宏明
--目标表  :dwd.dwd_d_debit_card_p 借记卡信息表
--数据原表:
--         odata.sym_mb_prod_type  产品类型定义表
--         odata.sym_cif_client    客户信息表
--         odata.sym_cd_card_arch  卡片基本信息表
--         odata.sym_mb_acct       账户基本信息表
--修改历史:
--         1、张礼娟     2022-10-27      新建
--         2、张礼娟     2023-02-22      新增开户柜员
--         3、刘丽红     2024-04-11      新增协议号
-------------------------------------------------------------------
insert overwrite table dwd.dwd_d_debit_card_p partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
     a1.card_no                                                           as debit_card_id --借记卡号
    ,a1.base_acct_no                                                      as acct_no --账号
    ,a1.branch                                                            as org_id --开卡机构号
    ,a1.prod_type                                                         as prod_code --产品号
    ,a2.prod_desc                                                         as prod_name --产品名称
    ,''                                                                   as card_issue_date --发卡日期
    ,from_unixtime(unix_timestamp(a1.issue_date,'yyyymmdd'),'yyyy-mm-dd') as card_open_date --开卡日期
    ,''                                                                   as open_channel_id --开卡渠道号
    ,a1.close_date                                                        as card_close_date --销卡日期
    ,a1.valid_thru_date                                                   as card_expr_date --卡片有效期截止日期 
    ,a1.card_status                                                       as card_status --卡片状态代码
    ,a1.lost_status                                                       as lost_status --挂失状态
    ,a1.client_no                                                         as cust_id --客户号
    ,a3.ch_client_name                                                    as cust_name --客户名称
    ,a1.card_medium                                                       as card_medium	--卡片介质
    ,''                                                                   as emp_flag --是否员工卡标志
    ,a1.issue_user_id                                                     as open_ltr --开卡柜员
	  ,a4.internal_key                                                      as cont_no --协议号    --add llh 20240411
from odata.sym_cd_card_arch a1                                           -- 卡片基本信息表
left join odata.sym_mb_prod_type a2                                      --产品类型定义表
  on a1.prod_type = a2.prod_type
  and a2.data_date = '${DATA_DATE}'
  and a2.bddw_end_date = '9999-99-99'    
left join odata.sym_cif_client a3                                        --客户信息表                                                                                   
  on  a1.client_no=a3.client_no
  and a3.data_date = '${DATA_DATE}'
  and a3.bddw_end_date = '9999-99-99'
left join odata.sym_mb_acct a4                                           --账户基本信息表
  on a1.acct_seq_no=a4.acct_seq_no
  and a1.base_acct_no=a4.base_acct_no
  and a4.data_date = '${DATA_DATE}'
  and a4.bddw_end_date = '9999-99-99'
where a1.data_date = '${DATA_DATE}'
  and a1.bddw_end_date = '9999-99-99'
  and a1.issue_date <= regexp_replace('${DATA_DATE}','-','')             --限制账户开户日期小于等于抽数日期
