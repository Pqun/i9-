--2.zhanglijuan.dwd_d_depo_acct_int_p
-------------------------------------------------------------------
--脚本名称:dwd.dwd_d_depo_acct_int_p
--功能描述:主题模型存款账户利息表
--作    者:华天顺
--开发日期:2022-03-29
--直属经理:方杰
--目标表  :dwd.dwd_d_depo_acct_int_p                 存款账户利息表
--数据原表:
--修改历史:
--         1、华天顺    20220329 新建
--         2、张礼娟    20221027 修改字段 
--                               accu_ajst_int 利息调整累计 变更字段英文名为 accu_adj_int
--                               curr_ajst_int 利率变动日利息调整（逾期利息） 变更字段英文名为 curr_adj_int
--         3、邓权      20221220 新增内部户存款
--         4、邓权      20230411 上下次结息日逻辑调整
--         5、邓权      20230512 结息周期逻辑调整
--         5、张礼娟    20230822 结息周期逻辑调整
-------------------------------------------------------------------
insert overwrite table dwd.dwd_d_depo_acct_int_p partition (data_date='${DATA_DATE}')
         select /*+ REPARTITION(1) */
                 t1.internal_key                                                                                             as cont_no        --协议号
                ,t2.base_acct_no                                                                                             as acct_no        --账户号
                ,t2.acct_seq_no                                                                                              as acct_seq_no    --账户序号
                ,nvl(from_unixtime(unix_timestamp(nvl(t31.last_deal_date,t1.last_cycle_date),'yyyyMMdd'),'yyyy-MM-dd'),'')   as last_int_date  --上一结息日期
                ,nvl(from_unixtime(unix_timestamp(nvl(t31.next_deal_date,t1.next_cycle_date),'yyyyMMdd'),'yyyy-MM-dd'),'')   as next_int_date  --下一结息日期
                ,t1.int_type                                                                                                 as rate_type      --利率类型
                ,coalesce(t31.period_freq,t32.period_freq,t1.cycle_freq,'')                                                  as int_perd       --结息周期  20230822修改
                ,t2.client_no                                                                                                as cust_id        --客户号
                ,nvl(t1.int_posted_ctd,0) + nvl(t5.cr_int_posted,0)                                                          as entry_int      --入账利息
                ,nvl(t1.int_accrued_ctd,0) + nvl(t5.cr_int_accrued_ctd,0)                                                    as curr_accru_int --计提利息,当天计提利息
                ,nvl(t1.int_accrued,0) + nvl(t5.cr_int_accrued,0)                                                            as accu_accru_int --计提利息，从上一结息日到现在的计提利息
                ,nvl(t1.int_adj,0) + nvl(t5.cr_int_adj,0)                                                                    as accu_adj_int  --利息调整累计
                ,nvl(t1.int_adj_ctd,0) + nvl(t5.cr_int_adj_ctd,0)                                                            as curr_adj_int  --利率变动日利息调整（逾期利息）
                ,nvl(t1.real_rate,0)                                                                                         as exec_rate      --执行利率
                ,case when t2.prod_type in ('210206', '210211') then nvl(t1.discnt_int, 0) - nvl(t8.billed_amt,0)
                      when t3.internal_key is not null then nvl(t7.discnt_int,0)-nvl(t4.tran_amt,0)+nvl(t5.discnt_int,0)
                      else nvl(t1.discnt_int,0)+nvl(t5.discnt_int,0) 
                  end                                                                                                        as dscnt_int      --折扣利息
                ,case when t2.prod_type='230101' 
                 then '20600201' 
                 when t2.prod_type='230203' 
                 then '20600301' 
                 else coalesce(a14.gl_code_int_pay,a15.gl_code_int_pay,a16.gl_code_int_pay,a161.gl_code_int_acr) end         as subj_no        --科目代码
          from  odata.sym_mb_acct_int_detail t1
    inner join  odata.sym_mb_acct t2
            on  t1.internal_key = t2.internal_key
           and  t2.source_module in ('RB','GL')  --存款、内部户
           and  t2.data_date = '${DATA_DATE}'
           and  t2.bddw_end_date = '9999-99-99'
     left join  odata.sym_mb_acct t6
            on  t1.internal_key = t6.internal_key
           and  t6.source_module in ('RB','GL')   --存款、内部户
           and  t6.data_date = date_add('${DATA_DATE}',-1)
           and  t6.bddw_end_date = '9999-99-99'
           and  t6.acct_status <> 'C' --未销户
     left join  odata.sym_mb_acct_int_detail t7
            on  t6.internal_key = t7.internal_key
           and  t7.data_date = date_add('${DATA_DATE}',-1)
           and  t7.int_class = 'INT'
           and  t7.bddw_end_date = '9999-99-99'
     left join  odata.sym_mb_acct_schedule t3 --账户计划表-- 前付息账户特殊处理：未销户的前付息账户，修改前付息金额为前一天的前付息金额减去当天反冲前付息交易金额
            on  t3.event_type = 'QFINT' --事件类型为前付息
           and  t3.data_date = '${DATA_DATE}'
           and  t3.bddw_end_date = '9999-99-99'
           and  t7.internal_key = t3.internal_key
     left join  odata.sym_mb_acct_schedule t31 --账户计划表
            on  t31.data_date = '${DATA_DATE}'
           and  t31.bddw_end_date = '9999-99-99'
           and  t1.internal_key = t31.internal_key
	 left join  odata.sym_mb_acct_schedule_hist t32 --账户计划表
            on  t32.data_date = '${DATA_DATE}'
           and  t32.bddw_end_date = '9999-99-99'
           and  t1.internal_key = t32.internal_key	   
     left join  (    
                         select 
                                 internal_key
                                ,sum(tran_amt) as tran_amt
                          from  odata.sym_mb_tran
                         where  data_date = '${DATA_DATE}'
                           and  substr(tran_date,1,10) = '${DATA_DATE}'
                           and  bddw_end_date = '9999-99-99'
                           and  tran_type = '5ADJ' --反冲前付息
                           and  reversal = 'N'
                           and  reversal_tran_type is null
                      group by internal_key
                    ) t4
            on  t3.internal_key = t4.internal_key
     left join (
                 select 
                         internal_key
                        ,sum(int_posted_ctd)        as cr_int_posted  --贷方已入账利息
                        ,sum(int_accrued_ctd)       as cr_int_accrued_ctd --计提日贷方应付利息
                        ,sum(int_accrued)           as cr_int_accrued --贷方应付利息
                        ,sum(int_adj)               as cr_int_adj --利息调整累计
                        ,sum(int_adj_ctd)           as cr_int_adj_ctd --利率变动日利息调整
                        ,sum(nvl(discnt_int,0))     as discnt_int --折扣利息
                  from  odata.sym_mb_acct_int_detail
                 where  data_date = '${DATA_DATE}'
                   and  bddw_end_date = '9999-99-99'
                   and  int_class in ( 'PDUE'     --超期利息
                                      ,'WYINT'    --违约利息
                                      ,'INTPRE'   --提前支取利息
                                     )
              group by  internal_key
                    ) t5
            on  t1.internal_key = t5.internal_key
     left join  odata.sym_cif_client a13
            on  t2.client_no = a13.client_no
           and  a13.data_date='${DATA_DATE}'
           and  a13.bddw_end_date='9999-99-99'
    --获取科目号、科目名称
     left join  odata.sym_gl_prod_accounting a14
            on  t2.prod_type = a14.prod_type
           and  t2.accounting_status = a14.accounting_status
           and  a13.category_type = a14.tran_category
           and  a14.data_date='${DATA_DATE}'
           and  a14.bddw_end_date='9999-99-99'
     left join  odata.sym_gl_prod_accounting a15
            on  t2.prod_type = a15.prod_type
           and  t2.accounting_status = a15.accounting_status
           and  a15.tran_category = 'ALL'
           and  a15.data_date='${DATA_DATE}'
           and  a15.bddw_end_date='9999-99-99'
     left join  odata.sym_gl_prod_accounting a16
            on  t2.prod_type = a16.prod_type
           and  a16.tran_category = 'ALL'
           and  a16.accounting_status = 'ALL'
           and  a16.data_date='${DATA_DATE}'
           and  a16.bddw_end_date='9999-99-99'
      left join odata.sym_gl_prod_accounting a161
        on t2.prod_type = a161.prod_type 
       and a161.accounting_status = 'ALL' 
       and a161.data_date = '${DATA_DATE}'
       and a161.bddw_end_date = '9999-99-99'
     left join (select 
                      internal_key
                     ,sum(billed_amt) as billed_amt 
                 from odata.sym_mb_invoice 
                where tran_date = regexp_replace(date_add('${DATA_DATE}',1),'-','')
                  and data_date='${DATA_DATE}'
                  and bddw_end_date='9999-99-99' 
             group by internal_key
                ) t8
            on  t1.internal_key = t8.internal_key
         where  t1.int_class = 'INT'  --正常利息
           and  t1.data_date = '${DATA_DATE}'
           and  t1.bddw_end_date = '9999-99-99'
