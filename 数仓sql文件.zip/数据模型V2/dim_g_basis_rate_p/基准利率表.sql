 -------------------------------------------------------------------
--脚本名称:数仓基准利率维表取数逻辑.sql
--功能描述:用于 gdata.dim_g_basis_rate_p 取数
--作    者:高源
--开发日期:2022-07-25
--直属经理:方杰
--目标表  :gdata.dim_g_basis_rate_p   基准利率维表
--数据原表:
--         odata.sym_irl_basis_rate       基准利率信息表
--         odata.sym_irl_int_basis        基准利率类型表
-------------------------------------------------------------------
insert overwrite table gdata.dim_g_basis_rate_p partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
   nvl(a.int_basis        ,'')      as int_basis       --利率代码
  ,nvl(b.int_basis_desc   ,'')      as int_basis_desc  --利率描述
  ,nvl(a.int_basis_rate   ,0 )      as int_basis_rate  --利率值
  ,nvl(from_unixtime(unix_timestamp(a.effect_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as effect_date     --利率生效日期
  ,nvl(a.ccy              ,'')      as ccy             --币种代码
from odata.sym_irl_basis_rate a
left join odata.sym_irl_int_basis b
 on a.int_basis=b.int_basis
 and b.data_date = '${DATA_DATE}'
 and b.bddw_end_date = '9999-99-99' 
where a.data_date = '${DATA_DATE}'
  and a.bddw_end_date = '9999-99-99'