--2.yangqihao.度小满代偿表
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran_total.sql
--功能描述：度小满代偿表
--作    者：刘丽红
--开发日期：2022-12-08
--直属经理：程宏明
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran_total.sql        
--数据原表：odata.slur_dzz_compensatory_detail               文件类代偿明细表
--修改历史：
--          1、李海涛   2021-06-17    new
--          2、刘丽红   2022-12-08    修改
-------------------------------------------------------------------
insert into dwd.mid_dxm_recv_int_scene_tran_total partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
  loan_no                          as business_no --借据号
  ,-sum(comps_int+comps_prin_pnlt) as yjlx --应收利息
from odata.slur_dzz_compensatory_detail ct
where ct.data_date = '${DATA_DATE}'
  and ct.bddw_end_date = '9999-99-99'
  and ct.prod_type = '110114'
  and ct.comps_status = 'S'  --代偿成功
  and ct.loan_type <> 'O'    --剔除表外代偿
  and ct.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
group by ct.loan_no