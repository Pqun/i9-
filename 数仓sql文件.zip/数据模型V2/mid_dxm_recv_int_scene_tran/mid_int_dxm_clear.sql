--2.yangqihao.度小满明细表插入汇总表
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran_total .sql
--功能描述：度小满明细表插入汇总表
--作    者：刘丽红
--开发日期：2022-12-08
--直属经理：程宏明
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran_total .sql              
--数据原表：dwd.mid_dxm_recv_int_scene_tran     代偿应计利息表         
--修改历史：
--          1、李海涛   2021-06-17    new
--          2、刘丽红   2022-12-08    修改
-------------------------------------------------------------------
insert overwrite table dwd.mid_dxm_recv_int_scene_tran_total partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
  loan_no  as business_no --借据号
  ,sum(case 
        when is_add_sub= '0' then amt
        else -amt 
      end) as yjlx --应收利息
from dwd.mid_dxm_recv_int_scene_tran t 
where t.data_date ='${DATA_DATE}'
  and t.amt<>0
group by loan_no 