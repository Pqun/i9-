--2.yangqihao.度小满GL005场景
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran.sql
--功能描述：度小满GL005场景(正常/逾期90天以内（含）短期贷款计提当日利息  加)
--作    者：刘丽红
--开发日期：2022-12-08
--直属经理：程宏明
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran.sql              
--数据原表：odata.slur_dxm_loan_file                           度小满借据文件表
--          odata.slur_dzz_compensatory_detail                 文件类代偿明细表
--          odata.slur_dxm_repayplan_file_clear                度小满还款计划表
--修改历史：
--          1、李海涛   2021-06-17    new
--          2、刘丽红   2022-12-08    修改
-------------------------------------------------------------------
-- 005场景  正  (加) 
insert overwrite table dwd.mid_dxm_recv_int_scene_tran partition(data_date='${DATA_DATE}' )

select /*+ REPARTITION(1) */
    sum(nvl(c.accrued_int,0))  as amt --应收利息       
	,c.loan_no                   as loan_no --借据号    
	,'GL005'                     as jd_gl_code --场景  
	,'0'                         as is_add_sub --加减标识
from odata.slur_dxm_loan_file_clear c                               --度小满借据文件表
where c.data_date = '${DATA_DATE}'
  and C.bddw_end_date = '9999-99-99'
  and c.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and c.overdue_days > 90
  and exists (select 1  from  odata.slur_dzz_compensatory_detail t1  --文件类代偿明细表
                where t1.data_date = '${DATA_DATE}'
                 and t1.bddw_end_date = '9999-99-99'
                 and t1.loan_no = c.loan_no
                 and t1.prod_type = '110114'                        --有钱花贷款
                 and t1.comps_status = 'S'                          --代偿状态s:成功，f:失败
                 and t1.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','')
             )
  -- 我行当日核算状态表内
  and not exists(select 1 from 
                   (select distinct drf.loan_no as loan_no
                         , drf.channel_date as channel_date
                      from odata.slur_dxm_repayplan_file_clear drf  --度小满贷款还款计划表
                      where drf.data_date = '${DATA_DATE}'
                        and drf.bddw_end_date = '9999-99-99' 
						and not exists(select 1 
						                 from odata.slur_dzz_compensatory_detail cct  --文件类代偿明细表
                                         where cct.data_date = '${DATA_DATE}'
                                           and cct.bddw_end_date = '9999-99-99'
                                           and drf.loan_no = cct.loan_no  
                                           and drf.term = cct.term_no
                                           and cct.channel_date < drf.channel_date
										   and cct.comps_status = 'S'
										   and cct.prod_type = '110114'
                                       )
                        and drf.status = 'N'                   
                        and datediff(from_unixtime(unix_timestamp(drf.channel_date,'yyyyMMdd'),'yyyy-MM-dd'),from_unixtime(unix_timestamp(drf.stmt_date,'yyyyMMdd'),'yyyy-MM-dd')) > 90 
                      ) fyj
                           where fyj.loan_no = c.loan_no 
                            and fyj.channel_date = c.channel_date
                  ) 
  group by c.loan_no