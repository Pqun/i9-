--2.yangqihao.度小满明细表
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran.sql
--功能描述：度小满明细表
--作    者：刘丽红
--开发日期：2022-12-08
--直属经理：程宏明
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran.sql        
--数据原表：odata.slur_dxm_loan_file                 度小满借据文件表
--数据原表：odata.slur_dxm_repay_file                度小满还款文件表
--数据原表：odata.slur_dzz_compensatory_detail       行外文件代偿表
--修改历史：
--          1、杨琦浩   2021-06-17    new
-------------------------------------------------------------------
--GL025 短期贷款实还逾期利息（表内）   减
insert into dwd.mid_dxm_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
  sum(nvl(t1.interest_amt,0)) as amt --应收利息       
  ,t1.loan_no                 as loan_no --借据号    
  ,'GL025(not exists)'        as jd_gl_code --场景  
  ,'1'                        as is_add_sub --加减标识
from odata.slur_dxm_repay_file t1
where t1.channel_date =regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and t1.data_date ='${DATA_DATE}'
  and t1.loan_no in (select
                 distinct t.loan_no
               from odata.slur_dzz_compensatory_detail t
               inner join odata.slur_dxm_loan_file_clear t2
                 on t.loan_no = t2.loan_no
                 and t2.data_date =date_add('${DATA_DATE}',-1)
                 and t2.channel_date =regexp_replace(date_add('${DATA_DATE}',-2),'-','')
                 and t2.overdue_days > 90
               where t.prod_type = '110114'
                 and t.comps_status = 'S'
                 and t.data_date ='2022-03-29'
                 and t.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','') )
  and not exists (select
                    1
                  from odata.slur_dzz_compensatory_detail d
                  where d.prod_type = '110114'
                    and d.comps_status = 'S'
                    and d.data_date ='2022-03-29'
                    and d.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                    and t1.term_no = d.term_no
                    and t1.loan_no =d.loan_no)
group by t1.loan_no

union all

--GL025 短期贷款实还逾期利息（表内）    加
select /*+ REPARTITION(1) */
  sum(nvl(t1.interest_amt,0)) as amt --应收利息       
  ,t1.loan_no                 as loan_no --借据号    
   ,'GL025(exists)'           as jd_gl_code --场景  
   ,'0'                       as is_add_sub --加减标识
from odata.slur_dxm_repay_file t1
where t1.channel_date =regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and t1.data_date ='${DATA_DATE}'
  and loan_no in(select
                   distinct t.loan_no
                 from odata.slur_dzz_compensatory_detail t
                 inner join odata.slur_dxm_loan_file_clear t2
                   on t.loan_no = t2.loan_no
                   and t2.data_date = date_add('${DATA_DATE}',-1)
                   and t2.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
                   and t2.overdue_days <= 90
                 where t.prod_type = '110114'
                   and t.comps_status = 'S'
                   and t.data_date ='2022-03-29'
                   and t.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','') )
  and exists (select
                1
              from odata.slur_dzz_compensatory_detail d
              where d.prod_type = '110114'
                and d.comps_status = 'S'
                and d.data_date ='2022-03-29'
                and d.channel_date <regexp_replace(date_add('${DATA_DATE}',-1),'-','')
                and t1.term_no = d.term_no
                and t1.loan_no =d.loan_no)
group by t1.loan_no
