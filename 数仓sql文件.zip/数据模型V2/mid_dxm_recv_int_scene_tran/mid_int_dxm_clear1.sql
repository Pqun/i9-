--2.yangqihao.度小满应计利息汇总表
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran_total .sql
--功能描述：度小满应计利息汇总表
--作    者：刘丽红
--开发日期：2022-12-08
--直属经理：程宏明
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran_total .sql              
--数据原表：dwd.mid_dxm_recv_int_scene_tran_total     代偿应计利息汇总表         
--修改历史：
--          1、李海涛   2021-06-17    new
--          2、刘丽红   2022-12-08    修改
-------------------------------------------------------------------
with tmp as (
select 
  t.business_no  as business_no --借据号
  ,t.yjlx        as yjlx --应收利息
from dwd.mid_dxm_recv_int_scene_tran_total t 
where t.data_date ='${DATA_DATE}' 
 union all 
select 
  t1.business_no  as business_no --借据号
  ,t1.yjlx        as yjlx --应收利息
from dwd.mid_dxm_recv_int_scene_tran_total t1 
where t1.data_date =date_add('${DATA_DATE}',-1) 
)

insert overwrite table dwd.mid_dxm_recv_int_scene_tran_total partition(data_date='${DATA_DATE}')

select  /*+ REPARTITION(1) */
  tmp.business_no    as business_no --借据号
  ,sum(yjlx)         as yjlx --应收利息
from tmp 
group by tmp.business_no