--2.yangqihao.度小满GL117_hx场景
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran.sql
--功能描述：度小满GL117_hx场景
--作    者：杨琦浩
--开发日期：2023-11-28
--直属经理：方杰
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran.sql              
--数据原表：odata.slur_dxm_reduce_file                     度小满减免文件
--          odata.slur_dzz_compensatory_detail                 文件类代偿明细表 
--          odata.slur_dxm_repayplan_file_clear                度小满贷款还款计划表
--修改历史：
--          1、杨琦浩   2023-11-28    new
--          2、杨琦浩   2024-02-22    slur_dxm_repayplan_file改为slur_dxm_repayplan_file_clear取数
-------------------------------------------------------------------
-- GL117_hx 短期贷款手工减免正常利息（表内）
insert into dwd.mid_dxm_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
     sum( t2.int_reduced_amt_manual )      as amt --应收利息       
     ,t2.loan_id                           as loan_no --借据号    
     ,'GL117_hx'                           as jd_gl_code --场景  
     ,'1'                                  as is_add_sub --加减标识
  from odata.slur_dxm_reduce_file t2                                           --度小满减免文件
  inner join odata.slur_dxm_loan_file_clear t3                              --度小满借据文件表
    on t3.loan_no = t2.loan_id 
    and t3.data_date = date_add('${DATA_DATE}',-1)
    and t3.bddw_end_date = '9999-99-99'
    and t3.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
    and t3.overdue_days <= 90
  inner join odata.slur_dxm_repayplan_file_clear drf                                     --度小满贷款还款计划表
    on t2.loan_id = drf.loan_no 
    and drf.data_date = '${DATA_DATE}'
    and drf.bddw_end_date = '9999-99-99'
    and t2.term_no = drf.term 
    and drf.channel_date = regexp_replace(substr(t2.channel_date,1,10),'-','')
    and datediff(from_unixtime(unix_timestamp(drf.channel_date,'yyyyMMdd'),'yyyy-MM-dd')
                ,from_unixtime(unix_timestamp(drf.stmt_date,'yyyyMMdd'),'yyyy-MM-dd')) - t3.grace_day <=0 
  where t2.data_date = '${DATA_DATE}'
    and t2.bddw_end_date = '9999-99-99'
    and substr(t2.channel_date,1,10) = date_add('${DATA_DATE}',-1 )
    and exists (select 1
              from odata.slur_acc_writeoff_detail awd
              where awd.data_date = '${DATA_DATE}' 
                and awd.bddw_end_date = '9999-99-99'
                and awd.status = 'S'
                and awd.loan_no = t2.loan_id)
    group by t2.loan_id 