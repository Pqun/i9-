--2.yangqihao.度小满GL009场景
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran.sql
--功能描述：度小满GL009场景(逾期90天以内（含）短期贷款计提当日罚息  当日-上日    加)
--作    者：刘丽红
--开发日期：2022-12-08
--直属经理：程宏明
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran.sql              
--数据原表：odata.slur_dxm_loan_file                           度小满借据文件表
--          odata.slur_dzz_compensatory_detail                 文件类代偿明细表
--          odata.slur_dxm_repayplan_file                      度小满贷款还款计划表              
--修改历史：
--          1、李海涛   2021-06-17    new
--          2、刘丽红   2022-12-08    修改
-------------------------------------------------------------------
--GL009 逾期90天以内（含）短期贷款计提当日罚息  当日-上日    正 (加)
insert into dwd.mid_dxm_recv_int_scene_tran partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
       sum( t2.penalty_due - t3.penalty_due ) as amt --应收利息       
       ,t2.loan_no                            as loan_no --借据号                       
       ,'GL009'                               as jd_gl_code --场景  
       ,'0'	                                  as is_add_sub --加减标识
  from odata.slur_dxm_repayplan_file_clear t2                                  --度小满贷款还款计划表
  inner join odata.slur_dxm_repayplan_file_clear t3                            --度小满贷款还款计划表
    on t3.loan_no = t2.loan_no 
	and t3.data_date = date_add('${DATA_DATE}',-1)
	and t3.bddw_end_date = '9999-99-99'
	and t3.term = t2.term 
	and t3.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
  where t2.data_date = '${DATA_DATE}'
	and t2.bddw_end_date = '9999-99-99'
	and t2.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
  -- 1.对客逾期天数>90
    and exists(select 1  
	             from odata.slur_dxm_loan_file_clear dlf                        --度小满借据文件表
				 where dlf.data_date = '${DATA_DATE}'
	               and dlf.bddw_end_date = '9999-99-99'
				   and dlf.loan_no = t2.loan_no 
				   --and t2.tran_date = dlf.d_tran_date
                   and t2.channel_date = dlf.channel_date 
				   and dlf.overdue_days > 90 )
	-- 2.做过代偿
    and exists (select 1 
	              from odata.slur_dzz_compensatory_detail t                      --文件类代偿明细表
				  where t.data_date = '${DATA_DATE}'
	               and t.bddw_end_date = '9999-99-99'
				   and t.loan_no = t2.loan_no 
		           and t.prod_type = '110114' 
				   and t.comps_status = 'S' 
				   and t.channel_date < t2.channel_date) 
  -- 3.当期未代偿
	and not exists (select 1 
	                  from odata.slur_dzz_compensatory_detail d                   --文件类代偿明细表
	                  where d.data_date = '${DATA_DATE}'
	                    and d.bddw_end_date = '9999-99-99'
					    and d.prod_type = '110114' 
					    and d.comps_status = 'S' 
					    and d.channel_date < t2.channel_date 
		                and t2.term = d.term_no 
					    and t2.loan_no = d.loan_no) 
  -- 4.我行核算状态当日表内
    and not exists(select 1 
	                 from (select distinct drf.loan_no as loan_no
					            , drf.channel_date     as channel_date 
                             from odata.slur_dxm_repayplan_file_clear drf         --度小满贷款还款计划表
                             where drf.data_date = '${DATA_DATE}'
	                           and drf.bddw_end_date = '9999-99-99'
							   and drf.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')  
							   and not exists(select 1 
							                    from odata.slur_dzz_compensatory_detail cct 
												where cct.data_date = '${DATA_DATE}'
	                                              and cct.bddw_end_date = '9999-99-99'
												  and drf.loan_no = cct.loan_no 
												  and drf.term = cct.term_no
                                                  and cct.channel_date < drf.channel_date 
												  and cct.comps_status = 'S' 
												  and cct.prod_type = '110114' )
                           and drf.status = 'N' 
						   and datediff(from_unixtime(unix_timestamp(drf.channel_date,'yyyyMMdd'),'yyyy-MM-dd')
                                       ,from_unixtime(unix_timestamp(drf.stmt_date,'yyyyMMdd'),'yyyy-MM-dd')) > 90) fyj
                   where fyj.loan_no = t2.loan_no 
				     and fyj.channel_date = t2.channel_date)
   group by t2.loan_no 
union all	
--GL009 逾期90天以内（含）短期贷款计提当日罚息  当日-上日	 (加)
select /*+ REPARTITION(1) */
	-sum( t2.penalty_due - t3.penalty_due ) as amt --应收利息       
	,t2.loan_no                             as loan_no --借据号    
	,'GL009'                                as jd_gl_code --场景  
	,'0'                                    as is_add_sub --加减标识
  from odata.slur_dxm_repayplan_file_clear t2                                --度小满贷款还款计划表     
  inner join odata.slur_dxm_repayplan_file_clear t3                          --度小满贷款还款计划表  
	on t3.loan_no = t2.loan_no 
	and t3.data_date = date_add('${DATA_DATE}',-1)
	and t3.bddw_end_date = '9999-99-99'
	and t3.term = t2.term 
	and t3.channel_date =  regexp_replace(date_add('${DATA_DATE}',-2),'-','') 
  where t2.data_date = '${DATA_DATE}'
	and t2.bddw_end_date = '9999-99-99'
	and t2.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','') 
    and exists(select 1 
	             from odata.slur_dzz_compensatory_detail t                             --文件类代偿明细表                            
	           inner join odata.slur_dxm_loan_file_clear t1                          --度小满借据文件表
	             on t.loan_no = t1.loan_no 
				 and t1.data_date = '${DATA_DATE}'
	             and t1.bddw_end_date = '9999-99-99'
	          	 and t1.overdue_days <= 90 
	          	 and t1.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
	          where t.data_date = '${DATA_DATE}'
	              and t.bddw_end_date = '9999-99-99'
				  and t.prod_type = '110114' 
	          	  and t.comps_status = 'S' 
	          	  and t.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-','')
	          	  and t.loan_no = t2.loan_no 
				  and t2.term = t.term_no 
	          ) 
	group by t2.loan_no 
	 