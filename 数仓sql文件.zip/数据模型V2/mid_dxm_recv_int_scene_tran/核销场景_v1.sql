--2.yangqihao.度小满核销场景
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran.sql
--功能描述：度小满核销场景
--作    者：刘丽红
--开发日期：2022-12-08
--直属经理：程宏明
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran.sql              
--数据原表：odata.slur_dxm_loan_file                           度小满借据文件表
--          odata.slur_dzz_compensatory_detail                 文件类代偿明细表
--          odata.slur_dxm_repayplan_file_clear                度小满贷款还款计划表 
--          odata.slur_acc_writeoff_detail                     核销数据表          
--修改历史：
--          1、李海涛   2021-06-17    new
--          2、刘丽红   2022-12-08    修改
--          3、杨琦浩   2024-02-22    slur_dxm_repayplan_file改为slur_dxm_repayplan_file_clear取数
-------------------------------------------------------------------
--核销场景
insert into dwd.mid_dxm_recv_int_scene_tran partition(data_date='${DATA_DATE}')
--HX005 正常/逾期90天以内（含）短期贷款计提当日利息核销  减
select /*+ REPARTITION(1) */
  sum(nvl(t1.accrued_int,0)) as amt --应收利息       
  ,awd.loan_no               as loan_no --借据号    
  ,'HX005'                   as jd_gl_code --场景  
  ,'1'                       as is_add_sub --加减标识
from odata.slur_acc_writeoff_detail awd
inner join odata.slur_dxm_loan_file_clear t1 --当日借据
   on awd.loan_no = t1.loan_no
  and t1.overdue_days <= 90
  and t1.data_date = '${DATA_DATE}'
  and t1.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
where awd.data_date = '${DATA_DATE}' 
  and awd.bddw_end_date = '9999-99-99'
  and awd.status = 'S'
group by awd.loan_no

union all

--HX009 逾期90天以内（含）短期贷款计提当日罚息核销  当日-上日    减
--当日
select /*+ REPARTITION(1) */
  sum(nvl(t2.penalty_due,0)) as amt --应收利息       
  ,t2.loan_no                as loan_no --借据号    
  ,'HX009'                   as jd_gl_code --场景  
  ,'1'                       as is_add_sub --加减标识
from odata.slur_dxm_repayplan_file_clear t2  --度小满贷款还款计划表
where t2.data_date = '${DATA_DATE}'
  and t2.channel_date = regexp_replace(date_add(t2.data_date,-1),'-','')
  and t2.loan_no in (select awd.loan_no
              from odata.slur_acc_writeoff_detail awd
              inner join odata.slur_dxm_loan_file t1 --当日借据
                 on awd.loan_no = t1.loan_no
                and t1.overdue_days <= 90
                and t1.data_date = '${DATA_DATE}'
                and t1.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
              where awd.data_date = '${DATA_DATE}'
                and awd.bddw_end_date = '9999-99-99'
				and substr(awd.tran_date,1,10) <= '${DATA_DATE}'
                and awd.status = 'S')
group by t2.loan_no
union all
--上日
select /*+ REPARTITION(1) */
  -sum(nvl(t2.penalty_due,0)) as amt --应收利息       
  ,t2.loan_no                 as loan_no --借据号    
  ,'HX009'                    as jd_gl_code --场景  
  ,'1'                        as is_add_sub --加减标识
from odata.slur_dxm_repayplan_file_clear t2  --度小满贷款还款计划表
where t2.data_date = date_add('${DATA_DATE}',-1)
  and t2.channel_date = regexp_replace(date_add(t2.data_date,-1),'-','')
  and t2.loan_no in (select awd.loan_no
              from odata.slur_acc_writeoff_detail awd
              inner join odata.slur_dxm_loan_file t1 --当日借据
                 on awd.loan_no = t1.loan_no
                and t1.overdue_days <= 90
                and t1.data_date = '${DATA_DATE}'
                and t1.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
              where awd.data_date = '${DATA_DATE}'
                and awd.bddw_end_date = '9999-99-99'
				and substr(awd.tran_date,1,10) <= '${DATA_DATE}'
                and awd.status = 'S')
group by t2.loan_no

union all

--HX025 短期贷款实还逾期利息（表内）核销    加
select /*+ REPARTITION(1) */
  sum(nvl(t1.interest_amt,0)) as amt --应收利息       
  ,t1.loan_no                 as loan_no --借据号    
  ,'HX025'                    as jd_gl_code --场景  
  ,'0'                        as is_add_sub --加减标识
from odata.slur_dxm_repay_file t1
where t1.channel_date =regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and t1.data_date ='${DATA_DATE}'
  and exists (select 1
              from odata.slur_acc_writeoff_detail awd
              inner join odata.slur_dxm_loan_file_clear t2 --上日借据
                 on awd.loan_no = t2.loan_no
                and t2.overdue_days <= 90
                and t2.data_date = date_add('${DATA_DATE}',-1)
                and t2.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
              where awd.data_date = '${DATA_DATE}' 
                and awd.bddw_end_date = '9999-99-99'
                and awd.status = 'S'
                and awd.loan_no = t1.loan_no)
group by t1.loan_no

union all

--HX029 短期贷款实还罚息（表内）核销 加
select /*+ REPARTITION(1) */
  sum(nvl(t1.penalty_amt,0)) as amt --应收利息       
  ,t1.loan_no                as loan_no --借据号    
  ,'HX029'                   as jd_gl_code --场景  
  ,'0'                       as is_add_sub --加减标识
from odata.slur_dxm_repay_file t1
where t1.channel_date =regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and t1.data_date ='${DATA_DATE}'
  and exists (select 1
              from odata.slur_acc_writeoff_detail awd
              inner join odata.slur_dxm_loan_file_clear t2 --上日借据
                 on awd.loan_no = t2.loan_no
                and t2.overdue_days <= 90
                and t2.data_date = date_add('${DATA_DATE}',-1)
                and t2.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
              where awd.data_date = '${DATA_DATE}' 
                and awd.bddw_end_date = '9999-99-99'
                and awd.status = 'S'
                and awd.loan_no = t1.loan_no)
group by t1.loan_no