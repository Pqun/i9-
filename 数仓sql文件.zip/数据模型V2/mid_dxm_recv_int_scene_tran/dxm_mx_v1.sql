--2.yangqihao.度小满明细表
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran_total.sql
--功能描述：度小满明细表
--作    者：刘丽红
--开发日期：2022-12-08
--直属经理：程宏明
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran_total.sql        
--数据原表：odata.slur_dxm_loan_file_clear                 度小满借据文件表
--修改历史：
--          1、杨琦浩   2021-06-17    new
-------------------------------------------------------------------
insert into dwd.mid_dxm_recv_int_scene_tran_total partition(data_date='${DATA_DATE}')
select /*+ REPARTITION(1) */
loan_no              as business_no --借据号
,nvl(t1.debit_int,0) as yjlx --应计利息
from odata.slur_dxm_loan_file_clear t1
where t1.data_date = '${DATA_DATE}'
  and t1.bddw_end_date = '9999-99-99'
  and t1.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and t1.overdue_days <= 90  
union all
select /*+ REPARTITION(1) */
loan_no               as business_no --借据号
,-nvl(t1.debit_int,0) as yjlx --应计利息
from odata.slur_dxm_loan_file_clear t1
where t1.data_date = date_add('${DATA_DATE}',-1)
  and t1.bddw_end_date = '9999-99-99'
  and t1.channel_date = regexp_replace(date_add('${DATA_DATE}',-2),'-','')
  and t1.overdue_days <= 90