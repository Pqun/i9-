--2.yangqihao.dwd.mid_dxm_recv_int_scene_tran
-------------------------------------------------------------------
--脚本名称：dwd.mid_dxm_recv_int_scene_tran.sql
--功能描述：度小满
--作    者：刘丽红
--开发日期：2022-12-08
--直属经理：程宏明
--目标表  ：
--          dwd.mid_dxm_recv_int_scene_tran.sql              
--数据原表：odata.slur_dxm_loan_file_clear                     度小满借据文件表
--          odata.slur_dzz_compensatory_detail                 文件类代偿明细表
--修改历史：
--          1、杨琦浩   2023-09-06    new
-------------------------------------------------------------------
insert overwrite table dwd.mid_dxm_recv_int_scene_tran partition(data_date='${DATA_DATE}')
--GL005 正常/逾期90天以内（含）短期贷款计提当日利息  加
select /*+ REPARTITION(1) */
    sum(nvl(c.accrued_int,0))  as amt --应收利息
    ,c.loan_no                 as loan_no --借据号
    ,'GL005'                   as jd_gl_code --场景
    ,'0'                       as is_add_sub --加减标识
from odata.slur_dxm_loan_file_clear c
where c.data_date = '${DATA_DATE}'
  and c.bddw_end_date = '9999-99-99'
  and c.channel_date = regexp_replace(date_add('${DATA_DATE}',-1),'-','')
  and c.overdue_days > 90
  and c.loan_no in (select distinct t1.loan_no
                    from odata.slur_dzz_compensatory_detail t1 
                    where t1.data_date = '2022-03-29'
                      and t1.bddw_end_date = '9999-99-99'
                      and t1.prod_type = '110114'
                      and t1.comps_status = 'S'
                      and t1.channel_date < regexp_replace(date_add('${DATA_DATE}',-1),'-',''))
group by c.loan_no