--2.yangqihao.dwd_d_indv_loan_bill_p
-------------------------------------------------------------------
--脚本名称:dwd_d_indv_loan_bill_p
--功能描述:个人贷款借据信息表
--作    者:于国睿
--开发日期:2021-09-24
--直属经理:方杰
--目标表  :dwd.dwd_d_indv_loan_bill_p 
--来源表：odata.sllv_mb_acct_schedule_detail    账户计划明细表
--来源表：odata.sllv_mb_invoice                 单据表
--来源表：odata.sllv_mb_acct                    账户基本信息表
--来源表：odata.sym_gl_prod_accounting          产品科目表
--来源表：odata.sym_cif_client                  客户信息表
--来源表：odata.sym_cif_client_document         客户证件信息表
--来源表：odata.sym_cif_client_contact_tbl      客户联系信息表
--来源表：odata.sllv_mb_acct_balance            账户余额表
--来源表：odata.sllv_mb_acct_int_detail         利息明细表
--来源表：odata.plm_loan_info_detail            贷款五级分类
--来源表：odata.order_contract_sign             合同签署表
--来源表：odata.order_main_loan_order           订单主表
--来源表：odata.sym_mb_prod_type                产品类型定义表
--来源表：odata.acct_loan_category              贷款五级分类
--来源表：odata.gl_v_gl_subject                 科目名称表
--来源表：odata.sym_mb_prod_define              产品科目表
--来源表：dwd.dwd_d_indv_credit_cont_p          个人授信合同表
--来源表：gdata.dim_g_partner_mapping_p         合作方编码映射表
--来源表：odata.order_bank_account_info         放款账户表 
--来源表：odata.order_product_loan_info         产品贷款信息表  
--来源表：odata.order_repay_account             还款账户信息表   
--来源表：odata.pawn_pawn_base                  押品主表
--来源表：odata.pawn_pawn_machine               机器抵押品信息表
--来源表：odata.order_job_info                  工作信息表 
--来源表：odata.order_main_credit_order         授信订单主表
--来源表：odata.order_company_info              公司信息表
--修改历史:
--         1、于国睿     2021-09-24     新建
--         2、高源       2022-06-06     新增应收未收利息、应收利息科目、利息调整、利息调整科目、利息拖欠日期、
--                                      来源系统、贷款投向行业、结清标识等字段,结清日期逻辑调整
--         3、高源       2022-06-22     新增记账时间字段逻辑,调整了五级分类逻辑
--         4、高源       2022-07-07     新增计息基础、客户所属行业、贷款业务细类、贷款用途明细分类字段逻辑
--         5、高源       2022-07-11     新增110158锡望贷-家电汇产品
--         6、高源       2022-07-12     贷款合同号逻辑调整
--         7、高源       2022-08-10     借据起始日期、借据到期日、借据关闭日期逻辑调整，结清时间格式调整
--         8、高源       2022-09-22     新增110161霖梓H5产品
--         9、高源       2022-10-09     新增机构号、贷款支用申请编号字段逻辑
--         10、高源      2022-10-24     贷款合同状态冲正部分逻辑调整
--         11、高源      2022-11-03     还款方式、还款频率逻辑调整
--         12.华天顺      2022-12-02    新增核算状态字段，新增锡望贷-上牌车，非上牌车产品
--         13.华天顺      2022-12-14    新增核算哈罗单车新产品
--         14.华天顺      2022-12-27    担保方式取数逻辑调整
--         15.华天顺     2023-01-03     逾期天数取数逻辑调整，新增逾期本金，利息和本金逾期日字段
--         16.华天顺      2023-01-10    锡惠贷个人融贷款合同号取数逻辑变更
--         17.华天顺     2023-01-11     哈罗，锡望贷取迁移后合同号
--         18.华天顺     2023-02-03     车商贷担保方式取数逻辑调整
--         19.华天顺     2023-02-23     新产品剔除失效合同
--         20.杨琦浩     2023-03-03     修复业务细类为空问题
--         21.杨琦浩     2023-03-14     增加到期日字段
--         22.杨琦浩     2023-03-16     新增乐花借钱、51半自营产品
--         23.杨琦浩     2023-03-27     担保方式逻辑调整，孚厘贷款业务细类逻辑调整
--         24.杨琦浩     2023-03-28     得物、颐尔信利息调整取数逻辑修改
--         25.杨琦浩     2023-04-14     业务细类逻辑修改
--         26.高源       2023-04-14     锡惠贷个人融、大鹅经营贷、铁甲产品投向行业逻辑调整
--         27.杨琦浩     2023-05-17     新增项目ID字段
--         28.杨琦浩     2023-06-21     新增小赢拒量产品
--         29.杨琦浩     2023-06-19     支付方式新增逻辑
--         30.杨琦浩     2023-06-27     授信信息逻辑调整
--         31.杨琦浩     2023-07-07     孚厘业务细类逻辑调整
--         32.杨琦浩     2023-07-21     新增聚盟产品
--         33.杨琦浩     2023-08-24     新增放款、还款账号信息字段
--         34.杨琦浩     2023-08-30     新增表内、表外欠息字段
--         35.杨琦浩     2023-08-31     修改计息方式取数逻辑
--         36.杨琦浩     2023-09-20     新增锡望贷-京东产品
--         37.杨琦浩     2023-09-22     修改信贷员工号逻辑
--         38.杨琦浩     2023-10-12     修改110151、110160产品担保方式
--         39.杨琦浩     2023-10-25     表外欠息调整为非应计标志
--         40.姚威       2023-11-09     新增合作资金方放款金额
--         41.杨琦浩     2023-11-18     表内欠息调整为罚息利率
--         42.姚威       2023-11-28     支付方式调整
--         43.杨琦浩     2023-12-01     入账、还款账号逻辑变更
--         44.杨琦浩     2023-12-13     加入平安普惠核销逻辑
--         45.邓权       2023-12-20     修改放款金额取上一日放款金额
--         46.杨琦浩     2024-01-10     新增vivo维易贷产品
--         47.杨琦浩     2024-03-20     新增锡享贷产品
-------------------------------------------------------------------
with t16
as (
    select 
         a.internal_key
        ,a.stage_no              as stage_no                                                               --期次
        ,from_unixtime(unix_timestamp(min(a.start_date),'yyyyMMdd'),'yyyy-MM-dd')      as term_start_date  --期次开始日期
        ,from_unixtime(unix_timestamp(max(a.end_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_end_date    --期次到期日期
    from odata.sllv_mb_acct_schedule_detail a
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    group by 
         a.internal_key
        ,a.stage_no
        ,a.start_date
        ,a.end_date
    ),
t17 as 
(
    select 
         a.internal_key
        ,b.stage_no  --期次
        ,from_unixtime(unix_timestamp(max(c.start_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_start_date    --期次开始期日
    from odata.sllv_mb_invoice a
   inner join (select a.internal_key
                     ,max(cast(a.stage_no as int)) as stage_no
                 from odata.sllv_mb_invoice a
                where a.data_date = '${DATA_DATE}'
                  and a.bddw_end_date = '9999-99-99'
                  and a.amt_type = 'INT'
                group by a.internal_key) b
     on a.internal_key=b.internal_key
    and a.stage_no=b.stage_no
   left join odata.sllv_mb_acct_schedule_detail c
     on c.data_date = '${DATA_DATE}'
    and c.bddw_end_date = '9999-99-99'
    and a.internal_key = c.internal_key
    and a.stage_no = c.stage_no
    and a.amt_type = c.amt_type
  where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and a.amt_type <> 'ODP'
    group by a.internal_key
            ,b.stage_no
),
t6 as 
(
    select  internal_key
           ,min(case when amt_type='PRI'then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_pri
           ,min(case when amt_type='INT'then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_int
    from odata.sllv_mb_invoice
      where outstanding>0   
        and data_date='${DATA_DATE}'
        and due_date < regexp_replace('${DATA_DATE}','-','')
        and bddw_end_date='9999-99-99'
    group by internal_key
),
t19 as  
(select internal_key
       ,min( from_unixtime(unix_timestamp(nvl(due_date,''),'yyyyMMdd'),'yyyy-MM-dd')) as due_date_pri
       ,sum(case when amt_type = 'PRI' then billed_amt else 0 end) as due_amount_pri
   from odata.sllv_mb_invoice
  where outstanding > 0
    and amt_type = 'PRI'
    and data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
  group by internal_key
),
t20 as 
(select internal_key
       ,min( from_unixtime(unix_timestamp(nvl(due_date,''),'yyyyMMdd'),'yyyy-MM-dd')) as due_date_int
       ,sum(case when amt_type = 'INT' then billed_amt else 0 end) as due_amount_int
   from odata.sllv_mb_invoice
  where outstanding > 0
    and amt_type = 'INT'
    and data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
  group by internal_key
)
insert overwrite table dwd.dwd_d_indv_loan_bill_p partition(data_date='${DATA_DATE}',prod_code)
select 
       /*+ REPARTITION(1) */
       nvl(t1.cmisloan_no,'')                                                                   as bill_no  --借据号
      ,nvl(t18.prod_desc,'')                                                                  as prod_name  --产品名称
      ,nvl(t1.base_acct_no,'')                                                                as acct_no  --账号
      ,nvl(t1.acct_seq_no,'')                                                                 as acct_seq_no  --账户序列号
      ,nvl(t14.product_type,'')                                                               as biz_prod_code  --业务产品号
      ,nvl(t14.sub_product_type,'')                                                           as sub_biz_prod_code  --业务子产品号
      ,'01'                                                                                   as accting_cacl_mode --会计核算方式
      ,nvl(t2.gl_code_a,'')                                                                   as subj_no  --科目号
      ,nvl(t22.gl_code_name,'')                                                               as subj_name  --科目名称
      ,nvl(t1.client_no,'')                                                                   as cust_id  --客户号
      ,nvl(t3.ch_client_name,'')                                                              as cust_name  --客户姓名     
      ,nvl(t4.document_type,'')                                                               as cert_type  --证件类型
      ,nvl(t4.document_id,'')                                                                 as cert_no  --证件号
      ,nvl(t5.contact_tel,'')                                                                 as mobile_no  --客户手机号
      --,nvl(t27.credit_limit,0)                  as credit_limit  --授信额度
      --,nvl(t27.credit_terms,'')                 as credit_term  --授信期限
      --,nvl(substr(t27.credit_start_date,1,10),'')     as credit_start_date  --授信起始日期
      --,nvl(substr(t27.credit_mature_date,1,10),'')    as credit_end_date  --授信到期日期
      ,coalesce(t27.credit_limit,t31.credit_limit,0)                                          as credit_limit  --授信额度
      --,coalesce(t27.credit_terms,t31.credit_terms,'')                 as credit_term  --授信期限
      ,''                                                                                     as credit_term  --授信期限
      ,coalesce(substr(t27.credit_start_date,1,10),substr(t31.credit_start_date,1,10),'')     as credit_start_date  --授信起始日期
      ,coalesce(substr(t27.credit_mature_date,1,10),substr(t31.credit_mature_date,1,10),'')   as credit_end_date  --授信到期日期
      ,nvl(t14.credit_order_id,t14.loan_id)                                                   as credit_cont_no  --授信合同编号
      ,nvl(t25.repay_type,'')                                                                 as repay_mode  --还款方式
      ,from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')               as loan_grant_date  --贷款发放日期
      ,'00:00:00'                                                                             as loan_grant_time  --贷款发放时间
      ,trim(coalesce(t8.contract_no,t61.contract_no,t60.contract_no,t62.contract_no,t1.cmisloan_no))       as loan_cont_no  --贷款合同号
      ,''                                                                                     as fin_supp_mode  --贷款财政扶持方式               
      ,case when t1.prod_type in ('110115','110116','110144','110123','110124','110125','110134','110154','110155','110168','110163','110172','110175','110180','110151','110160','110183') then 'C' 
            when t1.prod_type in ('110110','110122','110129','110130','110166') and t25.loan_method = 2 then 'D' 
            when t1.prod_type in ('110110','110122','110129','110130','110166') and t25.loan_method = 3 then 'C' 
            when t1.prod_type in ('110159','110161','110165') then 'C'
            when t1.prod_type in ('110120','110121') and t25.mortgage_type = '1' then 'B'
            when t1.prod_type in ('110120','110121') and t25.mortgage_type = '3' then 'A'
            when t1.prod_type in ('110120','110121') and t25.mortgage_type in ('2','4') then 'A'
            --when t1.prod_type in ('110151') then 'A'
            when t1.prod_type in ('110140','110152','110153','110156','110158','110170','110171','110173','110187') then 'D'  
            else '' 
        end                                                                                   as loan_guar_mode  --贷款担保方式                  
      ,case when t2.gl_code_a = '10400101' then '2' 
            when t2.gl_code_a = '10400201' then '3'  
            else '' 
        end                                                                                   as loan_purp  --贷款用途
      ,'TR05'                                                                                 as pric_benc  --定价基准
      ,case when t33.loan_no is not null then '108'
            when t1.acct_close_reason='发放冲正'  then '111'
            when t1.acct_status<>'C' and t1.accounting_status<>'ZHC' then '107' 
            when t1.acct_status<>'C' and t1.accounting_status='ZHC' then '105'
            when t1.acct_status='C' then '106'
            when t14.status in(1,2,13,14) then '101'
            when t14.status in(4,5) then '103'
            when t14.status =11 then '104'
            when t14.status =12 then '102'
            when t14.status =15 then '111'
        end                                                                                  as loan_cont_status  --贷款合同状态
      ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')      as loan_start_date  --借据起始日期
      ,nvl(from_unixtime(unix_timestamp(t1.ori_maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')   as loan_mature_date  --借据到期日期
      ,nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as loan_close_data  --借据关闭日期
      ,nvl(t9.total_amount_prev,0)                                                                as loan_amt  --放款金额
      ,nvl(t54.stage_no_max,0)                                                               as total_loan_terms  --放款总期数
      ,nvl(t17.stage_no,0)                                                                   as curr_term_no  --当前期次
      ,'RF01'                                                                                as rate_type  --利率类型
      ,nvl(t11.real_rate,0)                                                                  as real_rate  --实际利率
      ,nvl(t50.partner_id,'')                                                                as partner_id  --合作方编码
      ,nvl(t50.partner_name,'')                                                              as partner_name  --合作方名称
      ,''                                                                                    as sub_channel_type  --贷款办理渠道
      ,case when t1.prod_type in ('110105','110115','110134','110138','110140','110152','110144','110154','110155','110161') then '1'  --锡锡贷,锡车贷(个人消费),锡房贷消费贷,颐而信消费贷,大鹅贷消费
            when t1.prod_type in ('110129'  --锡机贷-上牌车-免征
                                 ,'110130'  --锡机贷-上牌车-非免征
                                 ,'110110'  --锡机贷
                                 ,'110122'  --锡机贷-工程机械-易起投-非免征
                                 ,'110108'  --锡房贷-亿联
                                 ,'110116'  --锡车贷-车主个人经营贷款
                                 ,'110124'  --锡惠贷个人经营贷款-免征
                                 ,'110125'  --锡惠贷个人经营贷款
                                 ,'110120'  --车商贷
                                 ,'110121'  --车商贷-免征
                                 ,'110153'  --大鹅贷经营
                                 ,'110151'  --铁甲          
                                 ,'110156'  --锡望贷—易起投
                                 ,'110158'  --锡望贷—家电汇
                                 ,'110160'  --锡惠贷个人融
                                 ,'110165'  --锡望贷-上牌车
                                 ,'110166'  --锡望贷-非上牌车
                                 ,'110170'  --饿了么经营贷
                                 ,'110173'  --聚盟
                                 ,'110180'  --锡望贷-京东
                                 ,'110187'  --锡享贷-厚沃个人
                                 ) then '' --经营性贷款不报
            else '0' 
        end                             as consume_scen_flag  --消费场景标签            
      ,1.00                             as invest_ratio  --出资比例
      ,t1.ccy                           as ccy  --币种
      ,nvl(t26.attr_value,0)            as grace_days  --宽限天数
      ,case when t33.loan_no is not null then substr(t33.tran_date,1,10)
            when nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')>'${DATA_DATE}'
            then ''
            else nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'') 
        end                             as clear_date  --结清日期
      ,case when t6.internal_key is not null
            then least(nvl(t6.due_date_pri,''),nvl(t6.due_date_int,''))
            else '' 
        end   as overdue_start_date  --逾期起始日
      ,case when t6.internal_key is not null
            then greatest(nvl(datediff('${DATA_DATE}',t6.due_date_pri),0),nvl(datediff('${DATA_DATE}',t6.due_date_int),0))
            else 0  
        end                       as overdue_days --逾期天数
      ,''                               as defer_mature_date  --贷款展期到期日期
      ,case when t6.due_date_pri is not null and t6.due_date_int is null 
            then '01'
            when t6.due_date_pri is null and t6.due_date_int is not null 
            then '02'
            when t6.due_date_pri is not null and t6.due_date_int is not null 
            then '03'
            else '' 
        end                             as overdue_type  --逾期类型
      ,case when t12.loan_id is not null then nvl(t12.manual_five_class,'')
            when t12.loan_id is null then nvl(t30.five_category,'')
            else ''
        end                             as five_risk_level  --贷款5级分类  
      ,case when t14.sub_product_type='11' then '12201010000252038' 
            when t14.sub_product_type='43' then case when t35.base_acct_no is not null and t37.loan_id is not null 
                                                     then nvl(t37.account_no,'')  --锡享贷登记账户
                                                     else nvl(t28.account_no,'')
                                                end
            else coalesce(t23.linked_base_acct_no,t28.account_no,'') end as receive_acct_no   --贷款入账账号 
      --,case when t1.prod_type in('110124','110125','110123') 
      --      then nvl(t28.account_no,'')  
      --      else nvl(t29.account_no,'')
      --  end                             as repay_acct_no  --还款账号
      ,case when t14.sub_product_type='43' then case when t36.base_acct_no is not null and t37.loan_id is not null 
                                                     then nvl(t37.account_no,'')  --锡享贷登记账户
                                                     else nvl(t29.account_no,'')
                                                end
            else coalesce(t29.account_no,t32.base_acct_no,'') end       as repay_acct_no  --还款账号
      --,case when t25.payment_mode=1 then '1' 
      --      when t25.payment_mode=2 then '2' 
      --      else ''  
      --  end                             as payment_mode  --支付方式
      ,case when t25.payment_mode is not null then cast (t25.payment_mode as string)
            when t28.payment_mode is not null then cast (t28.payment_mode as string) --110151、110156支付方式
            when t1.prod_type = '110156' and t25.payment_mode is null and t28.payment_mode is null then '2'              --110156支付方式  2 （受托支付）
       else ''  
       end                              as payment_mode  --支付方式
      ,'02'                             as cash_tran_flag  --现转标志
      ,nvl(t43.realname,'')             as credit_tlr_name  --信贷员姓名
      ,nvl(case when t43.username='fanyuandai' then 'xs0128' else t43.username end,'') --此人有两个username,取xs开头的
                                        as credit_tlr_id  --信贷员员工号
      ,case t11.cycle_freq
            when 'M1' then 'B01'
            when 'M3' then 'B02'
            when 'M6' then 'B06'
            else 'B99'
        end                             as int_mode  --计息方式
      ,case  when  t25.repay_type  ='3'  then '05'
             when  t25.repay_type  ='4'  then '06' 
             else  case t11.cycle_freq
                   when 'M1' then '01'
                   when 'M3' then '02'
                   when 'M6' then '03'
                   else '07'  end 
             end                        as repay_freq --还款频率
      ,''                               as pay_seq_no --支付流水号
      ,'2'                              as loan_biz_class  --业务分类
      --,nvl(a.total_amount_prev,0)       as bal        --贷款余额
      ,case when t33.loan_no is not null then 0
      else nvl(a.total_amount_prev,0)
      end                               as bal        --贷款余额
      ,nvl(case 
	      when t33.loan_no is not null then 0
	      when t1.accounting_status in ('ZHC','YUQ') then nvl(smaid.int_accrued,0) + nvl(smaid.int_adj,0) 
         + nvl(smiot.outstanding,0) else 0 end,0) as receiv_int --应收未收利息
      ,nvl(t2.gl_code_int_rec,'')                    as recv_int_subj  --应收利息科目
      ,nvl(case when t1.prod_type in ('110134','110140') then nvl(lxtz.amt,0) 
       else 0 end,0)                                  as int_adj  --利息调整
      ,nvl(case when t1.prod_type in ('110134','110140') then t2.gl_code_adjust else '' end,'')     as int_adj_subj  --利息调整科目
      ,nvl(t6.due_date_int,'')                        as overdue_date_int  --利息逾期日期
      ,'SYM'                                         as source_system  --来源系统  
      ,nvl(case when t1.prod_type in ('110120','110121','110165','110166','110168','110151') then substr(t25.loan_cast_industry_code,19,5) 
      when t1.prod_type in ('110124','110125') then 'F5299'
      when t1.prod_type ='110173' then 'G5430'
      when t1.prod_type='110160'  then  case when length(oci.industry_involved) = 23 then substr(oci.industry_involved,19,5)  
                                             else   oci.industry_involved      end
      when t1.prod_type in ('110110','110115','110116','110122','110129','110130','110170','110153','110180','110187') then t25.loan_cast_industry_code
      else '' end,'')                                           as loan_indst_type  --贷款投向行业
      ,case when nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')>'${DATA_DATE}' then '0'
            when t1.acct_close_date is not null then '1' 
            else  '0'   end                           as fully_settled -- 0未结清 1结清 
      ,from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')   as accting_date  --记账日期
      ,case when t11.year_basis='360' and t11.month_basis='30' then  '1'
            when t11.year_basis='360' and t11.month_basis='ACT' then  '2'  
            else '7'   end                           as int_basis    --计息基础
      ,''                                            as cust_indust_type  --客户所属行业
      ,case when t1.prod_type in('110151','110160') then 'A19'  --铁甲,锡惠贷个人融
            when t1.prod_type in ('110153','110158') then 'A18'  --大额经营贷,家电汇
            when t1.prod_type in ('110123','110134','110140','110144','110154','110155','110161','110171','110168','110163','110172','110175','110183') then 'A29'  
            when t1.prod_type in ('110115','110152') and t25.loan_need_type= 2 then 'A29'
            when t1.prod_type = '110124' then 
              case when t25.person_business_type = 1 then 'A18'                                                                          
                   when t25.person_business_type = 2 then 'A17' else 'A19' end 
            when t1.prod_type ='110125' then 
              case when t25.person_business_type = 1 then 'A18'                                                                          
                   when t25.person_business_type = 2 then 'A17'                                                                          
                   when t25.person_business_type in (3,4) then 'A19' else '' end 
            when t1.prod_type ='110156' then 
              case when t13.person_business_type = 1 then 'A18'                                                                          
                   when t13.person_business_type = 2 then 'A17'                                                                          
                   when t13.person_business_type in (3,4) then 'A19' else '' end 
            when t1.prod_type in ('110116') then
              case when t25.loan_need_type=3 and tt20.work_kind='1' then 'A18'    
                   when t25.loan_need_type=3 and tt20.work_kind='3' then 'A17'
                   when t25.loan_need_type=3 then 'A19' else ''  end 
            when t1.prod_type in ('110120','110121') then
              case when t25.loan_need_type=3 and tt22.work_kind='1' then 'A18'    
                   when t25.loan_need_type=3 and tt22.work_kind='3' then 'A17'
                   when t25.loan_need_type=3 then 'A19' else ''  end
            when t1.prod_type in ('110110','110122','110129') then 
              case when tt20.work_kind='1' then 'A18'
                   when tt20.work_kind in ('2','3','9') then 'A17' 
                   when tt20.work_kind='10' then 'A19'
                   else ''  end
            when t1.prod_type in ('110130')  then 
              case when tt20.work_kind='1' then 'A18'
                   when tt20.work_kind in ('2','3','9') then 'A17' 
                   when tt20.work_kind='10' then 'A19'
                   else ''  end
            when t1.prod_type in ('110165','110166')  then 
              case when tt20.work_kind='1' then 'A18'
                   when tt20.work_kind in ('2','3') then 'A17' 
                   when tt20.work_kind='9' then 'A19'
                   when tt20.work_kind='10' then 'A19'
                   else ''  end
            when t1.prod_type in ('110170')  then 
              case when tt21.work_kind='1' then 'A18'
                   when tt21.work_kind ='3' then 'A17' 
                   when tt21.work_kind='9' then 'A19'
                   when tt21.work_kind in ('2','10') then 'Z' else ''  end
            when t1.prod_type in ('110159')  then 
              case when tt20.work_kind='1' then 'A18'
                   when tt20.work_kind in ('2','3','9') then 'A17' 
                   when tt20.work_kind='10' then 'A19'
                   else ''  end 
            when t1.prod_type in ('110173','110180','110187')  then 
              case when tt21.work_kind='1' then 'A18'
                   when tt21.work_kind='3' then 'A17' 
                   when tt21.work_kind in ('2','9','10') then 'A19'
                   else ''  end
            else ''      end                      as loan_biz_detail  --贷款业务细类  
      ,case when t25.loan_need_type = '1' then '企业经营性贷款'
            when t25.loan_need_type = '2' then '个人消费贷款'
            when t25.loan_need_type = '3' then '个人经营性贷款'
            else  '其他'  end                     as loan_purp_detail  --贷款用途明细分类
      ,nvl(t1.branch   ,'')                         as org_id            --机构号
      ,nvl(t14.loan_id ,'')                         as loan_app_no       --贷款支用申请编号
      ,nvl(t1.accounting_status,'')                 as accting_status    --核算状态
      ,nvl(yq.pri_outstanding,0)                  as overdue_prin              --逾期本金
      ,nvl(yq.int_outstanding,0)+nvl(odp.odp_outstanding,0)                                       as overdue_int               --逾期利息
      ,nvl(t6.due_date_pri,'')                    as pri_overdue_date          --本金逾期日
      ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as mature_date  --到期日
      ,''                                           as project_id --项目ID
      ,case when t14.sub_product_type='11' then '323302000012'
            when t14.sub_product_type='43' then case when t35.base_acct_no is not null and t37.loan_id is not null 
                                                     then nvl(t37.bank_no,'')  --锡享贷登记账户
                                                     else nvl(t28.bank_name_code,'')
                                                end
            when t23.linked_base_acct_no is not null then nvl(case when length(t24.bank_code)=12 then t24.bank_code else '' end,'')
            when t28.account_no is not null then nvl(case when length(t28.bank_name_code)=12 then t28.bank_name_code else '' end,'')
            else ''
       end                                                                              as receive_bank_code --贷款入账账号所属行号
      ,case when t14.sub_product_type='11' then '无锡锡商银行股份有限公司' 
            when t14.sub_product_type='43' then case when t35.base_acct_no is not null and t37.loan_id is not null 
                                                     then nvl(t37.bank_name,'')  --锡享贷登记账户
                                                     else nvl(t28.bank_name,'')
                                                end
            when t23.linked_base_acct_no is not null then nvl(t24.bank_name,'')
            when t28.account_no is not null then nvl(t28.bank_name,'')
            else ''
       end                                                                              as receive_bank_name --贷款入账账号所属行名
      ,case when t14.sub_product_type='43' then case when t36.base_acct_no is not null and t37.loan_id is not null 
                                                     then nvl(t37.bank_no,'')  --锡享贷登记账户
                                                     else nvl(t29.settle_bank_code,'')
                                                end
            when t29.account_no is not null then nvl(case when length(t29.settle_bank_code)=12 then t29.settle_bank_code else '' end,'')
            when t32.base_acct_no is not null then nvl(case when length(t32.bank_code)=12 then t32.bank_code else '' end,'')
            else ''
       end                                                                              as repay_bank_code --还款账号所属行号
      ,case when t14.sub_product_type='43' then case when t36.base_acct_no is not null and t37.loan_id is not null 
                                                     then nvl(t37.bank_name,'')  --锡享贷登记账户
                                                     else nvl(t29.settle_bank_name,'')
                                                end
            when t29.account_no is not null then nvl(t29.settle_bank_name,'')
            when t32.base_acct_no is not null then nvl(t32.bank_name,'')
            else ''
       end                                                                              as repay_bank_name --还款账号所属行名
      ,0                                                                                as off_bal_int --表外欠息
      --,case when t1.accounting_status in ('ZHC','YUQ') and t1.prod_type='110159' then nvl(yq.int_int_outstanding,0)+nvl(t34.odp_outstanding,0)  --目前只有孚厘有罚息复利
      --      when t1.accounting_status in ('ZHC','YUQ') then nvl(yq.int_int_outstanding,0)+nvl(odp.odp_outstanding,0)
      --      else 0 end                                                                  as in_bal_int --表内欠息
      --,0                                                                                as in_bal_int --表内欠息
      ,nvl(t11_2.real_rate,0)                                                             as pena_rate --罚息利率
      ,case when t14.sub_product_type='11' then '上海识装信息科技有限公司'
            when t14.sub_product_type='43' then case when t35.base_acct_no is not null and t37.loan_id is not null 
                                                     then nvl(t37.account_name,'')  --锡享贷登记账户
                                                     else nvl(t28.payee_name,'')
                                                end
            else coalesce(t23.linked_acct_name,
                          case when t28.payee_name is null and t1.prod_type in ('110161','110172') then nvl(t3.ch_client_name,'')
                               else nvl(t28.payee_name,'')                              --'110161','110172'部分借据取不到payee_name，源系统回复可以取主借款人
                          end)                                                           
       end                                                                              as receive_acct_name --入账户名
      ,case when t1.accounting_status in ('FY','FYJ','WRN') then '1'
            else '0' end                                                                as non_accru_flag --非应计标志
	  ,0                                                                                as partner_loan_amt --新增合作资金方放款金额
      ,t1.prod_type                                                                     as prod_code         --产品号
  from odata.sllv_mb_acct t1
  left join odata.sym_gl_prod_accounting t2 --通过科目号来取消费还是经营
    on t1.prod_type = t2.prod_type
   and t2.data_date='${DATA_DATE}'
   and t2.bddw_end_date='9999-99-99'
   and t2.accounting_status = 'ZHC'
   and t2.tran_category = 'ALL'
  left join odata.sym_cif_client t3
    on t1.client_no=t3.client_no
   and t3.data_date='${DATA_DATE}'
   and t3.bddw_end_date='9999-99-99'
  left join odata.sym_cif_client_document t4
    on t1.client_no = t4.client_no
   and t4.data_date = '${DATA_DATE}'
   and t4.bddw_end_date = '9999-99-99'
   and t4.pref_flag='Y' 
  left join odata.sym_cif_client_contact_tbl t5
    on t1.client_no = t5.client_no 
   and t5.pref_flag='Y'
   and t5.data_date='${DATA_DATE}'
   and t5.bddw_end_date='9999-99-99'
  left join odata.order_contract_sign t8 
    on t1.cmisloan_no=t8.loan_id
   and t8.data_date='${DATA_DATE}'
   and t8.bddw_end_date='9999-99-99'
   and t8.signer_type= '1'   --签署人为借款人
   and t8.contract_type='2' --个人借款合同
   and t8.status='1'
left join odata.order_contract_sign t61
       on t1.cmisloan_no = t61.loan_id
      and t61.data_date = '${DATA_DATE}'
      and t61.bddw_end_date = '9999-99-99'
      and t61.signer_type = '1'   --签署人为借款人
      and t61.contract_type = '2' --个人借款合同
      and t61.sub_product_type = '8'
  left join odata.sllv_mb_acct_balance t9
    on t1.internal_key = t9.internal_key
   and t9.amt_type ='DDA'
   and t9.data_date = '${DATA_DATE}'
   and t9.bddw_end_date = '9999-99-99'
  left join odata.sllv_mb_acct_balance a
    on t1.internal_key = a.internal_key
   and a.amt_type ='BAL'
   and a.data_date = '${DATA_DATE}'
   and a.bddw_end_date = '9999-99-99'
  left join odata.sllv_mb_acct_int_detail t11
    on t1.internal_key = t11.internal_key
   and t11.int_class = 'INT'
   and t11.data_date='${DATA_DATE}'
   and t11.bddw_end_date='9999-99-99'
  left join odata.sllv_mb_acct_int_detail t11_2
    on t1.internal_key = t11_2.internal_key
   and t11_2.int_class = 'ODP'
   and t11_2.data_date='${DATA_DATE}'
   and t11_2.bddw_end_date='9999-99-99'
  left join(select loan_id
                  ,prod_type
                  ,case when manual_five_class = '正常'  then  'FQ01'
                        when manual_five_class = '关注'  then  'FQ02'
                        when manual_five_class = '次级'  then  'FQ03'
                        when manual_five_class = '可疑'  then  'FQ04'
                        when manual_five_class = '损失'  then  'FQ05'
                    end as manual_five_class
              from odata.plm_loan_info_detail
             where data_date = '${DATA_DATE}'
               and bddw_end_date = '9999-99-99'
               and manual_term_validity_date >= '${DATA_DATE}')t12
    on t1.cmisloan_no = t12.loan_id
   and t1.prod_type = t12.prod_type
  left join odata.acct_loan_category t30
    on trim(t1.cmisloan_no) = trim(t30.loan_id)
   and t30.data_date = '${DATA_DATE}'
   and t30.bddw_end_date = '9999-99-99'
  left join(select a.loan_id
                  ,a.sub_product_type
                  ,a.status
                  ,a.xsbank_salesman
                  ,a.product_type
                  ,a.credit_order_id
              from odata.order_main_loan_order a
             where a.data_date = '${DATA_DATE}'
               and a.bddw_end_date = '9999-99-99'
               and order_type='2') t14
    on t1.cmisloan_no = t14.loan_id
  left join  odata.order_main_credit_order t15
    on t14.credit_order_id=t15.loan_id
   --and t14.product_type='12'
   and t15.data_date = '${DATA_DATE}'
   and t15.bddw_end_date = '9999-99-99'
  left join odata.order_product_loan_info t13                --与授信关联 产品贷款信息
    on t15.loan_id=t13.loan_id
   and t13.data_date='${DATA_DATE}' 
   and t13.bddw_end_date='9999-99-99'
  left join odata.order_company_info oci     
   on trim(t14.credit_order_id) = trim(oci.loan_id)
  and oci.data_date='${DATA_DATE}' 
  and oci.bddw_end_date='9999-99-99' 
  and oci.is_guarantee=0               --非担保企业
 --总期次
  left join(
            select internal_key,max( cast(stage_no as int) ) as stage_no_max
              from odata.sllv_mb_acct_schedule_detail
             where data_date='${DATA_DATE}' and bddw_end_date='9999-99-99'
             group by internal_key) t54 
    on t1.internal_key=t54.internal_key
  --当前期次
  --left join(
  --          select
  --                 internal_key,min( cast(stage_no as int) )as stage_no_min
  --            from odata.sllv_mb_acct_schedule_detail
  --           where are_int_flag in ('N',null) and  data_date='${DATA_DATE}' and bddw_end_date='9999-99-99'
  --           group by internal_key) t55
  --  on t1.internal_key=t55.internal_key
  left join odata.sym_mb_prod_type t18
    on t1.prod_type=t18.prod_type
   and t18.data_date = '${DATA_DATE}'
   and t18.bddw_end_date = '9999-99-99'
  left join t19
    on t1.internal_key=t19.internal_key 
  left join t20
    on t1.internal_key=t20.internal_key
  left join odata.gl_v_gl_subject t22
    on t2.gl_code_a=t22.gl_code
   and t22.data_date='${DATA_DATE}'
   and t22.bddw_end_date='9999-99-99'
  left join odata.order_product_loan_info t25             --与借据关联 产品贷款信息
    on t14.loan_id=t25.loan_id
   and t25.data_date='${DATA_DATE}' 
   and t25.bddw_end_date='9999-99-99'
   left join odata.order_job_info tt20
    on t1.cmisloan_no=tt20.loan_id
   and tt20.data_date='${DATA_DATE}' 
   and tt20.bddw_end_date='9999-99-99'
   left join odata.order_job_info tt21
    on t15.loan_id=tt21.loan_id
   and tt21.data_date='${DATA_DATE}' 
   and tt21.bddw_end_date='9999-99-99'
   left join odata.order_job_info tt22
    on t14.credit_order_id=tt22.loan_id
   and tt22.data_date='${DATA_DATE}' 
   and tt22.bddw_end_date='9999-99-99'
  left join odata.sym_mb_prod_define t26
    on t1.prod_type = t26.prod_type 
   and t26.data_date='${DATA_DATE}'
   and t26.bddw_end_date='9999-99-99'
   and t26.assemble_id='GRACE_PERIOD'
  left outer join odata.sso_upms_user t43
    on t14.xsbank_salesman=t43.user_id 
   and t43.data_date='${DATA_DATE}' 
   and t43.bddw_end_date='9999-99-99'
  left join dwd.dwd_d_indv_credit_cont_p t27
    on t27.credit_cont_no=t14.credit_order_id
   and t27.prod_code=t1.prod_type
   and t27.data_date='${DATA_DATE}'
  left join dwd.dwd_d_indv_credit_cont_p t31
    on t31.credit_cont_no=t14.loan_id
   and t31.prod_code=t1.prod_type
   and t31.data_date='${DATA_DATE}'
  left join odata.order_bank_account_info t28
    on trim(t1.cmisloan_no)=trim(t28.loan_id) 
   and t28.data_date='${DATA_DATE}' 
   and t28.bddw_end_date='9999-99-99' 
  left join (
             select * 
                       ,row_number() over(partition by loan_id order by withhold_order)rn 
                from odata.order_repay_account  a 
                where a.data_date='${DATA_DATE}' 
                and a.bddw_end_date='9999-99-99' 
                and not exists(
                               select 1 from odata.order_repay_account  b
                               where a.id =b.id 
                               and b.data_date='${DATA_DATE}' 
                               and b.bddw_end_date='9999-99-99' 
                               and substr(b.account_no,1,3) = '144' 
                               and b.settle_bank_code = '323302000012'
                               and b.withhold_order ='1'
                               )
            ) t29
    on trim(t1.cmisloan_no)=trim(t29.loan_id) 
    and t29.rn=1
    and t29.id not in ('5306','45749','49741')
  left join t6 
    on t1.internal_key=t6.internal_key
  left join t17 
    on t1.internal_key=t17.internal_key
  left join t16
    on t17.internal_key = t16.internal_key
   and t17.stage_no = t16.stage_no
   and t17.term_start_date = t16.term_start_date
  left join odata.order_contract_sign t40   --用于区分担保类型
    on t1.cmisloan_no = t40.loan_id
   and t40.data_date = '${DATA_DATE}'
   and t40.bddw_end_date = '9999-99-99'
   and t40.signer_type = '2'   --签署人为担保人
   and t40.contract_type = '3' --个人担保协议
--锡机贷(非上牌车)担保方式逻辑(110122、110110)
  left join(select distinct a.loan_id
                  ,if(b.device_type=='0' and c.loan_id is NULL, '信用', '保证')  as coll_type
              from odata.pawn_pawn_base a
              left join odata.pawn_pawn_machine b
                on a.id=b.pawn_id
               and b.data_date='${DATA_DATE}'
               and b.bddw_end_date='9999-99-99'
              left join odata.order_contract_sign c
                on a.loan_id=c.loan_id
               and c.data_date='${DATA_DATE}'
               and c.bddw_end_date='9999-99-99'
               and c.contract_type in ('3','4')
             where a.data_date='${DATA_DATE}'
               and a.bddw_end_date='9999-99-99') t41
    on trim(t1.cmisloan_no)=trim(t41.loan_id)
  left join gdata.dim_g_partner_mapping_p t50
    on t1.partner_id=t50.order_partner_id
  left join (select internal_key,sum(int_accrued) int_accrued,sum(int_adj) int_adj from odata.sllv_mb_acct_int_detail 
           where data_date = '${DATA_DATE}'
           and bddw_end_date='9999-99-99' 
           and int_class in ('INT','ODP')    
           group by internal_key) smaid
       on t1.internal_key = smaid.internal_key 
  left join (select internal_key,sum(outstanding) as outstanding from odata.sllv_mb_invoice 
           where amt_type in ('INT','ODP') and data_date = '${DATA_DATE}' and bddw_end_date='9999-99-99' 
           group by internal_key) smiot 
       on t1.internal_key = smiot.internal_key
  left join (select b.cmisloan_no, sum(a.total_amount) amt from odata.sllv_mb_acct_balance a 
       inner join odata.sllv_mb_acct b
          on a.internal_key = b.internal_key 
         and b.data_date  = '${DATA_DATE}'
       and b.bddw_end_date = '9999-99-99' 
  left join odata.order_main_loan_order c
    on trim(b.cmisloan_no)=trim(c.loan_id) 
    and c.data_date='${DATA_DATE}' 
    and c.bddw_end_date='9999-99-99'
       where a.amt_type = 'IADJ' --利息调整
         and a.data_date = '${DATA_DATE}'
         and a.bddw_end_date = '9999-99-99' 
         and c.status in (7,8,9,10) --7：还款中 8：已结清
    group by b.cmisloan_no) lxtz
    on t1.cmisloan_no = lxtz.cmisloan_no
  left join (
      select
            ce.internal_key
           ,sum(case when ce.amt_type ='PRI' then ce.outstanding when ce.amt_type in ('INT','ODP') then 0 end) as pri_outstanding  --逾期本金
           ,sum(case when ce.amt_type ='PRI' then 0 when ce.amt_type in ('INT','ODP') then ce.outstanding end) as int_outstanding  --逾期利息
           ,sum(case when ce.amt_type ='INT' then ce.outstanding else 0 end) as int_int_outstanding
      from odata.sllv_mb_invoice  ce
      where ce.data_date='${DATA_DATE}' 
        and ce.bddw_end_date='9999-99-99'
        and ce.outstanding >0
        and ce.due_date < regexp_replace('${DATA_DATE}','-','')
      group by ce.internal_key
  ) yq 
  on t1.internal_key = yq.internal_key
  left join 
          (select
                od.internal_key
               ,sum(nvl(od.int_accrued,0)+nvl(od.int_adj,0)) as odp_outstanding  --逾期罚息
          from odata.sllv_mb_od_int_detail  od
          where od.data_date='${DATA_DATE}' 
            and od.bddw_end_date='9999-99-99'
            and od.int_class='ODP'
          group by od.internal_key)odp
  on t1.internal_key=odp.internal_key
  left join(
         select b.credit_order_id,a.contract_no
         from odata.order_contract_sign a
         left join odata.order_main_loan_order b
         on a.loan_id = b.loan_id
         and b.data_date = '${DATA_DATE}'
         and b.bddw_end_date = '9999-99-99'
         and b.status in ('5','7','8','15')
         where a.data_date = '${DATA_DATE}'
         and a.bddw_end_date = '9999-99-99'
         and a.sub_product_type = '24'
         and a.signer_type= '1'   --签署人为借款人
         and a.contract_type='2' --个人借款合同
         and a.status='1'
         )t60
  on t14.credit_order_id = t60.credit_order_id
  left join odata.xscontract_business_contract_records t62
         on t14.loan_id = t62.loan_id
         and t62.data_date = '${DATA_DATE}'
         and t62.bddw_end_date = '9999-99-99'
         and t62.contract_type = '2'
         and t62.status <> '3'  --合同失效后强制生成新的重复合同，所以剔除失效合同
  left join (
            select 
                  document_id
                  ,document_type
                  ,base_acct_no
                  ,bank_code
                  ,bank_name
                  ,row_number() over(partition by document_id order by tran_date desc) rn
            from odata.contract_um_agreement_comm
            where data_date = '${DATA_DATE}'
            and bddw_end_date = '9999-99-99'
            --and agreement_status='A'
            ) t32 
       on t4.document_id=t32.document_id
       --and t4.document_type=concat('1',t32.document_type)
       and t32.rn=1
  left join (
            select
                od.internal_key
               ,sum(nvl(od.int_accrued,0)+nvl(od.int_adj,0)) as odp_outstanding  --逾期罚息
          from odata.sllv_mb_od_int_detail  od
          where od.data_date='${DATA_DATE}' 
            and od.bddw_end_date='9999-99-99'
            and od.int_class in ('ODP','ODI')
          group by od.internal_key
             ) t34
on t1.internal_key=t34.internal_key
left join (
        select
                a.base_acct_no
               ,a.linked_base_acct_no
               ,a.linked_acct_name
               ,d.loan_id
               ,row_number() over(partition by a.base_acct_no,d.loan_id order by abs(unix_timestamp(nvl(f.time_stamp,concat(substr(a.tran_date,1,10),' 00:00:00')))-unix_timestamp(concat((from_unixtime(unix_timestamp(e.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')),' 00:00:00')))) rn
        from (
		     select 
                   t.base_acct_no,
                   t.linked_base_acct_no,
                   t.linked_acct_name,
                   t.tran_date,
                   t.main_seq_no,
                   t.linked_bank_flag,
                   case when t.tran_type = '01' and t1.num =0 and t2.linked_status = 'C' then '1'
                        else '0' end as error_status
                   from odata.va_am_aa_maint_hist t 
                   left join (select linked_base_acct_no,sum(case when tran_type = '02' then 1 else 0 end) num from odata.va_am_aa_maint_hist
                   where data_date = '${DATA_DATE}'
                   and bddw_end_date = '9999-99-99'
                   group by linked_base_acct_no) t1 
                   on t.linked_base_acct_no = t1.linked_base_acct_no
                   left join odata.va_am_rel_acct_acct t2 
                   on t2.data_date = '${DATA_DATE}'
                   and t2.bddw_end_date = '9999-99-99'
                   and t1.linked_base_acct_no = t2.linked_base_acct_no
                   where t.data_date = '${DATA_DATE}'
                   and t.bddw_end_date = '9999-99-99'
		     ) a
        left join odata.va_cm_tran_comm f
        on a.main_seq_no=f.main_seq_no
        and f.data_date=if ('${DATA_DATE}' <'2023-10-11','2023-10-11','${DATA_DATE}') --20231011之前数据不全
        and f.bddw_end_date='9999-99-99'
        left join 
        (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
        ) i
        on a.linked_base_acct_no=i.base_acct_no
        and i.rn=1
        left join odata.order_bank_account_info d 
        on a.base_acct_no=d.account_no
        and d.data_date='${DATA_DATE}'
        and d.bddw_end_date='9999-99-99'
        left join odata.sllv_mb_acct e 
        on d.loan_id=e.cmisloan_no
        and e.data_date='${DATA_DATE}'
        and e.bddw_end_date='9999-99-99'
        where a.linked_bank_flag = '02'         --02行外
		and a.error_status = '0'                --1错误绑定卡0曾绑卡或在绑卡
        and length(i.bank_code)=12
    ) t23
    on t28.account_no=t23.base_acct_no
    and t28.loan_id=t23.loan_id
    and t23.rn=1
left join 
    (
        select   base_acct_no
                ,bank_code
                ,bank_name
                ,row_number() over(partition by base_acct_no order by bddw_start_date desc )rn
        from odata.va_am_bank_acct
        where data_date='${DATA_DATE}'
          and bddw_end_date='9999-99-99'
          and acct_status='A'
    ) t24
        on t23.linked_base_acct_no=t24.base_acct_no
        and t24.rn=1
left join odata.slur_acc_writeoff_detail t33 
       on t1.cmisloan_no = t33.loan_no
      and t33.data_date = '${DATA_DATE}'
      and t33.bddw_end_date = '9999-99-99'
      and t33.status = 'S'  --核销成功
left join odata.valoan_va_loan_acct t35
        on t28.account_no=t35.base_acct_no
        and t35.data_date='${DATA_DATE}'
        and t35.bddw_end_date='9999-99-99'
    left join odata.valoan_va_loan_acct t36
        on t29.account_no=t36.base_acct_no
        and t36.data_date='${DATA_DATE}'
        and t36.bddw_end_date='9999-99-99'
    left join odata.order_xiangd_loan_info t37
        on t1.cmisloan_no=t37.loan_id
        and t37.data_date='${DATA_DATE}'
        and t37.bddw_end_date='9999-99-99'
 where t1.data_date='${DATA_DATE}'
   and t1.bddw_end_date='9999-99-99'
   and from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd') <= '${DATA_DATE}'
   and t1.prod_type in(     '110115'  --车主个人消费贷款
                           ,'110116'  --车主个人经营贷款
                           ,'110110'  --锡机贷-工程机械-易起投
                           ,'110122'  --锡机贷-工程机械-易起投-非免征
                           ,'110129'  --锡机贷-上牌车（免征）
                           ,'110130'  --锡机贷-上牌车
                           ,'110120'  --车商贷
                           ,'110121'  --车商贷-免征
                           ,'110123'  --锡惠贷个人消费贷款
                           ,'110124'  --锡惠贷个人经营贷款-免征
                           ,'110125'  --锡惠贷个人经营贷款
                           ,'110134'  --颐尔信消费贷
                           ,'110140'  --得物消费分期贷款   
                           ,'110151'  --铁甲
                           ,'110152'  --大鹅贷消费
                           ,'110153'  --大鹅贷经营
                           ,'110144'  --老板花标准助贷
                           ,'110154'  --锡锡贷-洋钱罐
                           ,'110155'  --欢太花钱
                           ,'110156'  --希望贷-易起投
                           ,'110158'  --锡望贷-家电汇
                           ,'110159'  --孚厘助贷
                           ,'110160'  --锡惠贷个人融    
                           ,'110161'  --霖梓H5
                                       ,'110165'  --锡望贷-上牌车
                                       ,'110166'  --锡望贷-非上牌车
                                       ,'110168'  --哈罗单车
                                       ,'110170'  --饿了么经营贷
                                       ,'110171'  --饿了么消费贷
                                       ,'110163'  --乐花借钱
                                       ,'110172'  --51半自营
                                       ,'110175'  --小赢拒量
                           ,'110173'  --聚盟
                           ,'110180'  --锡望贷-京东
                           ,'110183'  --vivo维易贷
                           ,'110187'  --锡享贷-厚沃个人
                       )