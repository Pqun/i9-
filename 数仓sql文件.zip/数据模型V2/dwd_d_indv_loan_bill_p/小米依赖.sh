XM_DATE=`hive -e "select data_date from ads.check_dwd_indv_loan_bill_data where prod_name='xm' and data_date='${DATA_DATE}'"`
if [ ${DATA_DATE} == $XM_DATE ];then
  exit 0
else
  exit 1
fi