--2.yangqihao.dwd_d_indv_loan_bill_p
-------------------------------------------------------------------
--脚本名称:dwd_d_indv_loan_bill_p
--功能描述:个人贷款借据信息表
--作    者:于国睿
--开发日期:2021-09-24
--直属经理:方杰
--目标表  :dwd.dwd_d_indv_loan_bill_p 
--来源表：odata.sllv_mb_acct_schedule_detail    账户计划明细表
--来源表：odata.sllv_mb_invoice                 单据表
--来源表：odata.sllv_mb_acct                    账户基本信息表
--来源表：odata.sym_gl_prod_accounting          产品科目表
--来源表：odata.sym_cif_client                  客户信息表
--来源表：odata.sym_cif_client_document         客户证件信息表
--来源表：odata.sym_cif_client_contact_tbl      客户联系信息表
--来源表：odata.sllv_mb_acct_balance            账户余额表
--来源表：odata.sllv_mb_acct_int_detail         利息明细表
--来源表：odata.plm_loan_info_detail            贷款五级分类
--来源表：odata.order_contract_sign             合同签署表
--来源表：odata.order_main_loan_order           订单主表
--来源表：odata.sym_mb_prod_type                产品类型定义表
--来源表：odata.acct_loan_category              贷款五级分类
--来源表：odata.gl_v_gl_subject                 科目名称表
--来源表：odata.sym_mb_prod_define              产品科目表
--来源表：dwd.dwd_d_indv_credit_cont_p          个人授信合同表
--来源表：gdata.dim_g_partner_mapping_p         合作方编码映射表
--来源表：odata.order_bank_account_info         放款账户表 
--来源表：odata.order_product_loan_info         产品贷款信息表  
--来源表：odata.order_repay_account             还款账户信息表
--来源表：odata.order_loan_order_house          房抵贷订单主表 
--来源表：odata.order_job_info                  工作信息表                    
--修改历史:
--         1、于国睿     2021-09-24     新建
--         2、高源       2022-06-07     新增应收未收利息、应收利息科目、利息调整、利息调整科目、利息拖欠日期、
--                                      来源系统、贷款投向行业、结清标识等字段,结清日期逻辑调整
--         3、高源       2022-06-22     新增记账时间字段逻辑
--         4、高源       2022-07-07     新增计息基础、客户所属行业、贷款业务细类、贷款用途明细分类字段逻辑
--         5、高源       2022-08-10     借据起始日期、借据到期日、借据关闭日期逻辑调整，结清时间格式调整
--         6、高源       2022-10-09     新增机构号、贷款支用申请编号字段逻辑
--         7、高源       2022-11-03     还款方式、还款频率逻辑调整
--         8、华天顺     2022-12-02     新增核算状态字段
--         9、华天顺     2023-01-03     逾期天数取数逻辑调整，新增逾期本金，利息和本金逾期日字段
--         10.杨琦浩     2023-03-14     新增到期日字段
--         11.高源       2023-04-14     投向行业逻辑调整
--         12.杨琦浩     2023-05-17     新增项目ID字段
--         13.杨琦浩     2023-06-19     支付方式取数逻辑调整
--         14.杨琦浩     2023-08-24     新增放款、还款账号信息字段
--         15.杨琦浩     2023-08-30     新增表内、表外欠息字段
--         16.杨琦浩     2023-10-12     调整还款账号信息取数逻辑，新增入账户名字段
--         17.杨琦浩     2023-10-25     表外欠息调整为非应计标志
--         18.姚威       2023-11-09     新增合作资金方放款金额
--         19.杨琦浩     2023-11-18     表内欠息调整为罚息利率
-------------------------------------------------------------------
--锡房贷
with t16
as (
    select 
         a.internal_key
        ,a.stage_no              as stage_no                                                               --期次
        ,from_unixtime(unix_timestamp(min(a.start_date),'yyyyMMdd'),'yyyy-MM-dd')      as term_start_date  --期次开始日期
        ,from_unixtime(unix_timestamp(max(a.end_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_end_date    --期次到期日期
    from odata.sllv_mb_acct_schedule_detail a
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    group by 
         a.internal_key
        ,a.stage_no
        ,a.start_date
        ,a.end_date
    ),
t17 as 
(
    select 
         a.internal_key
        ,b.stage_no  --期次
        ,from_unixtime(unix_timestamp(max(c.start_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_start_date    --期次开始期日
    from odata.sllv_mb_invoice a
   inner join (select a.internal_key
                     ,max(cast(a.stage_no as int)) as stage_no
                 from odata.sllv_mb_invoice a
                where a.data_date = '${DATA_DATE}'
                  and a.bddw_end_date = '9999-99-99'
                  and a.amt_type = 'INT'
                group by a.internal_key) b
     on a.internal_key=b.internal_key
    and a.stage_no=b.stage_no
   left join odata.sllv_mb_acct_schedule_detail c
     on c.data_date = '${DATA_DATE}'
    and c.bddw_end_date = '9999-99-99'
    and a.internal_key = c.internal_key
    and a.stage_no = c.stage_no
    and a.amt_type = c.amt_type
  where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and a.amt_type <> 'ODP'
    group by a.internal_key
            ,b.stage_no
),
t6 as 
(    select  internal_key
           ,min(case when amt_type='PRI'then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_pri
           ,min(case when amt_type='INT'then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_int
    from odata.sllv_mb_invoice
      where outstanding>0   
        and data_date='${DATA_DATE}' 
        and bddw_end_date='9999-99-99'
        and due_date < regexp_replace('${DATA_DATE}','-','')
    group by internal_key
),
t19 as  
(select internal_key
       ,min( from_unixtime(unix_timestamp(nvl(due_date,''),'yyyyMMdd'),'yyyy-MM-dd')) as due_date_pri
       ,sum(case when amt_type = 'PRI' then billed_amt else 0 end) as due_amount_pri
   from odata.sllv_mb_invoice
  where outstanding > 0
    and amt_type = 'PRI'
    and data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
  group by internal_key
),
t20 as 
(select internal_key
       ,min( from_unixtime(unix_timestamp(nvl(due_date,''),'yyyyMMdd'),'yyyy-MM-dd')) as due_date_int
       ,sum(case when amt_type = 'INT' then billed_amt else 0 end) as due_amount_int
   from odata.sllv_mb_invoice
  where outstanding > 0
    and amt_type = 'INT'
    and data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
  group by internal_key
)
insert overwrite table dwd.dwd_d_indv_loan_bill_p partition(data_date='${DATA_DATE}',prod_code)
select /*+ REPARTITION(1) */
       nvl(t1.cmisloan_no,'')     as bill_no  --借据号
      ,nvl(t18.prod_desc,'')      as prod_name  --产品名称
      ,nvl(t1.base_acct_no,'')    as acct_no  --账号
      ,nvl(t1.acct_seq_no,'')     as acct_seq_no  --账户序列号
      ,nvl(t14.product_type,'')   as biz_prod_code  --业务产品号
      ,nvl(t14.sub_product_type,'')       as sub_biz_prod_code  --业务子产品号
      ,'01'                       as accting_cacl_mode --会计核算方式
      ,nvl(t2.gl_code_a,'')       as subj_no  --科目号
      ,nvl(t22.gl_code_name,'')   as subj_name  --科目名称
      ,nvl(t1.client_no,'')       as cust_id  --客户号
      ,nvl(t3.ch_client_name,'')  as cust_name  --客户姓名
      ,nvl(t4.document_type,'')   as cert_type  --证件类型
      ,nvl(t4.document_id,'')     as cert_no  --证件号
      ,nvl(t5.contact_tel,'')     as mobile_no  --客户手机号
      ,nvl(t27.credit_limit,0)    as credit_limit  --授信额度
      ,nvl(t27.credit_terms,'')   as credit_term  --授信期限
      ,nvl(substr(t27.credit_start_date,1,10),'')     as credit_start_date  --授信起始日期
      ,nvl(substr(t27.credit_mature_date,1,10),'')    as credit_end_date  --授信到期日期
      ,nvl(t14.credit_order_id,t14.loan_id)           as credit_cont_no  --授信合同编号
      ,nvl(t25.repay_type,'')     as repay_mode  --还款方式
      ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as loan_grant_date  --贷款发放日期
      ,'00:00:00'                 as loan_grant_time  --贷款发放时间
      ,nvl(t7.contract_no,'')     as loan_cont_no  --贷款合同号
      ,''                         as fin_supp_mode  --贷款财政扶持方式
      ,'B'                        as loan_guar_mode  --贷款担保方式
      ,case when t2.gl_code_a = '10400101' then '2' 
            when t2.gl_code_a = '10400201' then '3'  
            else '' 
        end                       as loan_purp  --贷款用途
      ,'TR05'                     as pric_benc  --定价基准
      ,case when t1.acct_close_reason='发放冲正'  then '111'
            when t1.acct_status<>'C' and t1.accounting_status<>'ZHC' then '107' 
            when t1.acct_status<>'C' and t1.accounting_status='ZHC' then '105'
            when t1.acct_status='C' then '106'
            when t14.status in(1,2,13,14) then '101'
            when t14.status in(4,5) then '103'
            when t14.status =11 then '104'
            when t14.status =12 then '102'
            when t14.status =15 then '111'
        end                       as loan_cont_status  --贷款合同状态
      ,nvl(from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd'),'')     as loan_start_date  --借据起始日期
      ,nvl(from_unixtime(unix_timestamp(t1.ori_maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as loan_mature_date  --借据到期日期
      ,nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')    as loan_close_data  --借据关闭日期
      ,nvl(t9.total_amount,0)     as loan_amt  --放款金额
      ,nvl(t54.stage_no_max,0)    as total_loan_terms  --放款总期数
      ,nvl(t17.stage_no,0)        as curr_term_no  --当前期次
      ,'RF01'                     as rate_type  --利率类型
      ,nvl(t11.real_rate,0)       as real_rate  --实际利率
      ,nvl(t50.partner_name,'')   as partner_id  --合作方编码
      ,nvl(t50.partner_id,'')     as partner_name  --合作方名称
      ,''                         as channel_type  --贷款办理渠道
      ,'0'                        as consume_scen_flag  --消费场景标签
      ,1.00                       as invest_ratio  --出资比例
      ,nvl(t1.ccy,'')             as ccy  --币种
      ,nvl(t26.attr_value,0)      as grace_days  --宽限天数
      ,case when nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')>'${DATA_DATE}'
            then ''
            else nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'') 
        end                       as clear_date  --结清日期
      ,case when t6.internal_key is not null
            then least(nvl(t6.due_date_pri,''),nvl(t6.due_date_int,''))
            else '' 
        end   as overdue_start_date  --逾期起始日
      ,case when t6.internal_key is not null
            then greatest(nvl(datediff('${DATA_DATE}',t6.due_date_pri),0),nvl(datediff('${DATA_DATE}',t6.due_date_int),0))
            else 0  
        end                           as overdue_days --逾期天数
      ,''                         as defer_mature_date  --贷款展期到期日期
      ,case when t6.due_date_pri is not null and t6.due_date_int is null 
            then '01'
            when t6.due_date_pri is null and t6.due_date_int is not null 
            then '02'
            when t6.due_date_pri is not null and t6.due_date_int is not null 
            then '03'
            else '' 
        end                           as overdue_type  --逾期类型
      ,case when t12.loan_id is not null then t12.manual_five_class
            when t12.loan_id is null then nvl(t30.five_category,'')
        else ''
        end                       as five_risk_level  --贷款5级分类  
      ,nvl(t28.account_no,'')     as receive_acct_no   --贷款入账账号 
      --,nvl(t29.account_no,'')     as repay_acct_no  --还款账号
      ,coalesce(t29.account_no,t32.base_acct_no,'') as repay_acct_no  --还款账号
      --,if(t7.actual_loan_amount > 50*10000, '受托支付', '自主支付')   -- 基塔石系统中还没有做调整，暂时按照此逻辑取数
      ,if(t7.actual_loan_amount > 50*10000, 2, 1) as payment_mode  --支付方式
      ,'02'                       as cash_tran_flag  --现转标志
      ,'范远黛'                   as credit_tlr_name  --信贷员姓名
      ,'xs0128'                   as credit_tlr_id  --信贷员员工号
      ,case t11.cycle_freq
            when 'M1' then 'B01'
            when 'M3' then 'B02'
            when 'M6' then 'B06'
            else 'B99'
        end                       as int_mode  --计息方式
      ,case  when  t25.repay_type  ='3'  then '05'
             when  t25.repay_type  ='4'  then '06' 
             else  case t11.cycle_freq
                   when 'M1' then '01'
                   when 'M3' then '02'
                   when 'M6' then '03'
                   else '07'  end 
             end                  as repay_freq --还款频率
      ,''                         as pay_seq_no  --支付流水号
      ,'2'                        as loan_biz_class  --业务分类
      ,nvl(a.total_amount_prev,0)   as bal  --贷款余额
      ,nvl(case when t1.accounting_status in ('ZHC','YUQ') then nvl(smaid.int_accrued,0) + nvl(smaid.int_adj,0) 
         + nvl(smiot.outstanding,0) else 0 end,0) as receiv_int --应收未收利息
      ,nvl(t2.gl_code_int_rec,'')                 as recv_int_subj  --应收利息科目
      ,0                                          as int_adj        --利息调整
      ,''                                         as int_adj_subj   --利息调整科目
      ,nvl(t6.due_date_int,'')                      as overdue_date_int  --利息逾期日期
      ,'SYM'                                        as source_system  --来源系统  
      ,case when t7.loan_industry like '%,%' then nvl(substr(t7.loan_industry,19,5),'') 
            else nvl(t7.loan_industry,'') end     as loan_indst_type  --贷款投向行业
      ,case when nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')>'${DATA_DATE}' then '0'
            when t1.acct_close_date is not null then '1' 
            else  '0'   end                       as fully_settled -- 0未结清 1结清 
      ,from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')   as accting_date  --记账日期
      ,case when t11.year_basis='360' and t11.month_basis='30' then  '1'
            when t11.year_basis='360' and t11.month_basis='ACT' then  '2'  
            else '7'  end                         as int_basis    --计息基础
      ,''                                         as cust_indust_type  --客户所属行业
      ,case when t21.work_kind='1' then 'A18'
            when t21.work_kind='3' then 'A17'
            when t21.work_kind='9' then 'A19'
            else '' end                           as loan_biz_detail  --贷款业务细类
      ,case when t7.loan_need_type = '1' then '企业经营性贷款'
            when t7.loan_need_type = '2' then '个人消费贷款'
            when t7.loan_need_type = '3' then '个人经营性贷款'
            else  '其他'  end                                 as loan_purp_detail  --贷款用途明细分类
      ,nvl(t1.branch   ,'')                                   as org_id            --机构号
      ,nvl(t14.loan_id ,'')                                   as loan_app_no       --贷款支用申请编号
      ,nvl(t1.accounting_status,'')                           as accting_status    --核算状态
      ,nvl(yq.pri_outstanding,0)                              as overdue_prin              --逾期本金
      ,nvl(yq.int_outstanding,0)+nvl(odp.odp_outstanding,0)                                       as overdue_int               --逾期利息
      ,nvl(t6.due_date_pri,'')                                as pri_overdue_date          --本金逾期日
      ,nvl(from_unixtime(unix_timestamp(t1.maturity_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as loan_mature_date  --借据到期日期
      ,''                                                     as project_id --项目ID
      ,nvl(case when length(t28.bank_name_code)=12 then t28.bank_name_code else '' end,'')
                                                              as receive_bank_code --贷款入账账号所属行号
      ,nvl(t28.bank_name,'')                                  as receive_bank_name --贷款入账账号所属行名
      ,case when t29.account_no is not null then nvl(case when length(t29.settle_bank_code)=12 then t29.settle_bank_code else '' end,'')
            when t32.base_acct_no is not null then nvl(case when length(t32.bank_code)=12 then t32.bank_code else '' end,'')
            else ''
       end                                                    as repay_bank_code --还款账号所属行号
      ,case when t29.account_no is not null then nvl(t29.settle_bank_name,'')
            when t32.base_acct_no is not null then nvl(t32.bank_name,'')
            else ''
       end                                                    as repay_bank_name --还款账号所属行名
      ,0                                                      as off_bal_int --表外欠息
      --ase when t1.accounting_status in ('ZHC','YUQ') then nvl(yq.int_int_outstanding,0)+nvl(odp.odp_outstanding,0)
      --      else 0 end                                        as in_bal_int --表内欠息
      --,0                                                      as in_bal_int --表内欠息
      ,nvl(t11_2.real_rate,0)                                 as pena_rate --罚息利率
      ,nvl(t28.payee_name,'')                                 as receive_acct_name --入账户名
      ,case when t1.accounting_status in ('FY','FYJ','WRN') then '1'
            else '0'end                                       as non_accru_flag --非应计标志
	  ,0                                                      as partner_loan_amt --新增合作资金方放款金额
      ,'110108'                                               as prod_code  --产品号
  from odata.sllv_mb_acct t1
  left join odata.sym_gl_prod_accounting t2 --通过科目号来取消费还是经营
    on t2.data_date='${DATA_DATE}'
   and t2.bddw_end_date='9999-99-99'
   and t1.prod_type = t2.prod_type
   and t2.accounting_status = 'ZHC'
   and t2.tran_category = 'ALL'
  left join odata.sym_cif_client t3
    on t1.client_no=t3.client_no
   and t3.data_date='${DATA_DATE}'
   and t3.bddw_end_date='9999-99-99'
  left join odata.sym_cif_client_document t4
    on t1.client_no = t4.client_no
   and t4.data_date = '${DATA_DATE}'
   and t4.bddw_end_date = '9999-99-99'
   and t4.pref_flag='Y' 
  left join odata.sym_cif_client_contact_tbl t5
    on t1.client_no = t5.client_no 
   and t5.pref_flag='Y'
   and t5.data_date='${DATA_DATE}'
   and t5.bddw_end_date='9999-99-99'
  left join odata.order_loan_order_house t7  --锡房贷
    on t1.cmisloan_no=t7.loan_id
   and t7.data_date='${DATA_DATE}'
   and t7.bddw_end_date='9999-99-99'
  -- left join smart.xfd_cif_industry t200         
  --     on t7.contract_no = t200.contract_no
   left join (select internal_key,sum(int_accrued) int_accrued,sum(int_adj) int_adj from odata.sllv_mb_acct_int_detail 
           where data_date = '${DATA_DATE}'
           and bddw_end_date='9999-99-99' 
           and int_class in ('INT','ODP')    
           group by internal_key) smaid
       on t1.internal_key = smaid.internal_key 
   left join (select internal_key,sum(outstanding) as outstanding from odata.sllv_mb_invoice 
           where amt_type in ('INT','ODP') and data_date = '${DATA_DATE}' and bddw_end_date='9999-99-99' 
           group by internal_key) smiot 
       on t1.internal_key = smiot.internal_key
  left join odata.sllv_mb_acct_balance t9
    on t1.internal_key = t9.internal_key
   and t9.amt_type ='DDA'
   and t9.data_date = '${DATA_DATE}'
   and t9.bddw_end_date = '9999-99-99'
  left join odata.sllv_mb_acct_balance a
    on t1.internal_key = a.internal_key
   and a.amt_type ='BAL'
   and a.data_date = '${DATA_DATE}'
   and a.bddw_end_date = '9999-99-99'
  left join odata.sllv_mb_acct_int_detail t11
    on t1.internal_key = t11.internal_key
   and t11.int_class = 'INT'
   and t11.data_date='${DATA_DATE}'
   and t11.bddw_end_date='9999-99-99'
    left join odata.sllv_mb_acct_int_detail t11_2
    on t1.internal_key = t11_2.internal_key
   and t11_2.int_class = 'ODP'
   and t11_2.data_date='${DATA_DATE}'
   and t11_2.bddw_end_date='9999-99-99'
  left join(select loan_id
                  ,prod_type
                  ,case when manual_five_class = '正常'  then  'FQ01'
                        when manual_five_class = '关注'  then  'FQ02'
                        when manual_five_class = '次级'  then  'FQ03'
                        when manual_five_class = '可疑'  then  'FQ04'
                        when manual_five_class = '损失'  then  'FQ05'
                    end as manual_five_class
              from odata.plm_loan_info_detail
             where data_date = '${DATA_DATE}'
               and bddw_end_date = '9999-99-99'
               and manual_term_validity_date >= '${DATA_DATE}')t12
    on t1.cmisloan_no = t12.loan_id
   and t1.prod_type = t12.prod_type
  left join odata.acct_loan_category t30
    on trim(t1.cmisloan_no) = trim(t30.loan_id)
   and t30.data_date = '${DATA_DATE}'
   and t30.bddw_end_date = '9999-99-99'
  left join(select a.loan_id
                  ,a.sub_product_type
                  ,a.status
                  ,a.xsbank_salesman
                  ,a.product_type
                  ,a.credit_order_id
              from odata.order_main_loan_order a
             where a.data_date = '${DATA_DATE}'
               and a.bddw_end_date = '9999-99-99') t14
    on t1.cmisloan_no = t14.loan_id
 --总期次
  left join(
            select internal_key,max( cast(stage_no as int) ) as stage_no_max
              from odata.sllv_mb_acct_schedule_detail
             where data_date='${DATA_DATE}' and bddw_end_date='9999-99-99'
             group by internal_key) t54 
    on t1.internal_key=t54.internal_key
  left join odata.sym_mb_prod_type t18
    on t1.prod_type=t18.prod_type
   and t18.data_date = '${DATA_DATE}'
   and t18.bddw_end_date = '9999-99-99'
  left join t19
    on t1.internal_key=t19.internal_key 
  left join t20
    on t1.internal_key=t20.internal_key
  left join odata.order_job_info t21
    on t1.cmisloan_no=t21.loan_id
   and t21.data_date='${DATA_DATE}'
   and t21.bddw_end_date='9999-99-99'
  left join odata.gl_v_gl_subject t22
    on t2.gl_code_a=t22.gl_code
   and t22.data_date='${DATA_DATE}'
   and t22.bddw_end_date='9999-99-99'
  left join odata.order_loan_order_house t25
    on t14.loan_id=t25.loan_id
   and t25.data_date='${DATA_DATE}' 
   and t25.bddw_end_date='9999-99-99'
  left join odata.sym_mb_prod_define t26
    on t1.prod_type = t26.prod_type 
   and t26.data_date='${DATA_DATE}'
   and t26.bddw_end_date='9999-99-99'
   and t26.assemble_id='GRACE_PERIOD'
  left join dwd.dwd_d_indv_credit_cont_p t27
    on t27.credit_cont_no=t14.credit_order_id
   and t27.data_date='${DATA_DATE}'
  left join odata.order_bank_account_info t28
    on trim(t1.cmisloan_no)=trim(t28.loan_id) 
   and t28.data_date='${DATA_DATE}' 
   and t28.bddw_end_date='9999-99-99' 
   --and t28.product_type=1 
   --and t28.sub_product_type=4
  left join odata.order_repay_account t29
    on trim(t1.cmisloan_no)=trim(t29.loan_id) 
   and t29.data_date='${DATA_DATE}' 
   and t29.bddw_end_date='9999-99-99' 
   and t29.withhold_order=1 
  left join gdata.dim_g_partner_mapping_p t50
   on t1.partner_id=t50.order_partner_id
  left join t6 
    on t1.internal_key=t6.internal_key
  left join t17 
    on t1.internal_key=t17.internal_key
  left join t16
    on t17.internal_key = t16.internal_key
   and t17.stage_no = t16.stage_no
   and t17.term_start_date = t16.term_start_date
  left join (
      select
            ce.internal_key
           ,sum(case when ce.amt_type ='PRI' then ce.outstanding when ce.amt_type in ('INT','ODP') then 0 end) as pri_outstanding  --逾期本金
           ,sum(case when ce.amt_type ='PRI' then 0 when ce.amt_type in ('INT','ODP') then ce.outstanding end) as int_outstanding  --逾期利息
           ,sum(case when ce.amt_type ='INT' then ce.outstanding else 0 end) as int_int_outstanding
      from odata.sllv_mb_invoice  ce
      where ce.data_date='${DATA_DATE}' 
        and ce.bddw_end_date='9999-99-99'
        and ce.outstanding >0
        and ce.due_date < regexp_replace('${DATA_DATE}','-','')
      group by ce.internal_key
  ) yq 
  on t1.internal_key = yq.internal_key 
  left join 
          (select
                od.internal_key
               ,sum(nvl(od.int_accrued,0)+nvl(od.int_adj,0)) as odp_outstanding  --逾期罚息
          from odata.sllv_mb_od_int_detail  od
          where od.data_date='${DATA_DATE}' 
            and od.bddw_end_date='9999-99-99'
            and od.int_class='ODP'
          group by od.internal_key)odp
  on t1.internal_key=odp.internal_key
  left join (
            select 
                  document_id
                  ,document_type
                  ,base_acct_no
                  ,bank_code
                  ,bank_name
                  ,row_number() over(partition by document_id order by tran_date desc) rn
            from odata.contract_um_agreement_comm
            where data_date = '${DATA_DATE}'
            and bddw_end_date = '9999-99-99'
            and agreement_status='A'
            ) t32 
       on t4.document_id=t32.document_id
       and t4.document_type=concat('1',t32.document_type)
       and t32.rn=1
 where t1.data_date='${DATA_DATE}'
   and t1.bddw_end_date='9999-99-99'
   and from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd') <= '${DATA_DATE}'
   and t1.prod_type='110108'