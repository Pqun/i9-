--2.yangqihao.dwd_d_indv_loan_bill_p
-------------------------------------------------------------------
--脚本名称:dwd_d_indv_loan_bill_p
--功能描述:个人贷款借据信息表
--作    者:于国睿
--开发日期:2021-09-24
--直属经理:方杰
--目标表  :dwd.dwd_d_indv_loan_bill_p 
--来源表：odata.sllv_mb_acct_schedule_detail    账户计划明细表
--来源表：odata.sllv_mb_invoice                 单据表
--来源表：odata.sllv_mb_acct                    账户基本信息表
--来源表：odata.sym_gl_prod_accounting          产品科目表
--来源表：odata.sym_cif_client                  客户信息表
--来源表：odata.sym_cif_client_document         客户证件信息表
--来源表：odata.sym_cif_client_contact_tbl      客户联系信息表
--来源表：odata.sllv_mb_acct_balance            账户余额表
--来源表：odata.sllv_mb_acct_int_detail         利息明细表
--来源表：odata.plm_loan_info_detail            贷款五级分类
--来源表：odata.ols_loan_cont_info              支用合同信息表
--来源表：odata.ols_crd_cont_info               授信合同信息表
--来源表：odata.ols_biz_corporate_info          企业信息表
--来源表：odata.ols_loan_prd_info               贷款产品信息表
--来源表：odata.sym_mb_prod_type                产品类型定义表
--来源表：odata.ols_admin_sm_user               系统用户表
--来源表：odata.gl_v_gl_subject                 科目名称表
--来源表：odata.sym_mb_prod_define              产品科目表
--来源表：dwd.dwd_d_indv_credit_cont_p          个人授信合同表
--来源表：gdata.dim_g_partner_mapping_p         合作方编码映射表
--来源表：odata.ols_crd_app_info_adjust         授信额度调整表
--来源表：odata.upp_t_txn_payment               代付交易流水信息表
--来源表：odata.acct_loan_log                   账务中心放款记录表
--修改历史:
--         1、于国睿     2021-09-24     新建
--         2. 华天顺     2022-01-26     贷款发放日期及时间修改
--         3、高源       2022-06-06     新增应收未收利息、应收利息科目、利息调整、利息调整科目、利息拖欠日期、
--                                      来源系统、贷款投向行业、结清标识等字段,结清日期逻辑调整
--         4、高源       2022-06-22     新增记账时间字段逻辑
--         5、高源       2022-07-07     新增计息基础、客户所属行业、贷款业务细类、贷款用途明细分类字段逻辑
--         6、高源       2022-08-10     借据起始日期、借据到期日、借据关闭日期逻辑调整，结清时间格式调整
--         7、高源       2022-10-09     新增机构号、贷款支用申请编号字段逻辑，贷款合同状态冲正部分逻辑调整
--         8、高源       2022-11-03     贷款合同状态冲正部分逻辑调整,还款方式、还款频率逻辑调整
--         9、高源       2022-11-09     网贷表新增合同状态限制条件，剔除贷款作废状态数据，新增小赢经营贷产品逻辑
--         10.华天顺      2022-12-02     新增核算状态字段
--         11.华天顺     2022-12-27     担保方式取数逻辑调整
--         12.华天顺     2023-01-03     逾期天数取数逻辑调整，新增逾期本金，利息和本金逾期日字段
--         13.华天顺     2023-02-03     五级分类取数逻辑调整
--         14.华天顺     2023-02-17     新增维信金科产品
--         15.杨琦浩     2023-03-14     新增到期日字段
--         16.杨琦浩     2023-03-28     cont_status取消合同状态条件，避免借据取不到5级分类
--         17.杨琦浩     2023-05-17     新增项目ID字段
--         18.杨琦浩     2023-05-22     新增微财数科产品
--         19.杨琦浩     2023-06-19     小赢易贷出资比例逻辑调整
--         20.杨琦浩     2023-08-30     新增放款、还款账号信息、表内、表外欠息字段，修改计息方式取数逻辑
--         21.杨琦浩     2023-10-12     调整信贷员工姓名，入账、还款账号信息取数逻辑，新增入账户名字段
--         22.杨琦浩     2023-10-25     表外欠息调整为非应计标志
--         23.姚威       2023-11-09     新增合作资金方放款金额
--         24.杨琦浩     2023-11-18     表内欠息调整为罚息利率
--         25.姚威       2024-04-11     引入拍拍联合融担模式消费贷
-------------------------------------------------------------------
with t16
as (
    select 
         a.internal_key
        ,a.stage_no              as stage_no                                                               --期次
        ,from_unixtime(unix_timestamp(min(a.start_date),'yyyyMMdd'),'yyyy-MM-dd')      as term_start_date  --期次开始日期
        ,from_unixtime(unix_timestamp(max(a.end_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_end_date    --期次到期日期
    from odata.sllv_mb_acct_schedule_detail a
    where data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
    group by 
         a.internal_key
        ,a.stage_no
        ,a.start_date
        ,a.end_date
    ),
t17 as 
(
    select 
         a.internal_key
        ,b.stage_no  --期次
        ,from_unixtime(unix_timestamp(max(c.start_date),'yyyyMMdd'),'yyyy-MM-dd')        as term_start_date    --期次开始期日
    from odata.sllv_mb_invoice a
   inner join (select a.internal_key
                     ,max(cast(a.stage_no as int)) as stage_no
                 from odata.sllv_mb_invoice a
                where a.data_date = '${DATA_DATE}'
                  and a.bddw_end_date = '9999-99-99'
                  and a.amt_type = 'INT'
                group by a.internal_key) b
     on a.internal_key=b.internal_key
    and a.stage_no=b.stage_no
   left join odata.sllv_mb_acct_schedule_detail c
     on c.data_date = '${DATA_DATE}'
    and c.bddw_end_date = '9999-99-99'
    and a.internal_key = c.internal_key
    and a.stage_no = c.stage_no
    and a.amt_type = c.amt_type
  where a.data_date = '${DATA_DATE}'
    and a.bddw_end_date = '9999-99-99'
    and a.amt_type <> 'ODP'
    group by a.internal_key
            ,b.stage_no
),
t6 as 
(    select  internal_key
           ,min(case when amt_type='PRI'then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_pri
           ,min(case when amt_type='INT'then from_unixtime(unix_timestamp(nvl(due_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_int
    from odata.sllv_mb_invoice
      where outstanding>0   
        and data_date='${DATA_DATE}' 
        and bddw_end_date='9999-99-99'
        and due_date < regexp_replace('${DATA_DATE}','-','')
    group by internal_key
),
t19 as 
(select internal_key
       ,min( from_unixtime(unix_timestamp(nvl(due_date,''),'yyyyMMdd'),'yyyy-MM-dd')) as due_date_pri
       ,sum(case when amt_type = 'PRI' then billed_amt else 0 end) as due_amount_pri
   from odata.sllv_mb_invoice
  where outstanding > 0
    and amt_type = 'PRI'
    and data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
  group by internal_key
),
t20 as 
(select internal_key
       ,min( from_unixtime(unix_timestamp(nvl(due_date,''),'yyyyMMdd'),'yyyy-MM-dd')) as due_date_int
       ,sum(case when amt_type = 'INT' then billed_amt else 0 end) as due_amount_int
   from odata.sllv_mb_invoice
  where outstanding > 0
    and amt_type = 'INT'
    and data_date = '${DATA_DATE}'
    and bddw_end_date = '9999-99-99'
  group by internal_key
)
insert overwrite table dwd.dwd_d_indv_loan_bill_p partition(data_date='${DATA_DATE}',prod_code)
--行内产品
select /*+ REPARTITION(1) */
       nvl(t1.cmisloan_no,'')              as bill_no  --借据号
      ,nvl(t18.prod_desc,'')               as prod_name  --产品名称
      ,nvl(t1.base_acct_no,'')             as acct_no  --账号
      ,nvl(t1.acct_seq_no,'')              as acct_seq_no  --账户序列号
      ,nvl(t15.loan_no,'')                 as biz_prod_code  --业务产品号
      ,''                                  as sub_biz_prod_code  --业务子产品号
      ,'01'                                as accting_cacl_mode --会计核算方式
      ,nvl(t2.gl_code_a,'')                as subj_no  --科目号
      ,nvl(t22.gl_code_name,'')            as subj_name  --科目名称
      ,nvl(t1.client_no,'')                as cust_id  --客户号
      ,nvl(t3.ch_client_name,'')           as cust_name  --客户姓名
      ,nvl(t4.document_type,'')            as cert_type  --证件类型
      ,nvl(t4.document_id,'')              as cert_no  --证件号
      ,nvl(t5.contact_tel,'')              as mobile  --客户手机号
      ,case when nvl(t9.total_amount,0) <= nvl(t27.credit_limit,0)
            then nvl(t27.credit_limit,0) 
            when nvl(t9.total_amount,0) > nvl(t27.credit_limit,0) 
            then nvl(t55.adjust_bf_amt,0)
        end                                as credit_limit  --授信额度
      ,nvl(t27.credit_terms,'')            as credit_term  --授信期限
      ,nvl(t27.credit_start_date,'')       as credit_start_date  --授信起始日期
      ,nvl(t27.credit_mature_date,'')      as credit_end_date  --授信到期日期
      ,nvl(t13.crd_cont_no,'')             as credit_cont_no  --授信合同编号
      ,nvl(t13.repay_type,'')              as repay_mode  --还款方式
      ,coalesce(from_unixtime(unix_timestamp(t7.txn_date,'yyyyMMdd'),'yyyy-MM-dd'),from_unixtime(unix_timestamp(t8.loan_end_date,'yyyyMMdd'),'yyyy-MM-dd'),'')  as loan_grant_date  --贷款发放日期
      ,coalesce(concat(substr(t7.txn_time,1,2),':',substr(t7.txn_time,3,2),':',substr(t7.txn_time,5,2)),substr(t8.loan_end_time,11,8),'')                  as loan_grant_time  --贷款发放时间
      ,nvl(t1.cmisloan_no,'')              as loan_cont_no  --贷款合同号
      ,''                                  as fin_supp_mode  --贷款财政扶持方式
      ,'C'                                 as loan_guar_mode  --贷款担保方式
      ,case when t2.gl_code_a = '10400101' then '2' 
            when t2.gl_code_a = '10400201' then '3'  
            else '' 
        end                                as loan_purp  --贷款用途
      ,'TR05'                              as pric_benc  --定价基准
      ,case when t1.acct_close_reason='发放冲正'  then '111'
            else  nvl(t13.cont_status,'')  end as loan_cont_status  --贷款合同状态
      ,from_unixtime(unix_timestamp(nvl(t1.acct_open_date,''),'yyyyMMdd'),'yyyy-MM-dd')  as loan_start_date  --借据起始日期
      ,from_unixtime(unix_timestamp(nvl(t1.ori_maturity_date,''),'yyyyMMdd'),'yyyy-MM-dd')  as loan_mature_date  --借据到期日期
      ,nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')    as loan_close_date  --借据关闭日期
      ,nvl(t9.total_amount,0)              as loan_amt  --放款金额
      ,nvl(t54.stage_no_max,0)             as total_loan_terms  --放款总期数
      ,nvl(t17.stage_no,0)                 as curr_term_no  --当前期次
      ,'RF01'                              as rate_type  --利率类型
      ,nvl(t11.real_rate,0)                as real_rate  --实际利率
      ,nvl(t50.partner_id,'')              as partner_id  --合作方编码
      ,nvl(t50.partner_name,'')            as partner_name  --合作方名称
      ,nvl(t13.channel_type,'')            as channel_type  --贷款办理渠道
      ,case when t1.prod_type ='110164' then  ''
            else '0'   end                 as consume_scen_flag  --消费场景标签
      --,case when t1.prod_type = '110112' then 0.1 --小赢10%
      --      else  1  end            as invest_ratio  --出资比例
      ,1                                   as invest_ratio  --出资比例
      ,nvl(t1.ccy,'')                      as ccy  --币种
      ,nvl(t26.attr_value,0)               as grace_days  --宽限天数
      ,case when nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')>'${DATA_DATE}'
            then ''
            else nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'') 
        end                                as clear_date  --结清日期
      ,case when t6.internal_key is not null
            then least(nvl(t6.due_date_pri,''),nvl(t6.due_date_int,''))
            else '' 
        end   as overdue_start_date  --逾期起始日
      ,case when t6.internal_key is not null
            then greatest(nvl(datediff('${DATA_DATE}',t6.due_date_pri),0),nvl(datediff('${DATA_DATE}',t6.due_date_int),0))
            else 0  
        end                                    as overdue_days --逾期天数
      ,''                                  as defer_mature_date  --贷款展期到期日期
      ,case when t6.due_date_pri is not null and t6.due_date_int is null 
            then '01'
            when t6.due_date_pri is null and t6.due_date_int is not null 
            then '02'
            when t6.due_date_pri is not null and t6.due_date_int is not null 
            then '03'
            else '' 
        end                                    as overdue_type  --逾期类型
      ,case when t12.loan_id is not null then t12.manual_five_class
            when t12.loan_id is null and t13.five_cate = '1' then 'FQ01'
            when t12.loan_id is null and t13.five_cate = '2' then 'FQ02'
            when t12.loan_id is null and t13.five_cate = '3' then 'FQ03'
            when t12.loan_id is null and t13.five_cate = '4' then 'FQ04'
            when t12.loan_id is null and t13.five_cate = '5' then 'FQ05'
            else ''
        end                               as five_risk_level  --贷款5级分类  
      ,coalesce(t13.loan_card_no,t13.loan_acc,'')     as receive_acct_no   --贷款入账账号 
      ,coalesce(t13.repay_card_no,t13.repay_acc,'')    as repay_acct_no  --还款账号
      ,nvl(t15.pay_way,'')                as payment_mode  --支付方式
      ,'02'                               as cash_tran_flag  --现转标志
      ,nvl(t21.lastname,'')               as credit_tlr_name  --信贷员姓名
      ,nvl(t13.biz_manager_id,'')         as credit_tlr_id  --信贷员员工号
      ,case t11.cycle_freq
            when 'M1' then 'B01'
            when 'M3' then 'B02'
            when 'M6' then 'B06'
            else 'B99'
        end                               as int_mode  --计息方式
      ,case  when  t13.repay_type  ='3'  then '05'
             when  t13.repay_type  ='4'  then '06' 
             else  case t11.cycle_freq
                   when 'M1' then '01'
                   when 'M3' then '02'
                   when 'M6' then '03'
                   else '07'  end 
             end                                   as repay_freq --还款频率
      ,''                                          as pay_seq_no  --支付流水号
      ,'1'                                         as loan_biz_class  --业务分类
      ,nvl(a.total_amount_prev,0)                  as bal        --贷款余额
      ,nvl(case when t1.accounting_status in ('ZHC','YUQ') then nvl(smaid.int_accrued,0) + nvl(smaid.int_adj,0) 
         + nvl(smiot.outstanding,0) else 0 end,0)    as receiv_int --应收未收利息
      ,nvl(t2.gl_code_int_rec,'')                    as recv_int_subj  --应收利息科目
      ,0                                             as int_adj  --利息调整
      ,''                                            as int_adj_subj  --利息调整科目
      ,nvl(t6.due_date_int,'')                       as overdue_date_int  --利息逾期日期
      ,'SYM'                                         as source_system  --来源系统  
      ,''                                            as loan_indst_type  --贷款投向行业
      ,case when nvl(from_unixtime(unix_timestamp(t1.acct_close_date,'yyyyMMdd'),'yyyy-MM-dd'),'')>'${DATA_DATE}' then '0'
            when t1.acct_close_date is not null then '1' 
            else  '0'   end                        as fully_settled -- 0未结清 1结清 
      ,from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd')   as accting_date  --记账日期
      ,case when t11.year_basis='360' and t11.month_basis='30' then  '1'
            when t11.year_basis='360' and t11.month_basis='ACT' then  '2'  
            else '7'  end                          as int_basis    --计息基础
      ,''                                          as cust_indust_type  --客户所属行业
      ,case when t1.prod_type ='110164'  and t24.corporate_type ='01' then 'A18'
            when t1.prod_type ='110164'  and t24.corporate_type ='02' then 'A17' 
            else  'A29'  end                       as loan_biz_detail  --贷款业务细类
      ,case when t13.loan_purpose ='100' then '资金周转'
            when t13.loan_purpose ='101' then '投资需求'
            when t13.loan_purpose ='102' then '扩大经营规模'
            when t13.loan_purpose ='103' then '店面装修改造'
            when t13.loan_purpose ='104' then '购房'
            when t13.loan_purpose ='105' then '购车（自用型）'
            when t13.loan_purpose ='106' then '购买车位'
            when t13.loan_purpose ='107' then '房屋装修'
            when t13.loan_purpose ='108' then '购买大额耐用消费品'
            when t13.loan_purpose ='109' then '旅游'
            when t13.loan_purpose ='110' then '出国留学'
            when t13.loan_purpose ='111' then '教育'
            when t13.loan_purpose ='112' then '婚嫁'
            when t13.loan_purpose ='113' then '医疗保健'
            when t13.loan_purpose ='114' then '购买大额人寿保险'
            when t13.loan_purpose ='115' then '资产置换'
            when t13.loan_purpose ='116' then '其他'
            when t13.loan_purpose ='117' then '土地储备'
            when t13.loan_purpose ='118' then '房地产开发'
            when t13.loan_purpose ='119' then '个人住房'
            when t13.loan_purpose ='120' then '商业用房'
            when t13.loan_purpose ='121' then '基本建设'
            when t13.loan_purpose ='122' then '技术改造'
            when t13.loan_purpose ='123' then '基础设施'
            when t13.loan_purpose ='124' then '个人日常消费'
            else '其他'  end                                                                      as loan_purp_detail  --贷款用途明细分类
      ,nvl(t1.branch   ,'')                                                                       as org_id            --机构号
      ,nvl(t13.app_no  ,'')                                                                       as loan_app_no       --贷款支用申请编号
      ,nvl(t1.accounting_status,'')                                                               as accting_status    --核算状态
      ,nvl(yq.pri_outstanding,0)                                                                  as overdue_prin              --逾期本金
      ,nvl(yq.int_outstanding,0)+nvl(odp.odp_outstanding,0)                                       as overdue_int               --逾期利息
      ,nvl(t6.due_date_pri,'')                                                                    as pri_overdue_date          --本金逾期日
      ,from_unixtime(unix_timestamp(nvl(t1.maturity_date,''),'yyyyMMdd'),'yyyy-MM-dd')            as mature_date  --到期日
      ,''                                                                                         as project_id --项目ID
      ,case when length(t13.loan_acc_bank)=12 then nvl(t13.loan_acc_bank,'')
            else ''
       end                                                                                        as receive_bank_code --贷款入账账号所属行号
      ,nvl(t13.loan_acc_bank_name,'')                                                             as receive_bank_name --贷款入账账号所属行名
      ,case when length(t13.repay_acc_bank)=12 then nvl(t13.repay_acc_bank,'')
            else ''
       end                                                                                        as repay_bank_code --还款账号所属行号
      ,nvl(t13.repay_acc_bank_name,'')                                                            as repay_bank_name --还款账号所属行名
      ,0                                                                                          as off_bal_int --表外欠息
      --,case when t1.accounting_status in ('ZHC','YUQ') then nvl(yq.int_int_outstanding,0)+nvl(odp.odp_outstanding,0)
      --      else 0 end                                                                            as in_bal_int --表内欠息
      --,0                                                                                          as in_bal_int --表内欠息
      ,nvl(t11_1.real_rate,0)                                                                     as pena_rate --罚息利率
      ,nvl(t13.cust_name,'')                                                                      as receive_acct_name --入账户名
      ,case when t1.accounting_status in ('FY','FYJ','WRN') then '1'
            else '0' end                                                                          as non_accru_flag --非应计标志
	  ,0                                                                                          as partner_loan_amt --新增合作资金方放款金额	
      ,t1.prod_type                                                                               as prod_code  --产品号
  from odata.sllv_mb_acct t1
  left join odata.sym_gl_prod_accounting t2 --通过科目号来取消费还是经营
    on t2.data_date='${DATA_DATE}'
   and t2.bddw_end_date='9999-99-99'
   and t1.prod_type = t2.prod_type
   and t2.accounting_status = 'ZHC'
   and t2.tran_category = 'ALL'
  left join odata.sym_cif_client t3
    on t1.client_no=t3.client_no
   and t3.data_date='${DATA_DATE}'
   and t3.bddw_end_date='9999-99-99'
  left join odata.sym_cif_client_document t4
    on t1.client_no = t4.client_no
   and t4.data_date = '${DATA_DATE}'
   and t4.bddw_end_date = '9999-99-99'
   and t4.pref_flag='Y' 
  left join odata.sym_cif_client_contact_tbl t5
    on t1.client_no = t5.client_no 
   and t5.pref_flag='Y'
   and t5.data_date='${DATA_DATE}'
   and t5.bddw_end_date='9999-99-99'
  left join odata.sllv_mb_acct_balance t9
    on t1.internal_key = t9.internal_key
   and t9.amt_type ='DDA'
   and t9.data_date = '${DATA_DATE}'
   and t9.bddw_end_date = '9999-99-99'
  left join odata.sllv_mb_acct_balance a
    on t1.internal_key = a.internal_key
   and a.amt_type ='BAL'
   and a.data_date = '${DATA_DATE}'
   and a.bddw_end_date = '9999-99-99'
  left join odata.sllv_mb_acct_int_detail t11
    on t1.internal_key = t11.internal_key
   and t11.int_class = 'INT'
   and t11.data_date='${DATA_DATE}'
   and t11.bddw_end_date='9999-99-99'
  left join odata.sllv_mb_acct_int_detail t11_1
    on t1.internal_key = t11_1.internal_key
   and t11_1.int_class = 'ODP'
   and t11_1.data_date='${DATA_DATE}'
   and t11_1.bddw_end_date='9999-99-99'
  left join(select  loan_id
                   ,prod_type
                   ,case when manual_five_class = '正常'  then  'FQ01'
                         when manual_five_class = '关注'  then  'FQ02'
                         when manual_five_class = '次级'  then  'FQ03'
                         when manual_five_class = '可疑'  then  'FQ04'
                         when manual_five_class = '损失'  then  'FQ05'
                     end   as manual_five_class
              from odata.plm_loan_info_detail
             where data_date = '${DATA_DATE}'
               and bddw_end_date = '9999-99-99'
               and manual_term_validity_date >= '${DATA_DATE}')t12
    on t1.cmisloan_no = t12.loan_id
   and t1.prod_type = t12.prod_type
  left join odata.ols_loan_cont_info t13   
    on t1.cmisloan_no = t13.bill_no
   and t13.bddw_end_date = '9999-99-99'
   and t13.data_date = '${DATA_DATE}'
   --and t13.cont_status in ('104','105','106','107','108','109','110','111') 
  left join odata.ols_loan_prd_info t15
    on t13.prd_code=t15.loan_no
   and t15.data_date = '${DATA_DATE}'
   and t15.bddw_end_date = '9999-99-99'
  left join t6 
    on t1.internal_key=t6.internal_key
  left join t17 
    on t1.internal_key=t17.internal_key
  left join t16
    on t17.internal_key = t16.internal_key
   and t17.stage_no = t16.stage_no
   and t17.term_start_date = t16.term_start_date
  left join odata.sym_mb_prod_type t18
    on t1.prod_type=t18.prod_type
   and t18.data_date = '${DATA_DATE}'
   and t18.bddw_end_date = '9999-99-99'
  left join t19
    on t1.internal_key=t19.internal_key 
  left join t20
    on t1.internal_key=t20.internal_key
  left join odata.oa_hrmresource t21 
    on t13.biz_manager_id = t21.workcode
   and t21.data_date='${DATA_DATE}' 
   and t21.bddw_end_date='9999-99-99' 
  left join odata.gl_v_gl_subject t22
    on t2.gl_code_a=t22.gl_code
   and t22.data_date='${DATA_DATE}'
   and t22.bddw_end_date='9999-99-99'
left join odata.ols_crd_cont_info t23
  on t23.crd_cont_no=t13.crd_cont_no
  and t23.data_date='${DATA_DATE}' 
  and t23.bddw_end_date='9999-99-99'
left join odata.ols_biz_corporate_info t24 
  on  t23.app_no = t24.app_no  
  and t24.data_date='${DATA_DATE}'
  and t24.bddw_end_date='9999-99-99'
  and t24.prd_code='10061001002'
  left join odata.sym_mb_prod_define t26
    on t1.prod_type = t26.prod_type 
   and t26.data_date='${DATA_DATE}'
   and t26.bddw_end_date='9999-99-99'
   and t26.assemble_id='GRACE_PERIOD'
  left join dwd.dwd_d_indv_credit_cont_p t27
    on t27.credit_cont_no=t13.crd_cont_no
   and t27.data_date='${DATA_DATE}'
  left join gdata.dim_g_partner_mapping_p t50
    on t1.partner_id=t50.ols_partner_id
 -- left join odata.acct_loan_log t52
 --   on t52.loan_id = t1.cmisloan_no
 --  and t52.data_date='${DATA_DATE}' 
 --  and t52.bddw_end_date='9999-99-99'
 -- left join odata.upp_t_txn_payment t53
 --   on t52.upp_tran_no = t53.tran_no
 --  and t53.data_date='${DATA_DATE}' 
 --  and t53.bddw_end_date='9999-99-99'
  left join(
            select internal_key,max( cast(stage_no as int) ) as stage_no_max
              from odata.sllv_mb_acct_schedule_detail
             where data_date='${DATA_DATE}' and bddw_end_date='9999-99-99'
             group by internal_key) t54 
    on t1.internal_key=t54.internal_key
  left join (select row_number() over(partition by crd_cont_no order by appr_pass_date desc) as rum,
                    crd_cont_no,
                    adjust_bf_amt
               from odata.ols_crd_app_info_adjust
              where data_date = '${DATA_DATE}'
                and bddw_end_date = '9999-99-99'
                and op_type = '02'
                and app_status = '003') t55
    on t13.crd_cont_no = t55.crd_cont_no
   and rum=1
  left join odata.upp_t_txn_payment t7
    on t13.app_no = t7.tran_no
 --and t7.check_status = '00'
   and t7.data_date = '${DATA_DATE}'
   and t7.bddw_end_date = '9999-99-99'
  left join odata.acct_loan_log t8
    on t1.cmisloan_no = t8.loan_id 
   and t8.data_date = '${DATA_DATE}'
   and t8.bddw_end_date = '9999-99-99'
   and t8.system_id='OLS' 
   and t8.loan_status = 6  --放款成功
   left join (select internal_key,sum(int_accrued) int_accrued,sum(int_adj) int_adj from odata.sllv_mb_acct_int_detail 
           where data_date = '${DATA_DATE}'
           and bddw_end_date='9999-99-99' 
           and int_class in ('INT','ODP')    
           group by internal_key) smaid
       on t1.internal_key = smaid.internal_key 
  left join (select internal_key,sum(outstanding) as outstanding from odata.sllv_mb_invoice 
           where amt_type in ('INT','ODP') and data_date = '${DATA_DATE}' and bddw_end_date='9999-99-99' 
           group by internal_key) smiot 
       on t1.internal_key = smiot.internal_key
  left join (
      select
        sum(case when ce.amt_type ='PRI' then ce.outstanding when ce.amt_type in ('INT','ODP') then 0 end) as pri_outstanding,  --逾期本金
        sum(case when ce.amt_type ='PRI' then 0 when ce.amt_type in ('INT','ODP') then ce.outstanding end) as int_outstanding,  --逾期利息
        sum(case when ce.amt_type ='INT' then ce.outstanding else 0 end) as int_int_outstanding,
        ce.internal_key
      from odata.sllv_mb_invoice ce    --非联合贷 小花  小赢  锡房 锡车 
      where ce.data_date='${DATA_DATE}' 
        and ce.bddw_end_date='9999-99-99'
        and ce.outstanding >0
        and ce.due_date < regexp_replace('${DATA_DATE}','-','')
      group by ce.internal_key
  ) yq 
  on t1.internal_key = yq.internal_key
  left join 
          (select
                od.internal_key
               ,sum(nvl(od.int_accrued,0)+nvl(od.int_adj,0)) as odp_outstanding  --逾期罚息
          from odata.sllv_mb_od_int_detail  od
          where od.data_date='${DATA_DATE}' 
            and od.bddw_end_date='9999-99-99'
            and od.int_class='ODP'
          group by od.internal_key)odp
  on t1.internal_key=odp.internal_key
 where t1.data_date='${DATA_DATE}'
   and t1.bddw_end_date='9999-99-99'
   and from_unixtime(unix_timestamp(t1.acct_open_date,'yyyyMMdd'),'yyyy-MM-dd') <= '${DATA_DATE}'
   and t1.prod_type in (    '110106'  --霖梓贷
                           ,'110109'  --还享借
                           ,'110111'  --小花钱包
                           ,'110112'  --小赢易贷
                           ,'110113'  --洋钱罐借款
                           ,'110117'  --人品贷
                           ,'110131'  --即有钱
                           ,'110133'  --你我贷
                           ,'110139'  --萨摩耶
                           ,'110141'  --万达标准助贷
                           ,'110149'  --数禾标准助贷
                           ,'110147'  --拍拍贷标准助贷
                           ,'110148'  --时光分期标准助贷
                           ,'110164'  --小赢经营贷
                           ,'110167'  --维信金科
                           ,'110177'  --微财数科
						   ,'110190'  --拍拍联合融担模式消费贷
                          )
 --and t1.cmisloan_no not in ('XEDCRDNO20201227105671702','XEDCRDNO20200619000176503')