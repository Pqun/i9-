--2.yangqihao.dwd_d_indv_loan_bill_p
-------------------------------------------------------------------
--脚本名称:dwd_d_indv_loan_bill_p
--功能描述:个人贷款借据信息表
--作    者:于国睿
--开发日期:2021-09-24
--直属经理:方杰
--目标表  :dwd.dwd_d_indv_loan_bill_p 
--来源表：odata.sym_cif_client_contact_tbl        客户联系信息表
--来源表：odata.plm_loan_info_detail              贷款五级分类
--来源表：odata.ols_loan_cont_info                支用合同信息表
--来源表：odata.ols_loan_prd_info                 贷款产品信息表
--来源表：odata.slur_bdvc_loan_file_clear         百度虚拟卡借据文件
--来源表：odata.ols_admin_sm_user                 系统用户表
--来源表：odata.slur_dzz_repayplan_file_clear     百度虚拟卡贷款还款计划表
--来源表：dwd.dwd_d_indv_credit_cont_p            个人授信合同表
--来源表：odata.slur_dzz_compensatory_detail      文件类代偿明细表      
--修改历史:
--         1、于国睿     2021-09-24     新建
--         2、高源       2022-06-07     新增应收未收利息、应收利息科目、利息调整、利息调整科目、利息拖欠日期、
--                                      来源系统、贷款投向行业、结清标识等字段,结清日期逻辑调整
--         3、高源       2022-06-22     新增记账时间字段逻辑    
--         4、高源       2022-07-07     新增计息基础、客户所属行业、贷款业务细类、贷款用途明细分类字段逻辑
--         5、高源       2022-07-12     新增贷款做废部分数据、修改借据关闭日期字段逻辑
--         6、高源       2022-08-10     借据起始日期、借据到期日、借据关闭日期逻辑调整，结清时间格式调整
--         7、高源       2022-10-09     新增机构号、贷款支用申请编号字段逻辑
--         8.华天顺      2022-12-02     新增核算状态字段
--         9.华天顺      2022-12-28     逾期天数取数逻辑调整，新增逾期本金，利息和本金逾期日字段
--         10.杨琦浩     2023-03-14     增加到期日字段，修改出资比例逻辑
--         11.杨琦浩     2023-05-17     新增项目ID字段
--         12.杨琦浩     2023-06-14     结清日期、结清标识字段逻辑调整
--         13.杨琦浩     2023-08-24     新增放款、还款账号信息字段
--         14.杨琦浩     2023-08-29     新增表内、表外欠息字段
--         15.杨琦浩     2023-10-12     新增入账户名字段
--         16.于国睿     2023-10-24     虚拟卡和债转停批，大于等于2023-09-21的日期写死
--         17.杨琦浩     2023-10-25     表外欠息调整为非应计标志
--         18.姚威       2023-11-09     新增合作资金方放款金额
--         19.杨琦浩     2023-11-18     表内欠息调整为罚息利率
-------------------------------------------------------------------
--百度虚拟卡
insert overwrite table dwd.dwd_d_indv_loan_bill_p partition(data_date='${DATA_DATE}',prod_code)
select 
       /*+ REPARTITION(1) */
       nvl(t1.loan_no,'')                  as bill_no  --借据号
      ,'百度虚拟卡贷款'                  as prod_name  --产品名称
      ,nvl(t1.loan_no,'')                as acct_no   --账号
      ,''                                as acct_seq_no  --账户序列号
      ,nvl(t2.prd_code,'')               as biz_prod_code  --业务产品号
      ,''                                as sub_biz_prod_code  --业务子产品号
      ,'01'                              as accting_cacl_mode --会计核算方式
      ,'10400101'                        as subj_no  --科目号
      ,'个人消费贷款-成本'               as subj_name  --科目名称
      ,nvl(t2.cust_id_core,'')           as cust_id  --客户号
      ,nvl(t2.cust_name,'')              as cust_name  --客户姓名
      ,nvl(t2.cert_type,'')              as cert_type  --证件类型
      ,nvl(t2.cert_code,'')              as cert_no  --证件号
      ,nvl(t3.contact_tel,'')            as mobile_no  --客户手机号
      ,nvl(t27.credit_limit,0)           as credit_limit  --授信额度
      ,nvl(t27.credit_terms,'')          as credit_term  --授信期限
      ,nvl(t27.credit_start_date,'')     as credit_start_date  --授信起始日期
      ,nvl(t27.credit_mature_date,'')    as credit_end_date  --授信到期日期
      ,nvl(t2.crd_cont_no,'')            as credit_cont_no  --授信合同编号
      ,nvl(t2.repay_type,'')             as repay_mode  --还款方式
      ,nvl(date_add(t2.loan_start_date,1),'')  as loan_grant_date  --贷款发放日期
      ,'00:00:00'                        as loan_grant_time  --贷款发放时间
      ,nvl(t1.loan_no,'')                as loan_cont_no  --贷款合同号
      ,''                                as fin_supp_mode  --贷款财政扶持方式
      ,'D'                               as loan_guar_mode  --贷款担保方式
      ,'2'                               as loan_purp_desc  --贷款用途说明
      ,'TR05'                            as pric_benc  --定价基准
      ,nvl(t2.cont_status,'')            as loan_cont_status  --贷款合同状态
      ,nvl(t2.loan_start_date,'')        as loan_start_date  --借据起始日期
      ,nvl(t2.loan_end_date,'')          as loan_mature_date  --借据到期日期
      ,nvl(t2.loan_clear_date ,'')       as loan_close_data  --借据关闭日期
      ,nvl(t1.loan_amt,0)                as loan_amt  --放款金额
      ,nvl(t1.loan_term,'')              as total_loan_terms  --放款总期数
      ,nvl(t1.loan_term_now,'')          as curr_term_no  --当前期次
      ,'RF01'                            as rate_type  --利率类型
      ,nvl(t2.exec_rate,0)               as real_rate  --实际利率
      ,'4'                               as partner_id  --合作方编码
      ,'百度'                            as partner_name  --合作方名称
      ,nvl(t2.channel_type,'')           as sub_channel_type  --渠道类型
      ,'0'                               as consume_scen_flag  --消费场景标签
      --,case when t2.loan_start_date>='2021-08-01' 
      --      then t2.invest_ratio
      --      else 1       
      --  end                              as invest_ratio  --出资比例
      ,nvl(t2.invest_ratio,0)            as invest_ratio  --出资比例
      ,'CNY'                               as ccy  --币种
      ,nvl(t1.grace_day,'')              as grace_days  --宽限天数
      ,nvl(case when t4.loan_no is not null then from_unixtime(unix_timestamp(t4.tran_date,'yyyyMMdd'),'yyyy-MM-dd') 
          when t2.loan_clear_date is not null and t2.loan_clear_date >= '${DATA_DATE}' then t2.loan_clear_date
          when t2.loan_clear_date is not null and t2.loan_clear_date <  '${DATA_DATE}' then date_add(t2.loan_clear_date,1)
          --when t2.loan_clear_date is null and t1.principal_bal = 0 and t5.loan_no is not null then from_unixtime(unix_timestamp(t5.tran_date,'yyyyMMdd'),'yyyy-MM-dd') 
          end,'')                        as clear_date   -- 结清时间
      ,case when t1.loan_status='106' then 0 
            else nvl(least(t10.due_date_pri1,t10.due_date_int1),'')
        end                              as overdue_start_date  --逾期起始日
      ,case when t1.loan_status='106' then 0 
            else nvl(greatest(t10.due_date_pri,t10.due_date_int),0)
        end                              as overdue_days --逾期天数
      ,''    as defer_mature_date  --贷款展期到期日期
      ,case when t1.loan_status='106' then ''
            when t10.due_date_pri1 is not null and t10.due_date_int1 is null 
            then '01'
            when t10.due_date_pri1 is null and t10.due_date_int1 is not null 
            then '02'
            when t10.due_date_pri1 is not null and t10.due_date_int1 is not null 
            then '03'
            else ''
        end                               as overdue_type  --逾期类型
      ,case when t8.loan_id is not null then t8.manual_five_class
            when t8.loan_id is null and t2.five_cate = '1' then 'FQ01'
            when t8.loan_id is null and t2.five_cate = '2' then 'FQ02'
            when t8.loan_id is null and t2.five_cate = '3' then 'FQ03'
            when t8.loan_id is null and t2.five_cate = '4' then 'FQ04'
            when t8.loan_id is null and t2.five_cate = '5' then 'FQ05'
        end                              as five_risk_level  --贷款5级分类
      --,nvl(t2.loan_acc,'')               as receive_acct_no   --贷款入账账号 
      ,coalesce(t2.loan_card_no,t2.loan_acc,'') as receive_acct_no   --贷款入账账号 
      --,nvl(t2.repay_acc,'')              as repay_acct_no  --还款账号
      ,coalesce(t2.repay_card_no,t2.repay_acc,'') as repay_acct_no  --还款账号
      ,nvl(t15.pay_way,'')               as payment_mode  --支付方式
      ,'02'                              as cash_tran_flag  --现转标志
      ,nvl(t7.user_name,'')              as credit_tlr_name  --信贷员姓名
      ,nvl(t2.biz_manager_id,'')         as credit_tlr_id  --信贷员员工号
      ,'B01'                             as int_mode  --计息方式
      ,'01'                              as repay_freq  --还款频率
      ,''                                as pay_seq_no  --支付流水号
      ,'1'                               as loan_biz_class  --业务分类
      ,case when t1.loan_no = 'XNK5488058807701553385' then 0
            when t1.loan_no in ('XNK5731743192315142336','XNK5746298149317766356') then 0
            when t4.loan_no is not null then 0
            when t2.cont_status='104' then 0
            else nvl(t1.principal_bal,0)
        end                                           as bal  --贷款余额
      ,nvl(case when t71.is_daichang then 0 
       when t71.overdue_days <= 90 then nvl(t71.debit_int,0)
       else 0 end,0)                                  as receiv_int    --应收利息
      ,'10600701'                                     as overdue_int_subj  --应收利息科目
      ,0                                              as int_adj --利息调整 
      ,''                                             as int_adj_subj  --利息调整科目
      ,case when t1.loan_status='106' then ''
            else nvl(t10.due_date_int1,'')
        end                                           as overdue_date_int  --利息拖欠日期
      ,'SYM'                                          as source_system  --来源系统
      ,''                                             as loan_indst_type  --贷款投向行业
      ,nvl(case when t4.loan_no is not null then '1'
           when t2.loan_clear_date is not null then '1'
           --when t2.loan_clear_date is null and t1.principal_bal = 0 and t5.loan_no is not null then '1' 
           else '0'
           end,'')                                   as fully_settled   -- 0未结清 1结清
      ,nvl(from_unixtime(unix_timestamp(t21.tran_date,'yyyyMMdd'),'yyyy-MM-dd'),'') as accting_date  --记账日期
      ,''                                            as int_basis    --计息基础
      ,''                                            as cust_indust_type  --客户所属行业
      ,'A29'                                         as loan_biz_detail  --贷款业务细类
      ,case when t2.loan_purpose ='100' then '资金周转'
            when t2.loan_purpose ='101' then '投资需求'
            when t2.loan_purpose ='102' then '扩大经营规模'
            when t2.loan_purpose ='103' then '店面装修改造'
            when t2.loan_purpose ='104' then '购房'
            when t2.loan_purpose ='105' then '购车（自用型）'
            when t2.loan_purpose ='106' then '购买车位'
            when t2.loan_purpose ='107' then '房屋装修'
            when t2.loan_purpose ='108' then '购买大额耐用消费品'
            when t2.loan_purpose ='109' then '旅游'
            when t2.loan_purpose ='110' then '出国留学'
            when t2.loan_purpose ='111' then '教育'
            when t2.loan_purpose ='112' then '婚嫁'
            when t2.loan_purpose ='113' then '医疗保健'
            when t2.loan_purpose ='114' then '购买大额人寿保险'
            when t2.loan_purpose ='115' then '资产置换'
            when t2.loan_purpose ='116' then '其他'
            when t2.loan_purpose ='117' then '土地储备'
            when t2.loan_purpose ='118' then '房地产开发'
            when t2.loan_purpose ='119' then '个人住房'
            when t2.loan_purpose ='120' then '商业用房'
            when t2.loan_purpose ='121' then '基本建设'
            when t2.loan_purpose ='122' then '技术改造'
            when t2.loan_purpose ='123' then '基础设施'
            when t2.loan_purpose ='124' then '个人日常消费'
            else  '其他'   end                       as loan_purp_detail  --贷款用途明细分类
      ,'100000'                                      as org_id            --机构号
      ,nvl(t2.app_no  ,'')                           as loan_app_no       --贷款支用申请编号
      ,''                                            as accting_status    --核算状态
      ,case when t1.loan_status='106' then 0
            else nvl(yq.pri_outstanding,0)   
        end                                       as overdue_prin              --逾期本金
      ,case when t1.loan_status='106' then 0
            else nvl(yq.int_outstanding,0)+nvl(yq.yqodp,0)   
        end                                       as overdue_int               --逾期利息
      ,case when t1.loan_status='106' then ''
            else nvl(t10.due_date_pri1,'')
        end                as pri_overdue_date          --本金逾期日
      ,''                                            as mature_date  --到期日
      ,''                                            as project_id --项目ID
      ,nvl(case when length(t2.loan_acc_bank)=12 then t2.loan_acc_bank else '' end,'')
                                                     as receive_bank_code --贷款入账账号所属行号
      ,nvl(t2.loan_acc_bank_name,'')                 as receive_bank_name --贷款入账账号所属行名
      ,nvl(case when length(t2.repay_acc_bank)=12 then t2.repay_acc_bank else '' end,'')
                                                     as repay_bank_code --还款账号所属行号
      ,nvl(t2.repay_acc_bank_name,'')                as repay_bank_name --还款账号所属行名
      ,0                                             as off_bal_int --表外欠息
      --,case when t12.overdue_days <= 90 
      --      then (nvl(t12.int_total,0)-nvl(t12.int_repay,0))+(nvl(t12.pnlt_int_total,0)-nvl(t12.pnlt_int_repay,0))-(nvl(t4.comps_int,0)+nvl(t4.comps_prin_pnlt,0))
      --      else 0 end                               as in_bal_int --表内欠息
      --,0                                             as in_bal_int --表内欠息
      ,nvl(t2.exec_rate*1.5,0)                       as pena_rate --罚息利率
      ,nvl(t2.cust_name,'')                          as receive_acct_name --入账户名
      ,case when t12.overdue_days > 90
            then '1'
            else '0' end                             as non_accru_flag --非应计标志
	  ,0                                             as partner_loan_amt  --合作资金方放款金额
      ,'110132'                                      as prod_code         --产品号
 from odata.slur_bdvc_loan_file_clear t1
inner join odata.ols_loan_cont_info t2
   on t1.loan_no = t2.bill_no
  and t2.data_date='${DATA_DATE}'
  and t2.bddw_end_date='9999-99-99'
  and t2.cont_status in ('104','105','106','107','108','109','110')
  left join( select loan_no,tran_date ,row_number() over (partition by loan_no order by biz_date asc) as row_num
   from odata.slur_bdvc_loan_file
   where data_date = case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批
   and bddw_end_date = '9999-99-99'
   and from_unixtime(unix_timestamp(biz_date,'yyyyMMdd'),'yyyy-MM-dd')<=date_add('${DATA_DATE}',-1) 
   and loan_status in ('105', '106', '107', '108', '109', '110','111')) t21
   on t1.loan_no=t21.loan_no 
   and t21.row_num=1
 left join odata.sym_cif_client_contact_tbl t3
   on t2.cust_id_core = t3.client_no 
  and t3.pref_flag='Y'
  and t3.data_date='${DATA_DATE}'
  and t3.bddw_end_date='9999-99-99'
 left join odata.slur_dzz_compensatory_detail t4
        on t1.loan_no = t4.loan_no
       and t4.data_date = '${DATA_DATE}'
       and t4.bddw_end_date = '9999-99-99'
       and t4.comps_status = 'S'
       and t4.sl_id = 'BDVC'
       and t4.prod_class = '01' 
  left join dwd.dwd_d_indv_credit_cont_p t27
    on t27.credit_cont_no=t2.crd_cont_no
   and t27.data_date='${DATA_DATE}'
  left join(select loan_id
                 ,prod_type
                 ,case when manual_five_class = '正常'  then  'FQ01'
                       when manual_five_class = '关注'  then  'FQ02'
                       when manual_five_class = '次级'  then  'FQ03'
                       when manual_five_class = '可疑'  then  'FQ04'
                       when manual_five_class = '损失'  then  'FQ05'
                       end as manual_five_class
           from odata.plm_loan_info_detail
          where data_date = '${DATA_DATE}'
            and bddw_end_date = '9999-99-99'
            and prod_type = '110132'
            and manual_term_validity_date >= '${DATA_DATE}')t8
       on t1.loan_no = t8.loan_id
  left join odata.ols_admin_sm_user t7  
    on t2.biz_manager_id = t7.login_code 
   and t7.data_date='${DATA_DATE}' 
   and t7.bddw_end_date='9999-99-99'
   left join(select *,row_number() over (partition by loan_no order by biz_date asc ) as row_num 
            from odata.slur_bdvc_loan_file
           where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批
             and bddw_end_date='9999-99-99'
             and principal_bal = 0) t5
       on t1.loan_no = t5.loan_no
       and t5.row_num=1
   left join (select *,tran_date < regexp_replace('${DATA_DATE}','-','') and loan_status = '107' as is_daichang from odata.slur_bdvc_loan_file_clear
            where data_date = case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批
              and bddw_end_date = '9999-99-99') t71
       on trim(t2.bill_no) = trim(t71.loan_no)
  left join (select t1.loan_no,min(t9.stmt_date) as stmt_date
               from odata.slur_bdvc_loan_file_clear t1
               left join odata.slur_bdvc_repayplan_file_clear t9
                 on t1.loan_no=t9.loan_no
                and t9.data_date='2021-11-23'
                and t9.bddw_end_date='9999-99-99'
                and t9.status='N'
              where t1.data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批
                and t1.bddw_end_date='9999-99-99'
              group by t1.loan_no) t9
    on t1.loan_no=t9.loan_no
  left join odata.ols_loan_prd_info t15
    on t2.prd_code=t15.loan_no
   and t15.data_date = '${DATA_DATE}'
   and t15.bddw_end_date = '9999-99-99'
  left join 
  (
  select 
     yq1.loan_no
     ,nvl(datediff('${DATA_DATE}',yq1.due_date_pri1),0) as due_date_pri
     ,nvl(datediff('${DATA_DATE}',yq1.due_date_int1),0) as due_date_int
     ,yq1.due_date_pri1
     ,yq1.due_date_int1
  from
  (      select  loan_no
              ,min(case when principal-principal_paid<>0 then from_unixtime(unix_timestamp(nvl(stmt_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_pri1  --逾期本金天数
              ,min(case when  interest-interest_paid<>0 then from_unixtime(unix_timestamp(nvl(stmt_date,''), 'yyyyMMdd'), 'yyyy-MM-dd') end) due_date_int1  --逾期利息天数
       from odata.slur_bdvc_repayplan_file_clear
            where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批
            and bddw_end_date='9999-99-99'
          and stmt_date < regexp_replace('${DATA_DATE}','-','')
          and status='N'
       group by loan_no)yq1
  )t10
  on trim(t2.bill_no) = trim(t10.loan_no)
  left join 
  (       select loan_no
                ,sum(case when principal-principal_paid<>0 and stmt_date<regexp_replace('${DATA_DATE}','-','') then principal-principal_paid end) as pri_outstanding --逾期本金
                ,sum(case when interest-interest_paid<>0 and stmt_date<regexp_replace('${DATA_DATE}','-','') then interest-interest_paid  end) as int_outstanding --逾期利息
                ,sum(case when penalty_due-penalty_paid<>0 and stmt_date<regexp_replace('${DATA_DATE}','-','') then penalty_due-penalty_paid  end) as yqodp --逾期罚息
                ,sum(case when principal-principal_paid<>0 and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(stmt_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))>=31 and  datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(stmt_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))<=60  then principal-principal_paid else 0 end ) outstanding_pri_3160
                ,sum(case when principal-principal_paid<>0 and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(stmt_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))>=61 and  datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(stmt_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))<=90  then principal-principal_paid else 0 end ) outstanding_pri_6190
                ,sum(case when principal-principal_paid<>0 and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(stmt_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))>=91 and  datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(stmt_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))<=180 then principal-principal_paid else 0 end ) outstanding_pri_91180
                ,sum(case when principal-principal_paid<>0 and datediff('${DATA_DATE}',from_unixtime(unix_timestamp(nvl(stmt_date,''), 'yyyyMMdd'), 'yyyy-MM-dd'))>180 then principal-principal_paid else 0 end ) outstanding_pri_180
          from odata.slur_bdvc_repayplan_file_clear
            where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批
            and bddw_end_date='9999-99-99'
            and stmt_date < regexp_replace('${DATA_DATE}','-','')     
            and status='N'          
          group by loan_no
  ) yq
  on trim(t2.bill_no) = trim(yq.loan_no)
  left join (
             select loan_no
                    ,overdue_days
                    ,sum(nvl(int_total,0)) as int_total
                    ,sum(nvl(int_repay,0)) as int_repay
                    ,sum(nvl(pnlt_int_total,0)) as pnlt_int_total
                    ,sum(nvl(pnlt_int_repay,0)) as pnlt_int_repay
             from odata.slur_bdvc_loan_file_clear
             where data_date=case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批
             and bddw_end_date='9999-99-99'
             and from_unixtime(unix_timestamp(channel_date,'yyyyMMdd'),'yyyy-MM-dd') = date_add('${DATA_DATE}',-1)
             group by loan_no,overdue_days
             ) t12
    on t1.loan_no=t12.loan_no
 where t1.data_date = case when '${DATA_DATE}' < '2023-09-21' then '${DATA_DATE}'
                                        else '2023-09-21'
                                    end  --update 20231024 yuguorui 虚拟卡停批
   and t1.bddw_end_date = '9999-99-99'