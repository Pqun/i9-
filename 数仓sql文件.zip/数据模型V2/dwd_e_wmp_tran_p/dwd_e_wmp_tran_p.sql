--2.yangqihao.dwd_e_wmp_tran_p
---------------------------------------------------------------------------------------------------------------
--脚本名称：理财流水表取数逻辑.sql
--功能描述：生成每日结果数据并插入hive dwd层dwd.dwd_e_wmp_tran_p
--作    者：杨琦浩
--开发日期：2022-09-13
--直属经理：方杰
--来源表  ：odata.lcps_tbtransreq 委托类请求流水表
--来源表  ：odata.lcps_tbhistransreq 委托类历史请求流水表
--来源表  ：odata.lcps_tbshare 持仓表
--来源表  ：odata.lcpb_tbproduct 产品信息表
--来源表  ：odata.lcpb_tbcycleset 产品周期计划表
--来源表  ：odata.lcpb_tbtainfo TA信息表
--目标表  ：dwd.dwd_e_wmp_tran_p
--修改历史：
--          1.杨琦浩   2022-09-13    新建
--          2.杨琦浩   2023-02-09    新增发行人名称、手续费字段
--			3.彭群 	   2023-11-21
--                      新增 销售渠道、交易时间、存款开户行号、存款开户行名、现转标志、客户类型 、
--                      风险等级、本方清算账号、对方账号/卡号、对方账户名称、对方行号、交易币种
--------------------------------------------------------------------------------------------------------------
insert overwrite table dwd.dwd_e_wmp_tran_p partition(data_date = '${DATA_DATE}')
-----------状态不属于确认成功、失败、撤单-----------
select /*+ REPARTITION(1) */
nvl(t.serial_no,'') as seq_no --流水号
,nvl(t.client_no,'') as cust_id --客户号
,'WMF' as source_systerm --来源系统
,nvl(t.branch_no,'') as org_id --机构号
,nvl(t.prd_code,'') as prod_code --代销理财产品号
,nvl(t.bank_acc,'') as acct_no --主账户号
,nvl(f.term,0) as term --期限
,'D' as term_type --期限类型
,nvl(a.tot_vol,0) as share_value --份额
,nvl(a.frozen_vol,0) as frozen_share_value --冻结份额
,nvl(from_unixtime(unix_timestamp(cast (d.min_phy_date as string), 'yyyyMMdd'),'yyyy-MM-dd'),'') as start_date --开始日期
,'' as matured_date --到期日期
,nvl(a.cost,0) as buy_cost --买入成本
,nvl(a.tot_income,0) as total_income --累计收益
,nvl(a.income,0) as curr_income --当前收益
,nvl(from_unixtime(unix_timestamp(cast (e.max_phy_date as string), 'yyyyMMdd'),'yyyy-MM-dd'),'') as last_tran_date --上次交易日期
,nvl(t.host_serial,'') as reference --交易参考号
,nvl(t.trans_code,'') as tran_code --交易编码
,nvl(t.status,'') as tran_status --交易状态
,nvl(t.ta_code,'') as ta_code --过户代理代码
,nvl(t.cfm_amt,0) as amt --金额
,nvl(g.ta_name,'') as issuer_name --发行人名称
,nvl(t.manage_charge,0) as fee --手续费
,nvl(from_unixtime(unix_timestamp(cast (t.trans_date as string), 'yyyyMMdd'),'yyyy-MM-dd'),'') as tran_date --交易日期
,nvl(k.serial_no_seq,'')  as cont_no --协议号    																		--updata20231116 pengqun 新增字段
,nvl(t.channel,'') as sale_channel_id --销售渠道 																	--updata20231116 pengqun 新增字段
,nvl(concat(substring(lpad(t.trans_time,6,'0'),1,2),':', 
 substring(lpad(t.trans_time,6,'0'),3,2),':',
 substring(lpad(t.trans_time,6,'0'),5,2)),'')  as tran_time --交易时间 											--updata20231116 pengqun 新增字段
,'323302000012' as acct_bank_code --存款开户行号 															--updata20231116 pengqun 新增字段
,'无锡锡商银行股份有限公司' as acct_bank_name --存款开户行名称 												--updata20231116 pengqun 新增字段
,02 as cash_tran_flag --现转标志 																			--updata20231116 pengqun 新增字段
,'05' as cust_type --客户类型 																				--updata20231116 pengqun 新增字段
,nvl(i.risk_level,'')  as rating_risk_lvl --风险等级 														--updata20231116 pengqun 新增字段
,nvl(t.bank_acc,'') as self_acct_no --本方清算账号 																	--updata20231116 pengqun 新增字段
,case 
	when t.trans_code = '100200'  then nvl(j.bank_acc_up,'')
	when t.trans_code = '100202'  then nvl(j.bank_acc_down,'')
	else ''
end as oppo_acct_no --对方账号/卡号 																		--updata20231116 pengqun 新增字段
,CASE 
	when t.trans_code = '100200' then nvl(j.bank_acc_up_name,'')
	when t.trans_code = '100202' then nvl(j.bank_acc_down_name,'')
	else ''
END as oppo_acct_name --对方账户名称 																		--updata20231116 pengqun 新增字段
,case 
	when t.trans_code = '100200' then nvl(j.open_bank_up,'')
	when t.trans_code = '100202' then nvl(j.open_bank_down,'')
	else ''
end as oppo_bank_code --对方行号 																			--updata20231116 pengqun 新增字段
,case 
	when t.trans_code = '100200' then nvl(j.open_bank_up_name,'')
	when t.trans_code = '100202' then nvl(j.open_bank_down_name,'')
	else ''
end as oppo_bank_name --对方行名 																			--updata20231116 pengqun 新增字段
,'CNY' as tran_ccy --交易币种 																				--updata20231116 pengqun 新增字段	
from odata.lcps_tbtransreq t --委托类请求流水表 															
left join 
(
select bank_acc
       ,prd_code
       ,sum(tot_vol) as tot_vol
       ,sum(frozen_vol) as frozen_vol
       ,sum(cost) as cost
       ,sum(tot_income) as tot_income
       ,sum(income) as income
from odata.lcps_tbshare --持仓表
where data_date='${DATA_DATE}'
and bddw_end_date='9999-99-99'
group by bank_acc,prd_code
) a 
on t.bank_acc=a.bank_acc
and t.prd_code=a.prd_code
left join odata.lcpb_tbproduct b --产品信息表
on a.prd_code = b.prd_code
and b.data_date='${DATA_DATE}'
and b.bddw_end_date='9999-99-99'
left join 
(
select bank_acc
       ,min(phy_date) as min_phy_date
       from 
       (
       select bank_acc
              ,phy_date
              from odata.lcps_tbtransreq
              where data_date='${DATA_DATE}'
              and bddw_end_date='9999-99-99'
       union all 
       select bank_acc
              ,phy_date
              from odata.lcps_tbhistransreq
              where data_date='${DATA_DATE}'
              and bddw_end_date='9999-99-99'
       )a group by bank_acc
) d 
on t.bank_acc=d.bank_acc
left join 
(
-----取只有一次交易的账号及交易日期-----
     select bank_acc
            ,max_phy_date
from 
    (
    select bank_acc
           ,'' as max_phy_date
           ,count(bank_acc) over(partition by bank_acc) as cn
           from 
           (select bank_acc
                   ,phy_date 
            from odata.lcps_tbtransreq
            where data_date='${DATA_DATE}'
            and bddw_end_date='9999-99-99'
           union all
            select bank_acc
                   ,phy_date 
            from odata.lcps_tbhistransreq
            where data_date='${DATA_DATE}'
            and bddw_end_date='9999-99-99'
           ) tt
    )a where a.cn=1 --只有一条交易记录
-----取多次交易的账号及上次交易日期-----
    union all 
   select bank_acc
         ,max_phy_date 
   from 
     (
     select bank_acc
           ,phy_date as max_phy_date
           ,count(bank_acc) over(partition by bank_acc) as cn
           ,row_number() over(partition by bank_acc order by phy_date desc) as rn
           from
           (select bank_acc
                   ,phy_date 
            from odata.lcps_tbtransreq
            where data_date='${DATA_DATE}'
            and bddw_end_date='9999-99-99'
           union all
            select bank_acc
                   ,phy_date 
            from odata.lcps_tbhistransreq
            where data_date='${DATA_DATE}'
            and bddw_end_date='9999-99-99'
           ) ttt
     ) b where b.cn>1 and b.rn=2 --大于一条记录并且物理日期倒序第二
) e 
on t.bank_acc=e.bank_acc
left join 
(
select 
a.prd_code
,nvl(datediff(a.cycle_date,b.cycle_date),'') as term
from 
(
select 
prd_code
,cycle_date
from (
      select 
      prd_code
      ,from_unixtime(unix_timestamp(cast (cycle_date as string), 'yyyyMMdd'),'yyyy-MM-dd') as cycle_date
      ,row_number() over (partition by prd_code order by cycle_date desc) rn
      from odata.lcpb_tbcycleset
      where data_date='${DATA_DATE}'
      and bddw_end_date='9999-99-99'
      ) a where rn=1 )a
left join 
(
select 
prd_code
,cycle_date
from (
      select 
      prd_code
      ,from_unixtime(unix_timestamp(cast (cycle_date as string), 'yyyyMMdd'),'yyyy-MM-dd') as cycle_date
      ,row_number() over (partition by prd_code order by cycle_date desc) rn
      from odata.lcpb_tbcycleset
      where data_date='${DATA_DATE}'
      and bddw_end_date='9999-99-99'
      ) a where rn=2 )b
on a.prd_code=b.prd_code      
) f 
on t.prd_code=f.prd_code
left join odata.lcpb_tbtainfo g
   on t.ta_code = g.ta_code
  and g.data_date = '${DATA_DATE}'
  and g.bddw_end_date = '9999-99-99'
left join 
(
select bank_acc
       ,prd_code
	   ,serial_no
       ,min(phy_date) over (partition by bank_acc,prd_code order by phy_date) --取最早的时间
       ,min(serial_no) over(partition by bank_acc,prd_code order by phy_date) serial_no_seq --最小的serial_no一般是购买时间最早的
        from ( select bank_acc
			          ,prd_code
					  ,serial_no
					  ,phy_date
			   from odata.lcps_tbhistransreq
			   where data_date='${DATA_DATE}'
			   and bddw_end_date='9999-99-99'
	           union all 
			   select bank_acc
			          ,prd_code
					  ,serial_no
					  ,phy_date
			   from odata.lcps_tbtransreq
			    where data_date='${DATA_DATE}'
			   and bddw_end_date='9999-99-99'
	 )
)k 																											--updata20231117 pengqun新增关联关系
on k.bank_acc = t.bank_acc
and k.prd_code = t.prd_code
and k.serial_no = t.serial_no 
left join odata.lcpb_tbclientriskinfo i																		--updata20231116 pengqun 新增关联关系
on t.client_no = i.client_no
and i.data_date='${DATA_DATE}'
and i.bddw_end_date='9999-99-99'
left join odata.lcpb_tbprdbankacc j																			--updata20231116 pengqun 新增关联关系
on t.prd_code = j.prd_code
and j.data_date='${DATA_DATE}'
and j.bddw_end_date='9999-99-99'
where t.data_date='${DATA_DATE}'
and t.bddw_end_date='9999-99-99'
-----------状态属于确认成功、失败、撤单-----------
union all
select /*+ REPARTITION(1) */
nvl(t.serial_no,'') as serial_no --流水号
,nvl(t.client_no,'') as cust_id --客户号
,'WMF' as source_systerm --来源系统
,nvl(t.branch_no,'') as org_id --机构号
,nvl(t.prd_code,'') as prod_code --代销理财产品号
,nvl(t.bank_acc,'') as acct_no --主账户号
,nvl(f.term,0) as term --期限
,'D' as term_type --期限类型
,nvl(a.tot_vol,0) as share_value --份额
,nvl(a.frozen_vol,0) as frozen_share_value --冻结份额
,nvl(from_unixtime(unix_timestamp(cast (d.min_phy_date as string), 'yyyyMMdd'),'yyyy-MM-dd'),'') as start_date --开始日期
,'' as matured_date --到期日期
,nvl(a.cost,0) as buy_cost --买入成本
,nvl(a.tot_income,0) as total_income --累计收益
,nvl(a.income,0) as curr_income --当前收益
,nvl(from_unixtime(unix_timestamp(cast (e.max_phy_date as string), 'yyyyMMdd'),'yyyy-MM-dd'),'') as last_tran_date --上次交易日期
,nvl(t.host_serial,'') as reference --交易参考号
,nvl(t.trans_code,'') as tran_code --交易编码
,nvl(t.status,'') as tran_status --交易状态
,nvl(t.ta_code,'') as ta_code --过户代理代码
,nvl(t.cfm_amt,0) as amt --金额
,nvl(g.ta_name,'') as issuer_name --发行人名称
,nvl(t.manage_charge,0) as fee --手续费
,nvl(from_unixtime(unix_timestamp(cast (t.trans_date as string), 'yyyyMMdd'),'yyyy-MM-dd'),'') as tran_date --交易日期
,nvl(k.serial_no,'')  as cont_no --协议号                                                                            		--updata20231116 pengqun 新增字段
,nvl(t.channel,'') as sale_channel_id --销售渠道																			--updata20231116 pengqun 新增字段
,nvl(concat(substring(lpad(t.trans_time,6,'0'),1,2),':',																--updata20231116 pengqun 新增字段
 substring(lpad(t.trans_time,6,'0'),3,2),':',
 substring(lpad(t.trans_time,6,'0'),5,2)),'')  as tran_time --交易时间													--updata20231116 pengqun 新增字段
,'323302000012' as acct_bank_code --存款开户行号																	--updata20231116 pengqun 新增字段
,'无锡锡商银行股份有限公司' as acct_bank_name --存款开户行名称														--updata20231116 pengqun 新增字段
,02 as cash_tran_flag --现转标志																					--updata20231116 pengqun 新增字段
,'05' as cust_type --客户类型																						--updata20231116 pengqun 新增字段
,nvl(i.risk_level,'')  as rating_risk_lvl --风险等级																--updata20231116 pengqun 新增字段
,nvl(t.bank_acc,'') as self_acct_no --本方清算账号																			--updata20231116 pengqun 新增字段
,case 
	when t.trans_code = '100200'  then nvl(j.bank_acc_up,'')
	when t.trans_code = '100202'  then nvl(j.bank_acc_down,'')
	else ''
end as oppo_acct_no --对方账号/卡号																					--updata20231116 pengqun 新增字段
,case 
	when t.trans_code = '100200' then nvl(j.bank_acc_up_name,'')
	when t.trans_code = '100202' then nvl(j.bank_acc_down_name,'')
	else ''
end as oppo_acct_name --对方账户名称																				--updata20231116 pengqun 新增字段
,case 
	when t.trans_code = '100200' then nvl(j.open_bank_up,'')
	when t.trans_code = '100202' then nvl(j.open_bank_down,'')
	else ''
end as oppo_bank_code --对方行号																					--updata20231116 pengqun 新增字段
,case 
	when t.trans_code = '100200' then nvl(j.open_bank_up_name,'')
	when t.trans_code = '100202' then nvl(j.open_bank_down_name,'')
	else ''
end as oppo_bank_name --对方行名																					--updata20231116 pengqun 新增字段
,'CNY' as tran_ccy --交易币种																						--updata20231116 pengqun 新增字段
from odata.lcps_tbhistransreq t
left join 
(
select bank_acc
       ,prd_code
       ,sum(tot_vol) as tot_vol
       ,sum(frozen_vol) as frozen_vol
       ,sum(cost) as cost
       ,sum(tot_income) as tot_income
       ,sum(income) as income
from odata.lcps_tbshare 
where data_date='${DATA_DATE}'
and bddw_end_date='9999-99-99'
group by bank_acc,prd_code
) a 
on t.bank_acc=a.bank_acc
and t.prd_code=a.prd_code
left join odata.lcpb_tbproduct b 
on a.prd_code = b.prd_code
and b.data_date='${DATA_DATE}'
and b.bddw_end_date='9999-99-99'
left join 
(
       select bank_acc
              ,min(phy_date) as min_phy_date
              from odata.lcps_tbhistransreq
              where data_date='${DATA_DATE}'
              and bddw_end_date='9999-99-99'
       group by bank_acc
) d 
on t.bank_acc=d.bank_acc
left join 
(
select bank_acc,max_phy_date
from 
    (
    select bank_acc
           ,'' as max_phy_date
           ,count(bank_acc) over(partition by bank_acc) as cn
           from odata.lcps_tbhistransreq
           where data_date='${DATA_DATE}'
           and bddw_end_date='9999-99-99'
    )a where a.cn=1 --只有一条交易记录
    union all 
select bank_acc,max_phy_date 
from 
     (
     select bank_acc
           ,phy_date as max_phy_date
           ,count(bank_acc) over(partition by bank_acc) as cn
           ,row_number() over(partition by bank_acc order by phy_date desc) as rn
           from odata.lcps_tbhistransreq
           where data_date='${DATA_DATE}'
           and bddw_end_date='9999-99-99'
     ) b where b.cn>1 and b.rn=2 --大于一条记录并且物理日期倒序第二
) e 
on t.bank_acc=e.bank_acc
left join 
(
select 
a.prd_code
,nvl(datediff(a.cycle_date,b.cycle_date),'') as term
from 
(
select 
prd_code
,cycle_date
from (
      select 
      prd_code
      ,from_unixtime(unix_timestamp(cast (cycle_date as string), 'yyyyMMdd'),'yyyy-MM-dd') as cycle_date
      ,row_number() over (partition by prd_code order by cycle_date desc) rn
      from odata.lcpb_tbcycleset
      where data_date='${DATA_DATE}'
      and bddw_end_date='9999-99-99'
      ) a where rn=1 )a
left join 
(
select 
prd_code
,cycle_date
from (
      select 
      prd_code
      ,from_unixtime(unix_timestamp(cast (cycle_date as string), 'yyyyMMdd'),'yyyy-MM-dd') as cycle_date
      ,row_number() over (partition by prd_code order by cycle_date desc) rn
      from odata.lcpb_tbcycleset
      where data_date='${DATA_DATE}'
      and bddw_end_date='9999-99-99'
      ) a where rn=2 )b
on a.prd_code=b.prd_code      
) f 
on t.prd_code=f.prd_code
left join odata.lcpb_tbtainfo g
   on t.ta_code = g.ta_code
  and g.data_date = '${DATA_DATE}'
  and g.bddw_end_date = '9999-99-99'
left join odata.lcpb_tbclientriskinfo i																						--updata20231116 pengqun 新增关联关系
on t.client_no = i.client_no
and i.data_date='${DATA_DATE}'
and i.bddw_end_date='9999-99-99'
left join odata.lcpb_tbprdbankacc j																				            --updata20231116 pengqun 新增关联关系
on t.prd_code = j.prd_code
and j.data_date='${DATA_DATE}'
and j.bddw_end_date='9999-99-99'
left join 
(
select bank_acc
       ,prd_code
	   ,serial_no
       ,min(phy_date) over (partition by bank_acc,prd_code order by phy_date) --取最早的时间
       ,min(serial_no) over(partition by bank_acc,prd_code order by phy_date) serial_no_seq --最小的serial_no一般是购买时间最早的
        from ( select bank_acc
			          ,prd_code
					  ,serial_no
					  ,phy_date
			   from odata.lcps_tbhistransreq
			   where data_date='${DATA_DATE}'
			   and bddw_end_date='9999-99-99'
	           union all 
			   select bank_acc
			          ,prd_code
					  ,serial_no
					  ,phy_date
			   from odata.lcps_tbtransreq
			    where data_date='${DATA_DATE}'
			   and bddw_end_date='9999-99-99'
	)
)k																															--updata20231117 pengqun新增关联关系
on k.bank_acc = t.bank_acc
and k.prd_code = t.prd_code
and k.serial_no = t.serial_no
where t.data_date='${DATA_DATE}'
and t.bddw_end_date='9999-99-99'